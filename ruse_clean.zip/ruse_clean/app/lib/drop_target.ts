// ---------------------------------------------------------------
// Where did the dragged 📍 / 💬 button land? (Phase C2)
// Pure logic only (no React), so it is easy to test.
// ---------------------------------------------------------------
export type block_box = { top: number; height: number };

// Index of the block under `y` (all numbers in the same space, e.g. scroll content).
// Dropping in the small gap between two blocks picks the nearest one; far from every block = null.
export function block_at(y: number, boxes: (block_box | undefined)[], max_gap = 28): number | null {
  let best: number | null = null;
  let best_dist = Infinity;
  boxes.forEach((b, i) => {
    if (!b) return;
    const dist = y < b.top ? b.top - y : y > b.top + b.height ? y - (b.top + b.height) : 0;
    if (dist < best_dist) { best = i; best_dist = dist; }
  });
  return best !== null && best_dist <= max_gap ? best : null;
}

export type side = 'left' | 'right';

// A drag that ends close to the OPPOSITE screen edge moves the buttons there.
export function flip_side(current: side, end_x: number, screen_width: number, zone = 56): side | null {
  if (current === 'right' && end_x < zone) return 'left';
  if (current === 'left' && end_x > screen_width - zone) return 'right';
  return null;
}

// A touch that moved less than this is a tap, not a drag.
export const DRAG_MIN = 12;
export const is_drag = (dx: number, dy: number): boolean => Math.hypot(dx, dy) >= DRAG_MIN;

// Saved side (anything unknown = right).
export const clean_side = (v: unknown): side => (v === 'left' ? 'left' : 'right');
