import { W } from './words';
import { THEME_FONTS } from './upload_check';
import { BUTTON_PRESSES, BUTTON_SHAPES, BUTTON_STYLES } from './button_look';
import type { Theme } from './types';
// ---------------------------------------------------------------
// Empty starter files the user can download, fill in, and upload.
// Keys that start with "_" are hints only — strip_hints() removes them
// before the file is sent, so they never reach the backend.
// ---------------------------------------------------------------


// ---- Shared sound hint (luxury named set) ----
// The app ships six soft recorded-style voices. Prefer these names over
// inventing a sound code. Older short names still work and map to the set.
const SOUND_HINT =
  `effects.sound — pick ONE string (bundled soft ticks, not harsh beeps):
   Soft:     glass | harp | silk | water | piano | swell | none
   Crisp:    tick | click | chime | coin
   Paper:    page | leaf | wood | hush
   Playful:  pop | bubble | sparkle | bell
   Moody:    ink | ember | frost | pulse
   Extra:    fanfare
   Example:  "sound": "silk"
   Advanced: a sound code object is allowed but most authors should only use a name.`

// One file = one whole novel + its chapters.
export const NOVEL_TEMPLATE = {
  _read_me:
    'READ ME FIRST — ' + W.novel + ' upload.\n' +
    '1) novel.title — required, max 80 characters.\n' +
    '2) novel.summary — optional, max 300 characters.\n' +
    '3) novel.kind — "novel" | "manga" | "webtoon" (default novel).\n' +
    '4) novel.category — optional list of folder names, e.g. ["Romance","Slow burn"], max 4 levels.\n' +
    '5) chapters — 1 to 100. Each needs title + (blocks OR pages).\n' +
    '6) Text chapters: blocks = p | h | list | code | callout (tip|warn|ok) | table. Plain text only, no HTML.\n' +
    '7) Manga chapters: use "pages": ["https://…", …] (1–300 image links) instead of blocks. You can also upload pages from the app.\n' +
    '8) Optional per chapter: summary, minutes (1–240), style.font / style.accent / style.highlight.\n' +
    '9) No quiz field. Old quiz keys are ignored.\n' +
    '10) Keys starting with _ are hints and are stripped on upload.\n' +
    'Then: Settings → Choose file (Authors and Admins).',
  novel: {
    title: `My ${W.novel}`,
    summary: `One sentence about the ${W.novel}.`,
    kind: 'novel',
    category: ['Example category'],
  },
  chapters: [
    {
      title: 'First chapter',
      summary: 'What this chapter covers.',
      minutes: 5,
      style: { font: 'Lora', accent: '#0e9fb5', highlight: { soft: '#e0457b' } },
      blocks: [
        { type: 'p', text: 'Paragraph text. Plain text only, no HTML.' },
        { type: 'list', items: ['First point', 'Second point'] },
      ],
    },
    {
      title: 'Second chapter',
      minutes: 4,
      blocks: [
        { type: 'p', text: 'Next chapter text.' },
        { type: 'callout', kind: 'tip', text: 'A friendly tip. kind can be tip, warn or ok.' },
      ],
    },
  ],
};


const BUTTON_HELP =
  'button (all keys optional): style = ' + BUTTON_STYLES.join(' | ') + '. shape = ' + BUTTON_SHAPES.join(' | ') + '. press = ' + BUTTON_PRESSES.join(' | ') + '. ' +
  'depth = 0 to 8 (thickness of the chunky edge, raised style only). shine = true | false (glossy sweep when pressed). uppercase = true | false. ' +
  'colors = { bg, fg, edge } as #rrggbb; leave colors out to use the theme\'s primary and accent.';

// One theme per file.
export const THEME_TEMPLATE = {
  _read_me:
    'READ ME FIRST — theme upload (Authors and Admins).\n' +
    '1) name — required, max 40 characters. Becomes the theme id (slug).\n' +
    '2) font (body) and heading_font (titles/buttons): ' + THEME_FONTS.join(' | ') + '.\n' +
    '3) radius — 4 to 32 (card roundness).\n' +
    '4) colors — all nine keys as #rrggbb: bg, surface, ink, muted, line, primary, primaryFg, accent, accentFg.\n' +
    '5) effect — optional shortcut when you skip effects: none | ripple | confetti | sparkle | pop | hearts | petals | bubbles.\n' +
    '6) effects.tap — up to 6 recipes, max 40 pieces total per tap. effects.background — up to 4 recipes, max 30 pieces.\n' +
    '   Shapes: glyph (needs "glyph": 1–4 characters) | dot | ring | rect.\n' +
    '   Shared fields: colors (1–6 hex), size [min,max] 4–60, count, and optional spread/rise/spin/duration/grow/opacity.\n' +
    '7) effects.sound — ' + SOUND_HINT + '\n' +
    '8) effects.haptic — true | false (phone vibration on tap).\n' +
    '9) button — optional. How buttons look and feel (see _button_help). Leave it out for the lively default.\n' +
    '10) forSubject — optional ' + W.novel + ' id. Makes this theme exclusive to that ' + W.novel + ' (recommended look; hidden from Settings picker). Download “Theme for this novel” from Your ' + W.novels + ' to pre-fill.\n' +
    '11) Built-in theme names cannot be reused. Keys starting with _ are hints and are stripped on upload.\n' +
    'Then: Settings → Choose file.',
  name: 'My theme',
  font: 'Quicksand',
  heading_font: 'Figtree',
  radius: 18,
  // forSubject: 'paste-novel-id-here',
  button: {
    style: 'raised',
    shape: 'pill',
    press: 'wiggle',
    depth: 4,
    shine: true,
    uppercase: false,
    colors: { bg: '#ff6fa5', fg: '#ffffff', edge: '#c2457a' },
  },
  colors: {
    bg: '#fff1f6',
    surface: '#fffafc',
    ink: '#3b2340',
    muted: '#8a6f8e',
    line: '#f3d3e2',
    primary: '#8e3a8c',
    primaryFg: '#fff7fc',
    accent: '#ff6fa5',
    accentFg: '#ffffff',
  },
  effects: {
    haptic: true,
    // Pick any named sound (see _sound_names). Example moods: silk, tick, page, sparkle, ink
    sound: 'silk',
    tap: [
      {
        shape: 'glyph',
        glyph: '✦',
        colors: ['#ff6fa5', '#ffd1e8'],
        count: 6,
        size: [14, 22],
        spread: 110,
        rise: 90,
        spin: 120,
        duration: 900,
        grow: true,
      },
      {
        shape: 'dot',
        colors: ['#ffffff'],
        count: 8,
        size: [5, 9],
        spread: 60,
        rise: 0,
        spin: 0,
        duration: 500,
      },
    ],
    background: [
      {
        shape: 'glyph',
        glyph: '✿',
        colors: ['#f7aef8'],
        count: 8,
        size: [12, 18],
        duration: 24000,
        opacity: 0.35,
      },
    ],
  },
  _button_help: BUTTON_HELP,
  _sound_names:
    'Pick effects.sound as one name. Soft: glass harp silk water piano swell none. Crisp: tick click chime coin. Paper: page leaf wood hush. Playful: pop bubble sparkle bell. Moody: ink ember frost pulse. Extra: fanfare. All are soft bundled ticks — design the visual effect freely.' +
    ' You design the visual tick (tap/background recipes) freely; the sound is usually just one of these names.',
};

/** E4: theme template already filled with forSubject = this novel's id. */
export function theme_template_for_novel(subject_id: string, novel_title?: string) {
  const sid = (subject_id || '').trim();
  const title = (novel_title || '').trim();
  return {
    ...THEME_TEMPLATE,
    _read_me:
      `READ ME FIRST — theme for this ${W.novel} only.\n` +
      `This file is for ${title ? `“${title}” ` : ''}(id: ${sid}). ` +
      `It stays on that ${W.novel} and does not appear in Settings → theme picker. ` +
      `Readers see: “The author recommends … Try it?”\n` +
      `Change name, colours, tap recipes, and effects.sound (any named sound — silk, tick, page, sparkle, ink, …). ` +
      `Then Settings → Choose file.`,
    name: title ? `${title} look` : 'Novel theme',
    forSubject: sid,
  };
}


// ---------------------------------------------------------------
// B4 (new): every template is made by the app, so it always matches the rules the upload check enforces.
// The files in marginalia_templates/ are only a fallback. Each builder returns a plain object; the
// share helper turns it into a .json file. Keys that start with "_" are notes and are stripped on upload.
// ---------------------------------------------------------------

const RULES_NOTE =
  'Rules: plain text only (no HTML). Colours are #rrggbb. Page links start with https:// and open the image itself. ' +
  'Keys that start with _ are notes and are removed on upload.';

// A whole novel: novel block + two example chapters of text.
export function novel_template() {
  return {
    ...NOVEL_TEMPLATE,
    _rules: RULES_NOTE,
  };
}

// A whole comic or webtoon: the same shape, but each chapter is a list of page images.
export function comic_template() {
  return {
    _read_me:
      'READ ME FIRST — comic upload.\n' +
      '1) novel.title — required, max 80 characters. novel.summary — optional, max 300.\n' +
      '2) novel.kind — "webtoon" (vertical scroll) or "manga" (page by page).\n' +
      '3) novel.category — optional list of folder names, max 4 levels.\n' +
      '4) chapters — 1 to 100. Each needs a title and "pages": 1 to 300 https links to images, in reading order.\n' +
      '5) Each link must open the image itself. Easiest: skip links and use "Add manga chapter from photos" in Your ' + W.novels + '.\n' +
      '6) Optional per chapter: summary (max 400), minutes (1 to 240).\n' +
      RULES_NOTE + '\n' +
      'Then: Settings → Choose file.',
    novel: {
      title: 'My comic',
      summary: 'One sentence about the comic.',
      kind: 'webtoon',
      category: ['Example category'],
    },
    chapters: [
      {
        title: 'Episode 1',
        summary: 'What happens in this episode.',
        minutes: 3,
        pages: [
          'https://example.com/comic/ep1-01.jpg',
          'https://example.com/comic/ep1-02.jpg',
          'https://example.com/comic/ep1-03.jpg',
        ],
      },
      {
        title: 'Episode 2',
        minutes: 3,
        pages: [
          'https://example.com/comic/ep2-01.jpg',
          'https://example.com/comic/ep2-02.jpg',
        ],
      },
    ],
  };
}

// A theme file filled with the colours, fonts, radius and effects of a theme the person is looking at.
// Only fonts the app has installed are written; anything else falls back to Figtree.
const installed_font = (f: string | undefined, fallback: string): string =>
  f && (THEME_FONTS as readonly string[]).includes(f) ? f : fallback;

export function theme_template_from(theme: Theme) {
  const font = installed_font(theme.font, 'Figtree');
  const out: Record<string, any> = {
    _read_me:
      `READ ME FIRST — theme file made from “${theme.name}”.\n` +
      'Change the name (built-in names cannot be reused), colours, fonts, radius and effects, then Settings → Choose file.\n' +
      'Fonts: ' + THEME_FONTS.join(' | ') + '. Radius: 4 to 32. Colours: all nine keys as #rrggbb.\n' +
      'Effects: up to 6 tap recipes (max 40 pieces) and 4 background recipes (max 30 pieces). Shapes: glyph | dot | ring | rect.\n' +
      RULES_NOTE,
    name: `${theme.name} copy`.slice(0, 40),
    font,
    heading_font: installed_font(theme.heading_font, font),
    radius: Number.isInteger(theme.radius) ? theme.radius : 16,
    colors: { ...theme.colors },
  };
  if (theme.button) out.button = JSON.parse(JSON.stringify(theme.button));
  if (theme.effects) out.effects = JSON.parse(JSON.stringify(theme.effects));
  else out.effect = theme.effect || 'none';
  return out;
}

// An empty theme to design from scratch. Neutral colours that already pass the upload check.
export function blank_theme_template() {
  return {
    _read_me:
      'BLANK THEME. Fill every colour as #rrggbb, pick a font from the list, set the radius (4 to 32), then Settings → Choose file.\n' +
      'Fonts: ' + THEME_FONTS.join(' | ') + '.\n' +
      'effect: none | ripple | confetti | sparkle | pop | hearts | petals | bubbles. Or replace it with an "effects" design (see the theme template made from a theme).\n' +
      RULES_NOTE,
    name: 'My theme',
    font: 'Inter',
    heading_font: 'Newsreader',
    radius: 16,
    effect: 'none',
    button: { style: 'raised', shape: 'round', press: 'bounce', depth: 4, shine: true },
    colors: {
      bg: '#faf8f5', surface: '#ffffff', ink: '#1b1a17', muted: '#6b675f', line: '#e8e3db',
      primary: '#3d3a8f', primaryFg: '#ffffff', accent: '#3d3a8f', accentFg: '#ffffff',
    },
  };
}

// The instructions an author can hand to any AI chat together with a template file.
// Built from the same lists the upload check uses, so it can never name a font the app does not have.
export function ai_prompt_text(): string {
  return [
    'PROMPT FOR AI — Marginalia novel, comic and theme files',
    '',
    'Paste everything below into an AI chat and attach the template file you want (novel, comic or theme).',
    'Then ask for what you want, for example: "Write chapter 1 of a story about a lighthouse keeper. Use the attached novel template."',
    '',
    '-----------------------------------------------------------------------',
    '',
    'You will produce ONE JSON file for the Marginalia reading app. Output ONLY the JSON, with no explanation and no code fences.',
    '',
    'RULES',
    '1. Top level: an object with "novel" and "chapters".',
    '   "novel": { "title" (required, max 80), "summary" (optional, max 300), "kind": "novel" | "manga" | "webtoon", "category" (optional list, max 4 levels) }',
    '   "chapters": 1 to 100 chapters.',
    '2. Each chapter needs "title" (max 120) and either "blocks" (text) or "pages" (images). Optional: "summary" (max 400), "minutes" (1 to 240).',
    '3. TEXT chapters ("blocks"): 1 to 100 items, each one of:',
    '   { "type": "p", "text": "..." }                               a paragraph',
    '   { "type": "h", "text": "..." }                               a heading',
    '   { "type": "list", "items": ["...", "..."] }                  a bulleted list',
    '   { "type": "callout", "kind": "tip" | "warn" | "ok", "text": "..." }',
    '   { "type": "code", "text": "..." }                            a code block',
    '   { "type": "table", "headers": ["..."], "rows": [["..."]] }',
    '   Plain text only. No HTML and no markdown symbols such as ** or #.',
    '4. COMIC chapters ("pages"): 1 to 300 https links to images, in reading order. Each link must open the image itself.',
    '   Use kind "webtoon" for vertical scroll, or "manga" for page by page.',
    '5. Optional per chapter: "style": { "font", "accent", "highlight" }',
    '   font: one of the fonts below. accent: #rrggbb. highlight: { "word": "#rrggbb" }.',
    '6. Keys that start with "_" are notes and are removed on upload.',
    '7. Do not add keys that are not listed here. Do not use a "quiz" field.',
    '',
    'FONTS (use these exact names): ' + THEME_FONTS.join(', ') + '.',
    '',
    'THEME FILES (only if asked for a look). One JSON object:',
    '  "name" (max 40), "font", "heading_font" (from the fonts above), "radius" (4 to 32),',
    '  "colors": all nine keys as #rrggbb: bg, surface, ink, muted, line, primary, primaryFg, accent, accentFg.',
    '  "effect": none | ripple | confetti | sparkle | pop | hearts | petals | bubbles   (or an "effects" design)',
    '  "button" (optional): { "style": ' + BUTTON_STYLES.join(' | ') + ', "shape": ' + BUTTON_SHAPES.join(' | ') + ', "press": ' + BUTTON_PRESSES.join(' | ') + ',',
    '                       "depth": 0 to 8, "shine": true | false, "uppercase": true | false, "colors": { "bg", "fg", "edge" as #rrggbb } }',
    '  Make ink and bg easy to read on each other (strong contrast).',
    '',
    'CHECKLIST BEFORE YOU REPLY',
    '- Valid JSON: quotes, commas and brackets all match.',
    '- Every chapter has a title and either blocks or pages.',
    '- Every colour is #rrggbb with six hex digits.',
    '- Every page link starts with https://.',
    '',
  ].join('\n');
}
