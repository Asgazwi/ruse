import React, { createContext, useCallback, useContext, useEffect, useRef, useState } from 'react';
import { api } from './backend';
import { ACTION_GET_ADMIN_DATA, ACTION_GET_COURSE_DATA, ACTION_SAVE_PROGRESS } from './actions';
import { useAuth } from './auth';
import { useTheme } from './theme';
import { is_network_error } from './net_retry';
import { clear_saved, load_saved, save_saved } from './store';
import { normalize_admin_data, normalize_course_data, usable_saved, type saved_course_data } from './data_helpers';
import { merge_progress, same_progress, with_completed } from './progress_helpers';
import { reset_progress_payload } from './course_admin_helpers';
import type { AdminData, Chapter, CourseData, Progress } from './types';
import { W } from './words';
import { is_admin } from './roles';

// ---------------------------------------------------------------
// ONE shared store for courses, chapters, themes and progress.
// Home and Settings both read it, so they can never disagree.
//  - starts from what is saved on the phone (instant)
//  - refreshes from the backend in the background
//  - saves again after every good load
// ---------------------------------------------------------------
type DataCtx = {
  data: CourseData | null;     // null = nothing saved and nothing loaded yet
  syncing: boolean;            // a background refresh is running
  offline: boolean;            // last refresh could not reach the server
  error: string | null;        // the server answered, but said no
  last_synced: number | null;  // when the data on screen was last fresh from the server
  refresh: (opts?: { max_age_ms?: number }) => Promise<void>; // never throws
  admin: AdminData | null;     // admin only: access requests + people (null for everyone else)
  refresh_admin: () => Promise<string | null>; // admin only; returns an error text or null
  complete_chapter: (chapter: Chapter) => Promise<'saved' | 'queued'>; // never throws; 'queued' = will send when online
  progress_pending: boolean;   // finished chapters are waiting to be sent to the server
  reset_progress: () => Promise<'saved' | 'failed'>; // clears my ticks everywhere; needs the network
};
const Ctx = createContext<DataCtx>(null as unknown as DataCtx);
export const useData = () => useContext(Ctx);

const SAVED_COURSES = 'course_data';
const SAVED_PENDING = 'pending_progress';
type pending_progress = { email: string; progress: Progress };
const load_pending = (email: string | undefined): pending_progress | null => {
  const p = load_saved<pending_progress>(SAVED_PENDING);
  return p && email && String(p.email).toLowerCase() === email.toLowerCase() && p.progress ? p : null;
};

export function DataProvider({ children }: { children: React.ReactNode }) {
  const { status, me, reload, from_saved } = useAuth();
  const { setThemes, theme } = useTheme();
  const email = status === 'in' && me?.allowed ? me.email : undefined;

  const [data, setData] = useState<CourseData | null>(null);
  const [syncing, setSyncing] = useState(false);
  const [offline, setOffline] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [last_synced, setLastSynced] = useState<number | null>(null);

  const [admin, setAdmin] = useState<AdminData | null>(null);
  const [progress_pending, setProgressPending] = useState(false);

  // Latest values for the refresh function, so it does not change on every render.
  const is_owner = status === 'in' && is_admin(me); // admins load the people list (owner is always admin)
  const live = useRef({ email, from_saved, reload, setThemes, is_owner, data, theme_id: theme.id });
  live.current = { email, from_saved, reload, setThemes, is_owner, data, theme_id: theme.id };
  const synced_at = useRef<number | null>(null);
  const saved_stamp = useRef<number | null>(null); // when the saved copy was last fresh from the server (kept across offline edits)
  const inflight = useRef<Promise<void> | null>(null);
  const rerun = useRef(false);

  // 1) Saved copy first, so Home is not empty while the network wakes up.
  useEffect(() => {
    synced_at.current = null;
    saved_stamp.current = null;
    setLastSynced(null);
    setOffline(false);
    setError(null);
    setAdmin(null);
    setProgressPending(!!load_pending(email));
    if (!email) { setData(null); return; }
    const saved = usable_saved(load_saved<saved_course_data>(SAVED_COURSES), email);
    if (saved) {
      const wait = load_pending(email);
      setData(wait ? { ...saved.data, progress: merge_progress(saved.data.progress, wait.progress) } : saved.data);
      setThemes(saved.data.themes);
      saved_stamp.current = saved.saved_at;
      setLastSynced(saved.saved_at);
    } else {
      setData(null);
    }
  }, [email, setThemes]);

  // Admin only: who is waiting for approval and who has access.
  const refresh_admin = useCallback(async (): Promise<string | null> => {
    if (!live.current.is_owner) return null;
    try {
      setAdmin(normalize_admin_data(await api(ACTION_GET_ADMIN_DATA)));
      return null;
    } catch (e: any) {
      return e?.message || 'Could not load the people list.';
    }
  }, []);

  // Send finished chapters to the server. Safe to repeat (it sends the whole progress each time).
  const send_pending = useCallback(async (who: string): Promise<boolean> => {
    const wait = load_pending(who);
    if (!wait) { setProgressPending(false); return true; }
    try {
      await api(ACTION_SAVE_PROGRESS, wait.progress);
    } catch {
      return false; // still waiting; tried again at the next refresh
    }
    // Only forget it if nothing newer was queued while we were sending.
    if (same_progress(load_pending(who)?.progress ?? null, wait.progress)) {
      clear_saved(SAVED_PENDING);
      if (live.current.email === who) setProgressPending(false);
    }
    return true;
  }, []);

  const complete_chapter = useCallback(async (chapter: Chapter): Promise<'saved' | 'queued'> => {
    const who = live.current.email;
    const current = live.current.data;
    if (!who || !current) return 'queued';
    const next = with_completed(current.progress, chapter, live.current.theme_id);
    const updated: CourseData = { ...current, progress: next };
    setData(updated);                       // the tick shows right away
    live.current.data = updated;
    save_saved(SAVED_COURSES, { email: who, saved_at: saved_stamp.current ?? Date.now(), data: updated } as saved_course_data);
    save_saved(SAVED_PENDING, { email: who, progress: next } as pending_progress);
    setProgressPending(true);
    return (await send_pending(who)) ? 'saved' : 'queued';
  }, [send_pending]);

  // Reset my progress. The server is asked first: only when it says yes are the phone copies cleared.
  // A queued (unsent) progress is dropped too, so the merge can never bring old ticks back.
  const reset_progress = useCallback(async (): Promise<'saved' | 'failed'> => {
    const who = live.current.email;
    const current = live.current.data;
    if (!who || !current) return 'failed';
    const empty = reset_progress_payload(live.current.theme_id);
    try {
      await api(ACTION_SAVE_PROGRESS, empty);
    } catch {
      return 'failed';
    }
    clear_saved(SAVED_PENDING);
    setProgressPending(false);
    const cleared: CourseData = { ...current, progress: empty };
    setData(cleared);
    live.current.data = cleared;
    save_saved(SAVED_COURSES, { email: who, saved_at: saved_stamp.current ?? Date.now(), data: cleared } as saved_course_data);
    return 'saved';
  }, []);

  // 2) One pass: ask the server, show it, save it.
  const run_once = useCallback(async () => {
    const who = live.current.email;
    if (!who) return;
    setSyncing(true);
    try {
      // On the saved profile? Check with the server first; if it is still unreachable, stay offline.
      if (live.current.from_saved && !(await live.current.reload())) {
        setOffline(true);
        return;
      }
      let fresh = normalize_course_data(await api<CourseData>(ACTION_GET_COURSE_DATA));
      if (live.current.email !== who) return; // a different person signed in meanwhile
      // Chapters finished while offline are kept: merge them in, then send them.
      const wait = load_pending(who);
      if (wait) fresh = { ...fresh, progress: merge_progress(fresh.progress, wait.progress) };
      const now = Date.now();
      setData(fresh);
      live.current.setThemes(fresh.themes);
      setOffline(false);
      setError(null);
      synced_at.current = now;
      saved_stamp.current = now;
      setLastSynced(now);
      save_saved(SAVED_COURSES, { email: who, saved_at: now, data: fresh } as saved_course_data);
      if (wait) send_pending(who); // quiet; tried again next time if it fails
      refresh_admin(); // quiet; only does something for admins (feeds the request dot)
    } catch (e: any) {
      if (live.current.email !== who) return;
      if (is_network_error(e)) setOffline(true);
      else setError(e?.message || `Could not load your ${W.novels}.`);
    } finally {
      setSyncing(false);
    }
  }, [refresh_admin, send_pending]);

  // 3) Public refresh. Calls made while one is running are folded into one extra pass,
  //    so a refresh right after an upload always sees the upload.
  const refresh = useCallback(async (opts?: { max_age_ms?: number }) => {
    const age = synced_at.current ? Date.now() - synced_at.current : Infinity;
    if (opts?.max_age_ms !== undefined && age < opts.max_age_ms) return;
    if (inflight.current) {
      if (opts?.max_age_ms === undefined) rerun.current = true;
      return inflight.current;
    }
    inflight.current = (async () => {
      try {
        do {
          rerun.current = false;
          await run_once();
        } while (rerun.current);
      } finally {
        inflight.current = null;
      }
    })();
    return inflight.current;
  }, [run_once]);

  return <Ctx.Provider value={{ data, syncing, offline, error, last_synced, refresh, admin, refresh_admin, complete_chapter, progress_pending, reset_progress }}>{children}</Ctx.Provider>;
}
