// One friendly word for how far along a course is. Shown as a small chip on course cards.
export function progress_label(done: number, total: number): string {
  if (total <= 0) return 'Coming soon';
  if (done <= 0) return 'Not started';
  if (done >= total) return 'Complete ✓';
  return 'In progress';
}
