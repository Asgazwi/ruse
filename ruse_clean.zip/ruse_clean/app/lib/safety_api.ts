// Server calls for safety (Phase D4). Owner builds these in Code.gs:
//   getBlocked()                         -> string[]   usernames I blocked (read)
//   blockUser(username) / unblockUser(username)
//   reportUser({ username, reason })     -> { ok: true }  (rate-limited on the server)
//   getReports()                         -> Report[]   (admin only, read)
//   resolveReport(id)                    -> { ok: true }  (admin only)
//   setMessaging({ username, allowed })  -> { ok: true }  (admin only)
import { api } from './backend';
import {
  ACTION_BLOCK_USER, ACTION_UNBLOCK_USER, ACTION_GET_BLOCKED, ACTION_REPORT_USER,
  ACTION_GET_REPORTS, ACTION_RESOLVE_REPORT, ACTION_SET_MESSAGING,
} from './actions';
import type { Report, ReportReason } from './safety';

export const fetch_blocked = () => api<string[]>(ACTION_GET_BLOCKED);
export const block_user = (username: string) => api<{ ok: boolean }>(ACTION_BLOCK_USER, username);
export const unblock_user = (username: string) => api<{ ok: boolean }>(ACTION_UNBLOCK_USER, username);
export const report_user = (username: string, reason: ReportReason) => api<{ ok: boolean }>(ACTION_REPORT_USER, { username, reason });
export const fetch_reports = () => api<Report[]>(ACTION_GET_REPORTS);
export const resolve_report = (id: string) => api<{ ok: boolean }>(ACTION_RESOLVE_REPORT, id);
export const set_messaging = (username: string, allowed: boolean) => api<{ ok: boolean }>(ACTION_SET_MESSAGING, { username, allowed });
