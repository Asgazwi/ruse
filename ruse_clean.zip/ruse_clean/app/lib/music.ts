// Pure helpers for the background music (Phase F2). No React, no audio, so they can be tested alone.
// Sources: the author's track for that novel ("author"), or nothing ("off").
// Local music from the phone needs a picker package (new build), so it is not an option yet.

export type MusicSource = 'author' | 'off';
export type MusicPrefs = { volume: number; muted: boolean };
export const DEFAULT_PREFS: MusicPrefs = { volume: 0.4, muted: false };
export const VOLUME_STEP = 0.1;
export const STOP_DELAY_MS = 1500; // a quick hop to the next chapter must not stop the music

export const clamp_volume = (v: unknown): number => {
  const n = typeof v === 'number' && Number.isFinite(v) ? v : DEFAULT_PREFS.volume;
  return Math.round(Math.min(1, Math.max(0, n)) * 10) / 10;
};

// The author's track link, only if it is https. Anything else is ignored.
export function music_url(subject: { musicUrl?: unknown } | null | undefined): string | null {
  const u = typeof subject?.musicUrl === 'string' ? subject.musicUrl.trim() : '';
  return /^https:\/\/\S+$/.test(u) ? u : null;
}

// The choice for one novel: the author's track if there is one, otherwise off. A saved "off" wins.
export function source_for(subject_id: string, saved: Record<string, MusicSource> | null | undefined, has_author: boolean): MusicSource {
  if (saved?.[subject_id] === 'off') return 'off';
  return has_author ? 'author' : 'off';
}

// The file that plays for a choice (null = nothing plays).
export const track_for = (source: MusicSource, author_url: string | null): string | null =>
  source === 'author' ? author_url : null;

export const volume_up = (v: number): number => clamp_volume(v + VOLUME_STEP);
export const volume_down = (v: number): number => clamp_volume(v - VOLUME_STEP);

// F3 mixing: while a tap sound is on, the music drops to a fraction of its volume.
export const DUCK_FACTOR = 0.35;
export const DUCK_MS = 1200;          // a tap sound is short; the music comes back soon after
export const ducked_volume = (v: number, ducked: boolean): number =>
  Math.max(0, Math.min(1, ducked ? v * DUCK_FACTOR : v));

// Music plays only when there is a track, the choice is not off, and it is not muted.
export const should_play = (source: MusicSource, url: string | null, muted: boolean): boolean =>
  source === 'author' && !!url && !muted;
