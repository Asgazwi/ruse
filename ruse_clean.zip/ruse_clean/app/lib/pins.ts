import { useEffect, useSyncExternalStore } from 'react';
import { api } from './backend';
import { useAuth } from './auth';
import { is_network_error } from './net_retry';
import { load_saved, save_saved } from './store';
import { create_pin_store } from './pin_store';

// One shared store for the whole app (no provider needed), so the reader, the course screen,
// Home and the comments list never disagree.
export const pin_store = create_pin_store({
  call: (action, ...args) => api(action, ...args),
  load: (key) => load_saved<any>(key),
  save: (key, value) => save_saved(key, value),
  is_network_error,
  now: () => Date.now(),
  rand: Math.random,
});

export function usePins() {
  const { status, me } = useAuth();
  const email = status === 'in' && me?.allowed ? me.email : null;
  const st = useSyncExternalStore(pin_store.subscribe, pin_store.get);

  useEffect(() => {
    pin_store.init(email ?? null);
    if (email) void pin_store.sync({ max_age_ms: 15000 });
  }, [email]);

  return {
    pins: st.view.pins,
    comments: st.view.comments,
    waiting: st.queue.length,       // changes saved on the phone, not sent yet
    failed: st.failed,              // changes the server refused (kept, so they can be retried)
    offline: st.offline,
    error: st.error,
    sync: pin_store.sync,
    retry_failed: pin_store.retry_failed,
    discard_failed: pin_store.discard_failed,
    set_pin: pin_store.set_pin,
    remove_pin: pin_store.remove_pin,
    add_comment: pin_store.add_comment,
    edit_comment: pin_store.edit_comment,
    delete_comment: pin_store.delete_comment,
    reply: pin_store.reply,
    add_block_after: pin_store.add_block_after,
  };
}
