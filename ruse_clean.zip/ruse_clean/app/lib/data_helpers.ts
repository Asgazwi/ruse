import type { AdminData, AdminPerson, CourseData } from './types';

// Pure helpers for lib/data.tsx (no React, no Expo, easy to test).

export type saved_course_data = { email: string; saved_at: number; data: CourseData };

// The backend might leave a list out; the app always works with real lists.
export function normalize_course_data(d: Partial<CourseData> | null | undefined): CourseData {
  return {
    subjects: Array.isArray(d?.subjects) ? d!.subjects : [],
    chapters: Array.isArray(d?.chapters) ? d!.chapters : [],
    themes: Array.isArray(d?.themes) ? d!.themes : [],
    progress: d?.progress ?? null,
  };
}

// Saved courses are only used for the same Google account that saved them.
export function usable_saved(saved: saved_course_data | null, email: string | undefined): saved_course_data | null {
  if (!saved || !email || !saved.data) return null;
  if (String(saved.email).toLowerCase() !== email.toLowerCase()) return null;
  return { ...saved, data: normalize_course_data(saved.data) };
}

export function time_ago(then: number | null, now: number = Date.now()): string {
  if (!then) return '';
  const minutes = Math.floor((now - then) / 60000);
  if (minutes < 1) return 'just now';
  if (minutes < 60) return `${minutes} min ago`;
  const hours = Math.floor(minutes / 60);
  if (hours < 24) return `${hours} h ago`;
  const days = Math.floor(hours / 24);
  return `${days} day${days === 1 ? '' : 's'} ago`;
}

// The exact shape of getAdminData was never seen (Code.gs not uploaded), so accept the likely variants.
// Role is preferred; fall back to the old admin boolean (true → admin, false → author so existing
// people keep upload rights until an admin sets them explicitly to reader).
function person_role(p: any): 'reader' | 'author' | 'admin' {
  const r = typeof p?.role === 'string' ? p.role.trim().toLowerCase() : '';
  if (r === 'admin' || r === 'author' || r === 'reader') return r;
  if (p?.admin === true || p?.isAdmin === true || p?.isOwner === true) return 'admin';
  return 'author';
}

function pending_role_of(p: any): 'author' | null {
  // R3: role-upgrade requests. Accept a few backend shapes.
  const pr = p?.pendingRole ?? p?.requestedRole ?? p?.wantsRole ?? p?.roleRequest;
  if (typeof pr === 'string' && pr.trim().toLowerCase() === 'author') return 'author';
  if (p?.kind === 'role' || p?.requestKind === 'role' || p?.type === 'role') return 'author';
  return null;
}

function normalize_person(p: any): AdminPerson | null {
  if (typeof p === 'string') {
    return p.includes('@') ? { email: p.trim().toLowerCase(), name: '', role: 'author', admin: false } : null;
  }
  const email = typeof p?.email === 'string' ? p.email.trim().toLowerCase() : '';
  if (!email) return null;
  const name = typeof p.name === 'string' && p.name.trim() ? p.name.trim() : typeof p.requestName === 'string' ? p.requestName.trim() : '';
  const role = person_role(p);
  const pendingRole = pending_role_of(p);
  return { email, name, role, admin: role === 'admin', pendingRole };
}

export function normalize_admin_data(d: any): AdminData {
  const list = (x: any): AdminPerson[] => (Array.isArray(x) ? x.map(normalize_person).filter((p): p is AdminPerson => !!p) : []);
  // Access requests + role-upgrade requests (R3) in one list. Backend may send roleRequests separately.
  const access = list(d?.requests);
  const role_ups = list(d?.roleRequests ?? d?.role_requests).map((p) => ({ ...p, pendingRole: p.pendingRole || ('author' as const) }));
  const seen = new Set(access.map((p) => p.email));
  const merged = access.concat(role_ups.filter((p) => !seen.has(p.email)));
  return { requests: merged, users: list(d?.users) };
}
