// Plays theme tap sounds. Every named preset has a bundled soft WAV in sound_previews/.
// Custom sound codes still synthesize as a fallback. Never throws into the UI.
import { File, Paths } from 'expo-file-system';
import { createAudioPlayer, setAudioModeAsync, type AudioPlayer } from 'expo-audio';
import { Asset } from 'expo-asset';
import { resolve_sound, wav_bytes, type sound_code } from './sound_code';
import { duck_music } from './music_player';

const players = new Map<string, AudioPlayer>();
let mode_ready = false;

// Static requires so Metro packs every tick.
const BUNDLED: Record<string, number> = {
  glass: require('../sound_previews/glass.wav'),
  harp: require('../sound_previews/harp.wav'),
  silk: require('../sound_previews/silk.wav'),
  water: require('../sound_previews/water.wav'),
  piano: require('../sound_previews/piano.wav'),
  swell: require('../sound_previews/swell.wav'),
  tick: require('../sound_previews/tick.wav'),
  click: require('../sound_previews/click.wav'),
  chime: require('../sound_previews/chime.wav'),
  coin: require('../sound_previews/coin.wav'),
  page: require('../sound_previews/page.wav'),
  leaf: require('../sound_previews/leaf.wav'),
  wood: require('../sound_previews/wood.wav'),
  hush: require('../sound_previews/hush.wav'),
  pop: require('../sound_previews/pop.wav'),
  bubble: require('../sound_previews/bubble.wav'),
  sparkle: require('../sound_previews/sparkle.wav'),
  bell: require('../sound_previews/bell.wav'),
  ink: require('../sound_previews/ink.wav'),
  ember: require('../sound_previews/ember.wav'),
  frost: require('../sound_previews/frost.wav'),
  pulse: require('../sound_previews/pulse.wav'),
  fanfare: require('../sound_previews/fanfare.wav'),
};

function key_of(code: sound_code): string {
  const text = JSON.stringify(code);
  let h = 5381;
  for (let i = 0; i < text.length; i++) h = ((h * 33) ^ text.charCodeAt(i)) >>> 0;
  return h.toString(16);
}

async function ensure_mode() {
  if (mode_ready) return;
  mode_ready = true;
  await setAudioModeAsync({ playsInSilentMode: true }).catch(() => {});
}

export async function play_sound(spec: any): Promise<void> {
  try {
    if (spec === undefined || spec === null || spec === 'none') return;
    await ensure_mode();

    if (typeof spec === 'string') {
      const name = spec.trim().toLowerCase();
      if (!name || name === 'none') return;
      const mod = BUNDLED[name];
      if (mod != null) {
        let player = players.get('wav:' + name);
        if (!player) {
          const asset = Asset.fromModule(mod);
          await asset.downloadAsync();
          const uri = asset.localUri || asset.uri;
          if (!uri) return;
          player = createAudioPlayer({ uri });
          players.set('wav:' + name, player);
        }
        void player.seekTo(0);
        player.play();
        duck_music();
        return;
      }
    }

    const code = resolve_sound(spec);
    if (!code) return;
    const key = 'synth:' + key_of(code);
    let player = players.get(key);
    if (!player) {
      const file = new File(Paths.cache, `ruse_sound_${key_of(code)}.wav`);
      if (!file.exists) {
        file.create();
        file.write(wav_bytes(code));
      }
      player = createAudioPlayer({ uri: file.uri });
      players.set(key, player);
    }
    void player.seekTo(0);
    player.play();
    duck_music();
  } catch {
    /* never break a tap */
  }
}
