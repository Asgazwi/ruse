// Shares a file made by the app (a template, a prompt) as a real file: Save to Files / Drive / WhatsApp...
// If file sharing is not available, falls back to sharing the plain text.
import { Share } from 'react-native';
import { File, Paths } from 'expo-file-system';
import * as Sharing from 'expo-sharing';

const safe_name = (name: string) => name.replace(/[^a-zA-Z0-9._-]/g, '_');

export async function share_text_file(filename: string, text: string, mime: string, uti: string, title: string): Promise<void> {
  try {
    const file = new File(Paths.cache, safe_name(filename));
    // Delete first so an older, longer file can never leave leftovers behind.
    if (file.exists) file.delete();
    file.create();
    file.write(text);
    if (await Sharing.isAvailableAsync()) {
      await Sharing.shareAsync(file.uri, { mimeType: mime, dialogTitle: title, UTI: uti });
      return;
    }
  } catch {
    /* fall through to the text share below */
  }
  await Share.share({ message: text, title });
}

export const share_json_file = (filename: string, data: unknown): Promise<void> =>
  share_text_file(filename, JSON.stringify(data, null, 2), 'application/json', 'public.json', 'Save your template');

export const share_plain_file = (filename: string, text: string): Promise<void> =>
  share_text_file(filename, text, 'text/plain', 'public.plain-text', 'Save the file');
