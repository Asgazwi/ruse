import { load_saved, save_saved, clear_saved } from './store';
import type { Gender } from './types';

// Phone-side fallback when the profile backend is not ready yet (D1).
const KEY = 'profile_gender';

export function load_local_gender(): Gender | null {
  const g = load_saved<string>(KEY);
  if (g === 'boy' || g === 'girl' || g === 'skip') return g;
  return null;
}

export function save_local_gender(g: Gender): void {
  save_saved(KEY, g);
}

export function clear_local_gender(): void {
  clear_saved(KEY);
}

export function effective_gender(me: { gender?: Gender | null } | null | undefined): Gender | null {
  const g = me?.gender;
  if (g === 'boy' || g === 'girl' || g === 'skip') return g;
  return load_local_gender();
}
