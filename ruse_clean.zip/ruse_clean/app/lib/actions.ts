// ---------------------------------------------------------------
// Backend action names (Apps Script functions in Code.gs).
// Copied from the call("...") list in the original web page, so the
// app and the backend speak the same words. Rename here, nowhere else.
// ---------------------------------------------------------------
export const ACTION_GET_COURSE_DATA = 'getCourseData';
export const ACTION_SAVE_COURSE = 'saveCourseBundle'; // whole novel: { novel, chapters[] } (the old backend also gets a "course" copy)
export const ACTION_SAVE_CHAPTER = 'saveChapter';     // one chapter, needs "subject"
export const ACTION_SAVE_THEME = 'saveTheme';         // author/admin on the backend (role-checked)
export const ACTION_DELETE_THEME = 'deleteTheme';     // (id) B4: admin any uploaded; author own only; never built-in

// ---- Reads (safe to repeat) ----
// These are retried on a shaky network. Writes (save*, delete*, add*...) are NEVER
// retried on their own, because a retry after a half-finished save could create duplicates.
export const ACTION_GET_ME = 'getMe';
export const ACTION_GET_ADMIN_DATA = 'getAdminData';
// ---- Pins & comments (Phase 6b) ----
export const ACTION_GET_PINS = 'getPins';
export const ACTION_SAVE_PIN = 'savePin';                 // ({ chapter, block })
export const ACTION_DELETE_PIN = 'deletePin';             // (chapterId)
export const ACTION_GET_COMMENTS = 'getComments';
export const ACTION_SAVE_COMMENT = 'saveComment';         // ({ id, chapter, block, text }) add or edit mine
export const ACTION_DELETE_COMMENT = 'deleteComment';     // (id)
export const ACTION_REPLY_COMMENT = 'replyComment';       // ({ id, parent, text })
export const ACTION_ADD_BLOCK_AFTER_COMMENT = 'addBlockAfterComment'; // ({ comment, block }) uploader only

export const ACTION_REGISTER_PUSH_TOKEN = 'registerPushToken';     // (token) so the uploader gets a push for new comments
export const ACTION_UNREGISTER_PUSH_TOKEN = 'unregisterPushToken'; // (token)
export const ACTION_TEST_PUSH = 'testPush';                        // () sends a test notification to my own phones; answers { ok, text }
export const ACTION_RENAME_CATEGORY = 'renameCategory';             // ({ from, to }) owner only

// ---- Access (Phase 2b + R2). Admin-only on the backend, except requestAccess ----
export const ACTION_REQUEST_ACCESS = 'requestAccess';   // (name)
export const ACTION_REQUEST_ROLE = 'requestRole';       // ('author')  R3: reader asks to become author
export const ACTION_CHECK_USERNAME = 'checkUsername';   // (name) D1a → { ok: true } or error
export const ACTION_SAVE_USERNAME = 'saveUsername';     // (name) D1a; at most once / 30 days
export const ACTION_GET_PROFILE = 'getProfile';         // D1
export const ACTION_SAVE_PROFILE = 'saveProfile';       // ({ gender }) D1
export const ACTION_SAVE_AVATAR = 'saveAvatar';         // (base64) D1
// ---- Direct messages (D3). Owner builds these in Code.gs. ----
export const ACTION_GET_THREADS = 'getThreads';         // () -> my messages, both directions
export const ACTION_GET_MESSAGES = 'getMessages';       // (with_username) -> one conversation
export const ACTION_SEND_MESSAGE = 'sendMessage';       // ({ to_username, text }) -> the saved message
export const ACTION_MARK_READ = 'markRead';             // (with_username)
// ---- Safety (D4). Owner builds these in Code.gs. ----
export const ACTION_GET_BLOCKED = 'getBlocked';         // () -> usernames I blocked
export const ACTION_BLOCK_USER = 'blockUser';           // (username)
export const ACTION_UNBLOCK_USER = 'unblockUser';       // (username)
export const ACTION_REPORT_USER = 'reportUser';         // ({ username, reason })
export const ACTION_GET_REPORTS = 'getReports';         // () admin only
export const ACTION_RESOLVE_REPORT = 'resolveReport';   // (id) admin only
export const ACTION_SET_MESSAGING = 'setMessaging';     // ({ username, allowed }) admin only

export const READ_ACTIONS: string[] = [ACTION_GET_ME, ACTION_GET_COURSE_DATA, ACTION_GET_ADMIN_DATA, ACTION_GET_PINS, ACTION_GET_COMMENTS, ACTION_CHECK_USERNAME, ACTION_GET_PROFILE, ACTION_GET_THREADS, ACTION_GET_MESSAGES, ACTION_GET_BLOCKED, ACTION_GET_REPORTS];

export const ACTION_APPROVE_REQUEST = 'approveRequest'; // (email, role?)  role = reader|author (default reader)
export const ACTION_REJECT_REQUEST = 'rejectRequest';   // (email)
export const ACTION_ADD_USER = 'addUser';               // ({ email, name, role })  also sends admin for old backends
export const ACTION_SET_ROLE = 'setRole';               // ({ email, role })  R2; admin only
export const ACTION_SET_ADMIN = 'setAdmin';             // ({ email, admin })  kept for older backends; prefer setRole
export const ACTION_REMOVE_USER = 'removeUser';         // (email)

// ---- Progress (Phase 6) ----
// Sends the whole progress object { completed, active, subject, theme }. Sending the same
// thing twice is harmless, so the app may safely retry it later when the network is back.
export const ACTION_SAVE_PROGRESS = 'saveProgress';

// ---- Settings extras (Phase 7) ----
// Deletes and overwrites are owner / creator / uploader only on the backend (Code.gs v10).
export const ACTION_SAVE_SUBJECT = 'saveSubject';     // ({ title, summary, category, kind }) E1: kind + folderId from server
export const ACTION_DELETE_MESSAGE = 'deleteMessage';   // (id) delete one of MY messages
export const ACTION_UPLOAD_ASSET = 'uploadAsset';     // ({ folderId, name, mime, base64 }) E1
export const ACTION_DELETE_SUBJECT = 'deleteSubject'; // (courseId) also deletes its chapters
export const ACTION_DELETE_CHAPTER = 'deleteChapter'; // (chapterId)
