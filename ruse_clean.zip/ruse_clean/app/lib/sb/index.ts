// One file per moved action lives next to this one (snake_case), and is listed here by its ACTION name.
// Nothing is moved yet, so this is empty. Example for Phase 1:
//   import { get_me } from the file get_me.ts
//   export const sb_handlers = { [ACTION_GET_ME]: get_me, ... };
// A handler takes the same arguments the app already sends and returns the same shape the app already reads.
export type sb_handler = (...args: any[]) => Promise<unknown>;

export const sb_handlers: Record<string, sb_handler> = {};
