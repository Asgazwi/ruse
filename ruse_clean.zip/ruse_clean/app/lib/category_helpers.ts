import { novels_count } from './words';
// Pure helpers for categories (Phase 6c). A course sits in a path of categories:
// DATA > DATA ANALYSIS > POWER BI  =  category ["DATA", "DATA ANALYSIS"] + course "POWER BI".

export type CategoryNode = { name: string; path: string[]; courses: number }; // courses = how many courses are inside, at any depth

// The category path of a subject: accepts a list or a "A > B" text; anything else = no category.
export function category_of(subject: unknown): string[] {
  const raw = (subject as any)?.category;
  const parts: unknown[] = Array.isArray(raw) ? raw : typeof raw === 'string' ? raw.split('>') : [];
  return parts.map((p) => String(p ?? '').replace(/\s+/g, ' ').trim()).filter(Boolean);
}

export const path_key = (path: string[]): string => path.map((p) => p.toLowerCase()).join('>');
const starts_with = (cat: string[], path: string[]) => cat.length >= path.length && path_key(cat.slice(0, path.length)) === path_key(path);

// What sits directly inside a category (path [] = the top level):
// sub-categories (with how many courses are inside them) and the courses that live right here.
export function children_of<T>(subjects: T[], path: string[]): { categories: CategoryNode[]; courses: T[] } {
  const categories: CategoryNode[] = [];
  const courses: T[] = [];
  for (const s of subjects) {
    const cat = category_of(s);
    if (!starts_with(cat, path)) continue;
    if (cat.length === path.length) { courses.push(s); continue; }
    const name = cat[path.length];
    const child = [...path, name];
    const found = categories.find((c) => path_key(c.path) === path_key(child));
    if (found) found.courses += 1;
    else categories.push({ name, path: child, courses: 1 });
  }
  return { categories, courses };
}

// Does this category path exist (is any course inside it)?
export const category_exists = <T,>(subjects: T[], path: string[]): boolean => subjects.some((s) => starts_with(category_of(s), path));

// Safe to put in a screen address: /category?path=DATA%3EDATA%20ANALYSIS
export const encode_path = (path: string[]): string => encodeURIComponent(path.join('>'));
export function decode_path(text?: string | string[]): string[] {
  const one = Array.isArray(text) ? text[0] : text;
  if (!one) return [];
  let plain = one;
  try { plain = decodeURIComponent(one); } catch { /* already plain */ }
  return plain.split('>').map((p) => p.trim()).filter(Boolean);
}

export const courses_label = (n: number): string => novels_count(n);
