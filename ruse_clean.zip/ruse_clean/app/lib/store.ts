import { File, Paths } from 'expo-file-system';

// ---------------------------------------------------------------
// Tiny "saved on the phone" box. One small .json file per key, in the app's
// private document folder. Reads never throw: a missing or damaged file is just "nothing saved".
// ---------------------------------------------------------------
const file_for = (key: string) => new File(Paths.document, `ruse_saved_${key}.json`);

export function save_saved(key: string, value: unknown): void {
  try {
    const f = file_for(key);
    // Delete first so an older, longer file can never leave leftovers behind.
    if (f.exists) f.delete();
    f.create();
    f.write(JSON.stringify(value));
  } catch {
    /* saving is a bonus: if the phone refuses, the app still works online */
  }
}

export function load_saved<T>(key: string): T | null {
  try {
    const f = file_for(key);
    if (!f.exists) return null;
    return JSON.parse(f.textSync()) as T;
  } catch {
    return null;
  }
}

export function clear_saved(key: string): void {
  try {
    const f = file_for(key);
    if (f.exists) f.delete();
  } catch {
    /* nothing to clear */
  }
}
