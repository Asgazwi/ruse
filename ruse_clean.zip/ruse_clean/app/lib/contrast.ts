// ---------------------------------------------------------------
// Readable colors on any theme (Phase A1).
// Why: a few screens used fixed colors (dark text, pale boxes). That is fine on a pastel theme
// and invisible on a dark one. These helpers let a screen ask "what text color works on THIS
// background?" and "what is a soft tint of this color on THIS surface?" instead of hard-coding.
// Pure logic only: no React, no Expo, so it is easy to test.
// ---------------------------------------------------------------

const HEX = /^#([0-9a-f]{3}|[0-9a-f]{6})$/i;

// "#rgb" or "#rrggbb" -> [r, g, b] (0 to 255). Anything else -> null.
function to_rgb(hex: string): [number, number, number] | null {
  const raw = String(hex ?? '').trim();
  if (!HEX.test(raw)) return null;
  const h = raw.slice(1);
  const full = h.length === 3 ? h.split('').map((x) => x + x).join('') : h;
  return [parseInt(full.slice(0, 2), 16), parseInt(full.slice(2, 4), 16), parseInt(full.slice(4, 6), 16)];
}

const to_hex = (rgb: [number, number, number]): string =>
  '#' + rgb.map((v) => Math.max(0, Math.min(255, Math.round(v))).toString(16).padStart(2, '0')).join('');

// How bright a color looks to the eye: 0 (black) to 1 (white). Standard WCAG formula.
// An unreadable color counts as light (1), so we never guess "dark" from garbage.
export function luminance(hex: string): number {
  const rgb = to_rgb(hex);
  if (!rgb) return 1;
  const [r, g, b] = rgb.map((v) => {
    const s = v / 255;
    return s <= 0.03928 ? s / 12.92 : Math.pow((s + 0.055) / 1.055, 2.4);
  });
  return 0.2126 * r + 0.7152 * g + 0.0722 * b;
}

// True when light text is the better choice on this background.
// 0.179 is the point where white and black text have the same contrast.
export const is_dark = (hex: string): boolean => luminance(hex) < 0.179;

// The text color to put on `bg`: `light` on dark backgrounds, `dark` on light ones.
export const text_on = (bg: string, light = '#ffffff', dark = '#1f1a24'): string => (is_dark(bg) ? light : dark);

// A soft tint: `amount` (0 to 1) of `tint` mixed into `base`, returned as a solid "#rrggbb".
// Solid (not see-through) so it looks the same on every screen. Bad input returns `base`.
export function mix_hex(base: string, tint: string, amount: number): string {
  const a = to_rgb(base);
  const b = to_rgb(tint);
  if (!a || !b) return HEX.test(String(base ?? '').trim()) ? String(base).trim() : '#ffffff';
  const t = Math.max(0, Math.min(1, amount));
  return to_hex([a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t, a[2] + (b[2] - a[2]) * t]);
}
