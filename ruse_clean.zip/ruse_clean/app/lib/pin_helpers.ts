// Pure helpers for pins + comments (Phase 6b). No React / Expo, so they can be tested alone.

export type Pin = { chapter: string; subject: string; block: number; updated: string };
export type Comment = {
  id: string; chapter: string; subject: string; block: number;
  name: string; text: string; created: string; edited: string | null; parent: string | null;
  avatarUrl?: string | null; // D2: the writer's avatar, if the server sends one (optional)
  mine: boolean;        // I wrote it
  byUploader: boolean;  // the chapter's uploader wrote it
  toMe: boolean;        // it is on a chapter I uploaded
  pending?: boolean;    // only on this phone so far (waiting to be sent)
};
export type Snapshot = { pins: Pin[]; comments: Comment[] };

// Things done on the phone that the server has not heard about yet.
export type PinOp =
  | { kind: 'pin'; chapter: string; subject: string; block: number; at: number }
  | { kind: 'unpin'; chapter: string }
  | { kind: 'comment'; id: string; chapter: string; subject: string; block: number; text: string; name: string; at: number } // add, or edit when the id already exists
  | { kind: 'uncomment'; id: string }
  | { kind: 'reply'; id: string; parent: string; text: string; name: string; as_uploader: boolean; at: number };
export type Queued = { n: number; op: PinOp };

// A change the server refused (for example the chapter was removed). It is kept, with the reason,
// instead of being thrown away, so a comment the reader typed is never lost silently (Phase A2).
export type Failed = { n: number; op: PinOp; message: string };

// Name of the file on the phone that holds one account's pins, queue and refused changes.
export const pins_key = (email: string): string => 'pins_' + email.toLowerCase().replace(/[^a-z0-9]/g, '_');

// Short word for a change, for the "not sent" list.
export function op_label(op: PinOp): string {
  switch (op.kind) {
    case 'pin': return 'Pin';
    case 'unpin': return 'Remove pin';
    case 'comment': return 'Comment';
    case 'uncomment': return 'Delete comment';
    case 'reply': return 'Reply';
  }
}

// The words the reader typed, if this change has any (pins and deletes have none).
export const op_text = (op: PinOp): string => (op.kind === 'comment' || op.kind === 'reply' ? op.text : '');

// What other readers see as a name. An email is never shown: it falls back to "Reader" (Phase A9).
// This also covers old comments that were saved with an email as the name.
const LOOKS_LIKE_EMAIL = /\S+@\S+\.\S+/;
export function display_name(name: unknown, fallback = 'Reader'): string {
  const t = typeof name === 'string' ? name.trim() : '';
  return !t || LOOKS_LIKE_EMAIL.test(t) ? fallback : t;
}

export const MAX_COMMENT_CHARS = 1000;
// Comments belong to the whole chapter. `block` is only set when the writer chose to refer to a part of it;
// -1 means "no part, just the chapter".
export const WHOLE_CHAPTER = -1;
export const has_ref = (block: number): boolean => Number.isInteger(block) && block >= 0;
export const empty_snapshot = (): Snapshot => ({ pins: [], comments: [] });

const iso = (ms: number) => new Date(ms).toISOString();
export const same_email = (a?: string | null, b?: string | null) => !!a && !!b && a.trim().toLowerCase() === b.trim().toLowerCase();

// An id the backend accepts (letters, digits, - and _, 8 to 60 long). Made on the phone so
// sending the same comment twice never creates a second one.
export function new_id(now: number, rand: () => number): string {
  const r = Math.floor(rand() * 36 ** 6).toString(36).padStart(6, '0');
  return `c${now.toString(36)}${r}`;
}

// ---- Queue ----------------------------------------------------------------
// Keeps the waiting list short and in a safe order.
export function push_op(queue: Queued[], op: PinOp, next_n: () => number): Queued[] {
  switch (op.kind) {
    case 'pin':
    case 'unpin':
      // Only the last pin/unpin for a chapter matters.
      return [...queue.filter((q) => !((q.op.kind === 'pin' || q.op.kind === 'unpin') && q.op.chapter === op.chapter)), { n: next_n(), op }];
    case 'comment': {
      // Editing a comment that has not been sent yet: just change the waiting one.
      const old = queue.find((q) => q.op.kind === 'comment' && q.op.id === op.id);
      if (old && old.op.kind === 'comment') {
        const merged: PinOp = { ...old.op, text: op.text };
        return [...queue.filter((q) => q !== old), { n: next_n(), op: merged }].sort((a, b) => a.n - b.n);
      }
      return [...queue, { n: next_n(), op }];
    }
    case 'uncomment':
      // Anything still waiting for this comment (and replies to it) is pointless now.
      return [
        ...queue.filter((q) => !(
          (q.op.kind === 'comment' && q.op.id === op.id) ||
          (q.op.kind === 'reply' && (q.op.id === op.id || q.op.parent === op.id))
        )),
        { n: next_n(), op },
      ];
    case 'reply':
      return [...queue, { n: next_n(), op }];
  }
}

// ---- Show what the phone knows: server copy + the waiting list on top ------
// Safe to run again over a server copy that already contains these changes.
export function apply_ops(snap: Snapshot, ops: PinOp[]): Snapshot {
  let pins = snap.pins.slice();
  let comments = snap.comments.slice();
  for (const op of ops) {
    if (op.kind === 'pin') {
      pins = [...pins.filter((p) => p.chapter !== op.chapter), { chapter: op.chapter, subject: op.subject, block: op.block, updated: iso(op.at) }];
    } else if (op.kind === 'unpin') {
      pins = pins.filter((p) => p.chapter !== op.chapter);
    } else if (op.kind === 'comment') {
      const i = comments.findIndex((c) => c.id === op.id);
      if (i >= 0) comments[i] = { ...comments[i], text: op.text, edited: comments[i].edited ?? iso(op.at), pending: true };
      else comments.push({ id: op.id, chapter: op.chapter, subject: op.subject, block: op.block, name: op.name, text: op.text, created: iso(op.at), edited: null, parent: null, mine: true, byUploader: false, toMe: false, pending: true });
    } else if (op.kind === 'uncomment') {
      comments = comments.filter((c) => c.id !== op.id && c.parent !== op.id);
    } else if (op.kind === 'reply') {
      const root = comments.find((c) => c.id === op.parent);
      if (root && !comments.some((c) => c.id === op.id)) {
        comments.push({ id: op.id, chapter: root.chapter, subject: root.subject, block: root.block, name: op.name, text: op.text, created: iso(op.at), edited: null, parent: root.id, mine: true, byUploader: op.as_uploader, toMe: root.toMe, pending: true });
      }
    }
  }
  return { pins, comments };
}

// ---- Reading the lists ------------------------------------------------------
export type Thread = { root: Comment; replies: Comment[] };
const by_created = (a: Comment, b: Comment) => (a.created < b.created ? -1 : a.created > b.created ? 1 : 0);

export function group_threads(comments: Comment[]): Thread[] {
  return comments.filter((c) => !c.parent).sort(by_created).map((root) => ({
    root,
    replies: comments.filter((c) => c.parent === root.id).sort(by_created),
  }));
}
export const threads_for_block = (comments: Comment[], chapter: string, block: number): Thread[] =>
  group_threads(comments.filter((c) => c.chapter === chapter && c.block === block));
// Every comment thread on a chapter, whatever part it refers to (the chapter-level list).
export const threads_for_chapter = (comments: Comment[], chapter: string): Thread[] =>
  group_threads(comments.filter((c) => c.chapter === chapter));

// How many comment threads each block has: { blockNumber: count }
export function block_counts(comments: Comment[], chapter: string): Record<number, number> {
  const out: Record<number, number> = {};
  for (const c of comments) if (c.chapter === chapter && !c.parent && has_ref(c.block)) out[c.block] = (out[c.block] ?? 0) + 1;
  return out;
}

export const pin_for = (pins: Pin[], chapter: string): Pin | null => pins.find((p) => p.chapter === chapter) ?? null;

// The most recently pinned spot among these chapters (for "Continue where I stopped").
export function latest_pin(pins: Pin[], chapter_ids: string[]): Pin | null {
  const ok = new Set(chapter_ids);
  let best: Pin | null = null;
  for (const p of pins) if (ok.has(p.chapter) && (!best || p.updated > best.updated)) best = p;
  return best;
}

// Threads on my chapters, started by other people, that I have not answered.
export function is_unanswered(t: Thread): boolean {
  return t.root.toMe && !t.root.mine && !t.replies.some((r) => r.mine);
}
export const unanswered_count = (comments: Comment[]): number => group_threads(comments).filter(is_unanswered).length;

// Threads on chapters I uploaded, most recent activity first.
export function inbox_threads(comments: Comment[]): Thread[] {
  const last = (t: Thread) => [t.root, ...t.replies].reduce((m, c) => (c.created > m ? c.created : m), '');
  return group_threads(comments).filter((t) => t.root.toMe && !t.root.mine).sort((a, b) => (last(a) < last(b) ? 1 : -1));
}

// ---- Small display helpers ----------------------------------------------------
export function block_preview(block: any): string {
  if (!block || typeof block !== 'object') return '';
  const raw =
    typeof block.text === 'string' ? block.text
    : Array.isArray(block.items) ? block.items.filter((x: unknown) => typeof x === 'string').join(', ')
    : Array.isArray(block.headers) ? block.headers.filter((x: unknown) => typeof x === 'string').join(' | ')
    : '';
  const flat = raw.replace(/\s+/g, ' ').trim();
  return flat.length > 90 ? flat.slice(0, 87) + '…' : flat;
}

export function short_date(iso_text: string): string {
  const d = new Date(iso_text);
  if (isNaN(d.getTime())) return '';
  return d.toLocaleDateString(undefined, { day: 'numeric', month: 'short' });
}

// What the uploader can add right below a comment.
export function make_block(kind: 'p' | 'tip', text: string) {
  return kind === 'tip' ? { type: 'callout', kind: 'tip', text } : { type: 'p', text };
}

// ---- Defensive reading of server answers ------------------------------------
const is_obj = (x: unknown): x is Record<string, any> => !!x && typeof x === 'object' && !Array.isArray(x);
export function norm_pins(raw: unknown): Pin[] {
  if (!Array.isArray(raw)) return [];
  return raw.filter((p) => is_obj(p) && typeof p.chapter === 'string' && Number.isInteger(p.block))
    .map((p) => ({ chapter: p.chapter, subject: String(p.subject ?? ''), block: p.block, updated: String(p.updated ?? '') }));
}
export function norm_failed(raw: unknown): Failed[] {
  if (!Array.isArray(raw)) return [];
  return raw
    .filter((f) => is_obj(f) && Number.isInteger(f.n) && is_obj(f.op) && typeof f.op.kind === 'string')
    .map((f) => ({ n: f.n, op: f.op as PinOp, message: String(f.message ?? 'The server did not accept this.') }));
}
export function norm_comments(raw: unknown): Comment[] {
  if (!Array.isArray(raw)) return [];
  return raw.filter((c) => is_obj(c) && typeof c.id === 'string' && typeof c.chapter === 'string' && Number.isInteger(c.block) && typeof c.text === 'string')
    .map((c) => ({
      id: c.id, chapter: c.chapter, subject: String(c.subject ?? ''), block: c.block,
      name: String(c.name ?? ''), text: c.text, created: String(c.created ?? ''),
      edited: c.edited ? String(c.edited) : null, parent: c.parent ? String(c.parent) : null,
      mine: !!c.mine, byUploader: !!c.byUploader, toMe: !!c.toMe,
    }));
}
