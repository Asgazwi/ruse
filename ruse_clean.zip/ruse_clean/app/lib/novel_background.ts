import { api } from './backend';
import { ACTION_SAVE_SUBJECT, ACTION_UPLOAD_ASSET } from './actions';

// ---------------------------------------------------------------
// E5 · Author reading background for a novel.
// Image is resized on the phone, uploaded into the novel's Drive folder,
// then linked on the subject as backgroundUrl (backend must accept both).
// ---------------------------------------------------------------

const MAX_EDGE = 1280;
const JPEG_QUALITY = 0.75;
const ASSET_NAME = 'reading-background.jpg';

export type upload_bg_result =
  | { ok: true; url: string }
  | { ok: false; error: string };

/** Pick a photo, shrink it, upload to the novel folder, set subject.backgroundUrl. */
export async function upload_novel_background(args: {
  subject_id: string;
  folder_id: string;
}): Promise<upload_bg_result> {
  const subject_id = (args.subject_id || '').trim();
  const folder_id = (args.folder_id || '').trim();
  if (!subject_id) return { ok: false, error: 'Missing novel id.' };
  if (!folder_id) return { ok: false, error: 'This novel has no Drive folder yet. Create or refresh it first (backend).' };

  try {
    const ImagePicker = await import('expo-image-picker');
    const perm = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (!perm.granted) return { ok: false, error: 'Photo access is needed to pick a background.' };

    const picked = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ['images'],
      quality: 0.9,
      allowsEditing: true,
      // Wide-ish crop suits a full-screen reading backdrop.
      aspect: [9, 16],
    });
    if (picked.canceled || !picked.assets?.length) return { ok: false, error: 'cancelled' };

    const uri = picked.assets[0].uri;
    let b64: string | undefined;
    try {
      // @ts-ignore expo-image-manipulator is an optional package
      const Manipulator = await import('expo-image-manipulator');
      const out = await Manipulator.manipulateAsync(
        uri,
        [{ resize: { width: MAX_EDGE } }],
        { compress: JPEG_QUALITY, format: Manipulator.SaveFormat.JPEG, base64: true },
      );
      b64 = out.base64;
    } catch {
      return { ok: false, error: 'Background needs expo-image-manipulator in the build (or could not read the photo).' };
    }
    if (!b64) return { ok: false, error: 'Could not read the photo as base64.' };

    // Backend: store in the novel folder and return a public/open URL when possible.
    const uploaded = await api<{ url?: string; id?: string }>(ACTION_UPLOAD_ASSET, {
      folderId: folder_id,
      name: ASSET_NAME,
      mime: 'image/jpeg',
      base64: b64,
      kind: 'background', // hint for Code.gs if useful
    });

    const url = typeof uploaded?.url === 'string' ? uploaded.url.trim() : '';
    if (!url) {
      return {
        ok: false,
        error: 'Upload worked but the server did not return a url. Backend should return { url } from uploadAsset.',
      };
    }

    // Link on the subject so getCourseData can return backgroundUrl.
    await api(ACTION_SAVE_SUBJECT, { id: subject_id, backgroundUrl: url });
    return { ok: true, url };
  } catch (e: any) {
    const msg = String(e?.message || e || '');
    if (/ExpoImagePicker|Cannot find module|Native module/i.test(msg)) {
      return { ok: false, error: 'Photo picker needs a new app build (expo-image-picker).' };
    }
    if (msg === 'cancelled') return { ok: false, error: 'cancelled' };
    return { ok: false, error: msg || 'Could not upload the background.' };
  }
}

/** Clear the novel's reading background on the server. */
export async function clear_novel_background(subject_id: string): Promise<void> {
  const sid = (subject_id || '').trim();
  if (!sid) throw new Error('Missing novel id.');
  await api(ACTION_SAVE_SUBJECT, { id: sid, backgroundUrl: '' });
}

/** Effective background URI for the reader (null if none or turned off). */
export function effective_novel_bg(
  backgroundUrl: string | null | undefined,
  subject_id: string,
  is_off: (sid: string) => boolean,
): string | null {
  const url = typeof backgroundUrl === 'string' ? backgroundUrl.trim() : '';
  if (!url) return null;
  if (is_off(subject_id)) return null;
  return url;
}
