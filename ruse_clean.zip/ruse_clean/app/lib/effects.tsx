import React, { createContext, useCallback, useContext, useState } from 'react';
import { load_saved, save_saved } from './store';

// Two small on/off switches, remembered on the phone (Settings → Tap effects).
type Prefs = { effects_on: boolean; haptics_on: boolean };
type Ctx = Prefs & { set_effects_on: (v: boolean) => void; set_haptics_on: (v: boolean) => void };
const EffectsCtx = createContext<Ctx>(null as unknown as Ctx);
export const useEffects = () => useContext(EffectsCtx);

const SAVED = 'effects_prefs';

export function EffectsProvider({ children }: { children: React.ReactNode }) {
  const [prefs, setPrefs] = useState<Prefs>(() => ({ effects_on: true, haptics_on: true, ...(load_saved<Partial<Prefs>>(SAVED) || {}) }));
  const change = useCallback((patch: Partial<Prefs>) => {
    setPrefs((old) => { const next = { ...old, ...patch }; save_saved(SAVED, next); return next; });
  }, []);
  const set_effects_on = useCallback((v: boolean) => change({ effects_on: v }), [change]);
  const set_haptics_on = useCallback((v: boolean) => change({ haptics_on: v }), [change]);
  return <EffectsCtx.Provider value={{ ...prefs, set_effects_on, set_haptics_on }}>{children}</EffectsCtx.Provider>;
}
