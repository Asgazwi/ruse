// Pure helpers for direct messages (Phase D3). No React / Expo, so they can be tested alone.
// Messages go between USERNAMES, never emails (D1a). Plain text only: no photos, no read receipts.

export const MESSAGE_MAX_CHARS = 500;

// What the server sends back for one message. "from" and "to" are usernames.
export type Message = {
  id: string; from: string; to: string; text: string; created: string; read: boolean;
  fromAvatar?: string; toAvatar?: string; // picture links of the two people (empty when they have none)
};

// One conversation in the inbox: the other person, the newest message, and how many they sent
// that I have not read yet.
export type Thread = { with: string; last: Message; unread: number; avatarUrl: string };

const key = (name: string) => name.trim().toLowerCase();
export const same_user = (a?: string | null, b?: string | null) => !!a && !!b && key(a) === key(b);

// Trims the text and checks it is sendable. Returns the clean text, or the reason it is not.
export function clean_message(raw: string): { ok: true; text: string } | { ok: false; reason: string } {
  const text = raw.trim();
  if (!text) return { ok: false, reason: 'Type a message first.' };
  if (text.length > MESSAGE_MAX_CHARS) return { ok: false, reason: `At most ${MESSAGE_MAX_CHARS} characters.` };
  return { ok: true, text };
}

const time_of = (m: Message) => Date.parse(m.created) || 0;

// Groups all my messages into one thread per other person, newest thread first.
// Messages to someone else, or with a missing name, are ignored.
export function summarize_threads(messages: Message[], me: string | null | undefined): Thread[] {
  if (!me) return [];
  const by_other = new Map<string, Thread>();
  for (const m of messages) {
    const mine_out = same_user(m.from, me);
    const mine_in = same_user(m.to, me);
    if (!mine_out && !mine_in) continue;
    const other = mine_out ? m.to : m.from;
    if (!other || same_user(other, me)) continue;
    const k = key(other);
    const cur = by_other.get(k);
    const unread = mine_in && !m.read ? 1 : 0;
    const their_avatar = (mine_out ? m.toAvatar : m.fromAvatar) || '';
    if (!cur) {
      by_other.set(k, { with: other.trim(), last: m, unread, avatarUrl: their_avatar });
    } else {
      const newer = time_of(m) > time_of(cur.last);
      by_other.set(k, { with: cur.with, last: newer ? m : cur.last, unread: cur.unread + unread, avatarUrl: cur.avatarUrl || their_avatar });
    }
  }
  return [...by_other.values()].sort((a, b) => time_of(b.last) - time_of(a.last));
}

// The conversation with one person, oldest first (reads top to bottom like a chat).
export function thread_with(messages: Message[], me: string | null | undefined, other: string): Message[] {
  return messages
    .filter((m) => (same_user(m.from, me) && same_user(m.to, other)) || (same_user(m.from, other) && same_user(m.to, me)))
    .sort((a, b) => time_of(a) - time_of(b));
}

// Total unread across all threads, for the badge on Home.
export const unread_total = (threads: Thread[]): number => threads.reduce((n, t) => n + t.unread, 0);

// Short time for the inbox: a clock time today, otherwise a date.
export function message_time(iso: string, now = Date.now()): string {
  const ms = Date.parse(iso);
  if (!Number.isFinite(ms)) return '';
  const d = new Date(ms);
  const same_day = new Date(now).toDateString() === d.toDateString();
  return same_day
    ? d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    : d.toLocaleDateString([], { month: 'short', day: 'numeric' });
}

// The heading above a day of messages in a chat: "Today", "Yesterday", or a date.
export function day_label(iso: string, now = Date.now()): string {
  const ms = Date.parse(iso);
  if (!Number.isFinite(ms)) return '';
  const d = new Date(ms);
  const today = new Date(now);
  if (d.toDateString() === today.toDateString()) return 'Today';
  const yesterday = new Date(now - 86400000);
  if (d.toDateString() === yesterday.toDateString()) return 'Yesterday';
  return d.toLocaleDateString([], { month: 'long', day: 'numeric', year: d.getFullYear() === today.getFullYear() ? undefined : 'numeric' });
}

// True when this message starts a new day compared with the one before it (so a day heading goes above it).
export const starts_new_day = (iso: string, previous_iso?: string): boolean =>
  !previous_iso || new Date(Date.parse(iso)).toDateString() !== new Date(Date.parse(previous_iso)).toDateString();

