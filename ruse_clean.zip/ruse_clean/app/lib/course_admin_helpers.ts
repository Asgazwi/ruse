import { W } from './words';
// ---------------------------------------------------------------
// Phase 7 · Settings extras: pure logic for "Your courses",
// new course, delete course / chapter, and reset my progress.
// No React, no network: everything here is tested in tests/.
// ---------------------------------------------------------------

export type CourseLite = { id: string; title: string; summary?: string; category?: string[]; createdBy?: string; kind?: string; folderId?: string; uploaderName?: string };
export type ChapterLite = { id: string; subject: string; title: string; order: number; uploadedBy?: string; uploaderName?: string; blocks: unknown[] };

export const MAX_COURSE_TITLE = 80;     // same limit as the backend (saveSubject)
export const MAX_COURSE_SUMMARY = 300;  // same limit as the backend
export const MAX_CATEGORY_LEVELS = 4;   // same limit as the backend
export const MAX_CATEGORY_NAME = 40;

// Same rule as Code.gs slugify_: lowercase, non-letters/digits become dashes, max 60.
export function slugify(s: string): string {
  return String(s).toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 60);
}

// Returns a message for the user, or null when the name is fine.
// Any language is fine: a name with no English letters or digits (e.g. Arabic) gets a hash-based id on the backend.
export function course_title_error(title: string): string | null {
  const t = title.trim();
  if (t.length < 1) return `${W.Novel} name is required.`;
  if (t.length > MAX_COURSE_TITLE) return `${W.Novel} name can be at most ${MAX_COURSE_TITLE} characters.`;
  return null;
}

export function course_summary_error(summary: string): string | null {
  return summary.length > MAX_COURSE_SUMMARY ? `Summary can be at most ${MAX_COURSE_SUMMARY} characters.` : null;
}

// "DATA > DATA ANALYSIS" -> ["DATA", "DATA ANALYSIS"]. Empty input means no category. Returns an error or the list.
export function parse_category_text(text: string): { error: string | null; parts: string[] } {
  const parts = text.split('>').map((p) => p.replace(/\s+/g, ' ').trim()).filter((p) => p !== '');
  if (parts.length > MAX_CATEGORY_LEVELS) return { error: `A category can be at most ${MAX_CATEGORY_LEVELS} levels deep.`, parts: [] };
  if (parts.some((p) => p.length > MAX_CATEGORY_NAME)) return { error: `Category names can be at most ${MAX_CATEGORY_NAME} characters.`, parts: [] };
  return { error: null, parts };
}

// Owner (or the person recorded as creator/uploader) may delete. Same rule as the backend canManage_.
export function can_manage(recordedBy: string | undefined, email: string, is_owner: boolean): boolean {
  if (is_owner) return true;
  return !!recordedBy && recordedBy.toLowerCase() === email.toLowerCase();
}

// "Your courses": courses I created, plus courses that hold chapters I uploaded. The owner sees every course.
export function my_courses(courses: CourseLite[], chapters: ChapterLite[], email: string, is_owner: boolean) {
  return courses
    .filter((c) => is_owner
      || can_manage(c.createdBy, email, false)
      || chapters.some((ch) => ch.subject === c.id && can_manage(ch.uploadedBy, email, false)))
    .map((c) => ({
      course: c,
      chapters: chapters.filter((ch) => ch.subject === c.id).sort((a, b) => a.order - b.order),
    }));
}

// Warning shown before deleting a course: deleting it removes every chapter in it, including other people's.
export function delete_course_warning(course: CourseLite, chapters: ChapterLite[], email: string): string {
  const inside = chapters.filter((ch) => ch.subject === course.id);
  const others = inside.filter((ch) => (ch.uploadedBy || '').toLowerCase() !== email.toLowerCase()).length;
  const base = `Delete "${course.title}" and its ${inside.length} chapter${inside.length === 1 ? '' : 's'}? Its comments and pins go too. This cannot be undone.`;
  return others > 0 ? `${base}\n\n${others} of these chapters were uploaded by other people.` : base;
}

// A chapter template already filled in for one novel or comic. Passes the upload check.
// existingIds: every chapter id already used, so the new id never clashes.
// A comic (manga or webtoon) gets a page list; a novel gets text blocks.
export function chapter_template_for(courseId: string, courseChapterCount: number, existingIds: string[], kind: string = 'novel') {
  let n = courseChapterCount + 1;
  let id = `${courseId}-chapter-${n}`.slice(0, 60);
  while (existingIds.indexOf(id) !== -1) {
    n += 1;
    id = `${courseId}-chapter-${n}`.slice(0, 60);
  }
  const comic = kind === 'manga' || kind === 'webtoon';
  const base = {
    schemaVersion: 1,
    id,
    subject: courseId,
    order: courseChapterCount,
    title: `Chapter ${n}`,
    minutes: 5,
    summary: 'A short summary of this chapter (optional).',
  };
  if (comic) {
    return {
      _read_me: 'READ ME FIRST. Replace the title and the page links. "pages" is 1 to 300 https links to images, in reading order; each link must open the image itself. Or use "Add manga chapter from photos" instead. Keys that start with an underscore are notes: the upload ignores them. Then Settings, Choose file.',
      ...base,
      pages: [
        'https://example.com/comic/page-01.jpg',
        'https://example.com/comic/page-02.jpg',
      ],
    };
  }
  return {
    _read_me: 'READ ME FIRST. Replace the title and blocks with your own text. Block types: p, h, list, code, callout (tip|warn|ok), table. Plain text only. Keys that start with an underscore are notes: the upload ignores them. Then Settings, Choose file.',
    ...base,
    blocks: [
      { type: 'h', text: `Chapter ${n}` },
      { type: 'p', text: 'Write your text here.' },
    ],
  };
}

// Reset my progress: an empty progress object, keeping my chosen theme.
export function reset_progress_payload(theme: string | null | undefined) {
  return { completed: [], active: null, subject: null, theme: theme || 'cotton_candy' };
}
