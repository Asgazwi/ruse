// ---------------------------------------------------------------
// Theme effects written as DATA (JSON), not code. The person designs a tap effect
// with shapes, glyphs, colours, count, motion and timing; the app plays it with its own
// engine. Nothing in a theme file is ever run as code.
// Pure logic only: checks the recipes and turns them into particles / floaters.
// The same limits are checked again on the backend (Code.gs saveTheme).
// ---------------------------------------------------------------
import type { particle } from './effect_plan';
import { check_sound, type sound_code } from './sound_code';

export const SHAPES = ['glyph', 'dot', 'ring', 'rect'] as const;
export type shape = (typeof SHAPES)[number];

export type tap_recipe = {
  shape: shape;
  glyph?: string;      // shape "glyph": 1 to 4 characters, e.g. "🎀" or "✦"
  colors?: string[];   // 1 to 6 hex colours, e.g. "#ff6fa5"
  count: number;       // 1 to 24 pieces per tap
  size: [number, number]; // px, min and max, 4 to 60
  spread?: number;     // how far it flies from the tap, 0 to 300
  rise?: number;       // upward push, -200 (falls) to 300
  spin?: number;       // total turn in degrees, -720 to 720
  duration?: number;   // ms, 200 to 3000
  grow?: boolean;      // starts small and grows
};

export type background_recipe = {
  shape: shape;
  glyph?: string;
  colors?: string[];
  count: number;       // 1 to 20 floating pieces
  size: [number, number];
  duration?: number;   // one trip up the screen, ms, 8000 to 60000
  opacity?: number;    // 0.1 to 0.8
};

export type theme_effects = {
  haptic?: boolean;
  tap?: tap_recipe[];
  background?: background_recipe[];
  sound?: string | sound_code; // played on each tap: a preset name or a sound code (lib/sound_code.ts)
};

export const LIMITS = {
  tap_recipes: 6, tap_pieces: 40,
  background_recipes: 4, background_pieces: 30,
  colors: 6,
};

const is_obj = (x: unknown): x is Record<string, any> => !!x && typeof x === 'object' && !Array.isArray(x);
const in_range = (x: unknown, lo: number, hi: number) => typeof x === 'number' && Number.isFinite(x) && x >= lo && x <= hi;
const hex = (x: unknown) => typeof x === 'string' && /^#[0-9a-fA-F]{6}$/.test(x);

// Glyphs: one visible symbol (up to 4 characters, emoji included).
const glyph_ok = (g: unknown) => typeof g === 'string' && g.trim().length > 0 && [...g].length <= 4;

function check_common(r: any, where: string): string | null {
  if (!SHAPES.includes(r.shape)) return `${where}: "shape" must be one of ${SHAPES.join(', ')}.`;
  if (r.shape === 'glyph' && !glyph_ok(r.glyph)) return `${where}: a "glyph" shape needs "glyph": 1 to 4 characters (e.g. "🎀").`;
  if (r.colors !== undefined) {
    if (!Array.isArray(r.colors) || r.colors.length < 1 || r.colors.length > LIMITS.colors || !r.colors.every(hex)) {
      return `${where}: "colors" must be 1 to ${LIMITS.colors} hex colours like "#ff6fa5".`;
    }
  }
  if (!Array.isArray(r.size) || r.size.length !== 2 || !in_range(r.size[0], 4, 60) || !in_range(r.size[1], 4, 60) || r.size[0] > r.size[1]) {
    return `${where}: "size" must be [min, max] in pixels, each 4 to 60, min not bigger than max.`;
  }
  return null;
}

export function check_tap_recipe(r: any, where: string): string | null {
  if (!is_obj(r)) return `${where} is not an object.`;
  const common = check_common(r, where);
  if (common) return common;
  if (!in_range(r.count, 1, 24)) return `${where}: "count" must be a whole number from 1 to 24.`;
  if (r.spread !== undefined && !in_range(r.spread, 0, 300)) return `${where}: "spread" must be 0 to 300.`;
  if (r.rise !== undefined && !in_range(r.rise, -200, 300)) return `${where}: "rise" must be -200 to 300.`;
  if (r.spin !== undefined && !in_range(r.spin, -720, 720)) return `${where}: "spin" must be -720 to 720 degrees.`;
  if (r.duration !== undefined && !in_range(r.duration, 200, 3000)) return `${where}: "duration" must be 200 to 3000 ms.`;
  if (r.grow !== undefined && typeof r.grow !== 'boolean') return `${where}: "grow" must be true or false.`;
  return null;
}

export function check_background_recipe(r: any, where: string): string | null {
  if (!is_obj(r)) return `${where} is not an object.`;
  const common = check_common(r, where);
  if (common) return common;
  if (!in_range(r.count, 1, 20)) return `${where}: "count" must be a whole number from 1 to 20.`;
  if (r.duration !== undefined && !in_range(r.duration, 8000, 60000)) return `${where}: "duration" must be 8000 to 60000 ms.`;
  if (r.opacity !== undefined && !in_range(r.opacity, 0.1, 0.8)) return `${where}: "opacity" must be 0.1 to 0.8.`;
  return null;
}

// Checks the whole "effects" block of a theme. Returns the first problem, or null.
export function check_effects(e: any): string | null {
  if (e === undefined) return null;
  if (!is_obj(e)) return '"effects" must be an object.';
  if (e.haptic !== undefined && typeof e.haptic !== 'boolean') return '"effects.haptic" must be true or false.';
  if (e.tap !== undefined) {
    if (!Array.isArray(e.tap) || e.tap.length > LIMITS.tap_recipes) return `"effects.tap" must be a list of up to ${LIMITS.tap_recipes} recipes.`;
    for (let i = 0; i < e.tap.length; i++) {
      const p = check_tap_recipe(e.tap[i], `Tap recipe ${i + 1}`);
      if (p) return p;
    }
    const pieces = e.tap.reduce((n: number, r: any) => n + r.count, 0);
    if (pieces > LIMITS.tap_pieces) return `The tap effect makes ${pieces} pieces per tap. The limit is ${LIMITS.tap_pieces}.`;
  }
  if (e.sound !== undefined) {
    const sp = check_sound(e.sound);
    if (sp) return sp;
  }
  if (e.background !== undefined) {
    if (!Array.isArray(e.background) || e.background.length > LIMITS.background_recipes) return `"effects.background" must be a list of up to ${LIMITS.background_recipes} recipes.`;
    for (let i = 0; i < e.background.length; i++) {
      const p = check_background_recipe(e.background[i], `Background recipe ${i + 1}`);
      if (p) return p;
    }
    const pieces = e.background.reduce((n: number, r: any) => n + r.count, 0);
    if (pieces > LIMITS.background_pieces) return `The background makes ${pieces} floating pieces. The limit is ${LIMITS.background_pieces}.`;
  }
  return null;
}

// Turns tap recipes into the particles the effect layer already knows how to animate.
export function tap_particles(recipes: tap_recipe[], rand: () => number = Math.random): particle[] {
  const out: particle[] = [];
  const between = (lo: number, hi: number) => lo + rand() * (hi - lo);
  for (const r of recipes) {
    const spread = r.spread ?? 90;
    const rise = r.rise ?? 0;
    const spin = ((r.spin ?? 0) * Math.PI) / 180;
    const duration = r.duration ?? 900;
    const colors = r.colors && r.colors.length ? r.colors : [];
    for (let i = 0; i < r.count; i++) {
      const a = between(-Math.PI, Math.PI);
      const dist = spread * between(0.5, 1);
      out.push({
        shape: r.shape,
        glyph: r.shape === 'glyph' ? r.glyph : undefined,
        dx: Math.cos(a) * dist,
        dy: Math.sin(a) * dist - rise,
        rot: spin * between(0.5, 1),
        size: between(r.size[0], r.size[1]),
        delay: between(0, 120),
        duration: duration * between(0.85, 1.1),
        color_slot: 0,
        color: colors.length ? colors[Math.floor(rand() * colors.length)] : undefined,
        grow: r.grow ?? false,
      });
    }
  }
  return out;
}

export type floater_piece = {
  shape: shape;
  glyph?: string;
  color?: string;
  size: number;
  duration: number;
  delay: number;
  left_pct: number;
  sway: number;
  opacity: number;
};

// Same list every time (no randomness), so the background never jumps when the screen redraws.
export function background_floaters(recipes: background_recipe[]): floater_piece[] {
  const out: floater_piece[] = [];
  let n = 0;
  for (const r of recipes) {
    for (let i = 0; i < r.count; i++, n++) {
      const lo = r.size[0], hi = r.size[1];
      out.push({
        shape: r.shape,
        glyph: r.shape === 'glyph' ? r.glyph : undefined,
        color: r.colors && r.colors.length ? r.colors[i % r.colors.length] : undefined,
        size: lo + ((i * 5 + n) % (hi - lo + 1)),
        duration: (r.duration ?? 16000) + ((n * 2300) % 9000),
        delay: (n * 1700) % 8000,
        left_pct: 6 + ((n * 37) % 86),
        sway: (n % 2 === 0 ? 1 : -1) * (14 + ((n * 7) % 16)),
        opacity: r.opacity ?? 0.35,
      });
    }
  }
  return out;
}
