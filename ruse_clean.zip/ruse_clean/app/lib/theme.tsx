import React, { createContext, useCallback, useContext, useState } from 'react';
import { load_saved, save_saved } from './store';
import type { Theme } from './types';

// ---- Built-in themes (v61 redesign). Calm, editorial, one accent each.
// Paper is the default, gender-neutral look: serif titles (Newsreader), Inter for everything else, no tap effects.
// `primary` and `accent` are the same hue on purpose: one accent per theme keeps the app quiet.
export const PAPER: Theme = {
  id: 'paper', name: 'Paper', font: 'Inter', heading_font: 'Newsreader', effect: 'none', radius: 16,
  button: { style: 'raised', shape: 'round', press: 'bounce', depth: 3, shine: false },
  colors: { bg: '#faf8f5', surface: '#ffffff', ink: '#1b1a17', muted: '#6b675f', line: '#e8e3db', primary: '#3d3a8f', primaryFg: '#ffffff', accent: '#3d3a8f', accentFg: '#ffffff' },
};
// Luxurious: near-black with warm ivory text and a single gold accent, sharper corners, serif titles.
export const OBSIDIAN_GOLD: Theme = {
  id: 'obsidian_gold', name: 'Obsidian Gold', font: 'Inter', heading_font: 'Newsreader', effect: 'none', radius: 10,
  button: { style: 'raised', shape: 'square', press: 'sink', depth: 3, shine: true, uppercase: true },
  colors: { bg: '#0d0d10', surface: '#16161a', ink: '#f3ead7', muted: '#a69c86', line: '#2b2822', primary: '#c9a45c', primaryFg: '#17120a', accent: '#e3c07a', accentFg: '#17120a' },
};
// Super cute: bubblegum pink and lavender, rounded Quicksand everywhere, big round corners,
// hearts that float up the page and burst where you tap.
export const SUGAR_BLOOM: Theme = {
  id: 'sugar_bloom', name: 'Sugar Bloom', font: 'Quicksand', heading_font: 'Quicksand', effect: 'hearts', radius: 28,
  button: { style: 'raised', shape: 'pill', press: 'wiggle', depth: 5, shine: true },
  colors: { bg: '#fff0f6', surface: '#fffafc', ink: '#4a2540', muted: '#8c6684', line: '#f9d4e6', primary: '#d63384', primaryFg: '#ffffff', accent: '#8b5cf6', accentFg: '#ffffff' },
};
// Built-ins: Paper is the default and suits everyone; the other two are a choice.
// Old saved ids (the pastel set, Ink, Blush) fall back to Paper.
export const BUILT_IN = [PAPER, OBSIDIAN_GOLD, SUGAR_BLOOM];
export const DEFAULT_THEME = PAPER;

// Gender only suggests a starting look in the profile screens; Skip keeps the neutral default.
export function main_theme_id_for_gender(g: string | null | undefined): string | null {
  if (g === 'boy') return OBSIDIAN_GOLD.id;
  if (g === 'girl') return SUGAR_BLOOM.id;
  return null;
}
const SAVED_THEME = 'theme_id';

// True when this theme is tied to one novel and must not appear in Settings → theme picker.
export const is_novel_theme = (t: { forSubject?: string } | null | undefined): boolean =>
  typeof t?.forSubject === 'string' && t.forSubject.trim().length > 0;

type Ctx = {
  theme: Theme;              // effective theme (override if set, else the saved global one)
  global_theme: Theme;       // the Settings / saved choice (never a novel-exclusive theme)
  themes: Theme[];           // global picker list only (built-ins + free uploaded themes)
  all_themes: Theme[];       // includes novel-exclusive themes (for E4 / novel screens)
  setThemes: (t: Theme[]) => void;
  pick: (id: string) => void;
  theme_for_novel: (subject_id: string) => Theme | null; // recommended / exclusive theme for a novel
  /** Temporary override while reading a novel (E4). Pass null to clear. Does not change the saved global theme. */
  set_theme_override: (t: Theme | null) => void;
};
const ThemeCtx = createContext<Ctx>(null as unknown as Ctx);
export const useTheme = () => useContext(ThemeCtx);

export function ThemeProvider({ children }: { children: React.ReactNode }) {
  const [custom, setCustom] = useState<Theme[]>([]);
  // The chosen theme is remembered on the phone (a preference, so it stays after sign out).
  const [id, setId] = useState<string>(() => load_saved<string>(SAVED_THEME) || DEFAULT_THEME.id);
  const [override, setOverride] = useState<Theme | null>(null);
  const pick = useCallback((next: string) => { setId(next); save_saved(SAVED_THEME, next); }, []);
  const set_theme_override = useCallback((t: Theme | null) => { setOverride(t); }, []);

  const all_themes = [...BUILT_IN, ...custom.filter((t) => !BUILT_IN.some((b) => b.id === t.id))];
  // Global picker: never show themes uploaded for a specific novel — those stay on the novel.
  const themes = all_themes.filter((t) => !is_novel_theme(t));
  // If the saved id points at a novel-only theme (or a deleted one), fall back to default.
  const global_theme = themes.find((t) => t.id === id) || DEFAULT_THEME;
  // Effective theme for the current screen: novel override wins while set.
  const theme = override || global_theme;

  const theme_for_novel = useCallback((subject_id: string): Theme | null => {
    const sid = (subject_id || '').trim();
    if (!sid) return null;
    return all_themes.find((t) => is_novel_theme(t) && t.forSubject!.trim() === sid) || null;
  }, [all_themes]);

  return (
    <ThemeCtx.Provider value={{
      theme, global_theme, themes, all_themes, setThemes: setCustom, pick, theme_for_novel, set_theme_override,
    }}>
      {children}
    </ThemeCtx.Provider>
  );
}
