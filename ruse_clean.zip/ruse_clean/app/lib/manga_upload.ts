// Author flow for a manga chapter made from phone photos (Phase E2, folder upload).
// Photos are picked, shrunk on the phone, uploaded one by one into the novel's Drive folder,
// then saved as one chapter whose "pages" are the links the server returns.
// Needs expo-image-picker and expo-image-manipulator in the build (the cover photo already uses them).
import { api } from './backend';
import { ACTION_SAVE_CHAPTER, ACTION_UPLOAD_ASSET } from './actions';
import { check_pages, MAX_PAGES } from './manga';

const MAX_EDGE = 1200;
const JPEG_QUALITY = 0.8;

export type manga_upload_result = { ok: true; count: number; chapter_id: string } | { ok: false; error: string };

export async function upload_manga_chapter(args: {
  subject_id: string;
  folder_id: string;
  title: string;
  order: number;
  on_progress: (done: number, total: number) => void;
}): Promise<manga_upload_result> {
  const title = args.title.trim();
  if (!title) return { ok: false, error: 'Type a title for the chapter first.' };
  if (!args.folder_id) return { ok: false, error: 'This novel has no Drive folder yet.' };

  let assets: { uri: string }[] = [];
  try {
    const ImagePicker = await import('expo-image-picker');
    const perm = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (!perm.granted) return { ok: false, error: 'Photo access is needed to pick the pages.' };
    const picked = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ['images'],
      allowsMultipleSelection: true,
      selectionLimit: MAX_PAGES,
      quality: 1,
      orderedSelection: true, // keep the order the author tapped them in
    } as any);
    if (picked.canceled || !picked.assets?.length) return { ok: false, error: 'cancelled' };
    assets = picked.assets;
  } catch (e: any) {
    return { ok: false, error: /ExpoImagePicker|Cannot find module|Native module/i.test(String(e?.message)) ? 'Photo picker needs a new app build (expo-image-picker).' : 'Could not open the photos.' };
  }

  if (assets.length > MAX_PAGES) return { ok: false, error: `Pick at most ${MAX_PAGES} pages. Split the chapter in two.` };

  let Manipulator: any;
  // @ts-ignore expo-image-manipulator is an optional package
  try { Manipulator = await import('expo-image-manipulator'); }
  catch { return { ok: false, error: 'Page resizing needs expo-image-manipulator in the build.' }; }

  const stamp = Date.now().toString(36);
  const urls: string[] = [];
  for (let i = 0; i < assets.length; i++) {
    args.on_progress(i, assets.length);
    try {
      const out = await Manipulator.manipulateAsync(
        assets[i].uri,
        [{ resize: { width: MAX_EDGE } }],
        { compress: JPEG_QUALITY, format: Manipulator.SaveFormat.JPEG, base64: true },
      );
      if (!out.base64) return { ok: false, error: `Page ${i + 1}: could not read the photo.` };
      const up = await api<{ url?: string }>(ACTION_UPLOAD_ASSET, {
        folderId: args.folder_id,
        name: `manga-${stamp}-${String(i + 1).padStart(3, '0')}.jpg`,
        mime: 'image/jpeg',
        base64: out.base64,
        kind: 'manga-page',
      });
      const url = typeof up?.url === 'string' ? up.url.trim() : '';
      if (!url) return { ok: false, error: `Page ${i + 1} uploaded, but the server did not return a link. Backend: uploadAsset must return { url }.` };
      urls.push(url);
    } catch (e: any) {
      return { ok: false, error: `Page ${i + 1} failed: ${e?.message || 'upload problem'}. Pages sent so far are not saved as a chapter.` };
    }
  }
  args.on_progress(assets.length, assets.length);

  const problem = check_pages(urls, 'The chapter');
  if (problem) return { ok: false, error: problem };

  const chapter_id = `ch-${stamp}`;
  try {
    await api(ACTION_SAVE_CHAPTER, {
      schemaVersion: 1,
      id: chapter_id,
      subject: args.subject_id,
      order: args.order,
      title,
      minutes: Math.max(1, Math.round(urls.length / 10)),
      pages: urls,
    });
  } catch (e: any) {
    return { ok: false, error: `Pages uploaded, but the chapter was not saved: ${e?.message || 'try again'}.` };
  }
  return { ok: true, count: urls.length, chapter_id };
}
