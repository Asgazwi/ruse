import {
  apply_ops, empty_snapshot, new_id, norm_comments, norm_failed, norm_pins, pins_key, push_op,
  type Comment, type Failed, type PinOp, type Queued, type Snapshot,
} from './pin_helpers';
import {
  ACTION_ADD_BLOCK_AFTER_COMMENT, ACTION_DELETE_COMMENT, ACTION_DELETE_PIN, ACTION_GET_COMMENTS,
  ACTION_GET_PINS, ACTION_REPLY_COMMENT, ACTION_SAVE_COMMENT, ACTION_SAVE_PIN,
} from './actions';

// ---------------------------------------------------------------
// The pins + comments store, without React (so it can be tested).
//  - every change is applied on the phone first and put on a waiting list
//  - the waiting list is saved on the phone, and sent when the network is back
//  - every request is safe to send twice (pins replace, comments carry their own id)
//  - if the server says no, the change moves to a "not sent" list (with the reason) and stays
//    on the phone until the reader retries or discards it. Nothing typed is lost silently.
// ---------------------------------------------------------------
export type StoreDeps = {
  call: (action: string, ...args: any[]) => Promise<any>;
  load: (key: string) => any;
  save: (key: string, value: unknown) => void;
  is_network_error: (e: unknown) => boolean;
  now: () => number;
  rand: () => number;
};

export type StoreState = {
  email: string | null;
  snap: Snapshot;          // last copy from the server
  queue: Queued[];         // changes waiting to be sent
  failed: Failed[];        // changes the server refused, kept so they can be retried or discarded
  view: Snapshot;          // snap + queue: what the screens show
  syncing: boolean;
  offline: boolean;
  error: string | null;    // the server said no to something
  synced_at: number | null;
};

const blank = (email: string | null): StoreState => ({
  email, snap: empty_snapshot(), queue: [], failed: [], view: empty_snapshot(), syncing: false, offline: false, error: null, synced_at: null,
});
const message = (e: unknown) => String((e as any)?.message || e || 'Something went wrong.');

export function create_pin_store(deps: StoreDeps) {
  let state: StoreState = blank(null);
  let seq = 0;
  let flushing: Promise<void> | null = null;
  let again = false;
  let pulling: Promise<void> | null = null;
  const listeners = new Set<() => void>();

  const next_n = () => ++seq;
  const notify = () => listeners.forEach((l) => l());

  function set(patch: Partial<StoreState>) {
    const next = { ...state, ...patch };
    const changed = patch.snap !== undefined || patch.queue !== undefined;
    if (changed) next.view = apply_ops(next.snap, next.queue.map((q) => q.op));
    state = next;
    if ((changed || patch.failed !== undefined) && state.email) {
      deps.save(pins_key(state.email), { snap: state.snap, queue: state.queue, failed: state.failed });
    }
    notify();
  }

  // Which account is signed in. Saved changes are kept per account.
  function init(email: string | null) {
    const who = email ? email.toLowerCase() : null;
    if (who === state.email) return;
    state = blank(who);
    if (who) {
      const saved = deps.load(pins_key(who));
      if (saved && Array.isArray(saved.queue) && saved.snap) {
        const queue: Queued[] = saved.queue.filter((q: any) => q && Number.isInteger(q.n) && q.op && typeof q.op.kind === 'string');
        const failed = norm_failed(saved.failed); // older saved files have no such list: that is fine
        seq = Math.max(seq, ...queue.map((q) => q.n), ...failed.map((f) => f.n), 0);
        const snap = { pins: norm_pins(saved.snap.pins), comments: norm_comments(saved.snap.comments) };
        state = { ...state, snap, queue, failed, view: apply_ops(snap, queue.map((q) => q.op)) };
      }
    }
    notify();
  }

  function send(op: PinOp): Promise<unknown> {
    switch (op.kind) {
      case 'pin': return deps.call(ACTION_SAVE_PIN, { chapter: op.chapter, block: op.block });
      case 'unpin': return deps.call(ACTION_DELETE_PIN, op.chapter);
      case 'comment': return deps.call(ACTION_SAVE_COMMENT, { id: op.id, chapter: op.chapter, block: op.block, text: op.text });
      case 'uncomment': return deps.call(ACTION_DELETE_COMMENT, op.id);
      case 'reply': return deps.call(ACTION_REPLY_COMMENT, { id: op.id, parent: op.parent, text: op.text });
    }
  }

  // Send the waiting list, oldest first. Stops (and keeps the rest) when the network is down.
  async function drain() {
    const who = state.email;
    while (who && state.email === who && state.queue.length) {
      const item = state.queue[0];
      try {
        await send(item.op);
        if (state.email !== who) return;
        set({ offline: false });
      } catch (e) {
        if (state.email !== who) return;
        if (deps.is_network_error(e)) { set({ offline: true }); return; }
        // The server said no (for example the chapter was removed). Do NOT drop it: move it to the
        // "not sent" list with the reason, so the text can be seen, retried or discarded.
        const reason = message(e);
        set({
          error: reason,
          failed: [...state.failed, { n: item.n, op: item.op, message: reason }],
          queue: state.queue.filter((q) => q.n !== item.n),
        });
        continue;
      }
      set({ queue: state.queue.filter((q) => q.n !== item.n) });
    }
  }

  function flush(): Promise<void> {
    if (flushing) { again = true; return flushing; }
    flushing = (async () => {
      try { do { again = false; await drain(); } while (again); } finally { flushing = null; }
    })();
    return flushing;
  }

  async function pull_once() {
    const who = state.email;
    if (!who) return;
    set({ syncing: true });
    try {
      await flush();
      if (state.email !== who) return;
      if (state.queue.length) return; // still waiting to send: do not replace anything
      const [pins, comments] = await Promise.all([deps.call(ACTION_GET_PINS), deps.call(ACTION_GET_COMMENTS)]);
      if (state.email !== who) return;
      set({ snap: { pins: norm_pins(pins), comments: norm_comments(comments) }, offline: false, error: null, synced_at: deps.now() });
    } catch (e) {
      if (state.email !== who) return;
      if (deps.is_network_error(e)) set({ offline: true });
      else set({ error: message(e) });
    } finally {
      if (state.email === who) set({ syncing: false });
    }
  }

  function sync(opts?: { max_age_ms?: number }): Promise<void> {
    const age = state.synced_at ? deps.now() - state.synced_at : Infinity;
    if (opts?.max_age_ms !== undefined && age < opts.max_age_ms && !state.queue.length) return Promise.resolve();
    if (pulling) return pulling;
    pulling = pull_once().finally(() => { pulling = null; });
    return pulling;
  }

  function enqueue(op: PinOp) {
    if (!state.email) return;
    set({ queue: push_op(state.queue, op, next_n), error: null });
    void flush();
  }

  // ---- What the screens call ----
  const find = (id: string): Comment | undefined => state.view.comments.find((c) => c.id === id);
  return {
    init, sync, flush,
    get: () => state,
    subscribe: (l: () => void) => { listeners.add(l); return () => { listeners.delete(l); }; },

    set_pin: (chapter: { id: string; subject: string }, block: number) =>
      enqueue({ kind: 'pin', chapter: chapter.id, subject: chapter.subject, block, at: deps.now() }),
    remove_pin: (chapter_id: string) => enqueue({ kind: 'unpin', chapter: chapter_id }),

    add_comment: (a: { chapter_id: string; subject: string; block: number; text: string; name: string }): string => {
      const id = new_id(deps.now(), deps.rand);
      enqueue({ kind: 'comment', id, chapter: a.chapter_id, subject: a.subject, block: a.block, text: a.text, name: a.name, at: deps.now() });
      return id;
    },
    edit_comment: (id: string, text: string) => {
      const c = find(id);
      if (!c || !c.mine || c.parent) return;
      enqueue({ kind: 'comment', id, chapter: c.chapter, subject: c.subject, block: c.block, text, name: c.name, at: deps.now() });
    },
    delete_comment: (id: string) => enqueue({ kind: 'uncomment', id }),
    reply: (a: { parent: Comment; text: string; name: string; as_uploader: boolean }): string => {
      const id = new_id(deps.now(), deps.rand);
      enqueue({ kind: 'reply', id, parent: a.parent.id, text: a.text, name: a.name, as_uploader: a.as_uploader, at: deps.now() });
      return id;
    },

    // Put every refused change back on the waiting list and try again.
    retry_failed: () => {
      if (!state.email || !state.failed.length) return;
      let queue = state.queue;
      for (const f of state.failed) queue = push_op(queue, f.op, next_n);
      set({ failed: [], queue, error: null });
      void flush();
    },
    // Throw refused changes away: one (by its number) or all of them.
    discard_failed: (n?: number) => {
      const left = n === undefined ? [] : state.failed.filter((f) => f.n !== n);
      set({ failed: left, error: left.length ? state.error : null });
    },

    // Needs the network (a retry could add the block twice), so it is not put on the waiting list.
    add_block_after: async (comment_id: string, block: unknown) => {
      const r = await deps.call(ACTION_ADD_BLOCK_AFTER_COMMENT, { comment: comment_id, block });
      await sync();
      return r as { chapter: string; block: number };
    },
  };
}
