import { save_home_bg_from_uri } from './home_bg';

// null = the person closed the photo picker without choosing.
export type bg_outcome = { ok: true; uri: string } | { ok: false; text: string } | null;

// Pick a photo for the Home screen background. It is kept only on this phone.
export async function pick_home_background(): Promise<bg_outcome> {
  try {
    const ImagePicker = await import('expo-image-picker');
    const perm = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (!perm.granted) return { ok: false, text: 'Photo access is needed to pick a Home background.' };
    const picked = await ImagePicker.launchImageLibraryAsync({ mediaTypes: ['images'], quality: 0.85, allowsEditing: true, aspect: [9, 16] });
    if (picked.canceled || !picked.assets?.length) return null;
    return { ok: true, uri: await save_home_bg_from_uri(picked.assets[0].uri) };
  } catch (e: any) {
    const msg = String(e?.message || e || '');
    if (/ExpoImagePicker|Native module|Cannot find module/i.test(msg)) return { ok: false, text: 'The photo picker needs a new app build (expo-image-picker).' };
    return { ok: false, text: msg || 'Could not set the background.' };
  }
}
