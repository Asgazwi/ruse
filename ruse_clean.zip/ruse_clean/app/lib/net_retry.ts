// ---------------------------------------------------------------
// Pure helpers for "the network is shaky". No React, no Expo, so they are easy to test.
//   kind 'network' = we never got a real answer (no signal, timeout, server sent a web page)
//   kind 'backend' = the backend answered and said no (wrong input, no permission...)
// Only 'network' errors are retried, and only 'network' errors switch the app to offline mode.
// ---------------------------------------------------------------
export type error_kind = 'network' | 'backend';

export function make_error(message: string, kind: error_kind): Error {
  return Object.assign(new Error(message), { kind });
}

export const is_network_error = (e: unknown): boolean => (e as any)?.kind === 'network';

export const sleep = (ms: number) => new Promise<void>((resolve) => setTimeout(resolve, ms));

// Runs `attempt`. If it fails with a network error, waits and tries again,
// once per entry in `waits_ms` (so [800, 1600] = 1 try + 2 retries).
export async function run_with_retry<T>(
  attempt: () => Promise<T>,
  waits_ms: number[],
  wait: (ms: number) => Promise<void> = sleep,
): Promise<T> {
  for (let i = 0; ; i += 1) {
    try {
      return await attempt();
    } catch (e) {
      if (!is_network_error(e) || i >= waits_ms.length) throw e;
      await wait(waits_ms[i]);
    }
  }
}

// Waits for `promise`, but gives up after `ms` and answers TIMED_OUT instead (Phase A7: the app must not
// sit on a spinner when Google never answers offline). ms <= 0 means "wait as long as it takes".
// The slow promise is left alone; if it fails later, that failure is swallowed.
export const TIMED_OUT = Symbol('timed_out');
export function race_timeout<T>(promise: Promise<T>, ms: number): Promise<T | typeof TIMED_OUT> {
  if (ms <= 0) return promise;
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => resolve(TIMED_OUT), ms);
    promise.then(
      (v) => { clearTimeout(timer); resolve(v); },
      (e) => { clearTimeout(timer); reject(e); },
    );
  });
}
