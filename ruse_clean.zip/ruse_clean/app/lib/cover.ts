// Book-cover colours. A novel has no cover picture, so one is drawn from its title: the same title always
// gets the same colours. Muted on purpose, so a shelf of them looks like a library, not a candy shop.
export const COVER_COLORS: { bg: string; ring: string }[] = [
  { bg: '#2f3a5f', ring: '#9db0e8' }, // navy
  { bg: '#8a4b3a', ring: '#f0b9a5' }, // clay
  { bg: '#3e5b4d', ring: '#a9d1b9' }, // pine
  { bg: '#5b3f6b', ring: '#d2b3e6' }, // plum
  { bg: '#4a4a52', ring: '#c9c9d4' }, // slate
  { bg: '#7a5a2e', ring: '#ecd29c' }, // ochre
];

export function cover_for(title: string): { bg: string; ring: string } {
  let h = 0;
  for (let i = 0; i < title.length; i++) h = (h * 31 + title.charCodeAt(i)) >>> 0;
  return COVER_COLORS[h % COVER_COLORS.length];
}
