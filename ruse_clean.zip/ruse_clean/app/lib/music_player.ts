// The player for background music (F2). One player for the whole app, so the music keeps going
// while you turn chapters of the same novel, and stops when you leave the novel or put the app away.
// Native only (expo-audio, already in the app). A failure here must never break reading.
import { AppState } from 'react-native';
import { createAudioPlayer, setAudioModeAsync, type AudioPlayer } from 'expo-audio';
import { DUCK_MS, STOP_DELAY_MS, clamp_volume, ducked_volume } from './music';

let player: AudioPlayer | null = null;
let playing_url: string | null = null;
let playing_subject: string | null = null;
let stop_timer: ReturnType<typeof setTimeout> | null = null;
let volume = 0.4;
let muted = false;
let mode_ready = false;
let ducked = false;
let duck_timer: ReturnType<typeof setTimeout> | null = null;

const cancel_stop = () => { if (stop_timer) { clearTimeout(stop_timer); stop_timer = null; } };

// Start (or keep) the track for a novel. Same track already playing = leave it alone (no restart).
export async function play_music(subject_id: string, url: string, v: number, is_muted: boolean): Promise<void> {
  try {
    cancel_stop();
    volume = clamp_volume(v);
    muted = is_muted;
    if (player && playing_url === url) { apply(); return; }
    if (!mode_ready) { mode_ready = true; await setAudioModeAsync({ playsInSilentMode: false }).catch(() => {}); }
    stop_now();
    player = createAudioPlayer({ uri: url });
    player.loop = true;
    playing_url = url;
    playing_subject = subject_id;
    apply();
    player.play();
  } catch {
    /* music is a bonus: a failure just means no music */
  }
}

function apply() {
  if (!player) return;
  player.volume = ducked_volume(muted ? 0 : volume, ducked);
}

// F3: drop the music for a moment (a tap sound is playing), then bring it back.
// Calling it again while ducked just starts the countdown over.
export function duck_music(ms: number = DUCK_MS): void {
  if (!player) return;
  ducked = true;
  apply();
  if (duck_timer) clearTimeout(duck_timer);
  duck_timer = setTimeout(() => { ducked = false; duck_timer = null; apply(); }, ms);
}

export function set_music_volume(v: number) { volume = clamp_volume(v); apply(); }
export function set_music_muted(m: boolean) { muted = m; apply(); }

// Called when the reader leaves a chapter. Waits a moment: the next chapter of the same novel cancels it.
export function schedule_stop(subject_id: string): void {
  cancel_stop();
  stop_timer = setTimeout(() => { if (playing_subject === subject_id) stop_now(); }, STOP_DELAY_MS);
}

function stop_now() {
  cancel_stop();
  try { player?.pause(); player?.remove(); } catch { /* already gone */ }
  player = null;
  playing_url = null;
  playing_subject = null;
}

export const stop_music = () => stop_now();

// Put the app away = stop. (Coming back does not restart it; the reader presses play.)
AppState.addEventListener('change', (state) => { if (state !== 'active') stop_now(); });
