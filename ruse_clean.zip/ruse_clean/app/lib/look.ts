// ---------------------------------------------------------------
// Pure helpers for the "adorable look" (Phase 4b): colors, fonts, floating shapes.
// No React / Expo here, so they are easy to test.
// ---------------------------------------------------------------
const rgb = (hex: string): [number, number, number] => [1, 3, 5].map((i) => parseInt(hex.slice(i, i + 2), 16)) as [number, number, number];
const to_hex = (n: number) => Math.max(0, Math.min(255, Math.round(n))).toString(16).padStart(2, '0');

// Blend two #rrggbb colors. t = 0 gives `a`, t = 1 gives `b`.
export function mix_hex(a: string, b: string, t: number): string {
  const [ar, ag, ab] = rgb(a);
  const [br, bg, bb] = rgb(b);
  return `#${to_hex(ar + (br - ar) * t)}${to_hex(ag + (bg - ag) * t)}${to_hex(ab + (bb - ab) * t)}`;
}

// Smooth top-to-bottom gradient made of `n` thin bands (no extra native package needed).
export function gradient_steps(from: string, to: string, n: number): string[] {
  const count = Math.max(2, Math.floor(n));
  return Array.from({ length: count }, (_, i) => mix_hex(from, to, i / (count - 1)));
}

// The app's text uses Figtree names. When a theme asks for Quicksand, swap them.
// Only the two fonts that are really loaded are ever returned.
export function map_font(family: string | undefined, theme_font: string): string | undefined {
  if (!family || theme_font !== 'Quicksand') return family;
  if (family === 'Figtree_700Bold') return 'Quicksand_700Bold';
  if (family === 'Figtree_500Medium') return 'Quicksand_500Medium';
  return family;
}

// Shape that floats in the background for each tap effect.
export function glyph_for_effect(effect: string): string {
  switch (effect) {
    case 'hearts': return '♥';
    case 'petals': return '✿';
    case 'sparkle': return '✦';
    case 'confetti': return '✦';
    case 'bubbles': return '○';
    case 'pop': return '●';
    case 'ripple': return '○';
    default: return '';
  }
}

export type floater = { left_pct: number; size: number; duration: number; delay: number; sway: number };

// Same list every time, so the background never "jumps" when the screen redraws.
export function floater_plan(count: number): floater[] {
  return Array.from({ length: count }, (_, i) => ({
    left_pct: 6 + ((i * 37) % 86),
    size: 14 + ((i * 5) % 12),
    duration: 14000 + ((i * 2300) % 9000),
    delay: (i * 1700) % 8000,
    sway: (i % 2 === 0 ? 1 : -1) * (14 + ((i * 7) % 16)),
  }));
}

// Four friendly colors that cycle over the course cards' top strips.
export function card_palette(c: { primary: string; accent: string }): string[] {
  return [c.accent, c.primary, mix_hex(c.accent, c.primary, 0.5), mix_hex(c.accent, '#ffd166', 0.55)];
}

export const badge_letter = (title: string): string => (title.trim().charAt(0) || '•').toUpperCase();
