// Saves manga pages on the phone for offline reading (Phase E2). Native only.
// Now a thin layer over lib/downloads.ts, so every download is recorded and removed on sign-out.
import { download_one, local_for } from './downloads';

// The phone's copy of a page, or null when it is not saved yet.
export function saved_page_uri(url: string): string | null {
  return local_for(url);
}

// Downloads every page that is not saved yet. Reports progress; one failed page does not stop the rest.
export async function save_pages(urls: string[], on_progress: (done: number, total: number) => void): Promise<{ saved: number; failed: number }> {
  let saved = 0;
  let failed = 0;
  for (let i = 0; i < urls.length; i++) {
    (await download_one(urls[i])) ? saved++ : failed++;
    on_progress(i + 1, urls.length);
  }
  return { saved, failed };
}
