// Downloads for offline use (native only). A novel can be downloaded: its manga pages, its soundtrack
// and its background photo are saved on the phone, so they work in airplane mode.
// Every file is recorded in one small index on the phone, so sign-out can remove them all.
import { File, Paths } from 'expo-file-system';
import { load_saved, save_saved } from './store';
import { page_key, manga_pages } from './manga';
import type { Chapter, Subject } from './types';

const INDEX = 'downloads';                        // { [remote link]: file uri on this phone }
type Index = Record<string, string>;
const https = (u: unknown): u is string => typeof u === 'string' && /^https:\/\/\S+$/.test(u.trim());
const load = (): Index => load_saved<Index>(INDEX) ?? {};

// The phone's copy of a link, if it was downloaded and the file still exists; otherwise null.
export function local_for(url: string | null | undefined): string | null {
  if (!https(url)) return null;
  const uri = load()[url.trim()];
  if (!uri) return null;
  try { return new File(uri).exists ? uri : null; } catch { return null; }
}

// Use the phone's copy when there is one, otherwise the link itself.
export const resolve = (url: string | null | undefined): string | null => local_for(url) ?? (https(url) ? url.trim() : null);

// Every link a novel needs offline.
export function links_for(subject: Subject | null | undefined, chapters: Chapter[]): string[] {
  if (!subject) return [];
  const out: string[] = [];
  if (https(subject.backgroundUrl)) out.push(subject.backgroundUrl.trim());
  if (https(subject.musicUrl)) out.push(subject.musicUrl.trim());
  for (const ch of chapters) if (ch.subject === subject.id) out.push(...manga_pages(ch));
  return [...new Set(out)];
}

export const is_downloaded = (url: string): boolean => !!local_for(url);

// Downloads one link (skipped if already there). Returns true when the file is on the phone.
export async function download_one(url: string): Promise<boolean> {
  if (!https(url)) return false;
  const key = url.trim();
  if (local_for(key)) return true;
  try {
    const res = await fetch(key);
    if (!res.ok) return false;
    const bytes = new Uint8Array(await res.arrayBuffer());
    const f = new File(Paths.document, `ruse_dl_${page_key(key)}.bin`);
    if (f.exists) f.delete();
    f.create();
    f.write(bytes);
    save_saved(INDEX, { ...load(), [key]: f.uri });
    return true;
  } catch {
    return false;
  }
}

// Saves one soundtrack on the phone (v63). Refuses a link that is not an audio file, and says why.
// Saved in the app's own storage (Paths.document), never in Downloads or the gallery.
export async function download_track(url: string): Promise<{ ok: true } | { ok: false; error: string }> {
  if (!https(url)) return { ok: false, error: 'This track has no valid https link.' };
  const key = url.trim();
  if (local_for(key)) return { ok: true };
  try {
    const res = await fetch(key);
    if (!res.ok) return { ok: false, error: `The track could not be downloaded (error ${res.status}).` };
    const type = (res.headers.get('content-type') ?? '').toLowerCase();
    if (!(type.startsWith('audio/') || type === 'application/octet-stream')) {
      return { ok: false, error: 'This link is not an audio file, so it cannot be saved.' };
    }
    const bytes = new Uint8Array(await res.arrayBuffer());
    const f = new File(Paths.document, `ruse_dl_${page_key(key)}.bin`);
    if (f.exists) f.delete();
    f.create();
    f.write(bytes);
    save_saved(INDEX, { ...load(), [key]: f.uri });
    return { ok: true };
  } catch {
    return { ok: false, error: 'Could not save the track. Check your connection and try again.' };
  }
}

// How many files this phone keeps for offline use (Settings shows it).
export const saved_count = (): number => Object.keys(load()).length;

// Space the saved files use, in bytes (Settings shows it).
export function saved_bytes(): number {
  let total = 0;
  for (const uri of Object.values(load())) {
    try { const f = new File(uri); if (f.exists) total += f.size ?? 0; } catch { /* already gone */ }
  }
  return total;
}

export function size_label(bytes: number): string {
  if (bytes < 1024 * 1024) return `${Math.max(1, Math.round(bytes / 1024))} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(bytes < 10 * 1024 * 1024 ? 1 : 0)} MB`;
}

// Downloads everything a novel needs. Reports progress; one failed file does not stop the rest.
export async function download_novel(
  subject: Subject,
  chapters: Chapter[],
  on_progress: (done: number, total: number) => void,
): Promise<{ saved: number; failed: number }> {
  const all = links_for(subject, chapters);
  let saved = 0;
  let failed = 0;
  for (let i = 0; i < all.length; i++) {
    (await download_one(all[i])) ? saved++ : failed++;
    on_progress(i + 1, all.length);
  }
  return { saved, failed };
}

export const novel_downloaded = (subject: Subject | null | undefined, chapters: Chapter[]): boolean => {
  const all = links_for(subject, chapters);
  return all.length > 0 && all.every((u) => is_downloaded(u));
};

// Removes the files of one novel from the phone and from the index.
export function remove_novel(subject: Subject | null | undefined, chapters: Chapter[]): void {
  const index = load();
  for (const url of links_for(subject, chapters)) {
    const uri = index[url];
    if (uri) { try { const f = new File(uri); if (f.exists) f.delete(); } catch { /* already gone */ } }
    delete index[url];
  }
  save_saved(INDEX, index);
}

// Sign-out: remove every download from the phone.
export function delete_all_downloads(): void {
  const index = load();
  for (const uri of Object.values(index)) {
    try { const f = new File(uri); if (f.exists) f.delete(); } catch { /* already gone */ }
  }
  save_saved(INDEX, {});
}
