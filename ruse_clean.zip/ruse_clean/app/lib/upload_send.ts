import { api } from './backend';
import { ACTION_SAVE_CHAPTER, ACTION_SAVE_COURSE, ACTION_SAVE_THEME } from './actions';
import { strip_hints, type parsed_upload } from './upload_check';
import { W } from './words';

// Sends an already-checked upload to the backend and returns a friendly message.
// Not retried on purpose: a retry after a half-finished save could create duplicates.
export async function send_upload(upload: Extract<parsed_upload, { ok: true }>): Promise<string> {
  const kind = upload.kind;
  const data = strip_hints(upload.data);

  if (kind === 'novel') {
    // TEMP: the Apps Script backend still reads "course". Remove this alias when saveCourseBundle moves to Supabase.
    const r = await api<{ id?: string; chapters?: number }>(ACTION_SAVE_COURSE, { ...data, course: data.novel });
    const count = r?.chapters ?? data.chapters.length;
    return `${W.Novel} “${data.novel.title}” saved with ${count} chapter${count === 1 ? '' : 's'}.`;
  }

  if (kind === 'theme') {
    // Everything in the theme file goes over; the backend checks it again and makes the id.
    // forSubject (E4) links the theme to one novel — it stays off the global picker.
    const { id, createdBy, ...theme } = data;
    if (typeof theme.forSubject === 'string' && !theme.forSubject.trim()) delete theme.forSubject;
    await api(ACTION_SAVE_THEME, theme);
    if (theme.forSubject) {
      return `Theme “${data.name}” saved for that ${W.novel} only. Readers will see a recommend banner.`;
    }
    return `Theme “${data.name}” saved. Everyone can pick it in Settings.`;
  }

  // 'chapter' or 'chapters': one call per chapter, so say how far we got if one fails.
  const list: any[] = kind === 'chapters' ? data : [data];
  let saved = 0;
  try {
    for (const chapter of list) {
      await api(ACTION_SAVE_CHAPTER, chapter);
      saved += 1;
    }
  } catch (e: any) {
    throw new Error(`Saved ${saved} of ${list.length} chapters, then: ${e?.message || 'upload failed.'}`);
  }
  return `Saved ${saved} chapter${saved === 1 ? '' : 's'}.`;
}
