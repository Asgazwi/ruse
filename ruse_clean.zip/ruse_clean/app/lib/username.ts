// ---------------------------------------------------------------
// Unique usernames (Phase D1a). Pure logic only — easy to test.
// Rules: 3–20 chars; letters, digits, _ or . ; no spaces; case-insensitive uniqueness;
// change at most once every 30 days (server enforces; client can warn).
// ---------------------------------------------------------------

export const USERNAME_MIN = 3;
export const USERNAME_MAX = 20;
export const USERNAME_CHANGE_DAYS = 30;

// Reserved / blocked (case-insensitive). Keep short; server should mirror this.
const BLOCKED = new Set(
  [
    'admin', 'administrator', 'owner', 'mod', 'moderator', 'support', 'help',
    'ruse', 'system', 'null', 'undefined', 'everyone', 'all', 'me', 'you',
    'reader', 'author', 'official', 'staff', 'root', 'test', 'guest',
  ].map((w) => w.toLowerCase()),
);

const OK = /^[a-zA-Z0-9_.]+$/;

export function normalize_username(raw: string): string {
  return raw.trim();
}

/** Lowercase form used for uniqueness checks. */
export function username_key(name: string): string {
  return normalize_username(name).toLowerCase();
}

/**
 * First problem with a proposed username, or null if it looks fine locally.
 * Server still has the final say (unique, blocked list, rate limit).
 */
export function check_username_local(raw: string): string | null {
  const t = normalize_username(raw);
  if (!t) return 'Type a username.';
  if (t.length < USERNAME_MIN) return `At least ${USERNAME_MIN} characters.`;
  if (t.length > USERNAME_MAX) return `At most ${USERNAME_MAX} characters.`;
  if (/\s/.test(t)) return 'No spaces.';
  if (!OK.test(t)) return 'Only letters, digits, _ and .';
  if (BLOCKED.has(username_key(t))) return 'That name is reserved. Try another.';
  if (/^[._]/.test(t) || /[._]$/.test(t)) return 'Do not start or end with _ or .';
  if (/[._]{2,}/.test(t)) return 'No repeated _ or . in a row.';
  return null;
}

/** True when the person may change username again (client hint; server decides). */
export function can_change_username(changed_at: string | number | null | undefined, now = Date.now()): boolean {
  if (changed_at == null || changed_at === '') return true;
  const ms = typeof changed_at === 'number' ? changed_at : Date.parse(String(changed_at));
  if (!Number.isFinite(ms)) return true;
  return now - ms >= USERNAME_CHANGE_DAYS * 24 * 60 * 60 * 1000;
}

export function days_until_username_change(changed_at: string | number | null | undefined, now = Date.now()): number {
  if (can_change_username(changed_at, now)) return 0;
  const ms = typeof changed_at === 'number' ? changed_at : Date.parse(String(changed_at));
  const left = USERNAME_CHANGE_DAYS * 24 * 60 * 60 * 1000 - (now - ms);
  return Math.max(1, Math.ceil(left / (24 * 60 * 60 * 1000)));
}

/** What to show other readers: username first, never an email. */
export function public_name(me: { username?: string | null; name?: string | null } | null | undefined): string {
  const u = typeof me?.username === 'string' ? me.username.trim() : '';
  if (u) return u;
  // Fall back through display_name rules in pin_helpers (email → "Reader").
  const n = typeof me?.name === 'string' ? me.name.trim() : '';
  if (n && !/\S+@\S+\.\S+/.test(n)) return n;
  return 'Reader';
}
