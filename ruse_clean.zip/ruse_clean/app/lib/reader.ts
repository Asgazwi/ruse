import type { Chapter, Subject, ThemeColors } from './types';
import { THEME_FONTS, font_name } from './fonts';
import { mix_hex } from './contrast';

// ---------------------------------------------------------------
// Pure helpers for the course and chapter screens (Phase 5).
// No React / Expo here, so they are easy to test.
// ---------------------------------------------------------------

// Chapters of one course, in the order the uploader gave them.
export function chapters_for(chapters: Chapter[], subject_id: string): Chapter[] {
  return chapters
    .filter((ch) => ch.subject === subject_id)
    .sort((a, b) => (a.order ?? 0) - (b.order ?? 0));
}

export const find_subject = (subjects: Subject[], id: string | undefined): Subject | undefined =>
  id ? subjects.find((s) => s.id === id) : undefined;

export const find_chapter = (chapters: Chapter[], id: string | undefined): Chapter | undefined =>
  id ? chapters.find((ch) => ch.id === id) : undefined;

// Previous / next chapter inside the same course (null at the ends).
export function neighbours(chapters: Chapter[], chapter: Chapter): { prev: Chapter | null; next: Chapter | null } {
  const list = chapters_for(chapters, chapter.subject);
  const i = list.findIndex((ch) => ch.id === chapter.id);
  if (i < 0) return { prev: null, next: null };
  return { prev: list[i - 1] ?? null, next: list[i + 1] ?? null };
}

// How many chapters of a course are finished, for "2 of 5 done".
export function done_count(list: Chapter[], completed: string[] | undefined): number {
  const set = new Set(completed ?? []);
  return list.filter((ch) => set.has(ch.id)).length;
}

// Only accept real colors from uploaded files (#rgb or #rrggbb); anything else uses the fallback.
export function safe_color(value: unknown, fallback: string): string {
  return typeof value === 'string' && /^#([0-9a-f]{3}|[0-9a-f]{6})$/i.test(value.trim()) ? value.trim() : fallback;
}

// A chapter can ask for any font that is loaded in the app (see THEME_FONTS in lib/fonts.ts):
// Figtree, Newsreader, Inter, Merriweather, Lora, Roboto Mono or Quicksand. The match ignores
// upper/lower case. `exact` tells AppText to use that font as it is. Without it AppText would
// swap it for the theme's font, because that swap is how the theme's own font is applied.
// No font (or a name that is not loaded) means "the app's normal text", which follows the theme.
export function chapter_fonts(font: string | undefined): { regular: string; bold: string; exact: boolean } {
  const wanted = typeof font === 'string' ? font.trim().toLowerCase() : '';
  const known = THEME_FONTS.find((name) => name.toLowerCase() === wanted);
  return known
    ? { regular: font_name(known, 'medium'), bold: font_name(known, 'bold'), exact: true }
    : { regular: 'Figtree_500Medium', bold: 'Figtree_700Bold', exact: false };
}

export type text_piece = { text: string; color?: string };

const escape_regex = (s: string) => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

// Cuts a sentence into pieces, so the words listed in style.highlight get their own color.
// Longest words first ("Power BI" before "Power"); matching ignores upper/lower case.
export function split_highlights(text: string, highlight: Record<string, string> | undefined, fallback: string): text_piece[] {
  const words = Object.keys(highlight ?? {}).filter((w) => w.trim().length > 0).sort((a, b) => b.length - a.length);
  if (!text || words.length === 0) return [{ text }];
  const lookup = new Map(words.map((w) => [w.toLowerCase(), safe_color(highlight![w], fallback)]));
  const re = new RegExp(`(${words.map(escape_regex).join('|')})`, 'gi');
  const pieces: text_piece[] = [];
  let last = 0;
  for (const m of text.matchAll(re)) {
    const at = m.index ?? 0;
    if (at > last) pieces.push({ text: text.slice(last, at) });
    pieces.push({ text: m[0], color: lookup.get(m[0].toLowerCase()) });
    last = at + m[0].length;
  }
  if (last < text.length) pieces.push({ text: text.slice(last) });
  return pieces.length ? pieces : [{ text }];
}

// Soft box colors and a small label for tip / warn / ok callouts.
// The box is a soft tint of the bar color on the theme's own surface, so the theme's text color
// stays readable on light and dark themes alike (it used to be fixed pale boxes with fixed dark text).
export function callout_look(kind: string, c: ThemeColors): { label: string; bar: string; bg: string } {
  const bar = kind === 'warn' ? '#d9822b' : kind === 'ok' ? '#2e9e6b' : c.accent;
  const label = kind === 'warn' ? 'Careful' : kind === 'ok' ? 'Good to know' : 'Tip';
  return { label, bar, bg: mix_hex(c.surface, bar, 0.16) };
}
