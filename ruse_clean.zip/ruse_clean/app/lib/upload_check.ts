// ---------------------------------------------------------------
// Checks an uploaded JSON file BEFORE it is sent, and says what is wrong
// in plain words (with chapter / block numbers) instead of "Bad request".
// Pure functions: no React, no network, so they are easy to test.
// ---------------------------------------------------------------

// ---- Allowed values (same lists as the original web page) ----
export const THEME_FONTS = ['Figtree', 'Newsreader', 'Inter', 'Merriweather', 'Lora', 'Roboto Mono', 'Quicksand'];
export const THEME_EFFECTS = ['none', 'ripple', 'confetti', 'sparkle', 'pop', 'hearts', 'petals', 'bubbles'];
export const THEME_COLOR_KEYS = ['bg', 'surface', 'ink', 'muted', 'line', 'primary', 'primaryFg', 'accent', 'accentFg'];
import { check_effects } from './recipes';
import { check_button } from './button_look';
import { W } from './words';
import { check_pages } from './manga';

const BLOCK_TYPES = ['p', 'h', 'code', 'callout', 'list', 'table'];
const CALLOUT_KINDS = ['tip', 'warn', 'ok'];

// Keys that start with an underscore are hints for people (e.g. "_read_me"). They are removed
// before sending, so they never reach the backend. Works on a novel, a chapter, a list and a theme.
export function strip_hints<T>(data: T): T {
  const drop = (o: any) => {
    if (!o || typeof o !== 'object' || Array.isArray(o)) return o;
    const out: Record<string, any> = {};
    for (const k of Object.keys(o)) if (!k.startsWith('_')) out[k] = o[k];
    return out;
  };
  const top: any = drop(data);
  if (Array.isArray(top.chapters)) top.chapters = top.chapters.map(drop);
  if (Array.isArray(data) ) return (data as any).map(drop) as any;
  return top;
}

// ---- Result types ----
export type upload_kind = 'novel' | 'chapter' | 'chapters' | 'theme';
export type parsed_upload =
  | { ok: true; kind: upload_kind; data: any }
  | { ok: false; error: string };

// ---- Tiny helpers ----
const is_object = (x: unknown): x is Record<string, any> => !!x && typeof x === 'object' && !Array.isArray(x);
const is_text = (x: unknown): x is string => typeof x === 'string' && x.trim().length > 0;
const is_hex = (x: unknown): boolean => typeof x === 'string' && /^#[0-9a-fA-F]{6}$/.test(x);

// ---- One block ----
export function check_block(b: any, where: string): string | null {
  if (!is_object(b)) return `${where} is not an object.`;
  if (!BLOCK_TYPES.includes(b.type)) return `${where} has type "${b.type}". Use one of: ${BLOCK_TYPES.join(', ')}.`;
  if (b.type === 'p' || b.type === 'h' || b.type === 'code') {
    if (!is_text(b.text)) return `${where} (${b.type}) needs a "text".`;
  }
  if (b.type === 'callout') {
    if (!CALLOUT_KINDS.includes(b.kind)) return `${where} (callout) needs "kind": tip, warn or ok.`;
    if (!is_text(b.text)) return `${where} (callout) needs a "text".`;
  }
  if (b.type === 'list') {
    if (!Array.isArray(b.items) || !b.items.length || !b.items.every(is_text)) return `${where} (list) needs "items": a list of text.`;
  }
  if (b.type === 'table') {
    if (!Array.isArray(b.headers) || !b.headers.every(is_text)) return `${where} (table) needs "headers": a list of text.`;
    if (!Array.isArray(b.rows) || !b.rows.every((r: unknown) => Array.isArray(r))) return `${where} (table) needs "rows": a list of rows.`;
  }
  return null;
}


// ---- One chapter ----
// need_subject is true for single-chapter uploads (a novel bundle supplies the subject itself).
export function check_chapter(x: any, label: string, need_subject: boolean): string | null {
  if (!is_object(x)) return `${label} is not an object.`;
  if (need_subject && !is_text(x.subject)) {
    return `${label} needs a "subject" (the ${W.novel} id). Tip: upload a whole ${W.novel} file instead and it creates the ${W.novel} for you.`;
  }
  if (need_subject) {
    if (x.schemaVersion !== 1) return `${label} needs "schemaVersion": 1.`;
    if (!is_text(x.id) || !/^[a-z0-9-]{1,60}$/.test(x.id)) return `${label} needs an "id": lowercase letters, digits and dashes only (up to 60).`;
    if (!Number.isInteger(x.order) || x.order < 0) return `${label} needs an "order": a whole number, 0 or more.`;
  }
  if (!is_text(x.title)) return `${label} needs a "title".`;
  // E2: a manga chapter has "pages" (image links) instead of "blocks".
  if (x.pages !== undefined) {
    const problem = check_pages(x.pages, label);
    if (problem) return problem;
    return null;
  }
  if (!Array.isArray(x.blocks) || !x.blocks.length) return `${label} needs a "blocks" list with at least one block.`;
  for (let i = 0; i < x.blocks.length; i++) {
    const problem = check_block(x.blocks[i], `${label}, block ${i + 1}`);
    if (problem) return problem;
  }
  // quiz is ignored (novel reader, not an app for courses). Old files may still include it.
  return null;
}

// ---- A whole novel: { novel: {title}, chapters: [...] } ----
export function check_novel(x: any): string | null {
  if (!is_object(x.novel) || !is_text(x.novel.title)) return 'The file needs "novel": { "title": "..." }.';
  if (!Array.isArray(x.chapters) || !x.chapters.length) return 'The file needs a "chapters" list with at least one chapter.';
  for (let i = 0; i < x.chapters.length; i++) {
    const problem = check_chapter(x.chapters[i], `Chapter ${i + 1}`, false);
    if (problem) return problem;
  }
  return null;
}

// ---- A theme ----
export function check_theme(x: any): string | null {
  if (!is_text(x.name)) return 'The theme needs a "name".';
  if (!THEME_FONTS.includes(x.font)) return `The theme "font" (body text) must be one of: ${THEME_FONTS.join(', ')}.`;
  if (x.heading_font !== undefined && !THEME_FONTS.includes(x.heading_font)) return `The theme "heading_font" must be one of: ${THEME_FONTS.join(', ')}.`;
  if (x.effect !== undefined && !THEME_EFFECTS.includes(x.effect)) return `The theme "effect" must be one of: ${THEME_EFFECTS.join(', ')}.`;
  if (x.effect === undefined && x.effects === undefined) return `The theme needs an "effect" (one of: ${THEME_EFFECTS.join(', ')}) or an "effects" design.`;
  if (x.radius !== undefined && !(Number.isInteger(x.radius) && x.radius >= 4 && x.radius <= 32)) return 'The theme "radius" must be a whole number from 4 to 32.';
  // E4: optional link to one novel. Empty string is treated as absent.
  if (x.forSubject !== undefined && x.forSubject !== null) {
    if (typeof x.forSubject !== 'string') return 'The theme "forSubject" must be a string (the novel id), or leave it out.';
    if (x.forSubject.trim().length > 80) return 'The theme "forSubject" is too long (max 80 characters).';
  }
  const design = check_effects(x.effects);
  if (design) return design;
  const button = check_button(x.button);
  if (button) return `The theme ${button}`;
  if (!is_object(x.colors)) return 'The theme needs a "colors" object.';
  for (const key of THEME_COLOR_KEYS) {
    if (!is_hex(x.colors[key])) return `The theme color "${key}" must look like #aabbcc (a # and six letters or digits).`;
  }
  return null;
}

// ---- Entry point: text from the file -> checked, labelled result ----
export function parse_upload_text(text: string): parsed_upload {
  let data: any;
  try {
    data = JSON.parse(text);
  } catch {
    return { ok: false, error: 'That file is not valid JSON. Check commas, quotes and brackets (start from a template).' };
  }

  // A list of chapters
  if (Array.isArray(data)) {
    if (!data.length) return { ok: false, error: 'That list is empty.' };
    for (let i = 0; i < data.length; i++) {
      const problem = check_chapter(data[i], `Chapter ${i + 1}`, true);
      if (problem) return { ok: false, error: problem };
    }
    return { ok: true, kind: 'chapters', data };
  }

  if (!is_object(data)) return { ok: false, error: 'The file must hold one object or a list of chapters.' };

  // Older files call the top block "course". Read it as "novel" so they still upload.
  if (is_object(data.course) && data.novel === undefined) { const { course, ...rest } = data; data = { novel: course, ...rest }; }

  // Which shape is it? Decide by its most telling key.
  if (Array.isArray(data.chapters) || is_object(data.novel)) {
    const problem = check_novel(data);
    return problem ? { ok: false, error: problem } : { ok: true, kind: 'novel', data };
  }
  if (is_object(data.colors)) {
    const problem = check_theme(data);
    return problem ? { ok: false, error: problem } : { ok: true, kind: 'theme', data };
  }
  if (Array.isArray(data.blocks) || Array.isArray(data.pages)) {
    const problem = check_chapter(data, 'The chapter', true);
    return problem ? { ok: false, error: problem } : { ok: true, kind: 'chapter', data };
  }
  return { ok: false, error: `Not sure what this file is. It should be a ${W.novel} ("chapters"), one chapter ("blocks") or a theme ("colors"). Download a template to start.` };
}
