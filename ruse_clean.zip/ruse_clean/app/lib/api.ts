import { GoogleSignin } from '@react-native-google-signin/google-signin';
import { API_URL } from './config';
import { READ_ACTIONS } from './actions';
import { make_error, is_network_error, run_with_retry } from './net_retry';

export { is_network_error } from './net_retry';

const READ_TIMEOUT_MS = 20000;   // reads give up after 20 s...
const READ_RETRY_WAITS_MS = [800, 1600]; // ...and are tried again 2 more times
const WRITE_TIMEOUT_MS = 45000;  // writes (uploads) get longer, and are never retried

// One try at one Apps Script function (the same names the web page used with google.script.run).
async function call_once<T>(action: string, args: unknown[], timeout_ms: number): Promise<T> {
  let idToken: string;
  try {
    ({ idToken } = await GoogleSignin.getTokens()); // refreshed when needed
  } catch {
    throw make_error('Could not check your sign-in. Check your connection and try again.', 'network');
  }

  const stop = new AbortController();
  const timer = setTimeout(() => stop.abort(), timeout_ms);
  let status = 0;
  let text = '';
  try {
    const res = await fetch(API_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'text/plain;charset=utf-8' },
      body: JSON.stringify({ action, args, idToken }),
      signal: stop.signal,
    });
    status = res.status;
    text = await res.text();
  } catch {
    throw make_error(
      stop.signal.aborted ? 'The server took too long to answer.' : 'No connection to the server.',
      'network',
    );
  } finally {
    clearTimeout(timer);
  }

  let json: any;
  try {
    json = JSON.parse(text);
  } catch {
    // Apps Script sometimes answers with a web page when it is busy. Not the backend saying "no".
    throw make_error(
      status >= 500 ? 'The server is busy right now.' : 'The server sent something unexpected.',
      'network',
    );
  }
  if (!json.ok) throw make_error(json.error || 'Something went wrong.', 'backend');
  return json.data as T;
}

// The Apps Script backend. Screens do not call this directly: they call api() in lib/backend.ts,
// which sends each action to Apps Script (here) or to Supabase (lib/sb/), see SUPABASE_PLAN section 13.
// Reads retry 2x with a short wait and a 20 s timeout. Writes try once.
export async function gas_call<T>(action: string, ...args: unknown[]): Promise<T> {
  const is_read = READ_ACTIONS.includes(action);
  try {
    return await run_with_retry(
      () => call_once<T>(action, args, is_read ? READ_TIMEOUT_MS : WRITE_TIMEOUT_MS),
      is_read ? READ_RETRY_WAITS_MS : [],
    );
  } catch (e: any) {
    if (!is_read && is_network_error(e)) {
      // We do not know if the save went through, so say so instead of guessing.
      throw make_error(`${e.message} It may or may not have saved, so check before trying again.`, 'network');
    }
    throw e;
  }
}
