// ---------------------------------------------------------------
// Everything the app keeps on the phone, in one place (Phase A5).
// Why: "Sign out" must remove ALL of one person's saved files, and it can only do that if it knows
// every file name. Add a new per-account file here and sign-out cleans it up automatically.
// Pure logic only (no storage here), so it is easy to test.
// ---------------------------------------------------------------
import { pins_key } from './pin_helpers';
import { push_key } from './push_helpers';

export const SAVED_ME = 'me';                         // the signed-in profile
export const SAVED_COURSES = 'course_data';           // saved novels / courses
export const SAVED_PENDING = 'pending_progress';      // finished chapters not sent yet
export const SAVED_THEME = 'theme_id';                // a preference: it stays after sign out on purpose
const LEGACY_NOTES = 'notes_state';                   // phone-only notes of an old version: nothing uses it any more

// Every saved file that belongs to the signed-in person. `email` may be unknown (then the
// per-account files cannot be named, and only the fixed ones are returned).
export function account_keys(email: string | null | undefined): string[] {
  const fixed = [SAVED_ME, SAVED_COURSES, SAVED_PENDING, LEGACY_NOTES];
  const who = typeof email === 'string' ? email.trim() : '';
  return who ? [...fixed, pins_key(who), push_key(who)] : fixed;
}
