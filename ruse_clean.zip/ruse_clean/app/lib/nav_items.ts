// The floating nav bar's items. Pure config: which items exist, who sees them, and where they go.
// A route of null would mean "not mapped yet": the item shows, but tapping does nothing.
import { can_upload } from './roles';

export type NavItem = {
  key: string;
  label: string;
  emoji: string;
  icon: string;                  // Ionicons name (outline); the tab bar adds the filled one when active
  route: string | null;          // where it goes; null = not mapped yet (e.g. the Author area)
  show: (me: any) => boolean;    // who sees it
};

export const NAV_ITEMS: NavItem[] = [
  { key: 'home', label: 'Home', emoji: '🏠', icon: 'home', route: '/', show: () => true },
  { key: 'messages', label: 'Messages', emoji: '✉️', icon: 'chatbubble', route: '/messages', show: (me) => !!me?.allowed },
  { key: 'author', label: 'Author', emoji: '✍️', icon: 'create', route: '/courses', show: (me) => can_upload(me) }, // Your novels: where author tools live
  { key: 'settings', label: 'You', emoji: '⚙️', icon: 'person-circle', route: '/settings', show: () => true },
];

export const visible_nav = (me: any, items: NavItem[] = NAV_ITEMS): NavItem[] => items.filter((i) => i.show(me));

// Which item is active for the current screen path (longest matching route wins; '/' only matches exactly).
export function active_nav_key(path: string, items: NavItem[] = NAV_ITEMS): string | null {
  let best: NavItem | null = null;
  for (const i of items) {
    if (!i.route) continue;
    const hit = i.route === '/' ? path === '/' : path === i.route || path.startsWith(i.route + '/');
    if (hit && (!best || (i.route.length > (best.route ?? '').length))) best = i;
  }
  return best?.key ?? null;
}

// Where each item sits on the wheel: an arc above the round button, spread evenly from left to right.
// Offsets are in pixels from the button's centre (y is negative = up). One item sits straight up.
export function radial_offsets(count: number, radius: number): { x: number; y: number }[] {
  if (count <= 0) return [];
  if (count === 1) return [{ x: 0, y: -radius }];
  const from = Math.PI * 0.8; // left, a little above the horizon
  const to = Math.PI * 0.2;   // right, a little above the horizon
  return Array.from({ length: count }, (_, i) => {
    const a = from + ((to - from) * i) / (count - 1);
    return { x: Math.round(Math.cos(a) * radius), y: -Math.round(Math.sin(a) * radius) };
  });
}
