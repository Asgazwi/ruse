// Empty space kept under the last card on every screen, so the tab bar never covers content.
// The tab bar itself is 64 high (plus the phone's bottom inset, which screens add on their own).
export const NAV_CLEARANCE = 88;
export const TAB_BAR_HEIGHT = 64;
