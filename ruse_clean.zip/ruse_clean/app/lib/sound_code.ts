// Named tap sounds + optional raw sound codes.
// Prefer a preset name in theme JSON. Soft, short, low volume — never harsh or "gamey".

export type sound_code = {
  wave: string;
  notes: number[];
  step_ms: number;
  volume: number;
};

export const SOUND_PRESETS = [
  'none',
  // soft / luxury (also have bundled WAVs in sound_previews/)
  'glass', 'harp', 'silk', 'water', 'piano', 'swell',
  // crisp / UI
  'tick', 'click', 'chime', 'coin',
  // paper / organic
  'page', 'leaf', 'wood', 'hush',
  // bright / playful
  'pop', 'bubble', 'sparkle', 'bell',
  // deep / moody
  'ink', 'ember', 'frost', 'pulse',
  'fanfare',
] as const;

export type sound_preset = (typeof SOUND_PRESETS)[number];

const VOICES = ['glass', 'harp', 'silk', 'water', 'piano', 'swell'] as const;

/** Names that ship as real WAV files under sound_previews/ */
export const BUNDLED_WAV: readonly string[] = [
  'glass', 'harp', 'silk', 'water', 'piano', 'swell',
  'tick', 'click', 'chime', 'coin',
  'page', 'leaf', 'wood', 'hush',
  'pop', 'bubble', 'sparkle', 'bell',
  'ink', 'ember', 'frost', 'pulse', 'fanfare',
];

/**
 * Soft synthetic fallbacks when no bundled file exists.
 * Design rules: short (<120ms total), volume ≤ 0.14, mostly sine/soft layers, no loud square.
 */
const PRESETS: Record<string, sound_code> = {
  none: { wave: 'sine', notes: [], step_ms: 40, volume: 0 },

  // soft / luxury — gentle, airy
  glass:  { wave: 'glass',  notes: [784, 1175],     step_ms: 42, volume: 0.11 },
  harp:   { wave: 'harp',   notes: [523, 659],      step_ms: 55, volume: 0.1 },
  silk:   { wave: 'silk',   notes: [880],           step_ms: 70, volume: 0.09 },
  water:  { wave: 'water',  notes: [620],           step_ms: 65, volume: 0.1 },
  piano:  { wave: 'piano',  notes: [523],           step_ms: 80, volume: 0.1 },
  swell:  { wave: 'swell',  notes: [392, 523],      step_ms: 50, volume: 0.09 },

  // crisp / UI — tiny, dry
  tick:   { wave: 'sine',     notes: [1400],        step_ms: 22, volume: 0.08 },
  click:  { wave: 'triangle', notes: [1100],        step_ms: 18, volume: 0.07 },
  chime:  { wave: 'glass',    notes: [1046],        step_ms: 50, volume: 0.1 },
  coin:   { wave: 'triangle', notes: [1500, 900],   step_ms: 28, volume: 0.08 },

  // paper / organic — muted
  page:   { wave: 'silk',     notes: [240],         step_ms: 55, volume: 0.07 },
  leaf:   { wave: 'water',    notes: [480],         step_ms: 50, volume: 0.07 },
  wood:   { wave: 'triangle', notes: [160],         step_ms: 35, volume: 0.09 },
  hush:   { wave: 'sine',     notes: [360],         step_ms: 90, volume: 0.05 },

  // bright / playful — still soft
  pop:    { wave: 'sine',     notes: [520],         step_ms: 35, volume: 0.09 },
  bubble: { wave: 'sine',     notes: [640, 480],    step_ms: 40, volume: 0.08 },
  sparkle:{ wave: 'silk',     notes: [1320],        step_ms: 40, volume: 0.08 },
  bell:   { wave: 'glass',    notes: [880, 1320],   step_ms: 45, volume: 0.1 },

  // deep / moody
  ink:    { wave: 'sine',     notes: [180],         step_ms: 70, volume: 0.09 },
  ember:  { wave: 'triangle', notes: [140],         step_ms: 60, volume: 0.08 },
  frost:  { wave: 'silk',     notes: [1200],        step_ms: 45, volume: 0.08 },
  pulse:  { wave: 'sine',     notes: [100],         step_ms: 75, volume: 0.1 },

  fanfare:{ wave: 'piano',    notes: [392, 523, 659], step_ms: 48, volume: 0.1 },
};

export function resolve_sound(spec: unknown): sound_code | null {
  if (spec === undefined || spec === null || spec === 'none') return null;
  if (typeof spec === 'string') {
    const key = spec.trim().toLowerCase();
    if (key === 'none' || !key) return null;
    return PRESETS[key] || null;
  }
  if (typeof spec !== 'object' || Array.isArray(spec)) return null;
  const o = spec as any;
  const wave = String(o.wave || 'sine');
  const notes = Array.isArray(o.notes) ? o.notes.map(Number).filter((n: number) => n >= 80 && n <= 2000) : [];
  if (!notes.length) return null;
  const step_ms = Math.min(400, Math.max(30, Number(o.step_ms) || 50));
  // Cap custom volume so uploads can't blast
  const volume = Math.min(0.35, Math.max(0.05, Number(o.volume) || 0.12));
  return { wave, notes: notes.slice(0, 16), step_ms, volume };
}

export function check_sound(x: unknown): string | null {
  if (x === undefined || x === 'none') return null;
  if (typeof x === 'string') {
    return (SOUND_PRESETS as readonly string[]).includes(x)
      ? null
      : `"sound" must be one of ${SOUND_PRESETS.join(', ')}, or a sound code.`;
  }
  if (!x || typeof x !== 'object' || Array.isArray(x)) return '"sound" must be a sound name or a sound code (an object).';
  const o = x as any;
  const waves = ['sine', 'square', 'triangle', ...VOICES];
  if (!waves.includes(o.wave)) return `Sound code: "wave" must be one of ${waves.join(', ')}.`;
  if (!Array.isArray(o.notes) || o.notes.length < 1 || o.notes.length > 16) {
    return 'Sound code: "notes" must be 1 to 16 frequencies in Hz.';
  }
  for (const n of o.notes) {
    if (typeof n !== 'number' || n < 80 || n > 2000) return 'Sound code: each note must be 80 to 2000 Hz.';
  }
  if (typeof o.step_ms !== 'number' || o.step_ms < 30 || o.step_ms > 400) {
    return 'Sound code: "step_ms" must be 30 to 400 ms.';
  }
  if (typeof o.volume !== 'number' || o.volume < 0.05 || o.volume > 0.6) {
    return 'Sound code: "volume" must be 0.05 to 0.6.';
  }
  return null;
}

/** Soft mono WAV. Quick attack, longish exponential decay, low volume. */
export function wav_bytes(code: sound_code): Uint8Array {
  const sr = 22050;
  const attack = 0.004;
  const parts: number[] = [];

  for (let i = 0; i < code.notes.length; i++) {
    const freq = code.notes[i];
    const dur = Math.max(0.03, code.step_ms / 1000);
    const n = Math.floor(sr * dur);
    const vol = code.volume;
    for (let s = 0; s < n; s++) {
      const t = s / sr;
      // smooth attack + soft exponential release (no click, no buzz)
      const env =
        t < attack
          ? t / attack
          : Math.exp(-5.5 * (t - attack) / Math.max(0.025, dur - attack));
      const phase = 2 * Math.PI * freq * t;
      let sample = 0;
      const w = code.wave;
      if (w === 'square') {
        // soft square: filtered-ish by mixing sine
        sample = 0.35 * Math.sign(Math.sin(phase)) + 0.65 * Math.sin(phase);
      } else if (w === 'triangle') {
        sample = 2 * Math.asin(Math.sin(phase)) / Math.PI;
      } else if (w === 'glass') {
        sample = Math.sin(phase) + 0.22 * Math.sin(2 * phase) * Math.exp(-8 * t);
      } else if (w === 'harp') {
        sample = Math.sin(phase) * Math.exp(-3 * t) + 0.15 * Math.sin(2 * phase) * Math.exp(-6 * t);
      } else if (w === 'silk') {
        sample = Math.sin(phase) + 0.12 * Math.sin(phase * 1.002) + 0.06 * Math.sin(3 * phase);
      } else if (w === 'water') {
        sample = Math.sin(phase) * (0.85 + 0.15 * Math.sin(9 * t));
      } else if (w === 'piano') {
        sample = Math.sin(phase) + 0.28 * Math.sin(2 * phase) * Math.exp(-7 * t);
      } else if (w === 'swell') {
        const rise = Math.min(1, t / (dur * 0.35));
        sample = Math.sin(phase) * (0.5 + 0.5 * rise);
      } else {
        sample = Math.sin(phase);
      }
      parts.push(sample * env * vol);
    }
  }

  // short silence tail so the player doesn't click when looping seek
  const tail = Math.floor(sr * 0.05);
  for (let s = 0; s < tail; s++) parts.push(0);

  const dataSize = parts.length * 2;
  const buf = new ArrayBuffer(44 + dataSize);
  const view = new DataView(buf);
  const ws = (o: number, str: string) => {
    for (let i = 0; i < str.length; i++) view.setUint8(o + i, str.charCodeAt(i));
  };
  ws(0, 'RIFF');
  view.setUint32(4, 36 + dataSize, true);
  ws(8, 'WAVE');
  ws(12, 'fmt ');
  view.setUint32(16, 16, true);
  view.setUint16(20, 1, true);
  view.setUint16(22, 1, true);
  view.setUint32(24, sr, true);
  view.setUint32(28, sr * 2, true);
  view.setUint16(32, 2, true);
  view.setUint16(34, 16, true);
  ws(36, 'data');
  view.setUint32(40, dataSize, true);
  for (let i = 0; i < parts.length; i++) {
    const x = Math.max(-1, Math.min(1, parts[i]));
    view.setInt16(44 + i * 2, (x * 32767) | 0, true);
  }
  return new Uint8Array(buf);
}
