// ---------------------------------------------------------------
// The words the reader sees (Phase B1). Change a word HERE and the whole app follows.
// Only display text uses these. Ids, file keys ("subject") and backend action names
// stay exactly as they are, so nothing breaks.
// ---------------------------------------------------------------
export const W = {
  novel: 'novel',
  novels: 'novels',
  Novel: 'Novel',
  Novels: 'Novels',
};

// "1 novel" / "3 novels"
export const novels_count = (n: number): string => (n === 1 ? `1 ${W.novel}` : `${n} ${W.novels}`);
