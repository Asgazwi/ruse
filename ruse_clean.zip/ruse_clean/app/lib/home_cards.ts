// Pure helpers for the Home cards (messages waiting, where you left off, recommendations). No React.
import type { Chapter, Progress, Subject } from './types';
import type { Thread } from './messages';
import { chapters_for, done_count, find_chapter, find_subject } from './reader';

// Threads with unread messages, newest first, at most `n`.
export function waiting_threads(threads: Thread[], n = 3): Thread[] {
  return threads.filter((t) => t.unread > 0).slice(0, n);
}

// The chapter the reader left off in (progress.active), with how far through its novel they are.
export function continue_card(
  progress: Progress | null | undefined,
  chapters: Chapter[],
  subjects: Subject[],
): { chapter: Chapter; subject: Subject; done: number; total: number } | null {
  if (!progress?.active) return null;
  const chapter = find_chapter(chapters, progress.active);
  if (!chapter) return null;
  const subject = find_subject(subjects, chapter.subject);
  if (!subject) return null;
  const list = chapters_for(chapters, subject.id);
  return { chapter, subject, done: done_count(list, progress.completed), total: list.length };
}

// Novels that have at least one chapter (an empty novel is not worth recommending).
export function recommendable(subjects: Subject[], chapters: Chapter[], exclude_id?: string | null): Subject[] {
  return subjects.filter((s) => s.id !== exclude_id && chapters_for(chapters, s.id).length > 0);
}

// `n` items picked at random, without repeats (Fisher–Yates on a copy). `rand` can be replaced in tests.
export function pick_random<T>(list: T[], n: number, rand: () => number = Math.random): T[] {
  const a = list.slice();
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(rand() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a.slice(0, Math.max(0, n));
}

export const percent = (done: number, total: number): number => (total ? Math.round((done / total) * 100) : 0);
