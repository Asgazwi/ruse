// The name people see. Change it here (and "name" in app.json for the label under the phone icon).
// The Android package name, iOS bundle id, slug and link scheme are NOT touched by a rename on purpose:
// changing them would make the phone treat this as a different app.
export const APP_NAME = 'Marginalia';
