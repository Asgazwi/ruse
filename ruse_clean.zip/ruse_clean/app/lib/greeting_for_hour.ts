// A short greeting for the hour of the day (0 to 23). Used in the Home header.
export function greeting_for_hour(hour: number): string {
  if (hour < 5) return 'Late night learning 🌙';
  if (hour < 12) return 'Good morning ☀️';
  if (hour < 18) return 'Good afternoon 🌸';
  return 'Good evening 🌙';
}
