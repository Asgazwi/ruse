// Server calls for direct messages (Phase D3). The backend functions are written by the owner (Code.gs):
//   getThreads()                    -> Message[]  (all my messages, both directions)
//   getMessages(with_username)      -> Message[]  (one conversation)
//   sendMessage({ to_username, text }) -> Message
//   markRead(with_username)         -> { ok: true }
//   deleteMessage({ id })           -> { ok: true }   (only my own messages)
// Sending is online-only on purpose: a message is never queued silently on the phone.
import { api } from './backend';
import { ACTION_GET_THREADS, ACTION_GET_MESSAGES, ACTION_SEND_MESSAGE, ACTION_MARK_READ, ACTION_DELETE_MESSAGE } from './actions';
import type { Message } from './messages';

export const fetch_all_messages = () => api<Message[]>(ACTION_GET_THREADS);
export const fetch_conversation = (with_username: string) => api<Message[]>(ACTION_GET_MESSAGES, with_username);
export const send_message = (to_username: string, text: string) => api<Message>(ACTION_SEND_MESSAGE, { to_username, text });
export const mark_read = (with_username: string) => api<{ ok: boolean }>(ACTION_MARK_READ, with_username);
export const delete_message = (id: string) => api<{ ok: boolean }>(ACTION_DELETE_MESSAGE, { id });
