// The reader's button dock: three small round buttons stacked on one screen edge, low down,
// in this order: pin, comment, menu. One place for the numbers so the three buttons always line up.
export const DOCK_SIZE = 46;
export const DOCK_STEP = DOCK_SIZE + 10;   // button size + gap
export const DOCK_EDGE_GAP = 10;
export const DOCK_BOTTOM_GAP = 24;

// Height (from the top of the screen) of the first button, the pin.
export const dock_top = (screen_height: number, bottom_inset: number): number =>
  Math.round(screen_height - bottom_inset - DOCK_BOTTOM_GAP - 3 * DOCK_STEP + 10);

// Extra room at the end of a chapter so the dock never covers the last buttons.
export const DOCK_CLEARANCE = 3 * DOCK_STEP + DOCK_BOTTOM_GAP + 16;
