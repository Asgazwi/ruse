// ---------------------------------------------------------------
// Button looks written as DATA (JSON). A theme file can carry a "button" block; the app turns it
// into a lively button. Nothing in the file is ever run as code. Pure logic only (no React),
// so it is easy to test. The same limits should be allowed by the backend when it saves a theme.
//
//   "button": {
//     "style": "raised",            raised | flat | soft | outline
//     "shape": "pill",              round | pill | square
//     "press": "bounce",            bounce | sink | wiggle | pulse | none
//     "depth": 4,                   0 to 8   (thickness of the chunky bottom edge, raised only)
//     "shine": true,                a glossy highlight that sweeps across when pressed
//     "uppercase": false,           LABELS IN CAPITALS
//     "colors": { "bg": "#ff6fa5", "fg": "#ffffff", "edge": "#c2185b" }   all optional
//   }
// ---------------------------------------------------------------
import { alpha_hex } from './alpha_hex';
import { mix_hex } from './contrast';

export const BUTTON_STYLES = ['raised', 'flat', 'soft', 'outline'] as const;
export const BUTTON_SHAPES = ['round', 'pill', 'square'] as const;
export const BUTTON_PRESSES = ['bounce', 'sink', 'wiggle', 'pulse', 'none'] as const;

export type button_style = (typeof BUTTON_STYLES)[number];
export type button_shape = (typeof BUTTON_SHAPES)[number];
export type button_press = (typeof BUTTON_PRESSES)[number];

export type button_look = {
  style?: button_style;
  shape?: button_shape;
  press?: button_press;
  depth?: number;       // 0 to 8
  shine?: boolean;
  uppercase?: boolean;
  colors?: { bg?: string; fg?: string; edge?: string };
};

// The look every theme gets when it says nothing: a chunky raised button that squishes and springs.
export const DEFAULT_BUTTON: Required<Omit<button_look, 'colors'>> = {
  style: 'raised', shape: 'round', press: 'bounce', depth: 4, shine: true, uppercase: false,
};

const is_obj = (x: unknown): x is Record<string, any> => !!x && typeof x === 'object' && !Array.isArray(x);
const hex = (x: unknown) => typeof x === 'string' && /^#[0-9a-fA-F]{6}$/.test(x);
const KNOWN = ['style', 'shape', 'press', 'depth', 'shine', 'uppercase', 'colors'];

// Checks the "button" block of a theme. Returns the first problem in plain words, or null.
export function check_button(b: any): string | null {
  if (b === undefined) return null;
  if (!is_obj(b)) return '"button" must be an object.';
  for (const k of Object.keys(b)) {
    if (!k.startsWith('_') && !KNOWN.includes(k)) return `"button.${k}" is not a known setting. Use: ${KNOWN.join(', ')}.`;
  }
  if (b.style !== undefined && !BUTTON_STYLES.includes(b.style)) return `"button.style" must be one of: ${BUTTON_STYLES.join(', ')}.`;
  if (b.shape !== undefined && !BUTTON_SHAPES.includes(b.shape)) return `"button.shape" must be one of: ${BUTTON_SHAPES.join(', ')}.`;
  if (b.press !== undefined && !BUTTON_PRESSES.includes(b.press)) return `"button.press" must be one of: ${BUTTON_PRESSES.join(', ')}.`;
  if (b.depth !== undefined && !(typeof b.depth === 'number' && Number.isInteger(b.depth) && b.depth >= 0 && b.depth <= 8)) return '"button.depth" must be a whole number from 0 to 8.';
  if (b.shine !== undefined && typeof b.shine !== 'boolean') return '"button.shine" must be true or false.';
  if (b.uppercase !== undefined && typeof b.uppercase !== 'boolean') return '"button.uppercase" must be true or false.';
  if (b.colors !== undefined) {
    if (!is_obj(b.colors)) return '"button.colors" must be an object like { "bg": "#ff6fa5" }.';
    for (const k of Object.keys(b.colors)) {
      if (k.startsWith('_')) continue;
      if (!['bg', 'fg', 'edge'].includes(k)) return `"button.colors.${k}" is not known. Use bg, fg or edge.`;
      if (!hex(b.colors[k])) return `"button.colors.${k}" must look like #aabbcc (a # and six letters or digits).`;
    }
  }
  return null;
}

// Fills the gaps in whatever a theme gave, and quietly ignores anything invalid (a bad file
// can never break a screen: it just falls back to the defaults).
export function normalize_look(raw: unknown): typeof DEFAULT_BUTTON & { colors: { bg?: string; fg?: string; edge?: string } } {
  const b: any = is_obj(raw) && check_button(raw) === null ? raw : {};
  return {
    style: b.style ?? DEFAULT_BUTTON.style,
    shape: b.shape ?? DEFAULT_BUTTON.shape,
    press: b.press ?? DEFAULT_BUTTON.press,
    depth: b.depth ?? DEFAULT_BUTTON.depth,
    shine: b.shine ?? DEFAULT_BUTTON.shine,
    uppercase: b.uppercase ?? DEFAULT_BUTTON.uppercase,
    colors: is_obj(b.colors) ? { bg: b.colors.bg, fg: b.colors.fg, edge: b.colors.edge } : {},
  };
}

export type button_size = 'sm' | 'md' | 'lg';
export const SIZE_HEIGHT: Record<button_size, number> = { sm: 34, md: 44, lg: 52 };

export type resolved_button = {
  fill: string;          // face colour ('transparent' for outline)
  fg: string;            // label colour
  edge: string | null;   // chunky bottom edge colour (raised only)
  border: string | null; // outline colour
  radius: number;
  depth: number;         // px of edge; 0 when not raised
  shine: boolean;
  press: button_press;
  uppercase: boolean;
};

// base = the colour the screen asked for (usually theme primary or accent); base_fg = text on it.
// theme_radius = the theme's card radius; round buttons borrow a calmer version of it.
export function resolve_button(
  raw_look: unknown, base: string, base_fg: string, theme_radius: number | undefined,
  opts: { outline?: boolean; soft?: boolean; size?: button_size; keep_color?: boolean } = {},
): resolved_button {
  const look = normalize_look(raw_look);
  const size = opts.size ?? 'lg';
  const h = SIZE_HEIGHT[size];
  // keep_color (e.g. a red "Sign out") ignores the theme's colour overrides.
  const bg = !opts.keep_color && look.colors.bg ? look.colors.bg : base;
  const fg_on_fill = !opts.keep_color && look.colors.fg ? look.colors.fg : base_fg;

  const radius = look.shape === 'pill' ? h / 2 : look.shape === 'square' ? 6 : Math.max(8, Math.min(Math.round((theme_radius ?? 16) * 0.7), h / 2 - 2));

  // Which of the four styles this button is drawn in.
  let style: button_style = look.style;
  if (opts.outline) style = 'outline';
  else if (opts.soft) style = 'soft';

  if (style === 'outline') return { fill: 'transparent', fg: bg, edge: null, border: bg, radius, depth: 0, shine: false, press: look.press, uppercase: look.uppercase };
  if (style === 'soft') return { fill: alpha_hex(bg, 0.16), fg: bg, edge: null, border: null, radius, depth: 0, shine: false, press: look.press, uppercase: look.uppercase };
  const raised = style === 'raised' && look.depth > 0 && size !== 'sm';
  const edge = !raised ? null : (!opts.keep_color && look.colors.edge) || mix_hex(bg, '#000000', 0.3);
  return { fill: bg, fg: fg_on_fill, edge, border: null, radius, depth: raised ? Math.min(look.depth, size === 'md' ? 3 : 8) : 0, shine: look.shine, press: look.press, uppercase: look.uppercase };
}
