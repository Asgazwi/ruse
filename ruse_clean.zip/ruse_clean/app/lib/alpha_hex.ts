// Turns "#rrggbb" plus an alpha from 0 to 1 into "#rrggbbaa".
// Why: theme colors are plain 6-digit hex, and soft glows and rings need see-through versions of them.
export function alpha_hex(hex: string, alpha: number): string {
  const clean = /^#[0-9a-fA-F]{6}$/.test(hex) ? hex : '#000000';
  const clamped = Math.max(0, Math.min(1, alpha));
  const tail = Math.round(clamped * 255).toString(16).padStart(2, '0');
  return `${clean}${tail}`;
}
