import React, { createContext, useContext, useEffect, useRef, useState, useCallback } from 'react';
import { GoogleSignin } from '@react-native-google-signin/google-signin';
import { api } from './backend';
import { ACTION_GET_ME } from './actions';
import { is_network_error, race_timeout, TIMED_OUT } from './net_retry';
import { clear_saved, load_saved, save_saved } from './store';
import { delete_all_downloads } from './downloads';
import { account_keys, SAVED_COURSES, SAVED_ME } from './saved_keys';
import { IOS_CLIENT_ID, WEB_CLIENT_ID } from './config';
import type { Me } from './types';

type Auth = {
  status: 'loading' | 'out' | 'in';
  me: Me | null;
  error: string | null;
  from_saved: boolean; // true while "me" is the copy saved on the phone (we could not reach the server)
  signIn: () => Promise<void>;
  signOut: () => Promise<void>;
  reload: () => Promise<boolean>; // true = got fresh answer from the server
};
const Ctx = createContext<Auth>(null as unknown as Auth);
export const useAuth = () => useContext(Ctx);

// How long we wait for Google when the app opens. Longer than this and we open the saved profile
// instead of showing a spinner (offline phones can leave Google hanging).
const GOOGLE_WAIT_MS = 6000;

// Your own saved profile, but only if it is a real signed-in one.
const saved_me = (): Me | null => {
  const m = load_saved<Me>(SAVED_ME);
  return m && m.signedIn && m.email ? m : null;
};

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [status, setStatus] = useState<Auth['status']>('loading');
  const [me, setMe] = useState<Me | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [from_saved, setFromSaved] = useState(false);
  const from_saved_ref = useRef(false);

  const use_saved = (m: Me) => {
    from_saved_ref.current = true;
    setFromSaved(true);
    setMe(m);
    setStatus('in');
    setError(null);
  };

  // Removes everything saved on this phone for the signed-in person. ONLY "Sign out" calls this:
  // being offline, or Google not answering, must never wipe the saved novels.
  const forget_everything = () => {
    const email = saved_me()?.email; // read before the profile file is removed
    try { delete_all_downloads(); } catch { /* files that are already gone are fine */ } // downloads leave the phone too
    for (const key of account_keys(email)) clear_saved(key);
    from_saved_ref.current = false;
    setFromSaved(false);
    setMe(null);
    setStatus('out');
  };

  const reload = useCallback(async (): Promise<boolean> => {
    // If we are running on the saved profile, wake Google up quietly first (the sign-in is lost when
    // the app restarts offline). If Google says no, we do NOT wipe anything: the call below then fails
    // like any offline call, and the saved profile stays. Only "Sign out" removes saved data.
    if (from_saved_ref.current) {
      try { await GoogleSignin.signInSilently(); } catch { /* still offline: carry on */ }
    }
    try {
      const fresh = await api<Me>(ACTION_GET_ME);
      if (fresh?.signedIn) save_saved(SAVED_ME, fresh);
      from_saved_ref.current = false;
      setFromSaved(false);
      setMe(fresh);
      setStatus('in');
      setError(null);
      return true;
    } catch (e: any) {
      if (is_network_error(e)) {
        const saved = saved_me();
        if (saved) { use_saved(saved); return false; } // stay signed in, no scary login screen
      }
      setError(e.message);
      setStatus('out');
      return false;
    }
  }, []);

  useEffect(() => {
    GoogleSignin.configure({ webClientId: WEB_CLIENT_ID, iosClientId: IOS_CLIENT_ID });
    (async () => {
      const saved = saved_me();
      try {
        // Ask Google, but not forever: with a saved profile, a slow or missing network opens it right away.
        const r = await race_timeout(GoogleSignin.signInSilently(), saved ? GOOGLE_WAIT_MS : 0);
        if (r !== TIMED_OUT && r.type === 'success') { await reload(); return; }
      } catch { /* could not ask Google (probably no network) */ }
      // Google did not confirm anyone (offline, slow, or "nobody"): never wipe. Open what is saved, if anything.
      if (saved) use_saved(saved);
      else setStatus('out');
    })();
  }, [reload]);

  const signIn = async () => {
    try {
      setError(null);
      await GoogleSignin.hasPlayServices();
      const r = await GoogleSignin.signIn();
      if (r.type === 'success') {
        // A new login must never inherit the last person's saved profile or courses.
        clear_saved(SAVED_ME);
        clear_saved(SAVED_COURSES);
        from_saved_ref.current = false;
        await reload();
      }
    } catch (e: any) {
      setError(e.message);
    }
  };

  const signOut = async () => {
    try { await GoogleSignin.signOut(); } catch { /* signing out must always work */ }
    forget_everything();
  };

  return <Ctx.Provider value={{ status, me, error, from_saved, signIn, signOut, reload }}>{children}</Ctx.Provider>;
}
