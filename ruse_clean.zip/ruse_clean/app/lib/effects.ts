// Phone-only preferences for motion, haptics, and tap sounds.
import React, { createContext, useCallback, useContext, useMemo, useState } from 'react';
import { load_saved, save_saved } from './store';

type Prefs = {
  effects_on: boolean;
  haptics_on: boolean;
  sounds_on: boolean;
};

const KEY = 'effects_prefs';
const DEFAULTS: Prefs = { effects_on: true, haptics_on: true, sounds_on: true };

function load_prefs(): Prefs {
  const raw = load_saved<Partial<Prefs>>(KEY);
  if (!raw || typeof raw !== 'object') return { ...DEFAULTS };
  return {
    effects_on: raw.effects_on !== false,
    haptics_on: raw.haptics_on !== false,
    sounds_on: raw.sounds_on !== false,
  };
}

type Ctx = Prefs & {
  set_effects_on: (v: boolean) => void;
  set_haptics_on: (v: boolean) => void;
  set_sounds_on: (v: boolean) => void;
};

const EffectsCtx = createContext<Ctx | null>(null);

export function EffectsProvider({ children }: { children: React.ReactNode }) {
  const [prefs, set_prefs] = useState<Prefs>(load_prefs);

  const write = useCallback((patch: Partial<Prefs>) => {
    set_prefs((prev) => {
      const next = { ...prev, ...patch };
      save_saved(KEY, next);
      return next;
    });
  }, []);

  const value = useMemo<Ctx>(
    () => ({
      ...prefs,
      set_effects_on: (v) => write({ effects_on: v }),
      set_haptics_on: (v) => write({ haptics_on: v }),
      set_sounds_on: (v) => write({ sounds_on: v }),
    }),
    [prefs, write],
  );

  return React.createElement(EffectsCtx.Provider, { value }, children);
}

export function useEffects(): Ctx {
  const ctx = useContext(EffectsCtx);
  if (!ctx) {
    // Safe fallback if a screen is mounted outside the provider (shouldn't happen).
    return {
      ...DEFAULTS,
      set_effects_on: () => {},
      set_haptics_on: () => {},
      set_sounds_on: () => {},
    };
  }
  return ctx;
}
