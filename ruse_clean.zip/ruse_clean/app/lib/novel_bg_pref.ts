import { load_saved, save_saved } from './store';

// ---------------------------------------------------------------
// E5 · Reader choice: hide the author's novel background while reading.
// Phone-only. Missing / false → show background when the novel has one.
// ---------------------------------------------------------------

const KEY = 'novel_bg_off';

type OffMap = Record<string, boolean>;

function load_map(): OffMap {
  const raw = load_saved<OffMap>(KEY);
  if (!raw || typeof raw !== 'object') return {};
  const out: OffMap = {};
  for (const [k, v] of Object.entries(raw)) {
    if (v === true) out[k] = true;
  }
  return out;
}

/** True when the reader has turned off the author background for this novel. */
export function is_novel_bg_off(subject_id: string): boolean {
  const sid = (subject_id || '').trim();
  if (!sid) return false;
  return load_map()[sid] === true;
}

export function set_novel_bg_off(subject_id: string, off: boolean): void {
  const sid = (subject_id || '').trim();
  if (!sid) return;
  const map = load_map();
  if (off) map[sid] = true;
  else delete map[sid];
  save_saved(KEY, map);
}
