// ---------------------------------------------------------------
// Three roles (Phase R1): Reader, Author, Admin.
//   Reader: reads, comments, messages. Nothing else.
//   Author: also uploads novels and chapters, adds themes, recommends a theme for their novels.
//   Admin : oversees everything and accepts new requests (the owner is always an Admin).
// ONE place answers "may this person do X?", so no screen guesses on its own.
// The app only hides buttons: the server must check the role again on every write.
// Pure logic only (no React, no network), so it is easy to test.
// ---------------------------------------------------------------
export type role = 'reader' | 'author' | 'admin';

type who = { role?: unknown; isOwner?: boolean; isAdmin?: boolean; admin?: boolean; email?: string } | null | undefined;

// The person's role. Until the backend sends `role`, the old flags decide: owner or admin = Admin,
// everyone else keeps what they could do before (Author), so nothing disappears by surprise.
export function role_of(me: who): role {
  if (!me) return 'reader';
  if (me.isOwner === true || me.isAdmin === true || me.admin === true) return 'admin';
  const r = typeof me.role === 'string' ? me.role.trim().toLowerCase() : '';
  if (r === 'admin') return 'admin';
  if (r === 'author') return 'author';
  if (r) return 'reader'; // a role we do not know = the safest one
  return 'author';
}

export const is_admin = (me: who): boolean => role_of(me) === 'admin';
export const can_upload = (me: who): boolean => role_of(me) !== 'reader';        // novels, chapters, Your novels
export const can_add_theme = (me: who): boolean => role_of(me) !== 'reader';
export const can_recommend_theme = (me: who): boolean => role_of(me) !== 'reader'; // for their own novels (E4)
export const can_manage_people = (me: who): boolean => role_of(me) === 'admin';

export const role_label = (r: role): string => (r === 'admin' ? 'Admin' : r === 'author' ? 'Author' : 'Reader');

// B4: remove an uploaded theme. Built-ins are never removable (caller checks id list too).
// Admin: any uploaded theme. Author: only one they uploaded (mine / createdBy).
export function can_remove_theme(
  me: who,
  theme: { id?: string; mine?: boolean; createdBy?: string; forSubject?: string } | null | undefined,
  built_in_ids: string[],
): boolean {
  if (!theme?.id || built_in_ids.includes(theme.id)) return false;
  // Novel-exclusive themes are managed on the novel, not in the global picker.
  if (typeof theme.forSubject === 'string' && theme.forSubject.trim()) return false;
  const r = role_of(me);
  if (r === 'admin') return true;
  if (r !== 'author') return false;
  if (theme.mine === true) return true;
  const email = typeof me?.email === 'string' ? me.email.trim().toLowerCase() : '';
  const by = typeof theme.createdBy === 'string' ? theme.createdBy.trim().toLowerCase() : '';
  return !!email && !!by && email === by;
}
