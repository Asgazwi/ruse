// Pure helpers for push notifications (Phase 6c).

// What a notification from the backend carries: { kind, chapter, block }.
export function push_target(data: unknown): { chapter: string; block: number } | null {
  const d = data as any;
  if (!d || typeof d !== 'object') return null;
  if (typeof d.chapter !== 'string' || !/^[a-z0-9-]{1,60}$/.test(d.chapter)) return null;
  const block = Number(d.block);
  if (!Number.isInteger(block) || block < -1) return null; // -1 = a comment on the whole chapter
  return { chapter: d.chapter, block };
}

// Open the chapter at that spot with its comments showing.
export const push_route = (t: { chapter: string; block: number }): string =>
  t.block >= 0 ? `/chapter/${t.chapter}?block=${t.block}&sheet=1` : `/chapter/${t.chapter}?sheet=1`;

export const push_key = (email: string): string => 'push_' + email.toLowerCase().replace(/[^a-z0-9]/g, '_');

// Where a tapped notification opens: a message opens that chat, a comment or reply opens the chapter at that spot.
// Anything else (like the test notification) just opens the app.
export function push_destination(data: unknown): string | null {
  const d = data as any;
  if (!d || typeof d !== 'object') return null;
  if (d.type === 'message' && typeof d.with === 'string' && d.with.trim()) return `/message/${encodeURIComponent(d.with.trim())}`;
  const target = push_target(d);
  return target ? push_route(target) : null;
}

