// Author soundtrack (v63): the author pastes a DIRECT link to the audio file on a file host (MediaFire or similar).
// The app checks the link really gives an audio file (not a web page), then saves it on the novel as musicUrl.
// Nothing is uploaded by the app. Readers save a copy on their phone from the music bar (lib/downloads.ts).
import { api, is_network_error } from './backend';
import { ACTION_SAVE_SUBJECT } from './actions';

export type track_result = { ok: true } | { ok: false; error: string };

// An audio file says audio/… ; some hosts send a generic binary type for files, so that is accepted too.
export const is_audio_type = (type: string | null | undefined): boolean =>
  !!type && (type.toLowerCase().startsWith('audio/') || type.toLowerCase() === 'application/octet-stream');

// Asks for the first bytes only (Range), so a big track is not downloaded just to check it.
export async function check_track_link(url: string): Promise<track_result> {
  const u = url.trim();
  if (!/^https:\/\/\S+$/.test(u)) return { ok: false, error: 'The link must start with https://' };
  try {
    const res = await fetch(u, { headers: { Range: 'bytes=0-0' } });
    if (!res.ok) return { ok: false, error: `The link did not open (error ${res.status}). Use the direct download link of the track.` };
    if (!is_audio_type(res.headers.get('content-type'))) {
      return { ok: false, error: 'This link opens a web page, not an audio file. Use the direct download link of the track.' };
    }
    return { ok: true };
  } catch (e) {
    return { ok: false, error: is_network_error(e) ? 'You need to be online to check the link.' : 'Could not open that link.' };
  }
}

// Checks the link, then saves it on the novel. The author's own novel only (the server checks this).
export async function save_track_link(subject_id: string, url: string): Promise<track_result> {
  const checked = await check_track_link(url);
  if (!checked.ok) return checked;
  try {
    await api(ACTION_SAVE_SUBJECT, { id: subject_id, musicUrl: url.trim() });
    return { ok: true };
  } catch (e: any) {
    return { ok: false, error: `The link was not saved: ${e?.message || 'try again'}.` };
  }
}
