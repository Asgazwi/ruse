import { api } from './backend';
import { ACTION_SAVE_AVATAR } from './actions';

// null = the person closed the photo picker without choosing.
export type pick_outcome = { ok: boolean; text: string } | null;

// Pick a photo, shrink it to 256x256, send it as my picture. Words for every way it can fail, never a crash.
export async function pick_and_save_avatar(): Promise<pick_outcome> {
  try {
    const ImagePicker = await import('expo-image-picker');
    const perm = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (!perm.granted) return { ok: false, text: 'Photo access is needed for a picture.' };
    const picked = await ImagePicker.launchImageLibraryAsync({ mediaTypes: ['images'], quality: 0.9, allowsEditing: true, aspect: [1, 1] });
    if (picked.canceled || !picked.assets?.length) return null;

    let b64: string | undefined;
    try {
      // @ts-ignore expo-image-manipulator is an optional package
      const Manipulator = await import('expo-image-manipulator');
      const out = await Manipulator.manipulateAsync(picked.assets[0].uri, [{ resize: { width: 256, height: 256 } }], { compress: 0.7, format: Manipulator.SaveFormat.JPEG, base64: true });
      b64 = out.base64;
    } catch { /* optional package: handled just below */ }
    if (!b64) return { ok: false, text: 'The picture needs expo-image-manipulator in the build (or the photo could not be read).' };

    await api(ACTION_SAVE_AVATAR, b64);
    return { ok: true, text: 'Picture saved.' };
  } catch (e: any) {
    const msg = String(e?.message || e || '');
    if (/ExpoImagePicker|Cannot find module|Native module/i.test(msg)) return { ok: false, text: 'The picture needs a new build with expo-image-picker (and expo-image-manipulator).' };
    return { ok: false, text: msg || 'Could not save the picture.' };
  }
}
