// ---------------------------------------------------------------
// Novel kinds (Phase E1, changed in v63): Novel | Manga | Webtoon. Old 'donghua' items are read as Webtoon.
// Pure logic only.
// ---------------------------------------------------------------
import type { NovelKind } from './types';

export const NOVEL_KINDS: NovelKind[] = ['novel', 'manga', 'webtoon'];

export function normalize_kind(raw: unknown): NovelKind {
  const k = typeof raw === 'string' ? raw.trim().toLowerCase() : '';
  if (k === 'donghua' || k === 'webtoon') return 'webtoon';
  if (k === 'manga' || k === 'novel') return k;
  return 'novel';
}

export function kind_label(kind: unknown): string {
  const k = normalize_kind(kind);
  if (k === 'manga') return 'Manga';
  if (k === 'webtoon') return 'Webtoon';
  return 'Novel';
}

export function kind_emoji(kind: unknown): string {
  const k = normalize_kind(kind);
  if (k === 'manga') return '📗';
  if (k === 'webtoon') return '📱';
  return '📖';
}
