import * as Notifications from 'expo-notifications';
import Constants from 'expo-constants';
import { api } from './backend';
import { ACTION_REGISTER_PUSH_TOKEN, ACTION_TEST_PUSH } from './actions';

export type push_test_result = { ok: boolean; text: string };

// Runs the whole notification chain once, and says in plain words where it stops:
// permission -> this phone's address -> the server knows it -> Expo -> Google -> the phone.
export async function run_push_test(on_step: (text: string) => void): Promise<push_test_result> {
  on_step('Checking permission…');
  let perm = await Notifications.getPermissionsAsync();
  if (perm.status !== 'granted') perm = await Notifications.requestPermissionsAsync();
  if (perm.status !== 'granted') {
    return { ok: false, text: 'Notifications are switched off for Marginalia. Open the phone Settings, then Apps, then Marginalia, then Notifications, and allow them.' };
  }

  on_step('Getting this phone’s notification address…');
  let token = '';
  try {
    const project_id = (Constants as any)?.expoConfig?.extra?.eas?.projectId ?? (Constants as any)?.easConfig?.projectId;
    token = (await Notifications.getExpoPushTokenAsync(project_id ? { projectId: project_id } : undefined)).data;
  } catch (e: any) {
    return { ok: false, text: `This phone could not get a notification address: ${e?.message || 'unknown error'}. Notifications need a real build of the app (not Expo Go) that includes google-services.json.` };
  }

  on_step('Telling the server about this phone…');
  try {
    await api(ACTION_REGISTER_PUSH_TOKEN, token);
  } catch (e: any) {
    return { ok: false, text: `The server did not accept this phone: ${e?.message || 'try again'}.` };
  }

  on_step('Sending a test notification… this takes about 10 seconds.');
  try {
    const r = await api<{ ok?: boolean; text?: string }>(ACTION_TEST_PUSH);
    return { ok: !!r?.ok, text: String(r?.text || 'The server gave no details.') };
  } catch (e: any) {
    return { ok: false, text: `The test could not run: ${e?.message || 'try again'}.` };
  }
}
