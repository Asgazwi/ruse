export type Block =
  | { type: 'p' | 'h' | 'code'; text: string }
  | { type: 'callout'; kind: 'tip' | 'warn' | 'ok'; text: string }
  | { type: 'list'; items: string[] }
  | { type: 'table'; headers: string[]; rows: string[][] };

export type Chapter = {
  id: string; subject: string; order: number; title: string; summary?: string; minutes: number;
  style?: { font?: string; accent?: string; highlight?: Record<string, string> };
  blocks: Block[]; pages?: string[]; // E2: manga pages (https image links); a manga chapter uses pages instead of blocks
  uploadedBy?: string; uploaderName?: string; mine?: boolean; can_manage?: boolean;
  // quiz removed: this is a novel reader, not a course. Old JSON may still carry quiz; the app ignores it.
};

export type NovelKind = 'novel' | 'manga' | 'webtoon';
export type Subject = {
  id: string; order: number; title: string; summary?: string;
  kind?: NovelKind;           // E1: Novel | Manga | Webtoon
  folderId?: string;          // E1: Drive folder for assets (backend creates)
  backgroundUrl?: string;     // E5: author reading background (from novel folder)
  musicUrl?: string;          // F2: author's soundtrack, a direct https link to the audio file on a free host (v63)
  createdBy?: string; uploaderName?: string; category?: string[];
  mine?: boolean; can_manage?: boolean;
};

export type ThemeColors = {
  bg: string; surface: string; ink: string; muted: string; line: string;
  primary: string; primaryFg: string; accent: string; accentFg: string;
};
import type { theme_effects } from './recipes';
import type { button_look } from './button_look';
export type Theme = {
  id: string; name: string; font: string; effect: string; colors: ThemeColors;
  heading_font?: string;  // titles and buttons; "font" is used for body text
  radius?: number;        // corner radius of course and folder cards, 4 to 32
  effects?: theme_effects; // designed tap and background effects (see lib/recipes.ts)
  button?: button_look;    // how buttons look and feel (see lib/button_look.ts); optional
  createdBy?: string;     // uploader email or id (server); used for "own" checks until usernames (D1a)
  mine?: boolean;         // server says this person uploaded it
  // Linked to one novel (E4 / author novel theme). Stays on that novel only — never in the global theme picker.
  forSubject?: string;
};

export type Progress = { completed: string[]; active: string | null; subject: string | null; theme: string };
export type Gender = 'boy' | 'girl' | 'skip';
export type Me = { signedIn: boolean; email?: string; allowed?: boolean; name?: string; username?: string | null; usernameChangedAt?: string | null; gender?: Gender | null; avatarUrl?: string | null; isOwner?: boolean; isAdmin?: boolean; role?: string; requestStatus?: string | null; requestName?: string; roleRequestStatus?: string | null };
export type CourseData = { subjects: Subject[]; chapters: Chapter[]; themes: Theme[]; progress: Progress | null };

// People list for the Admin screen (R2). role is the source of truth; admin is kept
// as a convenience flag (true when role === 'admin') so older code still works.
export type AdminPerson = { email: string; name: string; role: 'reader' | 'author' | 'admin'; admin: boolean; pendingRole?: 'author' | null };
export type AdminData = { requests: AdminPerson[]; users: AdminPerson[] };
