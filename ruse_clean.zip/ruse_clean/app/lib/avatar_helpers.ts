// Pure helpers for avatars: the letter and the colour shown when a person has no photo.
const PALETTE = ['#8a4b3a', '#5b3f6b', '#3e5b4d', '#7a5a2e', '#2f3a5f', '#4a4a52', '#0f766e', '#993556'];

export function avatar_initial(name?: string | null): string {
  const t = (name ?? '').trim();
  return t ? (Array.from(t)[0] ?? '?').toUpperCase() : '?';
}

// The same name always gets the same colour, so a person looks the same everywhere.
export function avatar_color(name?: string | null): string {
  const t = (name ?? '').trim().toLowerCase();
  let h = 0;
  for (const ch of t) h = (h * 31 + ch.codePointAt(0)!) >>> 0;
  return PALETTE[h % PALETTE.length];
}
