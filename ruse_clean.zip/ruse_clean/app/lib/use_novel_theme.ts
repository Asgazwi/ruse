import { useEffect, useState } from 'react';
import { useTheme } from './theme';
import {
  get_novel_theme_choice,
  set_novel_theme_choice,
  should_use_novel_theme,
  type novel_theme_choice,
} from './novel_theme_pref';
import type { Theme } from './types';

// ---------------------------------------------------------------
// E4 · While a novel screen is focused: apply the exclusive theme if the
// reader accepted it, and expose banner state + handlers.
// Clears the override when the screen unmounts so other screens stay on the global theme.
// ---------------------------------------------------------------

export function useNovelTheme(subject_id: string | null | undefined) {
  const { theme_for_novel, set_theme_override } = useTheme();
  const sid = (subject_id || '').trim();
  const recommended = sid ? theme_for_novel(sid) : null;

  // Local mirror of the saved choice so the banner can hide without a full remount.
  const [choice, setChoice] = useState<novel_theme_choice | null>(() =>
    sid ? get_novel_theme_choice(sid) : null,
  );

  // Re-read when the novel id changes (navigating between novels).
  useEffect(() => {
    setChoice(sid ? get_novel_theme_choice(sid) : null);
  }, [sid]);

  // Apply / clear override while this screen is mounted.
  useEffect(() => {
    if (!sid || !recommended) {
      set_theme_override(null);
      return;
    }
    if (should_use_novel_theme(sid)) {
      set_theme_override(recommended);
    } else {
      set_theme_override(null);
    }
    return () => { set_theme_override(null); };
  }, [sid, recommended, choice, set_theme_override]);

  const show_banner = !!recommended && choice === null;

  const accept = (next: novel_theme_choice) => {
    if (!sid) return;
    set_novel_theme_choice(sid, next);
    setChoice(next);
    if (next === 'yes' || next === 'always') {
      if (recommended) set_theme_override(recommended);
    } else {
      set_theme_override(null);
    }
  };

  return {
    recommended: recommended as Theme | null,
    show_banner,
    on_yes: () => accept('yes'),
    on_always: () => accept('always'),
    on_no: () => accept('no'),
  };
}
