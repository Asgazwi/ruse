// Pure helpers for safety (Phase D4): Block, Report, and what admins see. No React, so they can be tested alone.
// The server checks every action again (who may report, rate limits, admin-only screens). The app only shows them.

export const REPORT_REASONS = [
  { key: 'spam', label: 'Spam or advertising' },
  { key: 'harass', label: 'Harassment or bullying' },
  { key: 'sexual', label: 'Sexual content' },
  { key: 'hate', label: 'Hate or threats' },
  { key: 'other', label: 'Something else' },
] as const;

export type ReportReason = (typeof REPORT_REASONS)[number]['key'];

export const reason_label = (key: string): string => REPORT_REASONS.find((r) => r.key === key)?.label ?? 'Something else';

const key = (name: string) => name.trim().toLowerCase();

export function is_valid_reason(k: unknown): k is ReportReason {
  return REPORT_REASONS.some((r) => r.key === k);
}

// A report needs a real username and a known reason. Nothing else is sent.
export function report_check(username: string, reason: unknown): { ok: true; reason: ReportReason } | { ok: false; reason: string } {
  if (!username.trim()) return { ok: false, reason: 'Pick a person first.' };
  if (!is_valid_reason(reason)) return { ok: false, reason: 'Pick a reason.' };
  return { ok: true, reason };
}

// Usernames I have blocked, as a set for quick checks.
export const blocked_set = (names: string[]): Set<string> => new Set(names.map(key));
export const is_blocked = (set: Set<string>, username: string | null | undefined): boolean => !!username && set.has(key(username));

// Friendly text for "they cannot message you" when the server refuses (messaging turned off by an admin).
export const MESSAGING_OFF_TEXT = 'This person cannot receive messages right now.';

// What the admin sees for one open report (from getReports).
export type Report = {
  id: string; reported: string; by: string; reason: string; created: string;
  count: number;             // how many different people reported this person
  messaging_off: boolean;    // an admin already turned messaging off for them
};
