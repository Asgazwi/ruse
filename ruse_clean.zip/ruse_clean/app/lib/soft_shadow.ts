// Quiet depth. Cards rest flat on a hairline border (level 1 = no shadow); level 2 is a barely-there lift;
// level 3 is for things that float above the page (tab bar, sheets). The colour argument is kept so
// existing calls still work, but shadows are neutral now: coloured glows are gone.
export function soft_shadow(_color: string, level: 1 | 2 | 3) {
  if (level === 1) return { elevation: 0 };
  const o = level === 2 ? { y: 2, blur: 8, a: 0.06, e: 1 } : { y: 6, blur: 16, a: 0.1, e: 4 };
  return { shadowColor: '#000000', shadowOffset: { width: 0, height: o.y }, shadowOpacity: o.a, shadowRadius: o.blur, elevation: o.e };
}
