// ---------------------------------------------------------------
// Decides WHAT flies out when you tap, for each effect name the backend knows.
// Pure numbers only (no React, no animation), so it is easy to test.
// The layer in components/effect_layer.tsx turns these into motion.
// ---------------------------------------------------------------
export const EFFECT_NAMES = ['none', 'ripple', 'confetti', 'sparkle', 'pop', 'hearts', 'petals', 'bubbles'] as const;
export type effect_name = (typeof EFFECT_NAMES)[number];

export type particle = {
  shape: 'glyph' | 'dot' | 'ring' | 'rect';
  glyph?: string;
  dx: number; dy: number;   // where it ends up, relative to the tap, in px
  rot: number;              // total turn in radians
  size: number;             // px
  delay: number; duration: number; // ms
  color_slot: number;       // 0 accent, 1 primary, 2-4 candy colors (resolved by the layer)
  color?: string;           // an exact colour from a custom theme (wins over color_slot)
  grow: boolean;            // starts small and grows to full size
};

export const MAX_BURSTS = 6; // never more than this many taps animating at once (keeps old phones smooth)

export const is_effect_name = (x: unknown): x is effect_name => EFFECT_NAMES.includes(x as effect_name);

const between = (rand: () => number, lo: number, hi: number) => lo + rand() * (hi - lo);
const sign = (rand: () => number) => (rand() < 0.5 ? -1 : 1);
const slot = (rand: () => number, n: number) => Math.floor(rand() * n);

export function make_particles(effect: string, rand: () => number = Math.random): particle[] {
  const list: particle[] = [];
  const add = (n: number, make: (i: number) => particle) => { for (let i = 0; i < n; i += 1) list.push(make(i)); };

  switch (effect) {
    case 'hearts':
      add(5, () => ({ shape: 'glyph', glyph: '♥', dx: between(rand, -32, 32), dy: -between(rand, 60, 115), rot: between(rand, -0.5, 0.5), size: between(rand, 14, 24), delay: between(rand, 0, 120), duration: between(rand, 800, 1100), color_slot: slot(rand, 2), grow: true }));
      break;
    case 'petals':
      add(6, () => ({ shape: 'glyph', glyph: '✿', dx: between(rand, -55, 55), dy: between(rand, 60, 115), rot: sign(rand) * between(rand, 2, 4), size: between(rand, 13, 20), delay: between(rand, 0, 160), duration: between(rand, 1000, 1400), color_slot: slot(rand, 2), grow: false }));
      break;
    case 'sparkle':
      add(6, (i) => { const a = (i / 6) * Math.PI * 2 + between(rand, -0.3, 0.3); const r = between(rand, 28, 58); return { shape: 'glyph', glyph: '✦', dx: Math.cos(a) * r, dy: Math.sin(a) * r, rot: between(rand, -1, 1), size: between(rand, 10, 17), delay: between(rand, 0, 80), duration: between(rand, 500, 700), color_slot: slot(rand, 3), grow: true }; });
      break;
    case 'confetti':
      add(14, () => { const a = -Math.PI / 2 + between(rand, -1.4, 1.4); const r = between(rand, 50, 115); return { shape: 'rect', dx: Math.cos(a) * r, dy: Math.sin(a) * r + 45, rot: sign(rand) * between(rand, 3, 7), size: between(rand, 6, 10), delay: between(rand, 0, 60), duration: between(rand, 800, 1100), color_slot: slot(rand, 5), grow: false }; });
      break;
    case 'bubbles':
      add(5, () => ({ shape: 'ring', dx: between(rand, -28, 28), dy: -between(rand, 50, 105), rot: 0, size: between(rand, 10, 24), delay: between(rand, 0, 140), duration: between(rand, 900, 1300), color_slot: slot(rand, 2), grow: true }));
      break;
    case 'pop':
      add(8, (i) => { const a = (i / 8) * Math.PI * 2 + between(rand, -0.2, 0.2); const r = between(rand, 22, 42); return { shape: 'dot', dx: Math.cos(a) * r, dy: Math.sin(a) * r, rot: 0, size: between(rand, 5, 8), delay: 0, duration: between(rand, 350, 450), color_slot: slot(rand, 3), grow: false }; });
      break;
    case 'ripple':
      add(1, () => ({ shape: 'ring', dx: 0, dy: 0, rot: 0, size: 72, delay: 0, duration: 600, color_slot: 0, grow: true }));
      break;
    default:
      break; // 'none' and anything unknown: nothing flies out
  }
  return list;
}

// How long a burst stays on screen before it can be thrown away.
export const burst_length_ms = (parts: particle[]): number =>
  parts.reduce((longest, p) => Math.max(longest, p.delay + p.duration), 0);
