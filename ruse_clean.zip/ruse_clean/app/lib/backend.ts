// The "move one action at a time" switch (SUPABASE_PLAN section 13).
// Every screen calls api(action, ...args). Today every action goes to Apps Script.
// When an action's Supabase version (lib/sb/) passes its tests, add its name to MOVED.
// Rolling one action back = deleting one word from MOVED. An action lives in exactly one place at a time.
import { gas_call, is_network_error } from './api';
import { sb_handlers } from './sb';
import { make_error } from './net_retry';

export { is_network_error };

// Empty on purpose: nothing has moved yet. Phase 1 first (profiles, roles, admin), then 2 (chat), 3, 4.
export const MOVED = new Set<string>([]);

export async function api<T>(action: string, ...args: unknown[]): Promise<T> {
  if (!MOVED.has(action)) return gas_call<T>(action, ...args);
  const handler = sb_handlers[action];
  if (!handler) throw make_error(`"${action}" is switched to the new backend but has no handler yet.`, 'backend');
  return (await handler(...args)) as T;
}
