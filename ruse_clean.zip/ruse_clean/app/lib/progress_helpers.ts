import type { Chapter, Progress } from './types';

// Pure helpers for progress. No React / Expo.

const unique = (list: string[]) => Array.from(new Set(list));

// Progress after finishing a chapter. Finishing twice changes nothing.
export function with_completed(old: Progress | null, chapter: Chapter, theme_id: string): Progress {
  return {
    completed: unique([...(old?.completed ?? []), chapter.id]),
    active: chapter.id,
    subject: chapter.subject,
    theme: old?.theme || theme_id,
  };
}

// Server copy + phone copy: nothing finished is ever lost. The phone copy wins on "active".
export function merge_progress(server: Progress | null, phone: Progress): Progress {
  return {
    completed: unique([...(server?.completed ?? []), ...phone.completed]),
    active: phone.active ?? server?.active ?? null,
    subject: phone.subject ?? server?.subject ?? null,
    theme: server?.theme || phone.theme,
  };
}

export function same_progress(a: Progress | null, b: Progress | null): boolean {
  if (!a || !b) return a === b;
  const x = [...a.completed].sort().join('|');
  const y = [...b.completed].sort().join('|');
  return x === y && a.active === b.active;
}

// Whole-number percent for a progress bar (0 when the novel has no chapters).
export const percent = (done: number, total: number): number => (total > 0 ? Math.round((done / total) * 100) : 0);
