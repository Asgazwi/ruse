import { File, Paths } from 'expo-file-system';
import { load_saved, save_saved, clear_saved } from './store';

// ---------------------------------------------------------------
// Home / app background photo (Phase B5).
// Phone-only preference (like the chosen theme id): stays after sign-out.
// The image itself is copied into the app's private folder so the URI stays valid.
// ---------------------------------------------------------------

export const SAVED_HOME_BG = 'home_bg_uri'; // preference key → string URI or null
const BG_FILE_NAME = 'ruse_home_bg.jpg';

const bg_file = () => new File(Paths.document, BG_FILE_NAME);

/** Current Home background URI, or null if none / missing file. */
export function load_home_bg(): string | null {
  const saved = load_saved<string>(SAVED_HOME_BG);
  if (!saved || typeof saved !== 'string' || !saved.trim()) return null;
  try {
    const f = bg_file();
    if (f.exists) return f.uri;
  } catch {
    /* fall through */
  }
  // Legacy: URI was stored without a local copy (still try it).
  return saved.trim();
}

/** Copy a picked image into the app folder and remember it. Returns the stable URI. */
export async function save_home_bg_from_uri(source_uri: string): Promise<string> {
  const src = new File(source_uri);
  const dest = bg_file();
  try {
    if (dest.exists) dest.delete();
  } catch {
    /* ok */
  }
  // Copy bytes into our private folder (survives picker cache cleanup).
  src.copy(dest);
  const uri = dest.uri;
  save_saved(SAVED_HOME_BG, uri);
  return uri;
}

/** Remove the Home background photo. */
export function clear_home_bg(): void {
  clear_saved(SAVED_HOME_BG);
  try {
    const f = bg_file();
    if (f.exists) f.delete();
  } catch {
    /* nothing to clear */
  }
}
