// ---------------------------------------------------------------
// Theme fonts. Every font in THEME_FONTS has a medium (500) and a bold (700) weight loaded
// in app/_layout.tsx. Screens keep writing "Figtree_700Bold"; the theme decides what it becomes:
//  - weight 700 (titles, buttons) uses the theme's heading font
//  - weight 500 (body text) uses the theme's body font
// ---------------------------------------------------------------
export const THEME_FONTS = ['Figtree', 'Newsreader', 'Inter', 'Merriweather', 'Lora', 'Roboto Mono', 'Quicksand'] as const;

const FAMILY: Record<string, string> = {
  Figtree: 'Figtree', Newsreader: 'Newsreader', Inter: 'Inter', Merriweather: 'Merriweather',
  Lora: 'Lora', 'Roboto Mono': 'RobotoMono', Quicksand: 'Quicksand',
};

// The loaded name for a theme font and weight, e.g. ("Lora", "bold") -> "Lora_700Bold".
export function font_name(theme_font: string, weight: 'bold' | 'medium'): string {
  const base = FAMILY[theme_font] ?? 'Figtree';
  return weight === 'bold' ? `${base}_700Bold` : `${base}_500Medium`;
}

// Maps a screen's font name to the theme's font. Other names (e.g. reader chapter fonts) are left alone.
// Bold text 17 and up is a title (heading font, e.g. the serif). Smaller bold text is a label or button
// and stays in the body font, so buttons and tab names look like an interface, not a book.
export const TITLE_MIN_SIZE = 17;
export function map_theme_fonts(family: string | undefined, body: string, heading: string, size?: number): string | undefined {
  if (!family) return family;
  if (family === 'Figtree_700Bold') return font_name(typeof size === 'number' && size < TITLE_MIN_SIZE ? body : heading, 'bold');
  if (family === 'Figtree_500Medium') return font_name(body, 'medium');
  return family;
}
