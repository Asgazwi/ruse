// Pure helpers for the profile card (Phase D2). No React / Expo, so they can be tested alone.
// The card only ever shows a username and avatar, never an email or real name (D1a, A9).
import { display_name } from './pin_helpers';

export type CardPerson = { username: string; avatarUrl: string | null; initial: string };

// Who a tap on a name should open. Returns null when there is nobody real to show
// (no name yet, an email, or the "Reader" / "Someone" fallbacks), so those names are not tappable.
export function card_person(name: unknown, avatarUrl?: unknown): CardPerson | null {
  const username = display_name(name, '');
  if (!username || username === 'Reader' || username === 'Someone') return null;
  const url = typeof avatarUrl === 'string' && /^https?:\/\//.test(avatarUrl.trim()) ? avatarUrl.trim() : null;
  return { username, avatarUrl: url, initial: username.charAt(0).toUpperCase() };
}
