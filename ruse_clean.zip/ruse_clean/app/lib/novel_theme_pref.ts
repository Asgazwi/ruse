import { load_saved, save_saved } from './store';

// ---------------------------------------------------------------
// E4 · Reader choice for a novel's recommended / exclusive theme.
// Phone-only preference (like the chosen theme id and Home background).
// 'yes' / 'always' → use the novel theme while on that novel's screens.
// 'no' → hide the banner for this novel.
// Missing → show the banner once the novel has a forSubject theme.
// ---------------------------------------------------------------

export type novel_theme_choice = 'yes' | 'no' | 'always';

const KEY = 'novel_theme_pref';

type PrefMap = Record<string, novel_theme_choice>;

function load_map(): PrefMap {
  const raw = load_saved<PrefMap>(KEY);
  if (!raw || typeof raw !== 'object') return {};
  const out: PrefMap = {};
  for (const [k, v] of Object.entries(raw)) {
    if (v === 'yes' || v === 'no' || v === 'always') out[k] = v;
  }
  return out;
}

export function get_novel_theme_choice(subject_id: string): novel_theme_choice | null {
  const sid = (subject_id || '').trim();
  if (!sid) return null;
  return load_map()[sid] ?? null;
}

/** True when the reader has accepted the recommended theme for this novel (session or always). */
export function should_use_novel_theme(subject_id: string): boolean {
  const c = get_novel_theme_choice(subject_id);
  return c === 'yes' || c === 'always';
}

export function set_novel_theme_choice(subject_id: string, choice: novel_theme_choice): void {
  const sid = (subject_id || '').trim();
  if (!sid) return;
  const map = load_map();
  map[sid] = choice;
  save_saved(KEY, map);
}

/** Clear a single novel's choice (e.g. after the author removes the exclusive theme). */
export function clear_novel_theme_choice(subject_id: string): void {
  const sid = (subject_id || '').trim();
  if (!sid) return;
  const map = load_map();
  if (!(sid in map)) return;
  delete map[sid];
  save_saved(KEY, map);
}
