// Pure helpers for the manga reader (Phase E2). No React, so they can be tested alone.
// A manga chapter is a list of page image links: chapter.pages = ["https://…/p1.jpg", …].

export const MAX_PAGES = 300;          // keeps one chapter a sane size on a phone
export const PRELOAD_AHEAD = 3;        // how many pages after the current one to fetch early

// Only https links are shown. Anything else is dropped rather than crashing the reader.
export function manga_pages(chapter: { pages?: unknown } | null | undefined): string[] {
  const list = Array.isArray(chapter?.pages) ? chapter!.pages as unknown[] : [];
  return list.filter((u): u is string => typeof u === 'string' && /^https:\/\/\S+$/.test(u.trim())).map((u) => u.trim());
}

export const is_manga_chapter = (chapter: { pages?: unknown } | null | undefined): boolean => manga_pages(chapter).length > 0;

// Upload check for a manga chapter. Returns a message for the author, or null when it is fine.
export function check_pages(pages: unknown, label: string): string | null {
  if (!Array.isArray(pages) || pages.length === 0) return `${label} needs a "pages" list with at least one image link.`;
  if (pages.length > MAX_PAGES) return `${label} has ${pages.length} pages. The limit is ${MAX_PAGES}. Split it into two chapters.`;
  const bad = pages.findIndex((u) => typeof u !== 'string' || !/^https:\/\/\S+$/.test(u.trim()));
  if (bad !== -1) return `${label}, page ${bad + 1}: each page must be an https image link.`;
  return null;
}

// Page indexes to fetch early after the reader lands on `current` (0-based).
export function preload_indexes(current: number, total: number, ahead = PRELOAD_AHEAD): number[] {
  const out: number[] = [];
  for (let i = current + 1; i <= Math.min(total - 1, current + ahead); i++) out.push(i);
  return out;
}

// "3 / 24" for the progress label.
export const page_label = (current: number, total: number): string => (total ? `${current + 1} / ${total}` : '');

// Page-by-page mode: move by one page, never past the ends.
export const step_page = (current: number, delta: number, total: number): number =>
  Math.max(0, Math.min(total - 1, current + delta));

// A short, stable name for one page link (used for its file name on the phone).
export function page_key(url: string): string {
  let h = 5381;
  for (let i = 0; i < url.length; i++) h = ((h * 33) ^ url.charCodeAt(i)) >>> 0;
  return h.toString(16);
}

// Rough size warning: pages are often 0.3 to 1 MB each. Shown before a big download.
export const pages_size_note = (count: number): string =>
  `About ${Math.max(1, Math.round((count * 0.6)))} MB on this phone, roughly.`;
