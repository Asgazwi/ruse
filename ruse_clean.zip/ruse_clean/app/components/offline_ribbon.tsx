import { ActivityIndicator, StyleSheet, View } from 'react-native';
import { AppText as Text } from './app_text';
import { BouncyPressable as Pressable } from './bouncy_pressable';
import { GlowButton } from './glow_button';
import { useData } from '../lib/data';
import { useTheme } from '../lib/theme';
import { time_ago } from '../lib/data_helpers';
import { soft_shadow } from '../lib/soft_shadow';
import { W } from '../lib/words';

// Small ribbon shown while we are offline and the screen is using saved courses.
export function OfflineRibbon() {
  const { offline, syncing, last_synced, data, refresh } = useData();
  const { theme } = useTheme();
  const c = theme.colors;
  if (!offline || !data) return null;
  const when = time_ago(last_synced);
  return (
    <View style={[s.ribbon, soft_shadow(c.muted, 1), { backgroundColor: c.surface, borderColor: c.line }]}>
      <Text style={s.icon}>📴</Text>
      <View style={{ flex: 1 }}>
        <Text style={[s.title, { color: c.ink }]}>Offline, showing saved {W.novels}</Text>
        {!!when && <Text style={[s.sub, { color: c.muted }]}>Saved {when}</Text>}
      </View>
      <GlowButton label="Retry" on_press={() => refresh()} busy={syncing} size="sm" color={c.primary} text_color={c.primaryFg} style={s.btn} />
    </View>
  );
}

const s = StyleSheet.create({
  ribbon: { flexDirection: 'row', alignItems: 'center', gap: 12, borderWidth: 1, borderRadius: 20, paddingVertical: 10, paddingLeft: 14, paddingRight: 10, marginBottom: 16 },
  icon: { fontSize: 20 },
  title: { fontFamily: 'Figtree_700Bold', fontSize: 14 },
  sub: { fontFamily: 'Figtree_500Medium', fontSize: 12, marginTop: 1 },
  btn: { minWidth: 72 },
  btn_text: { fontFamily: 'Figtree_700Bold', fontSize: 14 },
});
