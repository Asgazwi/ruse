import { StyleSheet, Text } from 'react-native';
import { useTheme } from '../lib/theme';
import { map_theme_fonts } from '../lib/fonts';

// Drop-in for <Text>. Screens write `fontFamily: 'Figtree_700Bold'`; when the chosen theme
// uses Quicksand this swaps in the Quicksand version. Everything else is passed straight through.
// `exact` = "use the font I wrote, do not swap it for the theme's font". The chapter reader sets it
// when a chapter asks for its own font (Phase A8), so a Lora chapter stays Lora on every theme.
export function AppText({ style, exact, ...rest }: any) {
  const { theme } = useTheme();
  if (exact) return <Text {...rest} style={style} />;
  const flat: any = StyleSheet.flatten(style) || {};
  const family = map_theme_fonts(flat.fontFamily, theme.font, theme.heading_font ?? theme.font, flat.fontSize);
  return <Text {...rest} style={family === flat.fontFamily ? style : [style, { fontFamily: family }]} />;
}
