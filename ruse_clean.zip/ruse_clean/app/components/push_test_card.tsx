import { useState } from 'react';
import { StyleSheet, View } from 'react-native';
import { AppText as Text } from './app_text';
import { GlowButton } from './glow_button';
import { useTheme } from '../lib/theme';
import { soft_shadow } from '../lib/soft_shadow';
import { run_push_test, type push_test_result } from '../lib/push_test';

// Settings: "Send me a test notification". Walks the whole chain and shows exactly where it stops.
export function PushTestCard() {
  const { theme } = useTheme();
  const c = theme.colors;
  const [busy, setBusy] = useState(false);
  const [step, setStep] = useState('');
  const [result, setResult] = useState<push_test_result | null>(null);

  const run = async () => {
    setBusy(true);
    setResult(null);
    try {
      setResult(await run_push_test(setStep));
    } catch (e: any) {
      setResult({ ok: false, text: `The test could not run: ${e?.message || 'try again'}.` });
    } finally {
      setBusy(false);
    }
  };

  return (
    <View style={[s.card, soft_shadow(c.primary, 1), { backgroundColor: c.surface, borderColor: c.line }]}>
      <Text style={{ color: c.muted, fontFamily: 'Figtree_500Medium', marginBottom: 12 }}>
        Not getting message or comment alerts? This checks every step between the server and this phone, and tells you which one fails.
      </Text>
      <GlowButton label={busy ? step || 'Working…' : 'Send me a test notification'} on_press={run} busy={busy} disabled={busy} color={c.primary} text_color={c.primaryFg} />
      {result ? (
        <Text style={{ color: result.ok ? c.ink : '#b3261e', fontFamily: 'Figtree_500Medium', marginTop: 12 }}>
          {result.ok ? '✅ ' : '⚠️ '}{result.text}
        </Text>
      ) : null}
    </View>
  );
}

const s = StyleSheet.create({
  card: { borderWidth: 1, borderRadius: 24, padding: 18 },
});
