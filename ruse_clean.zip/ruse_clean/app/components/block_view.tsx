import { Platform, ScrollView, StyleSheet, View } from 'react-native';
import { AppText as Text } from './app_text';
import { useTheme } from '../lib/theme';
import { alpha_hex } from '../lib/alpha_hex';
import { text_on } from '../lib/contrast';
import { callout_look, chapter_fonts, safe_color, split_highlights } from '../lib/reader';
import type { Block, Chapter } from '../lib/types';

const MONO = Platform.select({ ios: 'Menlo', default: 'monospace' });

// Text with the chapter's highlighted words colored.
function Rich({ text, chapter, style, color }: { text: string; chapter: Chapter; style?: any; color: string }) {
  const { theme } = useTheme();
  const f = chapter_fonts(chapter.style?.font);
  const pieces = split_highlights(text, chapter.style?.highlight, theme.colors.accent);
  return (
    <Text exact={f.exact} style={[{ color, fontFamily: f.regular }, style]}>
      {pieces.map((p, i) =>
        p.color
          ? <Text key={i} exact={f.exact} style={{ color: p.color, fontFamily: f.bold }}>{p.text}</Text>
          : <Text key={i} exact={f.exact}>{p.text}</Text>,
      )}
    </Text>
  );
}

// One block of a chapter: paragraph, heading, list, code, callout or table.
// (The old `extra`, `pinned` and `on_layout` props were never used by the reader, so they are gone.)
export function BlockView({ block, chapter }: { block: Block; chapter: Chapter }) {
  const { theme } = useTheme();
  const c = theme.colors;
  const accent = safe_color(chapter.style?.accent, c.accent);
  const f = chapter_fonts(chapter.style?.font);

  let body: React.ReactNode = null;
  switch (block.type) {
    case 'p':
      body = <Rich text={block.text} chapter={chapter} color={c.ink} style={s.p} />;
      break;
    case 'h':
      body = (
        // v63: a serif heading with a short hairline rule above it, in the chapter's accent colour.
        <View style={s.h_wrap}>
          <View style={[s.h_rule, { backgroundColor: accent }]} />
          <Text exact={f.exact} style={[s.h, { color: c.ink, fontFamily: f.bold }]}>{block.text}</Text>
        </View>
      );
      break;
    case 'list':
      body = (
        <View style={{ gap: 8 }}>
          {(block.items ?? []).map((item, i) => (
            <View key={i} style={s.li}>
              <View style={[s.dot, { backgroundColor: accent, borderColor: alpha_hex(accent, 0.25) }]} />
              <View style={{ flex: 1 }}><Rich text={item} chapter={chapter} color={c.ink} style={s.p} /></View>
            </View>
          ))}
        </View>
      );
      break;
    case 'code':
      body = (
        <View style={[s.code, { backgroundColor: c.surface, borderColor: c.line }]}>
          <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ padding: 14 }}>
            <Text selectable style={{ color: c.ink, fontFamily: MONO, fontSize: 14, lineHeight: 21 }}>{block.text}</Text>
          </ScrollView>
        </View>
      );
      break;
    case 'callout': {
      const look = callout_look(block.kind, c);
      body = (
        <View style={[s.callout, { backgroundColor: look.bg, borderLeftColor: look.bar }]}>
          <Text exact={f.exact} style={[s.callout_label, { color: look.bar, fontFamily: f.bold }]}>{look.label}</Text>
          <Rich text={block.text} chapter={chapter} color={c.ink} style={s.p} />
        </View>
      );
      break;
    }
    case 'table':
      body = (
        <ScrollView horizontal showsHorizontalScrollIndicator={false}>
          <View style={[s.table, { borderColor: c.line }]}>
            <View style={[s.tr, { backgroundColor: accent }]}>
              {(block.headers ?? []).map((h, i) => (
                <Text key={i} exact={f.exact} style={[s.th, { color: text_on(accent), fontFamily: f.bold }]}>{h}</Text>
              ))}
            </View>
            {(block.rows ?? []).map((row, r) => (
              <View key={r} style={[s.tr, { backgroundColor: r % 2 ? c.surface : c.bg, borderTopWidth: 1, borderTopColor: c.line }]}>
                {row.map((cell, i) => (
                  <Text key={i} exact={f.exact} style={[s.td, { color: c.ink, fontFamily: f.regular }]}>{cell}</Text>
                ))}
              </View>
            ))}
          </View>
        </ScrollView>
      );
      break;
  }
  if (!body) return null; // unknown block type from an old upload: skip it quietly

  return <View style={s.block}>{body}</View>;
}

const s = StyleSheet.create({
  block: { marginBottom: 20 },
  p: { fontSize: 17, lineHeight: 28 },
  h_wrap: { marginTop: 18, marginBottom: 2 },
  h_rule: { width: 36, height: 2, borderRadius: 1, marginBottom: 10 },
  h: { fontSize: 24, lineHeight: 30 },
  li: { flexDirection: 'row', alignItems: 'flex-start', gap: 12 },
  dot: { width: 6, height: 6, borderRadius: 3, marginTop: 11 },
  code: { borderRadius: 12, borderWidth: 1, overflow: 'hidden' },
  callout: { borderLeftWidth: 3, borderRadius: 12, paddingHorizontal: 16, paddingVertical: 14, gap: 4 },
  callout_label: { fontSize: 12, letterSpacing: 0.6, textTransform: 'uppercase' },
  table: { borderWidth: 1, borderRadius: 12, overflow: 'hidden' },
  tr: { flexDirection: 'row' },
  th: { width: 140, padding: 10, fontSize: 14 },
  td: { width: 140, padding: 10, fontSize: 14, lineHeight: 20 },
});
