import { StyleSheet, View } from 'react-native';
import { router } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { AppText as Text } from './app_text';
import { BouncyPressable as Pressable } from './bouncy_pressable';
import { Hero } from './hero';
import { useTheme } from '../lib/theme';

// Flat header shared by the course, category, chapter, settings and message screens: a quiet back link,
// a serif title, an optional line under it. `on_back` replaces the normal Back (the chapter reader uses it
// to show a closing message first).
export function BackHeader({ top_padding, back_label, title, sub, on_back, on_title }: { top_padding: number; back_label: string; title: string; sub?: string; on_back?: () => void; on_title?: () => void }) {
  const { theme } = useTheme();
  const c = theme.colors;
  return (
    <Hero top_padding={top_padding}>
      <View style={s.row}>
        <Pressable onPress={on_back ?? (() => (router.canGoBack() ? router.back() : router.replace('/')))} hitSlop={12} accessibilityRole="button" accessibilityLabel={`Back to ${back_label}`} style={s.back_wrap}>
          <Ionicons name="chevron-back" size={20} color={c.primary} />
          <Text style={[s.back, { color: c.primary }]} numberOfLines={1}>{back_label}</Text>
        </Pressable>
      </View>
      {on_title
        ? <Pressable onPress={on_title} accessibilityRole="button"><Text style={[s.title, { color: c.ink }]}>{title}</Text></Pressable>
        : <Text style={[s.title, { color: c.ink }]}>{title}</Text>}
      {!!sub && <Text style={[s.sub, { color: c.muted }]}>{sub}</Text>}
    </Hero>
  );
}

const s = StyleSheet.create({
  row: { flexDirection: 'row', marginBottom: 14 },
  back_wrap: { flexDirection: 'row', alignItems: 'center', maxWidth: '80%', marginLeft: -4 },
  back: { fontFamily: 'Figtree_700Bold', fontSize: 15 },
  title: { fontFamily: 'Figtree_700Bold', fontSize: 30, lineHeight: 36 },
  sub: { fontFamily: 'Figtree_500Medium', fontSize: 15, lineHeight: 21, marginTop: 6 },
});
