import React, { useCallback, useEffect, useRef, useState } from 'react';
import { Animated, Easing, StyleSheet, Text, View } from 'react-native';
import * as Haptics from 'expo-haptics';
import { useTheme } from '../lib/theme';
import { useEffects } from '../lib/effects';
import { burst_length_ms, make_particles, MAX_BURSTS, type particle } from '../lib/effect_plan';
import { tap_particles } from '../lib/recipes';
import { play_sound } from '../lib/sound_play';

type Burst = { id: number; x: number; y: number; parts: particle[] };
const CANDY = ['#ffd166', '#7bdff2', '#b2f7ef', '#f7aef8'];

// One flying piece. Moves with the native driver, so taps never slow the screen down.
function Piece({ p, x, y, colors }: { p: particle; x: number; y: number; colors: string[] }) {
  const t = useRef(new Animated.Value(0)).current;
  useEffect(() => {
    Animated.timing(t, { toValue: 1, duration: p.duration, delay: p.delay, easing: Easing.out(Easing.quad), useNativeDriver: true }).start();
  }, [t, p]);

  const color = p.color ?? colors[p.color_slot % colors.length];
  const fade = p.shape === 'ring' && p.dy === 0 ? [0.55, 0.3, 0] : [0, 1, 1, 0];
  const fade_at = p.shape === 'ring' && p.dy === 0 ? [0, 0.4, 1] : [0, 0.12, 0.65, 1];
  const style: any = {
    position: 'absolute', left: x - p.size / 2, top: y - p.size / 2, width: p.size, height: p.size,
    opacity: t.interpolate({ inputRange: fade_at, outputRange: fade }),
    transform: [
      { translateX: t.interpolate({ inputRange: [0, 1], outputRange: [0, p.dx] }) },
      { translateY: t.interpolate({ inputRange: [0, 1], outputRange: [0, p.dy] }) },
      { rotate: t.interpolate({ inputRange: [0, 1], outputRange: ['0rad', `${p.rot}rad`] }) },
      { scale: p.grow ? t.interpolate({ inputRange: [0, 1], outputRange: [0.3, 1] }) : 1 },
    ],
  };

  if (p.shape === 'glyph') {
    return <Animated.View style={style}><Text style={{ color, fontSize: p.size, lineHeight: p.size * 1.15, textAlign: 'center' }}>{p.glyph}</Text></Animated.View>;
  }
  if (p.shape === 'ring') return <Animated.View style={[style, { borderWidth: 2, borderColor: color, borderRadius: p.size / 2 }]} />;
  if (p.shape === 'rect') return <Animated.View style={[style, { backgroundColor: color, height: p.size * 0.6, borderRadius: 1 }]} />;
  return <Animated.View style={[style, { backgroundColor: color, borderRadius: p.size / 2 }]} />;
}

// Wraps the whole app. Listens to every touch WITHOUT stealing it (buttons keep working),
// plays the chosen theme's effect at the touch point, and gives a soft haptic tick.
export function EffectLayer({ children }: { children: React.ReactNode }) {
  const { theme } = useTheme();
  const { effects_on, haptics_on, sounds_on } = useEffects();
  const [bursts, setBursts] = useState<Burst[]>([]);
  const next_id = useRef(1);
  const last_tick = useRef(0);

  const on_touch = useCallback((e: any) => {
    const { pageX, pageY } = e.nativeEvent;
    if (haptics_on && theme.effects?.haptic !== false && Date.now() - last_tick.current > 80) {
      last_tick.current = Date.now();
      Haptics.selectionAsync().catch(() => {});
    }
    if (!effects_on) return;
    if (sounds_on && theme.effects?.sound) void play_sound(theme.effects.sound);
    const parts = theme.effects?.tap?.length ? tap_particles(theme.effects.tap) : make_particles(theme.effect);
    if (!parts.length) return;
    const id = next_id.current++;
    setBursts((old) => [...old.slice(-(MAX_BURSTS - 1)), { id, x: pageX, y: pageY, parts }]);
    setTimeout(() => setBursts((old) => old.filter((b) => b.id !== id)), burst_length_ms(parts) + 80);
  }, [theme.effect, theme.effects, effects_on, haptics_on, sounds_on]);

  const colors = [theme.colors.accent, theme.colors.primary, ...CANDY];
  return (
    <View style={{ flex: 1 }} onTouchStart={on_touch}>
      {children}
      <View pointerEvents="none" style={StyleSheet.absoluteFill}>
        {bursts.map((b) => b.parts.map((p, i) => <Piece key={`${b.id}-${i}`} p={p} x={b.x} y={b.y} colors={colors} />))}
      </View>
    </View>
  );
}
