import { useWindowDimensions } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useAuth } from '../lib/auth';
import { load_saved } from '../lib/store';
import { clean_side } from '../lib/drop_target';
import { DOCK_SIZE, DOCK_STEP, dock_top } from '../lib/dock_layout';
import { FloatingNav } from './floating_nav';

const FLOAT_SIDE_KEY = 'float_side'; // the saved edge the pin and comment buttons use (floating_tools.tsx)

// The reader's menu button: the third button of the dock, right under pin and comment.
// (No Back button here: the header has one, and so does the phone's own Back.)
export function ReaderEdge() {
  const { me } = useAuth();
  const { height } = useWindowDimensions();
  const insets = useSafeAreaInsets();
  const side = clean_side(load_saved<string>(FLOAT_SIDE_KEY));
  const top = dock_top(height, insets.bottom) + 2 * DOCK_STEP;
  return <FloatingNav me={me} active={null} place="edge" side={side} top={top} size={DOCK_SIZE} />;
}
