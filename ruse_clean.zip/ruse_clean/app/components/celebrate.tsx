import { useEffect, useRef } from 'react';
import { Animated, Easing, StyleSheet, Text, View, useWindowDimensions } from 'react-native';
import * as Haptics from 'expo-haptics';
import { useTheme } from '../lib/theme';
import { useEffects } from '../lib/effects';

const GLYPHS = ['♥', '✦', '✿', '●'];
const COUNT = 26;

// Same list every time, so the shower never "jumps" when the screen redraws.
const pieces = Array.from({ length: COUNT }, (_, i) => ({
  left_pct: (i * 37) % 96,
  size: 16 + ((i * 7) % 16),
  delay: (i * 90) % 900,
  duration: 1800 + ((i * 230) % 1200),
  sway: (i % 2 ? 1 : -1) * (12 + ((i * 5) % 28)),
  spin: (i % 2 ? 1 : -1) * (1 + (i % 3)),
}));

function Piece({ i, color, w, h }: { i: number; color: string; w: number; h: number }) {
  const p = pieces[i];
  const t = useRef(new Animated.Value(0)).current;
  useEffect(() => {
    Animated.timing(t, { toValue: 1, duration: p.duration, delay: p.delay, easing: Easing.in(Easing.quad), useNativeDriver: true }).start();
  }, [t, p]);
  return (
    <Animated.View
      style={{
        position: 'absolute', top: 0, left: (p.left_pct / 100) * w,
        opacity: t.interpolate({ inputRange: [0, 0.05, 0.8, 1], outputRange: [0, 1, 1, 0] }),
        transform: [
          { translateY: t.interpolate({ inputRange: [0, 1], outputRange: [-40, h] }) },
          { translateX: t.interpolate({ inputRange: [0, 0.5, 1], outputRange: [0, p.sway, 0] }) },
          { rotate: t.interpolate({ inputRange: [0, 1], outputRange: ['0deg', `${p.spin * 180}deg`] }) },
        ],
      }}>
      <Text style={{ color, fontSize: p.size }}>{GLYPHS[i % GLYPHS.length]}</Text>
    </Animated.View>
  );
}

// A one-time shower of shapes over the screen. Mount it when a chapter is finished.
// Respects the "Sparkles when I tap" and haptics switches in Settings.
export function Celebrate() {
  const { theme } = useTheme();
  const { effects_on, haptics_on } = useEffects();
  const { width, height } = useWindowDimensions();
  useEffect(() => {
    if (haptics_on) Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success).catch(() => {});
  }, [haptics_on]);
  if (!effects_on) return null;
  const colors = [theme.colors.accent, theme.colors.primary, '#ffd166', '#7bdff2', '#f7aef8'];
  return (
    <View pointerEvents="none" style={StyleSheet.absoluteFill}>
      {pieces.map((_, i) => <Piece key={i} i={i} color={colors[i % colors.length]} w={width} h={height} />)}
    </View>
  );
}
