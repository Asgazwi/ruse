import { useState } from 'react';
import { StyleSheet, View } from 'react-native';
import { AppText as Text } from '../app_text';
import { BouncyPressable as Pressable } from '../bouncy_pressable';
import { StatusLine, type status } from './settings_bits';
import { main_theme_id_for_gender, useTheme } from '../../lib/theme';
import { api } from '../../lib/backend';
import { ACTION_SAVE_PROFILE } from '../../lib/actions';
import { save_local_gender } from '../../lib/profile_local';
import type { Gender, Me } from '../../lib/types';

const CHOICES: { value: Gender; label: string }[] = [
  { value: 'boy', label: 'Boy' },
  { value: 'girl', label: 'Girl' },
  { value: 'skip', label: 'Skip' },
];

// Boy / Girl / Skip. It picks the main theme (Boy: Obsidian Gold, Girl: Sugar Bloom); Skip keeps the current theme.
export function GenderChips({ me, reload }: { me: Me | null | undefined; reload: () => Promise<unknown> | void }) {
  const { theme, pick } = useTheme();
  const c = theme.colors;
  const [busy, setBusy] = useState(false);
  const [result, setResult] = useState<status>(null);

  const choose = async (g: Gender) => {
    setBusy(true);
    setResult(null);
    try {
      try { await api(ACTION_SAVE_PROFILE, { gender: g }); } catch { /* saved on the phone below, the server gets it next time */ }
      save_local_gender(g);
      const theme_id = main_theme_id_for_gender(g);
      if (theme_id) pick(theme_id);
      try { await reload(); } catch { /* offline */ }
      setResult({ ok: true, text: 'Saved.' });
    } catch (e: any) {
      setResult({ ok: false, text: e?.message || 'Could not save.' });
    } finally {
      setBusy(false);
    }
  };

  return (
    <View>
      <Text style={[s.label, { color: c.ink }]}>Look</Text>
      <Text style={[s.hint, { color: c.muted }]}>Boy starts you on Obsidian Gold, Girl on Sugar Bloom. Skip keeps your current theme.</Text>
      <View style={s.chips}>
        {CHOICES.map((g) => {
          const on = me?.gender === g.value;
          return (
            <Pressable key={g.value} onPress={() => choose(g.value)} disabled={busy} accessibilityRole="button" accessibilityState={{ selected: on }}
              style={[s.chip, { borderColor: on ? c.primary : c.line, backgroundColor: on ? c.primary : 'transparent' }]}>
              <Text style={{ color: on ? c.primaryFg : c.ink, fontFamily: 'Figtree_700Bold' }}>{g.label}</Text>
            </Pressable>
          );
        })}
      </View>
      <StatusLine status={result} />
    </View>
  );
}

const s = StyleSheet.create({
  label: { fontFamily: 'Figtree_700Bold', fontSize: 15 },
  hint: { fontFamily: 'Figtree_500Medium', fontSize: 12.5, marginTop: 2, marginBottom: 10 },
  chips: { flexDirection: 'row', gap: 8 },
  chip: { flex: 1, height: 42, borderRadius: 21, borderWidth: 2, alignItems: 'center', justifyContent: 'center' },
});
