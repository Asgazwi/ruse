import { SwitchRow } from './settings_bits';
import { useEffects } from '../../lib/effects';

// The three little tap extras: sparkles, a soft buzz, and a tap sound.
export function TapEffectsCard() {
  const { effects_on, haptics_on, sounds_on, set_effects_on, set_haptics_on, set_sounds_on } = useEffects();
  return (
    <>
      <SwitchRow label="Sparkles when I tap" value={effects_on} on_change={set_effects_on} />
      <SwitchRow label="Soft vibration" value={haptics_on} on_change={set_haptics_on} />
      <SwitchRow label="Tap sounds" value={sounds_on} on_change={set_sounds_on} />
    </>
  );
}
