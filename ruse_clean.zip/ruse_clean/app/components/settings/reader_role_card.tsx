import { useState } from 'react';
import { router } from 'expo-router';
import { View } from 'react-native';
import { AppText as Text } from '../app_text';
import { LineButton, SettingsRow, SettingsSection, StatusLine, type status } from './settings_bits';
import { useTheme } from '../../lib/theme';
import { api } from '../../lib/backend';
import { ACTION_REQUEST_ROLE } from '../../lib/actions';
import { W } from '../../lib/words';
import type { Me } from '../../lib/types';

// For a Reader: what a reader can do, and a button to ask an admin for author rights.
export function ReaderRoleCard({ me, reload }: { me: Me | null | undefined; reload: () => Promise<unknown> | void }) {
  const { theme } = useTheme();
  const c = theme.colors;
  const [busy, setBusy] = useState(false);
  const [result, setResult] = useState<status>(null);

  const ask = async () => {
    setBusy(true);
    setResult(null);
    try {
      await api(ACTION_REQUEST_ROLE, 'author');
      await reload();
      setResult({ ok: true, text: 'Request sent. An admin will see it.' });
    } catch (e: any) {
      setResult({ ok: false, text: e?.message || 'Could not send the request.' });
    } finally {
      setBusy(false);
    }
  };

  return (
    <SettingsSection title="Your role">
      <View>
        <Text style={{ color: c.ink, fontFamily: 'Figtree_700Bold', fontSize: 15 }}>You are a Reader</Text>
        <Text style={{ color: c.muted, fontFamily: 'Figtree_500Medium', fontSize: 13, marginTop: 2 }}>
          You can read, comment and message. Authors upload {W.novels} and themes.
        </Text>
      </View>
      {me?.roleRequestStatus === 'pending'
        ? <Text style={{ color: c.primary, fontFamily: 'Figtree_500Medium' }}>Your request to become an author is waiting for an admin.</Text>
        : <LineButton label="Ask to become an author" on_press={ask} busy={busy} />}
      <StatusLine status={result} />
      <SettingsRow emoji="📈" label="My progress" on_press={() => router.push('/courses')} />
    </SettingsSection>
  );
}
