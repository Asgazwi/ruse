import { useState } from 'react';
import { Image, StyleSheet, View } from 'react-native';
import { AppText as Text } from '../app_text';
import { LineButton, StatusLine, type status } from './settings_bits';
import { useTheme } from '../../lib/theme';
import { clear_home_bg, load_home_bg } from '../../lib/home_bg';
import { pick_home_background } from '../../lib/pick_home_bg';

// A photo behind the Home screen. It stays on this phone only. Optional: the theme colour shows when there is none.
export function HomeBackgroundCard() {
  const { theme } = useTheme();
  const c = theme.colors;
  const [uri, setUri] = useState<string | null>(() => load_home_bg());
  const [busy, setBusy] = useState(false);
  const [result, setResult] = useState<status>(null);

  const choose = async () => {
    setBusy(true);
    setResult(null);
    const outcome = await pick_home_background();
    if (outcome?.ok) { setUri(outcome.uri); setResult({ ok: true, text: 'Saved on this phone.' }); }
    else if (outcome) setResult({ ok: false, text: outcome.text });
    setBusy(false);
  };

  return (
    <View>
      <Text style={[s.label, { color: c.ink }]}>Home background</Text>
      <Text style={[s.hint, { color: c.muted }]}>A photo behind the Home screen. It stays on this phone only.</Text>
      {uri ? <Image source={{ uri }} style={s.preview} resizeMode="cover" /> : null}
      <View style={{ gap: 10 }}>
        <LineButton label={uri ? 'Change photo' : 'Choose a photo'} on_press={choose} busy={busy} />
        {uri ? <LineButton label="Remove photo" danger on_press={() => { clear_home_bg(); setUri(null); setResult({ ok: true, text: 'Background removed.' }); }} /> : null}
      </View>
      <StatusLine status={result} />
    </View>
  );
}

const s = StyleSheet.create({
  label: { fontFamily: 'Figtree_700Bold', fontSize: 15 },
  hint: { fontFamily: 'Figtree_500Medium', fontSize: 12.5, marginTop: 2, marginBottom: 10 },
  preview: { width: '100%', height: 130, borderRadius: 16, marginBottom: 12 },
});
