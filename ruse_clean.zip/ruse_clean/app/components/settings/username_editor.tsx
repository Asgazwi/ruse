import { useState } from 'react';
import { ActivityIndicator, StyleSheet, TextInput, View } from 'react-native';
import { AppText as Text } from '../app_text';
import { BouncyPressable as Pressable } from '../bouncy_pressable';
import { GlowButton } from '../glow_button';
import { StatusLine, type status } from './settings_bits';
import { useTheme } from '../../lib/theme';
import { api } from '../../lib/backend';
import { ACTION_CHECK_USERNAME, ACTION_SAVE_USERNAME } from '../../lib/actions';
import { can_change_username, check_username_local, days_until_username_change, normalize_username, USERNAME_MAX } from '../../lib/username';
import type { Me } from '../../lib/types';

// My username: the name other readers see (never my email). It can change once every 30 days.
export function UsernameEditor({ me, reload }: { me: Me | null | undefined; reload: () => Promise<unknown> | void }) {
  const { theme } = useTheme();
  const c = theme.colors;
  const [draft, setDraft] = useState(me?.username ?? '');
  const [busy, setBusy] = useState(false);
  const [result, setResult] = useState<status>(null);
  const locked = !!me?.username && !can_change_username(me?.usernameChangedAt);

  const save = async () => {
    const name = normalize_username(draft);
    const problem = check_username_local(name);
    if (problem) { setResult({ ok: false, text: problem }); return; }
    if (me?.username && name.toLowerCase() === String(me.username).toLowerCase()) { setResult({ ok: true, text: 'That is already your username.' }); return; }
    if (locked) { setResult({ ok: false, text: `You can change your username again in about ${days_until_username_change(me?.usernameChangedAt)} days.` }); return; }
    setBusy(true);
    setResult(null);
    try {
      try { await api(ACTION_CHECK_USERNAME, name); } catch (e: any) {
        // An older backend may not have the check yet: that is fine, saving still checks everything.
        if (e?.message && !/unknown|not found|not implemented/i.test(String(e.message))) throw e;
      }
      await api(ACTION_SAVE_USERNAME, name);
      await reload();
      setDraft(name);
      setResult({ ok: true, text: 'Username saved.' });
    } catch (e: any) {
      setResult({ ok: false, text: e?.message || 'Could not save the username.' });
    } finally {
      setBusy(false);
    }
  };

  return (
    <View>
      <Text style={[s.label, { color: c.ink }]}>Username</Text>
      <Text style={[s.hint, { color: c.muted }]}>
        {locked ? `Next change in about ${days_until_username_change(me?.usernameChangedAt)} days.` : 'Other readers see this, never your email. You can change it once every 30 days.'}
      </Text>
      <View style={s.row}>
        <TextInput
          value={draft}
          onChangeText={setDraft}
          placeholder="username"
          placeholderTextColor={c.muted}
          autoCapitalize="none"
          autoCorrect={false}
          maxLength={USERNAME_MAX}
          editable={!busy}
          style={[s.input, { borderColor: c.line, color: c.ink, backgroundColor: c.bg }]}
        />
        <GlowButton label="Save" on_press={save} busy={busy} size="md" color={c.primary} text_color={c.primaryFg} style={s.save} />
      </View>
      <StatusLine status={result} />
    </View>
  );
}

const s = StyleSheet.create({
  label: { fontFamily: 'Figtree_700Bold', fontSize: 15 },
  hint: { fontFamily: 'Figtree_500Medium', fontSize: 12.5, marginTop: 2, marginBottom: 10 },
  row: { flexDirection: 'row', gap: 10, alignItems: 'center' },
  input: { flex: 1, height: 46, borderWidth: 1, borderRadius: 23, paddingHorizontal: 18, fontFamily: 'Figtree_500Medium', fontSize: 16 },
  save: { minWidth: 76 },
});
