import type { ReactNode } from 'react';
import { StyleSheet, Switch, View } from 'react-native';
import { AppText as Text } from '../app_text';
import { BouncyPressable as Pressable } from '../bouncy_pressable';
import { GlowButton } from '../glow_button';
import { CountDot } from '../count_dot';
import { useTheme } from '../../lib/theme';
import { soft_shadow } from '../../lib/soft_shadow';
import { alpha_hex } from '../../lib/alpha_hex';

// ---------------------------------------------------------------
// The small building blocks every Settings section is made from.
// ---------------------------------------------------------------

// A message under a control: green-ish when it worked, red when it did not. Nothing when there is none.
export type status = { ok: boolean; text: string } | null;

export function StatusLine({ status }: { status: status }) {
  const { theme } = useTheme();
  if (!status) return null;
  return (
    <Text style={{ color: status.ok ? theme.colors.primary : '#b3261e', fontFamily: 'Figtree_500Medium', marginTop: 10 }}>
      {status.ok ? '✓ ' : ''}{status.text}
    </Text>
  );
}

// A titled group. By default its content sits on one rounded card; `plain` leaves the content as it is.
export function SettingsSection({ title, hint, plain, children }: { title: string; hint?: string; plain?: boolean; children: ReactNode }) {
  const { theme } = useTheme();
  const c = theme.colors;
  return (
    <View style={s.section}>
      <Text style={[s.title, { color: c.muted }]}>{title.toUpperCase()}</Text>
      {hint ? <Text style={[s.hint, { color: c.muted }]}>{hint}</Text> : null}
      {plain ? children : (
        <View style={[s.card, soft_shadow(c.primary, 1), { backgroundColor: c.surface, borderColor: c.line }]}>{children}</View>
      )}
    </View>
  );
}

// A row that opens another screen: a little icon, the name, an optional count, an arrow.
export function SettingsRow({ emoji, label, hint, count, on_press }: { emoji: string; label: string; hint?: string; count?: number; on_press: () => void }) {
  const { theme } = useTheme();
  const c = theme.colors;
  return (
    <Pressable onPress={on_press} accessibilityRole="button" accessibilityLabel={label} style={s.row}>
      <View style={[s.icon, { backgroundColor: alpha_hex(c.primary, 0.12) }]}><Text style={{ fontSize: 18 }}>{emoji}</Text></View>
      <View style={{ flex: 1 }}>
        <Text style={{ color: c.ink, fontFamily: 'Figtree_700Bold', fontSize: 15 }}>{label}</Text>
        {hint ? <Text style={{ color: c.muted, fontFamily: 'Figtree_500Medium', fontSize: 12.5 }}>{hint}</Text> : null}
      </View>
      <CountDot count={count ?? 0} />
      <Text style={{ color: c.muted, fontSize: 22 }}>›</Text>
    </Pressable>
  );
}

// A label with an on/off switch.
export function SwitchRow({ label, value, on_change }: { label: string; value: boolean; on_change: (v: boolean) => void }) {
  const { theme } = useTheme();
  const c = theme.colors;
  return (
    <View style={s.row}>
      <Text style={{ color: c.ink, fontFamily: 'Figtree_500Medium', fontSize: 15, flex: 1 }}>{label}</Text>
      <Switch value={value} onValueChange={on_change} trackColor={{ true: c.accent }} accessibilityLabel={label} />
    </View>
  );
}

// A quiet outlined button for the actions inside a card.
export function LineButton({ label, on_press, danger, busy }: { label: string; on_press: () => void; danger?: boolean; busy?: boolean }) {
  const { theme } = useTheme();
  const color = danger ? '#b3261e' : theme.colors.primary;
  return (
    <GlowButton label={busy ? 'Please wait…' : label} on_press={on_press} disabled={busy} outline danger={danger} size="md" color={color} text_color={color} />
  );
}

const s = StyleSheet.create({
  section: { marginTop: 26 },
  title: { fontFamily: 'Figtree_700Bold', fontSize: 12.5, letterSpacing: 1.6, marginBottom: 8, marginLeft: 6 },
  hint: { fontFamily: 'Figtree_500Medium', fontSize: 13, marginBottom: 10, marginLeft: 6 },
  card: { borderWidth: 1, borderRadius: 24, padding: 16, gap: 14 },
  row: { flexDirection: 'row', alignItems: 'center', gap: 12, minHeight: 40 },
  icon: { width: 36, height: 36, borderRadius: 12, alignItems: 'center', justifyContent: 'center' },
  line_button: { height: 44, borderRadius: 22, borderWidth: 2, alignItems: 'center', justifyContent: 'center' },
});
