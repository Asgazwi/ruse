import { useState } from 'react';
import { Alert } from 'react-native';
import { AppText as Text } from '../app_text';
import { useTheme } from '../../lib/theme';
import { delete_all_downloads, saved_bytes, saved_count, size_label } from '../../lib/downloads';
import { LineButton, StatusLine, type status } from './settings_bits';

// Settings (v63): the files this phone keeps for offline use (manga pages, soundtracks, backgrounds).
// They live in the app's own storage, never in Downloads or the gallery. Clear removes them all.
export function SavedFilesCard() {
  const { theme } = useTheme();
  const c = theme.colors;
  const [count, setCount] = useState(() => saved_count());
  const [bytes, setBytes] = useState(() => saved_bytes());
  const [result, setResult] = useState<status>(null);

  const clear = () => Alert.alert(
    'Clear saved downloads?',
    'Saved pages, soundtracks and backgrounds are removed from this phone. Reading still works when you are online.',
    [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Clear',
        style: 'destructive',
        onPress: () => {
          delete_all_downloads();
          setCount(0);
          setBytes(0);
          setResult({ ok: true, text: 'Saved downloads cleared.' });
        },
      },
    ],
  );

  return (
    <>
      <Text style={{ color: c.ink, fontFamily: 'Figtree_500Medium', fontSize: 14 }}>
        {count === 0
          ? 'Nothing is saved on this phone.'
          : `${count} ${count === 1 ? 'file is' : 'files are'} saved in the app (${size_label(bytes)}). Not in Downloads or the gallery.`}
      </Text>
      {count > 0 ? <LineButton label="Clear saved downloads" danger on_press={clear} /> : null}
      <StatusLine status={result} />
    </>
  );
}
