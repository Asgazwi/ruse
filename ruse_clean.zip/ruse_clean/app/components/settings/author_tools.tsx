import { useState } from 'react';
import { router } from 'expo-router';
import * as DocumentPicker from 'expo-document-picker';
import { View } from 'react-native';
import { AppText as Text } from '../app_text';
import { GlowButton } from '../glow_button';
import { LineButton, SettingsRow, SettingsSection, StatusLine, type status } from './settings_bits';
import { useTheme } from '../../lib/theme';
import { useData } from '../../lib/data';
import { parse_upload_text } from '../../lib/upload_check';
import { send_upload } from '../../lib/upload_send';
import { share_json_file, share_plain_file } from '../../lib/share_json';
import { ai_prompt_text, blank_theme_template, comic_template, novel_template, theme_template_from } from '../../lib/templates';
import { can_add_theme } from '../../lib/roles';
import { W } from '../../lib/words';
import type { Me } from '../../lib/types';

// Everything an author or admin uses to add content: how-to, my novels, upload a .json file, empty templates.
export function AuthorTools({ me }: { me: Me | null | undefined }) {
  const { theme } = useTheme();
  const c = theme.colors;
  const { refresh } = useData();
  const [busy, setBusy] = useState(false);
  const [result, setResult] = useState<status>(null);

  const upload = async () => {
    setResult(null);
    try {
      const picked = await DocumentPicker.getDocumentAsync({ type: ['application/json', 'text/plain'], copyToCacheDirectory: true });
      if (picked.canceled || !picked.assets?.length) return;
      setBusy(true);
      const raw = await (await fetch(picked.assets[0].uri)).text();
      const parsed = parse_upload_text(raw);
      if (!parsed.ok) throw new Error(parsed.error);
      const message = await send_upload(parsed);
      await refresh(); // so Home (courses) and Settings (themes) both show the upload
      setResult({ ok: true, text: message });
    } catch (e: any) {
      setResult({ ok: false, text: e?.message || 'Upload failed.' });
    } finally {
      setBusy(false);
    }
  };

  // B4 (new): the app builds each file itself, so it always matches the upload rules.
  const share = async (make: () => Promise<void>) => {
    try { await make(); }
    catch (e: any) { setResult({ ok: false, text: e?.message || 'Could not share the file.' }); }
  };

  return (
    <>
      <SettingsSection title="Author tools">
        <SettingsRow emoji="📖" label="Read me first" hint="How to upload" on_press={() => router.push('/read_me')} />
        <SettingsRow emoji="📚" label={`Your ${W.novels}`} hint="Edit, add chapters and soundtracks" on_press={() => router.push('/courses')} />
      </SettingsSection>

      <SettingsSection title="Upload a file">
        <Text style={{ color: c.muted, fontFamily: 'Figtree_500Medium', fontSize: 13 }}>
          Choose a .json file. It can be a whole {W.novel}, one chapter (or a list of chapters), or a theme. I work out which one it is.
        </Text>
        <GlowButton label="Choose file" on_press={upload} busy={busy} color={c.accent} text_color={c.accentFg} />
        <StatusLine status={result} />
      </SettingsSection>

      <SettingsSection title="Templates" hint={`The app makes these for you. Download one, fill it in with any text editor, then upload it above. To add chapters to a ${W.novel} you already have, open Your ${W.novels}: its chapter template is there, ready filled in.`}>
        <View style={{ gap: 10 }}>
          <LineButton label={`${W.Novel} template`} on_press={() => share(() => share_json_file('marginalia-novel-template.json', novel_template()))} />
          <LineButton label="Comic template" on_press={() => share(() => share_json_file('marginalia-comic-template.json', comic_template()))} />
          {can_add_theme(me) ? <LineButton label={`Theme template (${theme.name})`} on_press={() => share(() => share_json_file('marginalia-theme-template.json', theme_template_from(theme)))} /> : null}
          {can_add_theme(me) ? <LineButton label="Blank theme template" on_press={() => share(() => share_json_file('marginalia-blank-theme.json', blank_theme_template()))} /> : null}
          <LineButton label="Prompt for an AI helper" on_press={() => share(() => share_plain_file('marginalia-prompt-for-ai.txt', ai_prompt_text()))} />
        </View>
      </SettingsSection>
    </>
  );
}
