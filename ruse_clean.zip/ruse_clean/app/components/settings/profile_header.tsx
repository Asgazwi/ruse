import { useState } from 'react';
import { StyleSheet, View } from 'react-native';
import { AppText as Text } from '../app_text';
import { Avatar } from '../avatar';
import { LineButton, StatusLine, type status } from './settings_bits';
import { useTheme } from '../../lib/theme';
import { soft_shadow } from '../../lib/soft_shadow';
import { alpha_hex } from '../../lib/alpha_hex';
import { pick_and_save_avatar } from '../../lib/pick_avatar';
import { role_label, role_of } from '../../lib/roles';
import type { Me } from '../../lib/types';

// The top of Settings: my picture, my name, my role, and a button to change the picture.
// The picture is what other people see beside my messages and comments.
export function ProfileHeader({ me, reload }: { me: Me | null | undefined; reload: () => Promise<unknown> | void }) {
  const { theme } = useTheme();
  const c = theme.colors;
  const [busy, setBusy] = useState(false);
  const [result, setResult] = useState<status>(null);

  const change_picture = async () => {
    setBusy(true);
    setResult(null);
    const outcome = await pick_and_save_avatar();
    if (outcome?.ok) { try { await reload(); } catch { /* offline: the picture is saved, it shows next time */ } }
    if (outcome) setResult(outcome);
    setBusy(false);
  };

  return (
    <View style={[s.card, soft_shadow(c.primary, 1), { backgroundColor: c.surface, borderColor: c.line }]}>
      <Avatar name={me?.username || me?.name} url={me?.avatarUrl} size={84} />
      <Text style={{ color: c.ink, fontFamily: 'Figtree_700Bold', fontSize: 22, marginTop: 12 }} numberOfLines={1}>
        {me?.username ? `@${me.username}` : 'Choose a username'}
      </Text>
      <View style={[s.pill, { backgroundColor: alpha_hex(c.primary, 0.14) }]}>
        <Text style={{ color: c.primary, fontFamily: 'Figtree_700Bold', fontSize: 12.5 }}>{role_label(role_of(me))}</Text>
      </View>
      <View style={{ alignSelf: 'stretch', marginTop: 14 }}>
        <LineButton label={me?.avatarUrl ? 'Change picture' : 'Add a picture'} on_press={change_picture} busy={busy} />
      </View>
      <StatusLine status={result} />
    </View>
  );
}

const s = StyleSheet.create({
  card: { borderWidth: 1, borderRadius: 28, padding: 20, alignItems: 'center' },
  pill: { borderRadius: 12, paddingHorizontal: 12, paddingVertical: 4, marginTop: 6 },
});
