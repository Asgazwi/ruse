import { Alert, StyleSheet, View } from 'react-native';
import { AppText as Text } from './app_text';
import { BouncyPressable as Pressable } from './bouncy_pressable';
import { GlowButton } from './glow_button';
import { useTheme } from '../lib/theme';
import { useData } from '../lib/data';
import { usePins } from '../lib/pins';
import { mix_hex } from '../lib/contrast';
import { op_label, op_text } from '../lib/pin_helpers';

const BAD = '#d64545';

// Two small cards, shown only when there is something to say (Phase A2):
//  1) "N changes waiting to send": saved on the phone, not on the server yet (pins, comments, finished chapters).
//  2) "N changes were not accepted": the server said no. The text is shown here, so nothing typed is lost,
//     and it can be sent again or thrown away.
export function SyncNotice() {
  const { theme } = useTheme();
  const c = theme.colors;
  const { waiting, offline, failed, retry_failed, discard_failed } = usePins();
  const { progress_pending } = useData();

  const total_waiting = waiting + (progress_pending ? 1 : 0);
  if (total_waiting === 0 && failed.length === 0) return null;

  const confirm_discard = (n: number) =>
    Alert.alert('Throw this away?', 'It was not sent, so the text will be gone for good.', [
      { text: 'Keep it', style: 'cancel' },
      { text: 'Throw away', style: 'destructive', onPress: () => discard_failed(n) },
    ]);

  return (
    <View style={s.wrap}>
      {total_waiting > 0 && (
        <View style={[s.card, { backgroundColor: c.surface, borderColor: c.line }]}>
          <Text style={[s.title, { color: c.ink }]}>⏳ {total_waiting} {total_waiting === 1 ? 'change' : 'changes'} waiting to send</Text>
          <Text style={[s.body, { color: c.muted }]}>
            {offline ? 'You are offline. They are saved on this phone and will send when you are back online.' : 'Saved on this phone. They will send in a moment.'}
          </Text>
        </View>
      )}

      {failed.length > 0 && (
        <View style={[s.card, { backgroundColor: mix_hex(c.surface, BAD, 0.1), borderColor: BAD }]}>
          <Text style={[s.title, { color: c.ink }]}>
            {failed.length === 1 ? '1 change was not accepted' : `${failed.length} changes were not accepted`}
          </Text>
          {failed.map((f) => (
            <View key={f.n} style={[s.item, { borderColor: c.line }]}>
              <Text style={[s.body, { color: c.muted }]}>{op_label(f.op)}: {f.message}</Text>
              {!!op_text(f.op) && <Text selectable style={[s.text, { color: c.ink }]}>{op_text(f.op)}</Text>}
              <Pressable onPress={() => confirm_discard(f.n)} hitSlop={8}>
                <Text style={[s.link, { color: BAD }]}>Throw away</Text>
              </Pressable>
            </View>
          ))}
          <GlowButton label="Try sending again" on_press={retry_failed} size="md" color={c.primary} text_color={c.primaryFg} style={s.retry} />
        </View>
      )}
    </View>
  );
}

const s = StyleSheet.create({
  wrap: { gap: 10, marginBottom: 14 },
  card: { borderWidth: 1, borderRadius: 20, padding: 14, gap: 6 },
  title: { fontFamily: 'Figtree_700Bold', fontSize: 15 },
  body: { fontFamily: 'Figtree_500Medium', fontSize: 13, lineHeight: 19 },
  text: { fontFamily: 'Figtree_500Medium', fontSize: 15, lineHeight: 22 },
  item: { borderTopWidth: 1, paddingTop: 8, gap: 4 },
  link: { fontFamily: 'Figtree_700Bold', fontSize: 13, marginTop: 2 },
  retry: { marginTop: 4 },
});
