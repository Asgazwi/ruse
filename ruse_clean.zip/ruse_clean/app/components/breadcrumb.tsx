import { StyleSheet, View } from 'react-native';
import { AppText as Text } from './app_text';
import { BouncyPressable as Pressable } from './bouncy_pressable';
import { useTheme } from '../lib/theme';

// DATA › DATA ANALYSIS › POWER BI › Chapter 1  (every part but the last can be tapped)
// Shown as one soft pill so the path reads as a single "you are here" strip.
export function Breadcrumb({ parts }: { parts: { label: string; on_press?: () => void }[] }) {
  const { theme } = useTheme();
  const c = theme.colors;
  if (parts.length < 2) return null;
  return (
    <View style={[s.strip, { backgroundColor: c.surface, borderColor: c.line }]}>
      {parts.map((p, i) => (
        <View key={i} style={s.item}>
          {i > 0 && <Text style={{ color: c.muted, fontFamily: 'Figtree_500Medium', fontSize: 13 }}> › </Text>}
          {p.on_press ? (
            <Pressable onPress={p.on_press} hitSlop={6}><Text style={{ color: c.primary, fontFamily: 'Figtree_700Bold', fontSize: 13 }}>{p.label}</Text></Pressable>
          ) : (
            <Text style={{ color: c.muted, fontFamily: 'Figtree_500Medium', fontSize: 13 }}>{p.label}</Text>
          )}
        </View>
      ))}
    </View>
  );
}

const s = StyleSheet.create({
  strip: { flexDirection: 'row', flexWrap: 'wrap', alignItems: 'center', alignSelf: 'flex-start', borderWidth: 1, borderRadius: 18, paddingHorizontal: 14, paddingVertical: 8, marginBottom: 16 },
  item: { flexDirection: 'row', alignItems: 'center' },
});
