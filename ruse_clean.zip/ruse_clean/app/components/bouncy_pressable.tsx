import { useRef } from 'react';
import { Animated, Easing, Pressable } from 'react-native';

const APressable = Animated.createAnimatedComponent(Pressable);

// Drop-in for <Pressable>: squishes a little when pressed and springs back.
// With `wiggle`, it also gives a small side-to-side wiggle when pressed (used on course cards).
export function BouncyPressable({ style, onPressIn, onPressOut, onPress, wiggle, ...rest }: any) {
  const squish = useRef(new Animated.Value(1)).current;
  const turn = useRef(new Animated.Value(0)).current;

  const down = (e: any) => {
    Animated.spring(squish, { toValue: 0.95, speed: 40, bounciness: 0, useNativeDriver: true }).start();
    onPressIn?.(e);
  };
  const up = (e: any) => {
    Animated.spring(squish, { toValue: 1, speed: 14, bounciness: 14, useNativeDriver: true }).start();
    onPressOut?.(e);
  };
  const press = (e: any) => {
    if (wiggle) {
      turn.setValue(0);
      Animated.sequence([-1, 1, -0.6, 0.6, 0].map((v) => Animated.timing(turn, { toValue: v, duration: 70, easing: Easing.inOut(Easing.quad), useNativeDriver: true }))).start();
    }
    onPress?.(e);
  };

  return (
    <APressable
      {...rest}
      onPressIn={down}
      onPressOut={up}
      onPress={press}
      style={[style, { transform: [{ scale: squish }, { rotate: turn.interpolate({ inputRange: [-1, 1], outputRange: ['-2.5deg', '2.5deg'] }) }] }]}
    />
  );
}
