import { StyleSheet, View } from 'react-native';
import { AppText as Text } from './app_text';
import { useTheme } from '../lib/theme';

// Section heading: a serif title, with an optional small action on the right. (It was small caps with a dot.)
export function SectionLabel({ text, right, on_right }: { text: string; right?: string; on_right?: () => void }) {
  const { theme } = useTheme();
  const c = theme.colors;
  return (
    <View style={s.row}>
      <Text style={[s.text, { color: c.ink }]}>{text}</Text>
      {!!right && <Text onPress={on_right} style={[s.right, { color: c.primary }]}>{right}</Text>}
    </View>
  );
}

const s = StyleSheet.create({
  row: { flexDirection: 'row', alignItems: 'baseline', justifyContent: 'space-between', marginTop: 24, marginBottom: 12 },
  text: { fontFamily: 'Figtree_700Bold', fontSize: 20 },
  right: { fontFamily: 'Figtree_700Bold', fontSize: 13.5 },
});
