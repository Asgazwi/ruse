import { StyleSheet, View } from 'react-native';
import { router } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { AppText as Text } from './app_text';
import { BouncyPressable as Pressable } from './bouncy_pressable';
import { Cover } from './cover';
import { FadeInView } from './fade_in_view';
import { ProgressBar } from './progress_bar';
import { useTheme } from '../lib/theme';
import { percent } from '../lib/home_cards';
import { progress_label } from '../lib/progress_label';

// One novel in a list (Home, category, your novels): small cover, title, who wrote it, a thin progress bar.
// `color` is accepted so old callers still compile. `index` only staggers the entrance.
export function CourseCard({ id, title, summary, done, total, pinned, index = 0, byline, kind_label: kind_text }: {
  id: string; title: string; summary?: string; color?: string; done: number; total: number; pinned?: boolean; index?: number;
  byline?: string; kind_label?: string;
}) {
  const { theme } = useTheme();
  const c = theme.colors;
  const pct = percent(done, total);
  const complete = total > 0 && done >= total;
  const line = [kind_text, byline].filter(Boolean).join(' · ');
  return (
    <FadeInView index={index}>
      <Pressable onPress={() => router.push(`/course/${id}`)} accessibilityRole="button" accessibilityLabel={`${title}. ${progress_label(done, total)}`}
        style={[s.card, { backgroundColor: c.surface, borderColor: c.line, borderRadius: theme.radius ?? 16 }]}>
        <Cover title={title} width={60} height={86} font_size={11} />
        <View style={s.body}>
          <View style={s.title_row}>
            <Text style={[s.title, { color: c.ink, flexShrink: 1 }]} numberOfLines={2}>{title}</Text>
            {pinned && <Ionicons name="bookmark" size={14} color={c.primary} style={{ marginTop: 4 }} />}
          </View>
          {!!line && <Text style={[s.sub, { color: c.muted }]} numberOfLines={1}>{line}</Text>}
          {!!summary && <Text style={[s.sub, { color: c.muted }]} numberOfLines={2}>{summary}</Text>}
          {total > 0 && (
            <View style={{ marginTop: 'auto', paddingTop: 10 }}>
              <ProgressBar value={pct} color={complete ? '#2e9e6b' : c.primary} track={c.line} height={4} />
              <Text style={[s.meta, { color: c.muted }]}>{complete ? 'Finished' : `${done} of ${total} chapters`}</Text>
            </View>
          )}
        </View>
      </Pressable>
    </FadeInView>
  );
}

const s = StyleSheet.create({
  card: { flexDirection: 'row', gap: 14, borderWidth: 1, padding: 12, marginBottom: 12 },
  body: { flex: 1, minWidth: 0 },
  title_row: { flexDirection: 'row', gap: 6, alignItems: 'flex-start' },
  title: { fontFamily: 'Figtree_700Bold', fontSize: 18, lineHeight: 22 },
  sub: { fontFamily: 'Figtree_500Medium', fontSize: 13, lineHeight: 18, marginTop: 2 },
  meta: { fontFamily: 'Figtree_500Medium', fontSize: 12, marginTop: 6 },
});
