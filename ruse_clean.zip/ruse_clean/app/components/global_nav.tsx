import { usePathname } from 'expo-router';
import { useAuth } from '../lib/auth';
import { active_nav_key } from '../lib/nav_items';
import { TabBar } from './tab_bar';

// Screens where the tab bar is NOT shown: the reader has its own edge buttons (ReaderEdge),
// and the message thread has its own composer at the bottom.
const HIDDEN_PREFIXES = ['/chapter/', '/message/'];

// The one bottom tab bar for the whole app. Shows only for people who may use the app.
export function GlobalNav() {
  const path = usePathname();
  const { me } = useAuth();
  if (!me?.allowed) return null;
  if (HIDDEN_PREFIXES.some((p) => path.startsWith(p))) return null;
  return <TabBar me={me} active={active_nav_key(path)} />;
}
