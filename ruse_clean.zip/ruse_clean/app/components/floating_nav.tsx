import { useRef, useState } from 'react';
import { Animated, Easing, StyleSheet, View, useWindowDimensions } from 'react-native';
import { router } from 'expo-router';
import { AppText as Text } from './app_text';
import { BouncyPressable as Pressable } from './bouncy_pressable';
import { useTheme } from '../lib/theme';
import { soft_shadow } from '../lib/soft_shadow';
import { radial_offsets, visible_nav, type NavItem } from '../lib/nav_items';

const ITEM = 64;     // each tab in the wheel
const RADIUS = 110;  // how far the tabs fan out from the button
const EDGE_GAP = 10;
const PILL_H = 44;    // edge mode: each tab is a pill with its name, in a tidy column above the button
const PILL_W = 140;
const PILL_GAP = 8;
const OPEN_MS = 260;
const CLOSE_MS = 160;

// One round button. Tap it and the tabs fan out in an arc (like the weapon wheel in GTA 5),
// growing from the button and fading in. Tap a tab to go there; tap outside to close.
//   place 'bottom' (default): bottom centre of the screen (main screens).
//   place 'edge': at a screen edge, at height `top` (the reader, next to pin and comment).
// The wheel mirrors itself on the right edge so it stays on screen.
export function FloatingNav({ me, active, items, place = 'bottom', side = 'left', top = 0, size = 60, on_open }: {
  me: any; active: string | null; items?: NavItem[];
  place?: 'bottom' | 'edge'; side?: 'left' | 'right'; top?: number; size?: number;
  on_open?: (open: boolean) => void;
}) {
  const { theme } = useTheme();
  const c = theme.colors;
  const { width } = useWindowDimensions();
  const [open, setOpen] = useState(false);     // the wheel is open (or opening)
  const [showing, setShowing] = useState(false); // the tabs are on screen (stays on while closing)
  const t = useRef(new Animated.Value(0)).current; // 0 = closed, 1 = fully open
  const list = visible_nav(me, items);
  const mirror = place === 'edge' && side === 'right' ? -1 : 1;
  const spots = radial_offsets(list.length, RADIUS);

  const set = (v: boolean) => {
    setOpen(v);
    on_open?.(v);
    if (v) {
      setShowing(true);
      Animated.timing(t, { toValue: 1, duration: OPEN_MS, easing: Easing.out(Easing.back(1.4)), useNativeDriver: false }).start();
    } else {
      Animated.timing(t, { toValue: 0, duration: CLOSE_MS, easing: Easing.in(Easing.quad), useNativeDriver: false })
        .start(({ finished }) => { if (finished) setShowing(false); });
    }
  };

  const go = (i: NavItem) => {
    set(false);
    if (i.route) router.push(i.route as any);
  };

  const anchor = place === 'edge'
    ? { left: side === 'right' ? width - size - EDGE_GAP : EDGE_GAP, top }
    : { left: '50%' as const, bottom: 24, marginLeft: -size / 2 };

  const centre = size / 2 - ITEM / 2;

  return (
    <View pointerEvents="box-none" style={StyleSheet.absoluteFill}>
      {open && <Pressable onPress={() => set(false)} style={[StyleSheet.absoluteFill, { backgroundColor: 'rgba(0,0,0,0.25)' }]} accessibilityLabel="Close menu" />}

      <View pointerEvents="box-none" style={[s.anchor, { width: size, height: size }, anchor as any]}>
        {showing && list.map((i, idx) => {
          const on = active === i.key;
          const p = spots[idx];
          if (place === 'edge') {
            const rise = t.interpolate({ inputRange: [0, 1], outputRange: [0, -(idx + 1) * (PILL_H + PILL_GAP)] });
            return (
              <Animated.View
                key={i.key}
                style={[
                  s.pill,
                  soft_shadow(c.primary, 2),
                  side === 'right' ? { right: 0 } : { left: 0 },
                  { top: rise, opacity: t, backgroundColor: on ? c.accent : c.surface, borderColor: c.line },
                ]}
              >
                <Pressable
                  onPress={() => go(i)}
                  accessibilityRole="button"
                  accessibilityLabel={i.label}
                  accessibilityState={{ selected: on }}
                  style={s.pill_fill}
                >
                  <Text style={{ fontSize: 18 }}>{i.emoji}</Text>
                  <Text style={{ color: on ? c.accentFg : c.ink, fontFamily: 'Figtree_700Bold', fontSize: 14 }} numberOfLines={1}>{i.label}</Text>
                </Pressable>
              </Animated.View>
            );
          }
          // Each tab starts at the button and travels out to its place on the arc.
          const left = t.interpolate({ inputRange: [0, 1], outputRange: [centre, centre + p.x * mirror] });
          const tabTop = t.interpolate({ inputRange: [0, 1], outputRange: [centre, centre + p.y] });
          const scale = t.interpolate({ inputRange: [0, 1], outputRange: [0.4, 1] });
          return (
            <Animated.View
              key={i.key}
              style={[
                s.item,
                soft_shadow(c.primary, 2),
                { left, top: tabTop, opacity: t, transform: [{ scale }], backgroundColor: on ? c.accent : c.surface, borderColor: c.line },
              ]}
            >
              <Pressable
                onPress={() => go(i)}
                accessibilityRole="button"
                accessibilityLabel={i.label}
                accessibilityState={{ selected: on }}
                style={s.fill}
              >
                <Text style={{ fontSize: 22 }}>{i.emoji}</Text>
                <Text style={{ color: on ? c.accentFg : c.ink, fontFamily: 'Figtree_700Bold', fontSize: 10 }} numberOfLines={1}>{i.label}</Text>
              </Pressable>
            </Animated.View>
          );
        })}

        <Pressable
          onPress={() => set(!open)}
          accessibilityRole="button"
          accessibilityLabel={open ? 'Close menu' : 'Open menu'}
          style={[s.button, { width: size, height: size, borderRadius: size / 2 }, soft_shadow(c.primary, 3), { backgroundColor: c.primary, borderColor: c.line }]}
        >
          <Text style={{ color: c.primaryFg, fontFamily: 'Figtree_700Bold', fontSize: size < 52 ? 18 : 22 }}>{open ? '✕' : '☰'}</Text>
        </Pressable>
      </View>
    </View>
  );
}

const s = StyleSheet.create({
  anchor: { position: 'absolute' },
  button: { borderWidth: 1, alignItems: 'center', justifyContent: 'center' },
  item: { position: 'absolute', width: ITEM, height: ITEM, borderRadius: ITEM / 2, borderWidth: 1 },
  fill: { flex: 1, alignItems: 'center', justifyContent: 'center', borderRadius: ITEM / 2 },
  pill: { position: 'absolute', width: PILL_W, height: PILL_H, borderRadius: PILL_H / 2, borderWidth: 1 },
  pill_fill: { flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, borderRadius: PILL_H / 2, paddingHorizontal: 12 },
});
