import { useState } from 'react';
import { ActivityIndicator, StyleSheet, TextInput, View } from 'react-native';
import { AppText as Text } from './app_text';
import { BouncyPressable as Pressable } from './bouncy_pressable';
import { GlowButton } from './glow_button';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useAuth } from '../lib/auth';
import { useTheme } from '../lib/theme';
import { api } from '../lib/backend';
import { ACTION_REQUEST_ACCESS } from '../lib/actions';

// Shown to a signed-in person who is not on the list yet.
// Before Phase 2b this screen was only text, so the admin never saw a request.
export function RequestAccess() {
  const { me, reload, signOut } = useAuth();
  const { theme } = useTheme();
  const insets = useSafeAreaInsets();
  const c = theme.colors;
  const [name, setName] = useState(me?.requestName || me?.name || '');
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState<{ ok: boolean; text: string } | null>(null);

  const pending = me?.requestStatus === 'pending';
  const rejected = me?.requestStatus === 'rejected';

  const send = async () => {
    if (!name.trim()) { setMessage({ ok: false, text: 'Please type your name first.' }); return; }
    setBusy(true);
    setMessage(null);
    try {
      await api(ACTION_REQUEST_ACCESS, name.trim());
      await reload(); // me.requestStatus becomes "pending"
      setMessage({ ok: true, text: 'Request sent. The admin will see it.' });
    } catch (e: any) {
      setMessage({ ok: false, text: e?.message || 'Could not send the request.' });
    } finally {
      setBusy(false);
    }
  };

  const check_again = async () => {
    setBusy(true);
    setMessage(null);
    const fresh = await reload(); // if approved, allowed becomes true and Home opens by itself
    if (!fresh) setMessage({ ok: false, text: 'Could not reach the server. Try again in a moment.' });
    setBusy(false);
  };

  return (
    <View style={[s.center, { backgroundColor: c.bg, paddingTop: insets.top, paddingBottom: insets.bottom }]}>
      <Text style={[s.brand, { color: c.primary }]}>{pending ? 'Waiting for approval' : 'No access yet'}</Text>
      <Text style={[s.muted, { color: c.muted }]}>
        {pending
          ? `Your request for ${me?.email} was sent. You will get in as soon as the admin approves it.`
          : rejected
            ? `Your last request for ${me?.email} was not approved. You can ask again.`
            : `${me?.email} is not on the list yet. Send a request and the admin can approve it.`}
      </Text>

      {pending ? (
        <GlowButton label="Check again" on_press={check_again} busy={busy} color={c.accent} text_color={c.accentFg} style={s.btn} />
      ) : (
        <>
          <TextInput
            value={name}
            onChangeText={setName}
            placeholder="Your name"
            placeholderTextColor={c.muted}
            autoCapitalize="words"
            style={[s.input, { borderColor: c.line, backgroundColor: c.surface, color: c.ink }]}
          />
          <GlowButton label={rejected ? 'Ask again' : 'Request access'} on_press={send} busy={busy} color={c.accent} text_color={c.accentFg} style={s.btn} />
        </>
      )}

      {message && <Text style={[s.muted, { color: message.ok ? c.primary : '#b3261e', marginTop: 16 }]}>{message.text}</Text>}
      <Pressable onPress={signOut} hitSlop={12}>
        <Text style={[s.link, { color: c.primary, marginTop: 24 }]}>Sign out</Text>
      </Pressable>
    </View>
  );
}

const s = StyleSheet.create({
  center: { flex: 1, alignItems: 'center', justifyContent: 'center', padding: 24 },
  brand: { fontFamily: 'Figtree_700Bold', fontSize: 30, textAlign: 'center' },
  muted: { fontFamily: 'Figtree_500Medium', fontSize: 15, textAlign: 'center', marginTop: 8 },
  input: { alignSelf: 'stretch', height: 50, borderWidth: 1, borderRadius: 25, paddingHorizontal: 20, marginTop: 24, fontFamily: 'Figtree_500Medium', fontSize: 16 },
  btn: { alignSelf: 'stretch', marginTop: 16 },
  btn_text: { fontFamily: 'Figtree_700Bold', fontSize: 16 },
  link: { fontFamily: 'Figtree_500Medium', fontSize: 16 },
});
