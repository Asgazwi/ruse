import { useEffect, useState } from 'react';
import { StyleSheet, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { AppText as Text } from './app_text';
import { BouncyPressable as Pressable } from './bouncy_pressable';
import { useTheme } from '../lib/theme';
import { load_saved, save_saved } from '../lib/store';
import { DEFAULT_PREFS, music_url, source_for, track_for, volume_down, volume_up, type MusicPrefs, type MusicSource } from '../lib/music';
import { play_music, schedule_stop, set_music_muted, set_music_volume, stop_music } from '../lib/music_player';
import { download_track, is_downloaded, resolve } from '../lib/downloads';

const PREFS_KEY = 'music_prefs';
const SOURCE_KEY = 'music_source'; // { [novel id]: 'author' | 'off' }

// The music bar in the chapter reader (F2): the author's track for this novel, or off.
// Your own music is in the Music tab on the wheel.
export function MusicBar({ subject }: { subject: { id: string; musicUrl?: unknown } | null | undefined }) {
  const { theme } = useTheme();
  const c = theme.colors;
  const url = music_url(subject);
  const subject_id = subject?.id ?? '';
  const [prefs, setPrefs] = useState<MusicPrefs>(() => load_saved<MusicPrefs>(PREFS_KEY) ?? DEFAULT_PREFS);
  const [sources, setSources] = useState<Record<string, MusicSource>>(() => load_saved<Record<string, MusicSource>>(SOURCE_KEY) ?? {});
  const source = source_for(subject_id, sources, !!url);
  const track = track_for(source, url ? resolve(url) : null); // the phone's copy when downloaded
  const [saving, setSaving] = useState(false);
  const [note, setNote] = useState<string | null>(null);
  const [, bump] = useState(0);
  const saved = !!url && is_downloaded(url);

  // "Save for offline": a copy in the app's own storage (never Downloads). Refuses a link that is not audio.
  const save_copy = async () => {
    if (!url) return;
    setSaving(true);
    setNote(null);
    const r = await download_track(url);
    setSaving(false);
    if (r.ok === false) setNote(r.error);
    else { setNote('Saved on this phone. Clear saved downloads in Settings removes it.'); bump((n) => n + 1); }
  };

  // Start or keep the track while this novel is open. Mute is handled by the volume (never a stop).
  useEffect(() => {
    if (track) play_music(subject_id, track, prefs.volume, prefs.muted);
    else stop_music();
  }, [track, subject_id]); // eslint-disable-line react-hooks/exhaustive-deps

  // Leaving this novel's chapter (to another chapter or out): stop soon, unless a chapter of the same novel opens first.
  useEffect(() => () => { if (subject_id) schedule_stop(subject_id); }, [subject_id]);

  // No author track for this novel: nothing to control, so nothing is shown.
  if (!subject_id || !url) return null;

  const save_prefs = (p: MusicPrefs) => { setPrefs(p); save_saved(PREFS_KEY, p); };
  const change_volume = (v: number) => { save_prefs({ ...prefs, volume: v }); set_music_volume(v); };
  const toggle_mute = () => { const m = !prefs.muted; save_prefs({ ...prefs, muted: m }); set_music_muted(m); };
  const choose = (s: MusicSource) => {
    const map = { ...sources, [subject_id]: s };
    setSources(map);
    save_saved(SOURCE_KEY, map);
  };

  const playing = source === 'author' && !!track;
  const status = !playing ? 'Off' : prefs.muted ? 'Muted' : 'Playing';
  // A small round button with one symbol.
  const round = (symbol: string, label: string, on_press: () => void, on = false) => (
    <Pressable onPress={on_press} accessibilityRole="button" accessibilityLabel={label}
      style={[s.round, { borderColor: c.line, backgroundColor: on ? c.accent : c.surface }]}>
      <Text style={{ color: on ? c.accentFg : c.ink, fontFamily: 'Figtree_700Bold', fontSize: 15 }}>{symbol}</Text>
    </Pressable>
  );

  return (
    <View style={[s.bar, { borderColor: c.line, backgroundColor: c.surface }]}>
      {round(playing ? '❚❚' : '▶', playing ? 'Turn the soundtrack off' : 'Turn the soundtrack on', () => choose(playing ? 'off' : 'author'), playing)}
      <View style={s.label}>
        <Text style={{ color: c.ink, fontFamily: 'Figtree_700Bold', fontSize: 14 }} numberOfLines={1}>🎵 Soundtrack</Text>
        <Text style={{ color: c.muted, fontFamily: 'Figtree_500Medium', fontSize: 12 }} numberOfLines={1}>{status}</Text>
        {!!note && <Text style={{ color: c.muted, fontFamily: 'Figtree_500Medium', fontSize: 12 }} numberOfLines={2}>{note}</Text>}
      </View>
      {saved ? (
        <View accessibilityLabel="Saved on this phone" style={[s.round, { borderColor: c.line, backgroundColor: c.surface }]}>
          <Ionicons name="checkmark" size={18} color={c.primary} />
        </View>
      ) : (
        <Pressable onPress={save_copy} disabled={saving} accessibilityRole="button" accessibilityLabel="Save for offline"
          style={[s.round, { borderColor: c.line, backgroundColor: c.surface, opacity: saving ? 0.5 : 1 }]}>
          <Ionicons name="download-outline" size={18} color={c.ink} />
        </Pressable>
      )}
      {playing ? (
        <View style={s.controls}>
          {round(prefs.muted ? '🔇' : '🔊', prefs.muted ? 'Unmute' : 'Mute', toggle_mute)}
          {round('−', 'Volume down', () => change_volume(volume_down(prefs.volume)))}
          {round('+', 'Volume up', () => change_volume(volume_up(prefs.volume)))}
        </View>
      ) : null}
    </View>
  );
}

const s = StyleSheet.create({
  bar: { flexDirection: 'row', alignItems: 'center', gap: 10, borderWidth: 1, borderRadius: 22, paddingVertical: 8, paddingHorizontal: 10 },
  label: { flex: 1, minWidth: 0 },
  controls: { flexDirection: 'row', gap: 6 },
  round: { width: 38, height: 38, borderRadius: 19, borderWidth: 1, alignItems: 'center', justifyContent: 'center' },
});
