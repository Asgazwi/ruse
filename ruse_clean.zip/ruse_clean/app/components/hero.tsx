import { StyleSheet, View } from 'react-native';
import { useTheme } from '../lib/theme';

// Page header container. Flat: the page colour with a hairline under it. (It used to be a gradient with
// floating blobs and stars.) Kept under the same name so every screen that uses it picks up the new look.
export function Hero({ children, top_padding }: { children: React.ReactNode; top_padding: number }) {
  const { theme } = useTheme();
  const c = theme.colors;
  return <View style={[s.hero, { paddingTop: top_padding, backgroundColor: c.bg, borderBottomColor: c.line }]}>{children}</View>;
}

const s = StyleSheet.create({
  hero: { paddingHorizontal: 20, paddingBottom: 18, borderBottomWidth: 1 },
});
