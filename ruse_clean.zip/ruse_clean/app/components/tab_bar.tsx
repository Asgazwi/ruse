import { useEffect, useState } from 'react';
import { StyleSheet, View } from 'react-native';
import { router, usePathname } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { AppText as Text } from './app_text';
import { BouncyPressable as Pressable } from './bouncy_pressable';
import { CountDot } from './count_dot';
import { useTheme } from '../lib/theme';
import { visible_nav } from '../lib/nav_items';
import { TAB_BAR_HEIGHT } from '../lib/nav_clearance';
import { fetch_all_messages } from '../lib/messages_api';
import { fetch_blocked } from '../lib/safety_api';
import { blocked_set, is_blocked } from '../lib/safety';
import { summarize_threads, unread_total } from '../lib/messages';

// The bottom tab bar for the whole app: icon over a short name, the current tab in the accent colour,
// the unread count on Messages. It replaces the round fan-out button.
export function TabBar({ me, active }: { me: any; active: string | null }) {
  const { theme } = useTheme();
  const c = theme.colors;
  const insets = useSafeAreaInsets();
  const path = usePathname();
  const [unread, setUnread] = useState(0);
  const list = visible_nav(me);

  // Re-count when the screen changes. (With Supabase Realtime this becomes a live subscription.)
  useEffect(() => {
    if (!me?.allowed) return;
    let live = true;
    Promise.all([fetch_all_messages(), fetch_blocked().catch(() => [] as string[])])
      .then(([all, blocked]) => {
        if (!live) return;
        const hidden = blocked_set(blocked);
        setUnread(unread_total(summarize_threads(all, me?.username ?? null).filter((t) => !is_blocked(hidden, t.with))));
      })
      .catch(() => {});
    return () => { live = false; };
  }, [path, me?.allowed, me?.username]);

  return (
    <View style={[s.bar, { height: TAB_BAR_HEIGHT + insets.bottom, paddingBottom: insets.bottom, backgroundColor: c.surface, borderTopColor: c.line }]}>
      {list.map((i) => {
        const on = i.key === active;
        const color = on ? c.primary : c.muted;
        return (
          <Pressable key={i.key} onPress={() => i.route && router.push(i.route as any)} accessibilityRole="tab" accessibilityLabel={i.label} accessibilityState={{ selected: on }} style={s.tab}>
            <View>
              <Ionicons name={(on ? i.icon : `${i.icon}-outline`) as any} size={24} color={color} />
              {i.key === 'messages' && unread > 0 && <View style={s.badge}><CountDot count={unread} /></View>}
            </View>
            <Text style={{ color, fontFamily: 'Figtree_700Bold', fontSize: 11, marginTop: 3 }}>{i.label}</Text>
          </Pressable>
        );
      })}
    </View>
  );
}

const s = StyleSheet.create({
  bar: { position: 'absolute', left: 0, right: 0, bottom: 0, flexDirection: 'row', borderTopWidth: 1 },
  tab: { flex: 1, alignItems: 'center', justifyContent: 'center', paddingTop: 6 },
  badge: { position: 'absolute', top: -6, left: 14 },
});
