import { useState } from 'react';
import { Alert, Image, StyleSheet, View } from 'react-native';
import { AppText as Text } from './app_text';
import { BouncyPressable as Pressable } from './bouncy_pressable';
import { useTheme } from '../lib/theme';
import { type CardPerson } from '../lib/profile_card';
import { REPORT_REASONS, report_check, type ReportReason } from '../lib/safety';
import { block_user, report_user } from '../lib/safety_api';
import { is_network_error } from '../lib/net_retry';

// Small card shown when a reader taps a username (D2). "Send message" (D3) and
// "Block" / "Report" (D4) live here too. Drawn as an overlay, not a second Modal,
// so it can sit on top of the comment sheet without a nested-modal conflict.
export function ProfileCard({ person, on_close, on_message, on_blocked }: {
  person: CardPerson | null;
  on_close: () => void;
  on_message: (username: string) => void;
  on_blocked?: (username: string) => void;
}) {
  const { theme } = useTheme();
  const c = theme.colors;
  const [reporting, setReporting] = useState(false);
  const [busy, setBusy] = useState(false);
  const [note, setNote] = useState<{ ok: boolean; text: string } | null>(null);
  if (!person) return null;

  const fail = (e: any) => setNote({ ok: false, text: is_network_error(e) ? 'You need to be online for that.' : e?.message || 'That did not work.' });

  const send_report = async (reason: ReportReason) => {
    const checked = report_check(person.username, reason);
    if (!checked.ok) { setNote({ ok: false, text: checked.reason }); return; }
    setBusy(true);
    try {
      await report_user(person.username, checked.reason);
      setReporting(false);
      setNote({ ok: true, text: 'Thanks. An admin will look at it.' });
    } catch (e) { fail(e); } finally { setBusy(false); }
  };

  const confirm_block = () =>
    Alert.alert(`Block ${person.username}?`, 'They cannot message you, and you will not see their messages.', [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Block', style: 'destructive',
        onPress: async () => {
          setBusy(true);
          try {
            await block_user(person.username);
            on_blocked?.(person.username);
            on_close();
          } catch (e) { fail(e); } finally { setBusy(false); }
        },
      },
    ]);

  return (
    <View style={s.overlay} pointerEvents="box-none">
      <Pressable onPress={on_close} style={s.backdrop} />
      <View style={[s.card, { backgroundColor: c.surface, borderColor: c.line }]}>
        <View style={[s.avatar, { backgroundColor: c.accent }]}>
          {person.avatarUrl
            ? <Image source={{ uri: person.avatarUrl }} style={s.avatar_img} accessibilityLabel={`${person.username}'s avatar`} />
            : <Text style={{ color: c.accentFg, fontFamily: 'Figtree_700Bold', fontSize: 28 }}>{person.initial}</Text>}
        </View>
        <Text style={[s.name, { color: c.ink }]} numberOfLines={1}>{person.username}</Text>

        {!!note && <Text style={{ color: note.ok ? c.primary : '#b3261e', fontFamily: 'Figtree_500Medium', fontSize: 13, textAlign: 'center' }}>{note.text}</Text>}

        {!reporting && (
          <>
            <Pressable onPress={() => on_message(person.username)} style={[s.message, { borderColor: c.primary, backgroundColor: c.primary }]} accessibilityRole="button">
              <Text style={{ color: c.primaryFg, fontFamily: 'Figtree_700Bold' }}>Send message</Text>
            </Pressable>
            <View style={s.row}>
              <Pressable onPress={confirm_block} disabled={busy} hitSlop={8} accessibilityRole="button">
                <Text style={[s.link, { color: '#b3261e' }]}>Block</Text>
              </Pressable>
              <Pressable onPress={() => { setReporting(true); setNote(null); }} disabled={busy} hitSlop={8} accessibilityRole="button">
                <Text style={[s.link, { color: c.muted }]}>Report</Text>
              </Pressable>
            </View>
          </>
        )}

        {reporting && (
          <View style={{ alignSelf: 'stretch', gap: 8 }}>
            <Text style={{ color: c.muted, fontFamily: 'Figtree_700Bold', fontSize: 13, textAlign: 'center' }}>Why are you reporting this?</Text>
            {REPORT_REASONS.map((r) => (
              <Pressable key={r.key} onPress={() => send_report(r.key)} disabled={busy} style={[s.reason, { borderColor: c.line, backgroundColor: c.bg }]}>
                <Text style={{ color: c.ink, fontFamily: 'Figtree_500Medium' }}>{r.label}</Text>
              </Pressable>
            ))}
            <Pressable onPress={() => setReporting(false)} hitSlop={8}>
              <Text style={[s.link, { color: c.primary, textAlign: 'center' }]}>Cancel</Text>
            </Pressable>
          </View>
        )}

        <Pressable onPress={on_close} hitSlop={12} style={s.close}>
          <Text style={{ color: c.primary, fontFamily: 'Figtree_700Bold', fontSize: 16 }}>Close</Text>
        </Pressable>
      </View>
    </View>
  );
}

// Same as the old StyleSheet.absoluteFillObject, written out so it works on every React Native version.
const fill_object = { position: 'absolute', top: 0, right: 0, bottom: 0, left: 0 } as const;

const s = StyleSheet.create({
  overlay: { ...fill_object, justifyContent: 'center', alignItems: 'center', padding: 24 },
  backdrop: { ...fill_object, backgroundColor: 'rgba(0,0,0,0.4)' },
  card: { width: '100%', maxWidth: 320, borderWidth: 1, borderRadius: 24, padding: 22, alignItems: 'center', gap: 12 },
  avatar: { width: 72, height: 72, borderRadius: 36, alignItems: 'center', justifyContent: 'center', overflow: 'hidden' },
  avatar_img: { width: 72, height: 72, borderRadius: 36 },
  name: { fontFamily: 'Figtree_700Bold', fontSize: 20, maxWidth: '100%' },
  message: { alignSelf: 'stretch', height: 46, borderRadius: 23, borderWidth: 1, alignItems: 'center', justifyContent: 'center' },
  row: { flexDirection: 'row', gap: 28, marginTop: 2 },
  link: { fontFamily: 'Figtree_700Bold', fontSize: 14 },
  reason: { borderWidth: 1, borderRadius: 14, paddingVertical: 10, paddingHorizontal: 14 },
  close: { paddingVertical: 6 },
});
