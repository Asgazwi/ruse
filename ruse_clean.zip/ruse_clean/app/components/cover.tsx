import { StyleSheet, View } from 'react-native';
import { AppText as Text } from './app_text';
import { cover_for } from '../lib/cover';
import { font_name } from '../lib/fonts';
import { useTheme } from '../lib/theme';

// A drawn book cover: a muted colour, one big soft circle, the title in the heading font.
export function Cover({ title, width, height, font_size }: { title: string; width: number; height: number; font_size?: number }) {
  const { theme } = useTheme();
  const col = cover_for(title);
  const fs = font_size ?? Math.max(11, Math.round(width * 0.15));
  const ring = width * 0.85;
  return (
    <View style={[s.box, { width, height, backgroundColor: col.bg, borderRadius: Math.max(6, width * 0.09) }]}>
      <View style={{ position: 'absolute', right: -ring * 0.3, top: -ring * 0.25, width: ring, height: ring, borderRadius: ring / 2, backgroundColor: col.ring, opacity: 0.32 }} />
      <Text exact numberOfLines={4} style={{ position: 'absolute', left: width * 0.1, right: width * 0.08, bottom: height * 0.08, color: '#ffffff', fontFamily: font_name(theme.heading_font ?? 'Newsreader', 'medium'), fontSize: fs, lineHeight: fs * 1.18 }}>
        {title}
      </Text>
    </View>
  );
}

const s = StyleSheet.create({ box: { overflow: 'hidden' } });
