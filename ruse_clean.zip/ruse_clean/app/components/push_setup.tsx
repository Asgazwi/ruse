import { useEffect, useRef } from 'react';
import { Platform } from 'react-native';
import * as Notifications from 'expo-notifications';
import Constants from 'expo-constants';
import { router } from 'expo-router';
import { api } from '../lib/backend';
import { useAuth } from '../lib/auth';
import { load_saved, save_saved } from '../lib/store';
import { pin_store } from '../lib/pins';
import { ACTION_REGISTER_PUSH_TOKEN } from '../lib/actions';
import { push_destination, push_key } from '../lib/push_helpers';

// Show a banner even while the app is open.
try {
  Notifications.setNotificationHandler({
    handleNotification: async () => ({ shouldShowBanner: true, shouldShowList: true, shouldPlaySound: true, shouldSetBadge: false }),
  });
} catch { /* push is a bonus: the app works without it */ }

// Draws nothing. Once signed in: asks for permission, tells the backend this phone's push token,
// refreshes comments when a push arrives, and opens the right chapter spot when one is tapped.
// (Push needs a real build, not Expo Go. Without one this quietly does nothing.)
export function PushSetup() {
  const { status, me } = useAuth();
  const email = status === 'in' && me?.allowed ? me.email : null;
  const last = Notifications.useLastNotificationResponse();
  const handled = useRef<string | null>(null);

  // 1) Permission + token
  useEffect(() => {
    if (!email) return;
    let stop = false;
    (async () => {
      try {
        if (Platform.OS === 'android') {
          await Notifications.setNotificationChannelAsync('default', { name: 'Messages and comments', importance: Notifications.AndroidImportance.HIGH });
        }
        let perm = await Notifications.getPermissionsAsync();
        if (perm.status !== 'granted') perm = await Notifications.requestPermissionsAsync();
        if (perm.status !== 'granted' || stop) return;
        const project_id = (Constants as any)?.expoConfig?.extra?.eas?.projectId ?? (Constants as any)?.easConfig?.projectId;
        const { data: token } = await Notifications.getExpoPushTokenAsync(project_id ? { projectId: project_id } : undefined);
        if (!token || stop) return;
        if (load_saved<string>(push_key(email)) === token) return; // already told the backend
        await api(ACTION_REGISTER_PUSH_TOKEN, token);
        save_saved(push_key(email), token);
      } catch { /* no permission, Expo Go, or offline: tried again next time the app opens */ }
    })();
    return () => { stop = true; };
  }, [email]);

  // 2) A push arrived while the app is open: fetch the new comment.
  useEffect(() => {
    if (!email) return;
    const sub = Notifications.addNotificationReceivedListener(() => { void pin_store.sync(); });
    return () => sub.remove();
  }, [email]);

  // 3) A push was tapped (also when it opened the app): go to that spot.
  useEffect(() => {
    if (!email || !last) return;
    const id = last.notification.request.identifier;
    if (handled.current === id) return;
    handled.current = id;
    if (last.actionIdentifier !== Notifications.DEFAULT_ACTION_IDENTIFIER) return;
    const destination = push_destination(last.notification.request.content.data);
    if (destination) router.push(destination as any);
  }, [email, last]);

  return null;
}
