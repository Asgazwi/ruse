import { useEffect, useRef, useState } from 'react';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Animated, PanResponder, StyleSheet, View, useWindowDimensions } from 'react-native';
import { AppText as Text } from './app_text';
import { Ionicons } from '@expo/vector-icons';
import { useTheme } from '../lib/theme';
import { load_saved, save_saved } from '../lib/store';
import { clean_side, flip_side, is_drag, type side } from '../lib/drop_target';
import { DOCK_EDGE_GAP, DOCK_SIZE, DOCK_STEP, dock_top } from '../lib/dock_layout';

const SIZE = DOCK_SIZE;
const EDGE_GAP = DOCK_EDGE_GAP;
const SAVED_SIDE = 'float_side'; // a preference: it stays after sign out, like the theme

type Kind = 'pin' | 'comment';

// Two round buttons at the screen edge (Phase C2). Drag one and drop it on a block:
// 📍 pins that spot, 💬 opens that block's comments. Drop near the other edge to move them there.
export function FloatingTools({ on_hover, on_drop, on_tap }: {
  on_hover: (root_y: number | null) => void;      // finger height while dragging (null = not over anything)
  on_drop: (kind: Kind, root_y: number) => void;  // released away from the edges
  on_tap: (kind: Kind) => void;                   // touched without dragging: 💬 opens the chapter's comments, 📍 shows a hint
}) {
  const { width, height } = useWindowDimensions();
  const insets = useSafeAreaInsets();
  const [where, setWhere] = useState<side>(() => clean_side(load_saved<string>(SAVED_SIDE)));
  const move_to = (next: side) => { setWhere(next); save_saved(SAVED_SIDE, next); };
  const x = where === 'right' ? width - SIZE - EDGE_GAP : EDGE_GAP;
  const top = dock_top(height, insets.bottom);

  return (
    <View pointerEvents="box-none" style={StyleSheet.absoluteFill}>
      <DragButton kind="pin" icon="bookmark-outline" label="Pin button. Drag it onto a paragraph." x={x} y={top} side={where} width={width} on_hover={on_hover} on_drop={on_drop} on_tap={on_tap} on_flip={move_to} />
      <DragButton kind="comment" icon="chatbubble-outline" label="Comment button. Drag it onto a paragraph." x={x} y={top + DOCK_STEP} side={where} width={width} on_hover={on_hover} on_drop={on_drop} on_tap={on_tap} on_flip={move_to} />
    </View>
  );
}

function DragButton({ kind, icon, label, x, y, side: where, width, on_hover, on_drop, on_tap, on_flip }: {
  kind: Kind; icon: React.ComponentProps<typeof Ionicons>['name']; label: string; x: number; y: number; side: side; width: number;
  on_hover: (root_y: number | null) => void; on_drop: (kind: Kind, root_y: number) => void;
  on_tap: (kind: Kind) => void; on_flip: (s: side) => void;
}) {
  const { theme } = useTheme();
  const c = theme.colors;
  const pan = useRef(new Animated.ValueXY()).current;
  const [lifted, setLifted] = useState(false);
  // The responder is made once, so it reads the newest props from here.
  const live = useRef({ x, y, where, width, on_hover, on_drop, on_tap, on_flip, kind });
  live.current = { x, y, where, width, on_hover, on_drop, on_tap, on_flip, kind };

  const back = (animated: boolean) => {
    if (animated) Animated.spring(pan, { toValue: { x: 0, y: 0 }, useNativeDriver: false, friction: 6 }).start();
    else pan.setValue({ x: 0, y: 0 });
  };

  const responder = useRef(PanResponder.create({
    onStartShouldSetPanResponder: () => true,
    onPanResponderTerminationRequest: () => false, // the page must not scroll away with the button
    onPanResponderGrant: () => { pan.stopAnimation(); pan.setValue({ x: 0, y: 0 }); setLifted(true); },
    onPanResponderMove: (_e, g) => {
      pan.setValue({ x: g.dx, y: g.dy });
      const l = live.current;
      l.on_hover(is_drag(g.dx, g.dy) ? l.y + g.dy + SIZE / 2 : null);
    },
    onPanResponderRelease: (_e, g) => {
      const l = live.current;
      setLifted(false);
      l.on_hover(null);
      if (!is_drag(g.dx, g.dy)) { back(true); l.on_tap(l.kind); return; }
      const flip = flip_side(l.where, l.x + g.dx + SIZE / 2, l.width);
      if (flip) { back(false); l.on_flip(flip); return; }
      l.on_drop(l.kind, l.y + g.dy + SIZE / 2);
      back(true);
    },
    onPanResponderTerminate: () => { setLifted(false); live.current.on_hover(null); back(true); },
  })).current;

  useEffect(() => { back(false); }, [where]); // eslint-disable-line react-hooks/exhaustive-deps

  return (
    <Animated.View
      {...responder.panHandlers}
      accessibilityRole="button"
      accessibilityLabel={label}
      style={[
        s.btn,
        { left: x, top: y, backgroundColor: c.surface, borderColor: lifted ? c.primary : c.line, opacity: lifted ? 1 : 0.96, transform: [...pan.getTranslateTransform(), { scale: lifted ? 1.08 : 1 }] },
      ]}>
      <Ionicons name={icon} size={22} color={kind === 'pin' ? c.accent : c.primary} />
    </Animated.View>
  );
}

const s = StyleSheet.create({
  btn: { position: 'absolute', width: SIZE, height: SIZE, borderRadius: SIZE / 2, borderWidth: 2, alignItems: 'center', justifyContent: 'center' },
});
