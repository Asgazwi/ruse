import { StyleSheet, View } from 'react-native';
import { AppText as Text } from './app_text';
import { BouncyPressable as Pressable } from './bouncy_pressable';
import { GlowButton } from './glow_button';
import { useTheme } from '../lib/theme';
import { soft_shadow } from '../lib/soft_shadow';
import type { Theme } from '../lib/types';

// E4 · Banner on a novel screen when the author recommends an exclusive theme.
// Never forced: Yes (use while on this novel), Always (remember), No (hide).
export function RecommendThemeBanner({
  recommended,
  on_yes,
  on_always,
  on_no,
}: {
  recommended: Theme;
  on_yes: () => void;
  on_always: () => void;
  on_no: () => void;
}) {
  const { theme } = useTheme();
  const c = theme.colors;
  const dots = [recommended.colors.primary, recommended.colors.accent, recommended.colors.bg];

  return (
    <View style={[s.card, soft_shadow(c.primary, 1), { backgroundColor: c.surface, borderColor: c.line }]}>
      <View style={s.row}>
        <View style={s.swatch}>
          {dots.map((color, i) => (
            <View
              key={i}
              style={[
                s.dot,
                { backgroundColor: color, borderColor: c.surface },
                i > 0 ? s.dot_overlap : null,
              ]}
            />
          ))}
        </View>
        <View style={{ flex: 1 }}>
          <Text style={{ color: c.ink, fontFamily: 'Figtree_700Bold', fontSize: 15 }}>
            Author recommends {recommended.name}
          </Text>
          <Text style={{ color: c.muted, fontFamily: 'Figtree_500Medium', fontSize: 13, marginTop: 2 }}>
            Try this look while you read? You can change your mind any time.
          </Text>
        </View>
      </View>
      <View style={s.actions}>
        <GlowButton label="Yes" on_press={on_yes} size="sm" color={c.accent} text_color={c.accentFg} style={s.btn} />
        <GlowButton label="Always" on_press={on_always} outline size="sm" color={c.primary} text_color={c.primaryFg} style={s.btn} />
        <Pressable
          onPress={on_no}
          hitSlop={6}
          style={s.btn_plain}
          accessibilityRole="button"
          accessibilityLabel="No thanks">
          <Text style={{ color: c.muted, fontFamily: 'Figtree_700Bold', fontSize: 14 }}>No</Text>
        </Pressable>
      </View>
    </View>
  );
}

const s = StyleSheet.create({
  card: { borderWidth: 1, borderRadius: 18, padding: 14, gap: 12 },
  row: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  swatch: { flexDirection: 'row', alignItems: 'center' },
  dot: { width: 16, height: 16, borderRadius: 8, borderWidth: 2 },
  dot_overlap: { marginLeft: -6 },
  actions: { flexDirection: 'row', flexWrap: 'wrap', alignItems: 'center', gap: 8 },
  btn: { minWidth: 64 },
  btn_plain: { paddingHorizontal: 12, height: 36, justifyContent: 'center' },
});
