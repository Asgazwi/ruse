import { View } from 'react-native';
import { router } from 'expo-router';
import { AppText as Text } from './app_text';
import { BouncyPressable as Pressable } from './bouncy_pressable';
import { Cover } from './cover';
import { useTheme } from '../lib/theme';

// A cover with its title and author underneath, for the sideways "Picked for you" row.
export function CoverTile({ id, title, byline }: { id: string; title: string; byline?: string }) {
  const { theme } = useTheme();
  const c = theme.colors;
  return (
    <Pressable onPress={() => router.push(`/course/${id}`)} accessibilityRole="button" accessibilityLabel={title} style={{ width: 104, marginRight: 14 }}>
      <Cover title={title} width={104} height={150} font_size={15} />
      <View style={{ marginTop: 8 }}>
        <Text style={{ color: c.ink, fontFamily: 'Figtree_700Bold', fontSize: 13.5 }} numberOfLines={1}>{title}</Text>
        {!!byline && <Text style={{ color: c.muted, fontFamily: 'Figtree_500Medium', fontSize: 12 }} numberOfLines={1}>{byline}</Text>}
      </View>
    </Pressable>
  );
}
