import { StyleSheet, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { AppText as Text } from './app_text';
import { BouncyPressable as Pressable } from './bouncy_pressable';
import { useTheme } from '../lib/theme';
import { alpha_hex } from '../lib/alpha_hex';

// Under a block, ONLY when it has something: a "Pinned" tag (tap to remove) and a comment count
// (tap to open). Blocks with nothing show no row at all. Pins and comments are added with the
// floating buttons (Phase C2).
export function PinBar({ pinned, count, on_pin, on_comments }: {
  pinned: boolean;
  count: number;
  on_pin: () => void;       // tapping the "Pinned" tag removes the pin
  on_comments: () => void;
}) {
  const { theme } = useTheme();
  const c = theme.colors;
  if (!pinned && count === 0) return null;
  return (
    <View style={s.row}>
      {pinned && (
        <Pressable onPress={on_pin} hitSlop={8} accessibilityLabel="Remove pin" style={[s.pill, { backgroundColor: c.ink, borderColor: c.ink }]}>
          <Ionicons name="bookmark" size={12} color={c.bg} />
          <Text style={[s.text, { color: c.bg }]}>Pinned</Text>
        </Pressable>
      )}
      {count > 0 && (
        <Pressable onPress={on_comments} hitSlop={8} accessibilityLabel="Comments on this spot" style={[s.pill, { backgroundColor: 'transparent', borderColor: c.line }]}>
          <Ionicons name="chatbubble-outline" size={12} color={c.primary} />
          <Text style={[s.text, { color: c.primary }]}>{count}</Text>
        </Pressable>
      )}
    </View>
  );
}

const s = StyleSheet.create({
  row: { flexDirection: 'row', justifyContent: 'flex-end', gap: 8, marginTop: -4, marginBottom: 14 },
  pill: { borderWidth: 1, borderRadius: 999, paddingHorizontal: 11, height: 28, flexDirection: 'row', alignItems: 'center', gap: 5 },
  text: { fontFamily: 'Figtree_500Medium', fontSize: 12 },
});
