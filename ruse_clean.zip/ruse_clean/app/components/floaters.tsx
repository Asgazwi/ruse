import { useEffect, useRef } from 'react';
import { Animated, Easing, StyleSheet, Text, View, useWindowDimensions } from 'react-native';
import { useTheme } from '../lib/theme';
import { useEffects } from '../lib/effects';
import { floater_plan, glyph_for_effect, type floater } from '../lib/look';
import { background_floaters, type floater_piece } from '../lib/recipes';

function Floater({ f, glyph, color, height, width, opacity = 0.3 }: { f: floater; glyph: string; color: string; height: number; width: number; opacity?: number }) {
  const t = useRef(new Animated.Value(0)).current;
  useEffect(() => {
    const loop = Animated.loop(Animated.timing(t, { toValue: 1, duration: f.duration, delay: f.delay, easing: Easing.linear, useNativeDriver: true }));
    loop.start();
    return () => loop.stop();
  }, [t, f.duration, f.delay]);
  return (
    <Animated.View
      style={{
        position: 'absolute', top: 0, left: (f.left_pct / 100) * width,
        opacity: t.interpolate({ inputRange: [0, 0.1, 0.85, 1], outputRange: [0, opacity, opacity, 0] }),
        transform: [
          { translateY: t.interpolate({ inputRange: [0, 1], outputRange: [height, -f.size * 2] }) },
          { translateX: t.interpolate({ inputRange: [0, 0.5, 1], outputRange: [0, f.sway, 0] }) },
        ],
      }}>
      <Text style={{ color, fontSize: f.size }}>{glyph}</Text>
    </Animated.View>
  );
}

// Gentle shapes drifting upward behind the screen. Off when "Sparkles when I tap" is off.
export function Floaters() {
  const { theme } = useTheme();
  const { effects_on } = useEffects();
  const { width, height } = useWindowDimensions();
  if (effects_on && theme.effects?.background?.length) {
    const pieces = background_floaters(theme.effects.background);
    return (
      <View pointerEvents="none" style={StyleSheet.absoluteFill}>
        {pieces.map((p, i) => <DesignedFloater key={i} p={p} height={height} width={width} fallback={theme.colors.accent} />)}
      </View>
    );
  }
  const glyph = glyph_for_effect(theme.effect);
  if (!effects_on || !glyph) return null;
  const plan = floater_plan(7);
  return (
    <View pointerEvents="none" style={StyleSheet.absoluteFill}>
      {plan.map((f, i) => <Floater key={i} f={f} glyph={glyph} color={i % 2 ? theme.colors.primary : theme.colors.accent} height={height} width={width} />)}
    </View>
  );
}

// A floater from a designed background recipe: a glyph (drawn by Floater), or a dot / ring / rect.
function DesignedFloater({ p, height, width, fallback }: { p: floater_piece; height: number; width: number; fallback: string }) {
  const f: floater = { left_pct: p.left_pct, size: p.size, duration: p.duration, delay: p.delay, sway: p.sway };
  const color = p.color ?? fallback;
  if (p.shape === 'glyph') return <Floater f={f} glyph={p.glyph ?? '•'} color={color} height={height} width={width} opacity={p.opacity} />;
  return <ShapeFloater p={p} f={f} color={color} height={height} width={width} />;
}

function ShapeFloater({ p, f, color, height, width }: { p: floater_piece; f: floater; color: string; height: number; width: number }) {
  const t = useRef(new Animated.Value(0)).current;
  useEffect(() => {
    const loop = Animated.loop(Animated.timing(t, { toValue: 1, duration: f.duration, delay: f.delay, easing: Easing.linear, useNativeDriver: true }));
    loop.start();
    return () => loop.stop();
  }, [t, f.duration, f.delay]);
  const border = p.shape === 'ring' ? { borderWidth: 2, borderColor: color, backgroundColor: 'transparent' } : { backgroundColor: color };
  return (
    <Animated.View
      style={[{
        position: 'absolute', top: 0, left: (f.left_pct / 100) * width, width: f.size, height: p.shape === 'rect' ? f.size * 0.6 : f.size,
        borderRadius: p.shape === 'rect' ? 1 : f.size / 2, opacity: t.interpolate({ inputRange: [0, 0.1, 0.85, 1], outputRange: [0, p.opacity, p.opacity, 0] }),
        transform: [
          { translateY: t.interpolate({ inputRange: [0, 1], outputRange: [height, -f.size * 2] }) },
          { translateX: t.interpolate({ inputRange: [0, 0.5, 1], outputRange: [0, f.sway, 0] }) },
        ],
      }, border]}
    />
  );
}
