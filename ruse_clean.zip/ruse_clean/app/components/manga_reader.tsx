import { useEffect, useRef, useState } from 'react';
import { FlatList, Image, StyleSheet, useWindowDimensions, View } from 'react-native';
import { AppText as Text } from './app_text';
import { BouncyPressable as Pressable } from './bouncy_pressable';
import { useTheme } from '../lib/theme';
import { page_label, pages_size_note, preload_indexes, step_page } from '../lib/manga';
import { save_pages, saved_page_uri } from '../lib/manga_offline';

// Manga pages (Phase E2). Two modes:
//   strip: pages stacked top to bottom, scroll like a long web page.
//   page : one page at a time, swipe sideways or tap the left/right third.
// Pinch to zoom is NOT in this version: it needs a gesture package (new build). Next pages are
// fetched early so turning a page is quick. Strip mode scrolls with the chapter screen.
export function MangaReader({ pages, on_page }: { pages: string[]; on_page?: (index: number) => void }) {
  const { theme } = useTheme();
  const c = theme.colors;
  const { width, height } = useWindowDimensions();
  const [mode, setMode] = useState<'strip' | 'page'>('strip');
  const [current, setCurrent] = useState(0);
  const [ratios, setRatios] = useState<Record<number, number>>({}); // real page shape, learned on load
  const [saving, setSaving] = useState<{ done: number; total: number } | null>(null);
  const [offline, setOffline] = useState(false);     // every page is on the phone
  const flat = useRef<FlatList<string>>(null);

  // Use the phone's copy of a page when it is saved, otherwise the link.
  const src = (u: string) => saved_page_uri(u) ?? u;
  useEffect(() => { setOffline(pages.every((u) => !!saved_page_uri(u))); }, [pages]);

  const start_save = async () => {
    const pending = pages.length;
    setSaving({ done: 0, total: pending });
    const r = await save_pages(pages, (done, total) => setSaving({ done, total }));
    setSaving(null);
    setOffline(r.failed === 0);
  };

  // Fetch the next few pages in the background.
  useEffect(() => {
    preload_indexes(current, pages.length).forEach((i) => Image.prefetch(pages[i]).catch(() => {}));
    on_page?.(current);
  }, [current, pages, on_page]);

  const learn = (i: number) => (e: any) => {
    const src = e?.nativeEvent?.source;
    if (src?.width && src?.height) setRatios((r) => (r[i] ? r : { ...r, [i]: src.height / src.width }));
  };

  const go = (i: number) => {
    setCurrent(i);
    if (mode === 'page') flat.current?.scrollToIndex({ index: i, animated: true });
  };

  const save_row = (
    <View style={s.toolbar}>
      {offline ? (
        <Text style={{ color: c.muted, fontFamily: 'Figtree_500Medium', fontSize: 13 }}>✓ Saved on this phone</Text>
      ) : saving ? (
        <Text style={{ color: c.muted, fontFamily: 'Figtree_500Medium', fontSize: 13 }}>Saving {saving.done} / {saving.total}…</Text>
      ) : (
        <Pressable onPress={start_save} style={[s.chip, { borderColor: c.line, backgroundColor: 'transparent' }]} accessibilityRole="button">
          <Text style={{ color: c.ink, fontFamily: 'Figtree_700Bold', fontSize: 13 }}>Save pages offline</Text>
        </Pressable>
      )}
      <Text style={{ color: c.muted, fontFamily: 'Figtree_500Medium', fontSize: 11 }}>{pages_size_note(pages.length)}</Text>
    </View>
  );

  const toggle = (
    <View style={s.toolbar}>
      {(['strip', 'page'] as const).map((m) => (
        <Pressable key={m} onPress={() => { setMode(m); }} style={[s.chip, { borderColor: c.line, backgroundColor: mode === m ? c.accent : 'transparent' }]} accessibilityRole="button">
          <Text style={{ color: mode === m ? c.accentFg : c.muted, fontFamily: 'Figtree_700Bold', fontSize: 13 }}>{m === 'strip' ? 'Scroll' : 'Page by page'}</Text>
        </Pressable>
      ))}
      <Text style={{ color: c.muted, fontFamily: 'Figtree_500Medium', fontSize: 13, marginLeft: 'auto' }}>
        {mode === 'page' ? page_label(current, pages.length) : `${pages.length} pages`}
      </Text>
    </View>
  );

  if (mode === 'strip') {
    // The chapter screen scrolls, so the pages are simply stacked here (no second scroll inside it).
    return (
      <View>
        {toggle}
        {save_row}
        {pages.map((u, i) => (
          <Image
            key={u + i}
            source={{ uri: src(u) }}
            onLoad={learn(i)}
            resizeMode="contain"
            accessibilityLabel={`Page ${i + 1} of ${pages.length}`}
            style={{ width, height: width * (ratios[i] ?? 1.45), backgroundColor: c.surface }}
          />
        ))}
      </View>
    );
  }

  return (
    <View>
      {toggle}
      {save_row}
      <FlatList
        ref={flat}
        data={pages}
        horizontal
        pagingEnabled
        showsHorizontalScrollIndicator={false}
        keyExtractor={(u, i) => u + i}
        initialNumToRender={2}
        getItemLayout={(_, i) => ({ length: width, offset: width * i, index: i })}
        onMomentumScrollEnd={(e) => {
          const i = Math.round(e.nativeEvent.contentOffset.x / width);
          if (i !== current) setCurrent(i);
        }}
        renderItem={({ item, index }) => (
          <Pressable
            onPress={(e: any) => {
              const x = e?.nativeEvent?.locationX ?? width / 2;
              if (x < width / 3) go(step_page(index, -1, pages.length));
              else if (x > (width * 2) / 3) go(step_page(index, 1, pages.length));
            }}
            style={{ width }}
            accessibilityLabel={`Page ${index + 1} of ${pages.length}`}
          >
            <Image source={{ uri: src(item) }} onLoad={learn(index)} resizeMode="contain" style={{ width, height: Math.min(height * 0.8, width * (ratios[index] ?? 1.45)), alignSelf: 'center' }} />
          </Pressable>
        )}
      />
    </View>
  );
}

const s = StyleSheet.create({
  toolbar: { flexDirection: 'row', alignItems: 'center', gap: 8, paddingVertical: 8, paddingHorizontal: 4 },
  chip: { borderWidth: 1, borderRadius: 14, paddingHorizontal: 12, height: 30, justifyContent: 'center' },
});
