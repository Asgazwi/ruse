import { StyleSheet, View } from 'react-native';
import { AppText as Text } from './app_text';
import { useTheme } from '../lib/theme';

// Small round number (unread messages, waiting requests). Hidden at 0. Uses the theme's accent.
export function CountDot({ count }: { count: number }) {
  const { theme } = useTheme();
  if (count < 1) return null;
  return (
    <View style={[s.dot, { backgroundColor: theme.colors.primary }]}>
      <Text style={[s.text, { color: theme.colors.primaryFg }]}>{count > 9 ? '9+' : count}</Text>
    </View>
  );
}

const s = StyleSheet.create({
  dot: { minWidth: 18, height: 18, borderRadius: 9, paddingHorizontal: 5, alignItems: 'center', justifyContent: 'center' },
  text: { fontFamily: 'Figtree_700Bold', fontSize: 11 },
});
