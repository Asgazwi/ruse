import { useState } from 'react';
import { ActivityIndicator, Image, Modal, StyleSheet, View } from 'react-native';
import { AppText as Text } from './app_text';
import { BouncyPressable as Pressable } from './bouncy_pressable';
import { GlowButton } from './glow_button';
import { useTheme, main_theme_id_for_gender } from '../lib/theme';
import { useAuth } from '../lib/auth';
import { api } from '../lib/backend';
import { ACTION_SAVE_AVATAR, ACTION_SAVE_PROFILE } from '../lib/actions';
import type { Gender } from '../lib/types';
import { save_local_gender } from '../lib/profile_local';

// First-time profile (D1): gender → optional main theme, optional avatar.
// Shown after username is set. Skip leaves theme for the user to pick.
export function ProfileSetup({ visible }: { visible: boolean }) {
  const { theme, pick } = useTheme();
  const { reload, signOut } = useAuth();
  const c = theme.colors;
  const [gender, setGender] = useState<Gender | null>(null);
  const [avatar_uri, setAvatarUri] = useState<string | null>(null);
  const [avatar_b64, setAvatarB64] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const pick_avatar = async () => {
    setError(null);
    try {
      const ImagePicker = await import('expo-image-picker');
      const perm = await ImagePicker.requestMediaLibraryPermissionsAsync();
      if (!perm.granted) {
        setError('Photo access is needed for an avatar.');
        return;
      }
      const picked = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: ['images'],
        quality: 0.9,
        allowsEditing: true,
        aspect: [1, 1],
      });
      if (picked.canceled || !picked.assets?.length) return;
      let uri = picked.assets[0].uri;
      // Shrink to a small square before upload (needs expo-image-manipulator in the build).
      try {
        // @ts-ignore expo-image-manipulator is an optional package
        const Manipulator = await import('expo-image-manipulator');
        const out = await Manipulator.manipulateAsync(uri, [{ resize: { width: 256, height: 256 } }], {
          compress: 0.7,
          format: Manipulator.SaveFormat.JPEG,
          base64: true,
        });
        uri = out.uri;
        if (out.base64) setAvatarB64(out.base64);
      } catch {
        // Still use the picked URI; upload may fail until manipulator is in the build.
        setAvatarB64(null);
      }
      setAvatarUri(uri);
    } catch (e: any) {
      const msg = String(e?.message || e || '');
      if (/ExpoImagePicker|Native module|Cannot find module/i.test(msg)) {
        setError('Avatar picker needs a new app build (expo-image-picker).');
      } else {
        setError(msg || 'Could not pick a photo.');
      }
    }
  };

  const save = async (g: Gender) => {
    setBusy(true);
    setError(null);
    try {
      try {
        await api(ACTION_SAVE_PROFILE, { gender: g });
      } catch {
        // Backend may not be ready — keep going with local preference.
      }
      save_local_gender(g);
      if (avatar_b64) {
        try {
          await api(ACTION_SAVE_AVATAR, avatar_b64);
        } catch (e: any) {
          if (e?.message && !/unknown|not found|not implemented/i.test(String(e.message))) {
            setError(e.message || 'Avatar could not be uploaded (backend). Gender was saved if the server allowed it.');
          }
        }
      }
      const tid = main_theme_id_for_gender(g);
      if (tid) pick(tid);
      await reload();
    } catch (e: any) {
      setError(e?.message || 'Could not save profile.');
    } finally {
      setBusy(false);
    }
  };

  const chip = (g: Gender, label: string, hint: string) => (
    <Pressable
      key={g}
      onPress={() => setGender(g)}
      disabled={busy}
      style={[
        s.chip,
        {
          borderColor: gender === g ? c.primary : c.line,
          backgroundColor: gender === g ? c.primary : 'transparent',
        },
      ]}>
      <Text style={{ color: gender === g ? c.primaryFg : c.ink, fontFamily: 'Figtree_700Bold', fontSize: 16 }}>{label}</Text>
      <Text style={{ color: gender === g ? c.primaryFg : c.muted, fontFamily: 'Figtree_500Medium', fontSize: 13, marginTop: 4 }}>{hint}</Text>
    </Pressable>
  );

  return (
    <Modal visible={visible} transparent animationType="fade" onRequestClose={() => {}}>
      <View style={s.backdrop}>
        <View style={[s.card, { backgroundColor: c.surface, borderColor: c.line }]}>
          <Text style={[s.title, { color: c.ink }]}>Your profile</Text>
          <Text style={[s.body, { color: c.muted }]}>
            Pick a starting look. The default is Paper, and you can change theme any time in Settings. Avatar is optional.
          </Text>

          <Text style={[s.label, { color: c.ink }]}>I am a…</Text>
          <View style={s.row}>
            {chip('boy', 'Boy', 'Starts you on Obsidian Gold')}
            {chip('girl', 'Girl', 'Starts you on Sugar Bloom')}
          </View>
          {chip('skip', 'Skip', 'I will pick a theme myself')}

          <Text style={[s.label, { color: c.ink, marginTop: 18 }]}>Avatar (optional)</Text>
          <View style={s.avatar_row}>
            {avatar_uri ? (
              <Image source={{ uri: avatar_uri }} style={s.avatar} />
            ) : (
              <View style={[s.avatar, { backgroundColor: c.bg, borderColor: c.line, borderWidth: 1, alignItems: 'center', justifyContent: 'center' }]}>
                <Text style={{ color: c.muted, fontSize: 28 }}>☺</Text>
              </View>
            )}
            <GlowButton label={avatar_uri ? 'Change' : 'Add photo'} on_press={pick_avatar} disabled={busy} outline size="md" color={c.primary} text_color={c.primaryFg} />
          </View>

          {error ? <Text style={s.err}>{error}</Text> : null}

          <GlowButton label="Continue" on_press={() => gender && save(gender)} busy={busy} disabled={!gender} color={c.accent} text_color={c.accentFg} style={s.btn} />
          <Pressable onPress={signOut} hitSlop={12} style={{ marginTop: 14 }}>
            <Text style={{ color: c.primary, fontFamily: 'Figtree_500Medium', textAlign: 'center' }}>Sign out</Text>
          </Pressable>
        </View>
      </View>
    </Modal>
  );
}

const s = StyleSheet.create({
  backdrop: { flex: 1, backgroundColor: 'rgba(0,0,0,0.45)', justifyContent: 'center', padding: 24 },
  card: { borderWidth: 1, borderRadius: 24, padding: 22, maxHeight: '92%' },
  title: { fontFamily: 'Figtree_700Bold', fontSize: 22, marginBottom: 8 },
  body: { fontFamily: 'Figtree_500Medium', fontSize: 15, marginBottom: 14 },
  label: { fontFamily: 'Figtree_700Bold', fontSize: 15, marginBottom: 8 },
  row: { flexDirection: 'row', gap: 10 },
  chip: { flex: 1, borderWidth: 2, borderRadius: 18, paddingVertical: 12, paddingHorizontal: 10, marginBottom: 10 },
  avatar_row: { flexDirection: 'row', alignItems: 'center', gap: 14, marginBottom: 8 },
  avatar: { width: 64, height: 64, borderRadius: 32 },
  small_btn: { height: 40, paddingHorizontal: 16, borderRadius: 20, borderWidth: 2, justifyContent: 'center' },
  err: { color: '#b3261e', fontFamily: 'Figtree_500Medium', marginTop: 8 },
  btn: { marginTop: 16 },
  btn_text: { fontFamily: 'Figtree_700Bold', fontSize: 16 },
});
