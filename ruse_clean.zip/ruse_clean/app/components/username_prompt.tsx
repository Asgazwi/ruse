import { useState } from 'react';
import { ActivityIndicator, Modal, StyleSheet, TextInput, View } from 'react-native';
import { AppText as Text } from './app_text';
import { BouncyPressable as Pressable } from './bouncy_pressable';
import { GlowButton } from './glow_button';
import { useTheme } from '../lib/theme';
import { useAuth } from '../lib/auth';
import { api } from '../lib/backend';
import { ACTION_CHECK_USERNAME, ACTION_SAVE_USERNAME } from '../lib/actions';
import { check_username_local, normalize_username, USERNAME_MAX, USERNAME_MIN } from '../lib/username';

// First-time username pick (D1a). Blocks Home until a username is saved (or user signs out).
export function UsernamePrompt({ visible }: { visible: boolean }) {
  const { theme } = useTheme();
  const { reload, signOut } = useAuth();
  const c = theme.colors;
  const [value, setValue] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const save = async () => {
    const name = normalize_username(value);
    const local = check_username_local(name);
    if (local) { setError(local); return; }
    setBusy(true);
    setError(null);
    try {
      try {
        await api(ACTION_CHECK_USERNAME, name);
      } catch (e: any) {
        // Older backends may not have checkUsername yet — still try save.
        if (e?.kind === 'backend' && /unknown|not found|not implemented/i.test(String(e?.message || ''))) {
          /* fall through to save */
        } else if (e?.message) {
          setError(e.message);
          setBusy(false);
          return;
        }
      }
      await api(ACTION_SAVE_USERNAME, name);
      await reload();
    } catch (e: any) {
      setError(e?.message || 'Could not save the username.');
    } finally {
      setBusy(false);
    }
  };

  return (
    <Modal visible={visible} transparent animationType="fade" onRequestClose={() => {}}>
      <View style={s.backdrop}>
        <View style={[s.card, { backgroundColor: c.surface, borderColor: c.line }]}>
          <Text style={[s.title, { color: c.ink }]}>Choose a username</Text>
          <Text style={[s.body, { color: c.muted }]}>
            Other readers see this name on comments and novels — never your email.
            {USERNAME_MIN}–{USERNAME_MAX} characters: letters, digits, _ or .
          </Text>
          <TextInput
            value={value}
            onChangeText={setValue}
            placeholder="your_name"
            placeholderTextColor={c.muted}
            autoCapitalize="none"
            autoCorrect={false}
            maxLength={USERNAME_MAX}
            editable={!busy}
            style={[s.input, { borderColor: c.line, color: c.ink, backgroundColor: c.bg }]}
          />
          {error ? <Text style={s.err}>{error}</Text> : null}
          <GlowButton label="Save username" on_press={save} busy={busy} color={c.accent} text_color={c.accentFg} style={s.btn} />
          <Pressable onPress={signOut} hitSlop={12} style={{ marginTop: 16 }}>
            <Text style={{ color: c.primary, fontFamily: 'Figtree_500Medium', textAlign: 'center' }}>Sign out</Text>
          </Pressable>
        </View>
      </View>
    </Modal>
  );
}

const s = StyleSheet.create({
  backdrop: { flex: 1, backgroundColor: 'rgba(0,0,0,0.45)', justifyContent: 'center', padding: 24 },
  card: { borderWidth: 1, borderRadius: 24, padding: 22 },
  title: { fontFamily: 'Figtree_700Bold', fontSize: 22, marginBottom: 8 },
  body: { fontFamily: 'Figtree_500Medium', fontSize: 15, marginBottom: 16 },
  input: { height: 48, borderWidth: 1, borderRadius: 24, paddingHorizontal: 18, fontFamily: 'Figtree_500Medium', fontSize: 16 },
  err: { color: '#b3261e', fontFamily: 'Figtree_500Medium', marginTop: 10 },
  btn: { marginTop: 16 },
  btn_text: { fontFamily: 'Figtree_700Bold', fontSize: 16 },
});
