import { useState } from 'react';
import { ActivityIndicator, Alert, Modal, Pressable as RNPressable, ScrollView, StyleSheet, View } from 'react-native';
import { AppText as Text } from './app_text';
import { BouncyPressable as Pressable } from './bouncy_pressable';
import { useTheme, BUILT_IN } from '../lib/theme';
import { useAuth } from '../lib/auth';
import { useData } from '../lib/data';
import { api } from '../lib/backend';
import { ACTION_DELETE_THEME } from '../lib/actions';
import { can_remove_theme } from '../lib/roles';
import { alpha_hex } from '../lib/alpha_hex';
import { soft_shadow } from '../lib/soft_shadow';
import type { Theme } from '../lib/types';

const BUILT_IN_IDS = BUILT_IN.map((t) => t.id);

// Two overlapping color dots (primary + accent) and the theme name.
function Swatch({ t, ring }: { t: Theme; ring: string }) {
  return (
    <View style={s.swatch}>
      <View style={[s.dot, { backgroundColor: t.colors.primary }]} />
      <View style={[s.dot, s.dot_overlap, { backgroundColor: t.colors.accent, borderColor: ring }]} />
    </View>
  );
}

// Theme dropdown (Phase B3 + B4): list with ✓ on the current one; Remove for uploaded themes the role may delete.
export function ThemePicker() {
  const { me } = useAuth();
  const { theme, themes, pick } = useTheme();
  const { refresh } = useData();
  const c = theme.colors;
  const [open, setOpen] = useState(false);
  const [busy_id, setBusyId] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const remove_theme = (t: Theme) => {
    Alert.alert('Remove this theme?', `“${t.name}” will be gone for everyone. This cannot be undone.`, [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Remove',
        style: 'destructive',
        onPress: async () => {
          setBusyId(t.id);
          setError(null);
          try {
            await api(ACTION_DELETE_THEME, t.id);
            // If we were on the removed theme, fall back to the default built-in.
            if (theme.id === t.id) pick(BUILT_IN[0]?.id || 'paper');
            await refresh();
          } catch (e: any) {
            setError(e?.message || 'Could not remove the theme.');
          } finally {
            setBusyId(null);
          }
        },
      },
    ]);
  };

  return (
    <>
      <Pressable
        onPress={() => { setError(null); setOpen(true); }}
        accessibilityRole="button"
        accessibilityLabel={`Theme: ${theme.name}. Tap to change.`}
        style={[s.trigger, soft_shadow(c.primary, 1), { backgroundColor: c.surface, borderColor: c.line }]}>
        <Swatch t={theme} ring={c.surface} />
        <Text style={{ color: c.ink, fontFamily: 'Figtree_700Bold', flex: 1 }} numberOfLines={1}>{theme.name}</Text>
        <Text style={{ color: c.muted, fontSize: 16 }}>▾</Text>
      </Pressable>

      <Modal visible={open} transparent animationType="fade" onRequestClose={() => setOpen(false)}>
        <RNPressable style={s.backdrop} onPress={() => setOpen(false)}>
          {/* The inner Pressable swallows taps so touching the list does not close it. */}
          <RNPressable style={[s.sheet, { backgroundColor: c.surface, borderColor: c.line }]} onPress={() => {}}>
            <Text style={{ color: c.ink, fontFamily: 'Figtree_700Bold', fontSize: 18, marginBottom: 8 }}>Choose a theme</Text>
            {error ? (
              <Text style={{ color: '#b3261e', fontFamily: 'Figtree_500Medium', marginBottom: 6 }}>{error}</Text>
            ) : null}
            <ScrollView style={{ maxHeight: 420 }} showsVerticalScrollIndicator={false}>
              {themes.map((t) => {
                const on = t.id === theme.id;
                const can_remove = can_remove_theme(me, t, BUILT_IN_IDS);
                return (
                  <View
                    key={t.id}
                    style={[s.item, { backgroundColor: on ? alpha_hex(c.primary, 0.09) : 'transparent', borderColor: on ? c.primary : 'transparent' }]}>
                    <Pressable
                      onPress={() => { pick(t.id); setOpen(false); }}
                      style={s.item_main}
                      accessibilityRole="button"
                      accessibilityLabel={t.name}>
                      <Swatch t={t} ring={c.surface} />
                      <Text style={{ color: c.ink, flex: 1, fontFamily: on ? 'Figtree_700Bold' : 'Figtree_500Medium' }} numberOfLines={1}>{t.name}</Text>
                      {on && <Text style={{ color: c.primary, fontFamily: 'Figtree_700Bold' }}>✓</Text>}
                    </Pressable>
                    {can_remove ? (
                      <Pressable
                        onPress={() => remove_theme(t)}
                        disabled={busy_id !== null}
                        hitSlop={8}
                        accessibilityRole="button"
                        accessibilityLabel={`Remove ${t.name}`}
                        style={s.remove_btn}>
                        {busy_id === t.id ? (
                          <ActivityIndicator size="small" color="#b3261e" />
                        ) : (
                          <Text style={{ color: '#b3261e', fontFamily: 'Figtree_700Bold', fontSize: 13 }}>Remove</Text>
                        )}
                      </Pressable>
                    ) : null}
                  </View>
                );
              })}
            </ScrollView>
            <Pressable onPress={() => setOpen(false)} hitSlop={8} style={{ alignSelf: 'center', marginTop: 12, padding: 6 }}>
              <Text style={{ color: c.primary, fontFamily: 'Figtree_700Bold' }}>Close</Text>
            </Pressable>
          </RNPressable>
        </RNPressable>
      </Modal>
    </>
  );
}

const s = StyleSheet.create({
  trigger: { flexDirection: 'row', alignItems: 'center', gap: 12, borderWidth: 1, borderRadius: 22, paddingHorizontal: 16, height: 52 },
  swatch: { flexDirection: 'row', alignItems: 'center' },
  dot: { width: 18, height: 18, borderRadius: 9 },
  dot_overlap: { marginLeft: -7, borderWidth: 2 },
  backdrop: { flex: 1, backgroundColor: 'rgba(0,0,0,0.4)', justifyContent: 'center', padding: 24 },
  sheet: { borderWidth: 1, borderRadius: 26, padding: 18 },
  item: { flexDirection: 'row', alignItems: 'center', borderWidth: 2, borderRadius: 18, paddingHorizontal: 8, paddingVertical: 6, marginTop: 6, gap: 4 },
  item_main: { flex: 1, flexDirection: 'row', alignItems: 'center', gap: 12, paddingHorizontal: 4, paddingVertical: 6 },
  remove_btn: { paddingHorizontal: 10, paddingVertical: 8, minWidth: 64, alignItems: 'center', justifyContent: 'center' },
});
