import { public_name } from '../lib/username';
import { is_admin } from '../lib/roles';
import { useEffect, useMemo, useState } from 'react';
import { Alert, KeyboardAvoidingView, Modal, Platform, ScrollView, StyleSheet, TextInput, View } from 'react-native';
import { AppText as Text } from './app_text';
import { SyncNotice } from './sync_notice';
import { BouncyPressable as Pressable } from './bouncy_pressable';
import { useTheme } from '../lib/theme';
import { useAuth } from '../lib/auth';
import { Avatar } from './avatar';
import { useData } from '../lib/data';
import { usePins } from '../lib/pins';
import { is_network_error } from '../lib/net_retry';
import { fetch_blocked } from '../lib/safety_api';
import { blocked_set, is_blocked } from '../lib/safety';
import { Ionicons } from '@expo/vector-icons';
import {
  block_preview, display_name, has_ref, make_block, MAX_COMMENT_CHARS, same_email, short_date, threads_for_chapter, WHOLE_CHAPTER,
  type Comment,
} from '../lib/pin_helpers';
import { card_person, type CardPerson } from '../lib/profile_card';
import { ProfileCard } from './profile_card';
import { router } from 'expo-router';
import type { Chapter } from '../lib/types';

type Mode =
  | { kind: 'new' }
  | { kind: 'edit'; id: string }
  | { kind: 'reply'; parent: Comment }
  | { kind: 'add'; comment: Comment };

// Comments on a whole chapter. Every comment belongs to the chapter; the writer can OPTIONALLY refer to a part of it
// ("Refer to a part"). A comment that refers to a part shows that passage above it, and tapping it jumps there.
// Everyone who can read the chapter can see the thread and reply (one level deep).
// Delete: own always; chapter uploader on their novel; admin any. "Add to chapter" is uploader-only and
// only for comments that refer to a part. Pins stay private (not here).
export function CommentSheet({ chapter, open, initial_ref, on_close, on_jump }: {
  chapter: Chapter; open: boolean; initial_ref: number | null; on_close: () => void; on_jump?: (block: number) => void;
}) {
  const { theme } = useTheme();
  const { me } = useAuth();
  const me_name = me?.username ?? 'You';
  const my_avatar = me?.avatarUrl ?? '';
  const { refresh } = useData();
  const { comments, add_comment, edit_comment, delete_comment, reply, add_block_after } = usePins();
  const c = theme.colors;

  const [mode, setMode] = useState<Mode>({ kind: 'new' });
  const [text, setText] = useState('');
  const [add_kind, setAddKind] = useState<'p' | 'tip'>('p');
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);
  const [who, setWho] = useState<CardPerson | null>(null); // D2: profile card for a tapped name
  const [ref, setRef] = useState<number | null>(null);        // the part the new comment refers to (null = whole chapter)
  const [picking, setPicking] = useState(false);              // the "which part?" list is showing
  const signed_in = !!me?.allowed;

  // Start fresh each time the sheet opens.
  useEffect(() => { if (open) { setMode({ kind: 'new' }); setText(''); setErr(null); setRef(initial_ref); setPicking(false); } }, [open, initial_ref]);

  // D4: comments from people I blocked are hidden here (roots and replies).
  const [blocked, setBlocked] = useState<Set<string>>(() => new Set());
  useEffect(() => { if (open) fetch_blocked().then((list) => setBlocked(blocked_set(list))).catch(() => {}); }, [open]);
  const threads = useMemo(
    () => (open ? threads_for_chapter(comments, chapter.id) : [])
      .filter((t) => !is_blocked(blocked, t.root.name))
      .map((t) => ({ ...t, replies: t.replies.filter((r) => !is_blocked(blocked, r.name)) })),
    [comments, chapter.id, open, blocked],
  );
  const is_uploader = same_email((chapter as any).uploadedBy, me?.email) || (chapter as any).mine === true || (chapter as any).can_manage === true;
  const am_admin = is_admin(me);
  const blocks = Array.isArray(chapter.blocks) ? chapter.blocks : [];
  const part_of = (b: number) => block_preview(blocks[b]);
  // The parts a writer can refer to: every block that has words.
  const parts = useMemo(() => blocks.map((b, i) => ({ i, text: block_preview(b) })).filter((x) => x.text), [chapter.id, blocks.length]); // eslint-disable-line react-hooks/exhaustive-deps
  // Other readers see username (D1a); never an email. No username yet = "Reader".
  const name = public_name(me);

  const reset = () => { setMode({ kind: 'new' }); setText(''); setErr(null); setRef(null); setPicking(false); };

  const send = async () => {
    const t = text.trim();
    if (!t || busy) return;
    setErr(null);
    if (mode.kind === 'new') add_comment({ chapter_id: chapter.id, subject: chapter.subject, block: ref ?? WHOLE_CHAPTER, text: t, name });
    else if (mode.kind === 'edit') edit_comment(mode.id, t);
    else if (mode.kind === 'reply') reply({ parent: mode.parent, text: t, name, as_uploader: is_uploader });
    else {
      setBusy(true);
      try {
        await add_block_after(mode.comment.id, make_block(add_kind, t));
        await refresh(); // the chapter on screen now has the new block
      } catch (e: any) {
        setErr(is_network_error(e) ? 'You need to be online to add to the chapter.' : e?.message || 'Could not add that.');
        setBusy(false);
        return;
      }
      setBusy(false);
    }
    reset();
  };

  const confirm_delete = (cm: Comment) =>
    Alert.alert(cm.parent ? 'Delete this reply?' : 'Delete this comment?', cm.parent ? undefined : 'Replies to it will be deleted too.', [
      { text: 'Cancel', style: 'cancel' },
      { text: 'Delete', style: 'destructive', onPress: () => delete_comment(cm.id) },
    ]);

  const prompt =
    mode.kind === 'edit' ? 'Edit your comment'
    : mode.kind === 'reply' ? `Reply to ${display_name(mode.parent.name, 'comment')}`
    : mode.kind === 'add' ? 'Add to the chapter, right after this part'
    : 'Comment on this chapter';

  const link = (label: string, on_press: () => void, danger?: boolean) => (
    <Pressable onPress={on_press} hitSlop={8}>
      <Text style={[s.link, { color: danger ? '#b3261e' : c.primary }]}>{label}</Text>
    </Pressable>
  );

  const bubble = (cm: Comment, is_reply: boolean, thread_root: Comment) => {
    // D2: a tapped name opens a small profile card (username + avatar only). Names that are
    // not real usernames yet ("Reader", emails) are not tappable.
    const card = cm.mine ? null : card_person(cm.name, cm.avatarUrl);
    const name_text = <Text style={[s.who, { color: c.ink }]}>{cm.mine ? 'You' : display_name(cm.name, 'Someone')}{cm.byUploader && !cm.mine ? ' · author' : ''}</Text>;
    return (
    <View key={cm.id} style={[s.bubble, is_reply && s.reply, { backgroundColor: is_reply ? c.bg : c.surface, borderColor: c.line }]}>
      <View style={s.who_row}>
        <View style={s.who_left}>
          <Avatar name={cm.mine ? me_name : cm.name} url={cm.mine ? my_avatar : cm.avatarUrl} size={26} />
          {card
            ? <Pressable onPress={() => setWho(card)} hitSlop={6} style={s.who_tap} accessibilityRole="button" accessibilityLabel={`Open profile of ${card.username}`}>{name_text}</Pressable>
            : name_text}
        </View>
        <Text style={[s.when, { color: c.muted }]}>{cm.pending ? '⏳ will send when online' : `${short_date(cm.created)}${cm.edited ? ' · edited' : ''}`}</Text>
      </View>
      {!is_reply && has_ref(cm.block) && !!part_of(cm.block) && (
        <Pressable onPress={() => on_jump?.(cm.block)} disabled={!on_jump} style={[s.quote, { borderLeftColor: c.primary, backgroundColor: c.surface }]} accessibilityRole="button" accessibilityLabel="Go to the part this comment refers to">
          <Text numberOfLines={2} style={{ color: c.muted, fontFamily: 'Figtree_500Medium', fontSize: 13, fontStyle: 'italic' }}>{part_of(cm.block)}</Text>
        </Pressable>
      )}
      <Text style={{ color: c.ink, fontFamily: 'Figtree_500Medium', fontSize: 15 }}>{cm.text}</Text>
      <View style={s.actions}>
        {cm.mine && !cm.parent && link('Edit', () => { setMode({ kind: 'edit', id: cm.id }); setText(cm.text); setErr(null); })}
        {(cm.mine || is_uploader || am_admin) && link('Delete', () => confirm_delete(cm), true)}
        {!is_reply && link('Reply', () => { setMode({ kind: 'reply', parent: thread_root }); setText(''); setErr(null); })}
        {!is_reply && is_uploader && has_ref(cm.block) && link('Add to chapter', () => { setMode({ kind: 'add', comment: cm }); setText(''); setErr(null); })}
      </View>
    </View>
    );
  };

  return (
    <Modal visible={open} transparent animationType="slide" onRequestClose={on_close}>
      <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : undefined} style={s.fill}>
        <Pressable onPress={on_close} style={s.backdrop} />
        <View style={[s.sheet, { backgroundColor: c.bg, borderColor: c.line }]}>
          <View style={s.head}>
            <View style={{ flex: 1 }}>
              <Text style={[s.title, { color: c.ink }]}>Comments</Text>
              <Text numberOfLines={1} style={{ color: c.muted, fontFamily: 'Figtree_500Medium', fontSize: 13 }}>{chapter.title}</Text>
            </View>
            <Pressable onPress={on_close} hitSlop={12}><Text style={[s.link, { color: c.primary, fontSize: 16 }]}>Close</Text></Pressable>
          </View>

          <SyncNotice />

          {picking ? (
            <View>
              <View style={s.prompt_row}>
                <Text style={{ color: c.ink, fontFamily: 'Figtree_700Bold', fontSize: 15 }}>Which part?</Text>
                {link('Back', () => setPicking(false))}
              </View>
              <ScrollView style={{ maxHeight: 360, marginTop: 8 }} keyboardShouldPersistTaps="handled">
                {parts.length === 0 && <Text style={{ color: c.muted, fontFamily: 'Figtree_500Medium', paddingVertical: 12 }}>This chapter has no text to refer to.</Text>}
                {parts.map((p) => (
                  <Pressable key={p.i} onPress={() => { setRef(p.i); setPicking(false); }} style={[s.part, { borderColor: ref === p.i ? c.primary : c.line, backgroundColor: c.surface }]}>
                    <Text style={{ color: c.muted, fontFamily: 'Figtree_700Bold', fontSize: 12 }}>Part {p.i + 1}</Text>
                    <Text numberOfLines={3} style={{ color: c.ink, fontFamily: 'Figtree_500Medium', fontSize: 14, marginTop: 2 }}>{p.text}</Text>
                  </Pressable>
                ))}
              </ScrollView>
            </View>
          ) : (
          <>
          <ScrollView style={{ flexGrow: 0, maxHeight: 320 }} keyboardShouldPersistTaps="handled">
            {threads.length === 0 && <Text style={{ color: c.muted, fontFamily: 'Figtree_500Medium', paddingVertical: 12 }}>No comments on this chapter yet. Start the conversation.</Text>}
            {threads.map((t) => (
              <View key={t.root.id}>
                {bubble(t.root, false, t.root)}
                {t.replies.map((r) => bubble(r, true, t.root))}
              </View>
            ))}
          </ScrollView>

          <View style={s.composer}>
            <View style={s.prompt_row}>
              <Text style={{ color: c.muted, fontFamily: 'Figtree_700Bold', fontSize: 13 }}>{prompt}</Text>
              {mode.kind !== 'new' && link('Cancel', reset)}
            </View>
            {mode.kind === 'new' && parts.length > 0 && (
              <View style={s.ref_row}>
                {ref === null ? (
                  <Pressable onPress={() => setPicking(true)} style={[s.ref_btn, { borderColor: c.line }]} accessibilityRole="button">
                    <Ionicons name="return-down-forward-outline" size={16} color={c.primary} />
                    <Text style={{ color: c.primary, fontFamily: 'Figtree_700Bold', fontSize: 13 }}>Refer to a part (optional)</Text>
                  </Pressable>
                ) : (
                  <View style={[s.ref_chip, { borderColor: c.primary, backgroundColor: c.surface }]}>
                    <Pressable onPress={() => setPicking(true)} style={{ flex: 1 }}>
                      <Text numberOfLines={1} style={{ color: c.ink, fontFamily: 'Figtree_500Medium', fontSize: 13 }}>Part {ref + 1}: {part_of(ref)}</Text>
                    </Pressable>
                    <Pressable onPress={() => setRef(null)} hitSlop={10} accessibilityLabel="Remove reference"><Ionicons name="close" size={18} color={c.muted} /></Pressable>
                  </View>
                )}
              </View>
            )}
            {mode.kind === 'add' && (
              <View style={s.chips}>
                {(['p', 'tip'] as const).map((k) => (
                  <Pressable key={k} onPress={() => setAddKind(k)} style={[s.chip, { borderColor: c.line, backgroundColor: add_kind === k ? c.accent : 'transparent' }]}>
                    <Text style={{ color: add_kind === k ? c.accentFg : c.muted, fontFamily: 'Figtree_500Medium', fontSize: 13 }}>{k === 'p' ? 'Paragraph' : '💡 Tip'}</Text>
                  </Pressable>
                ))}
              </View>
            )}
            <TextInput
              value={text}
              onChangeText={setText}
              multiline
              maxLength={MAX_COMMENT_CHARS}
              placeholder={mode.kind === 'add' ? 'What should the chapter say here?' : 'Write your comment'}
              placeholderTextColor={c.muted}
              style={[s.input, { color: c.ink, borderColor: c.line, backgroundColor: c.surface }]}
            />
            {!!err && <Text style={{ color: '#b3261e', fontFamily: 'Figtree_500Medium', fontSize: 13 }}>{err}</Text>}
            <Pressable onPress={send} disabled={!text.trim() || busy} style={[s.send, { backgroundColor: text.trim() && !busy ? c.primary : c.line }]}>
              <Text style={{ color: text.trim() && !busy ? c.primaryFg : c.muted, fontFamily: 'Figtree_700Bold' }}>
                {busy ? 'Adding…' : mode.kind === 'add' ? 'Add to chapter' : mode.kind === 'edit' ? 'Save' : mode.kind === 'reply' ? 'Reply' : 'Send'}
              </Text>
            </Pressable>
          </View>
          </>
          )}
        </View>
        <ProfileCard
          person={who}
          on_close={() => setWho(null)}
          on_message={(username) => { setWho(null); on_close(); router.push(`/message/${encodeURIComponent(username)}`); }}
          on_blocked={() => setWho(null)}
        />
      </KeyboardAvoidingView>
    </Modal>
  );
}

const s = StyleSheet.create({
  fill: { flex: 1, justifyContent: 'flex-end' },
  backdrop: { position: 'absolute', left: 0, right: 0, top: 0, bottom: 0, backgroundColor: 'rgba(0,0,0,0.35)' },
  sheet: { borderTopLeftRadius: 22, borderTopRightRadius: 22, borderWidth: 1, padding: 18, paddingBottom: 28, maxHeight: '88%' },
  head: { flexDirection: 'row', alignItems: 'flex-start', gap: 12, marginBottom: 10 },
  title: { fontFamily: 'Figtree_700Bold', fontSize: 20 },
  bubble: { borderWidth: 1, borderRadius: 14, padding: 12, marginBottom: 8 },
  reply: { marginLeft: 22 },
  who_row: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', gap: 8, marginBottom: 6 },
  who_left: { flexDirection: 'row', alignItems: 'center', gap: 8, flexShrink: 1 },
  who_tap: { flexShrink: 1 },
  who: { fontFamily: 'Figtree_700Bold', fontSize: 14, flexShrink: 1 },
  when: { fontFamily: 'Figtree_500Medium', fontSize: 12 },
  actions: { flexDirection: 'row', flexWrap: 'wrap', gap: 16, marginTop: 8 },
  link: { fontFamily: 'Figtree_700Bold', fontSize: 13 },
  composer: { gap: 8, marginTop: 8 },
  prompt_row: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  chips: { flexDirection: 'row', gap: 8 },
  quote: { borderLeftWidth: 3, borderRadius: 4, paddingVertical: 6, paddingHorizontal: 10, marginBottom: 8 },
  part: { borderWidth: 1, borderRadius: 14, padding: 12, marginBottom: 8 },
  ref_row: { flexDirection: 'row' },
  ref_btn: { flexDirection: 'row', alignItems: 'center', gap: 6, borderWidth: 1, borderRadius: 16, paddingHorizontal: 12, height: 34 },
  ref_chip: { flex: 1, flexDirection: 'row', alignItems: 'center', gap: 8, borderWidth: 1, borderRadius: 16, paddingHorizontal: 12, height: 34 },
  chip: { borderWidth: 1, borderRadius: 14, paddingHorizontal: 12, height: 30, justifyContent: 'center' },
  input: { borderWidth: 1, borderRadius: 14, paddingHorizontal: 14, paddingTop: 12, paddingBottom: 12, minHeight: 72, maxHeight: 140, fontFamily: 'Figtree_500Medium', fontSize: 15, textAlignVertical: 'top' },
  send: { height: 48, borderRadius: 14, alignItems: 'center', justifyContent: 'center' },
});
