import { useEffect, useRef } from 'react';
import { Animated, Easing, View } from 'react-native';

// Rounded progress bar that glides to its value. Flat: no highlight.
// `value` is 0 to 100. Width cannot use the native driver, which is fine for such a small view.
export function ProgressBar({ value, color, track, height = 10 }: { value: number; color: string; track: string; height?: number }) {
  const safe = Math.max(0, Math.min(100, Number.isFinite(value) ? value : 0));
  const width = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    const run = Animated.timing(width, { toValue: safe, duration: 700, easing: Easing.out(Easing.cubic), useNativeDriver: false });
    run.start();
    return () => run.stop();
  }, [width, safe]);

  return (
    <View style={{ height, borderRadius: height / 2, backgroundColor: track, overflow: 'hidden' }}>
      <Animated.View
        style={{
          height, borderRadius: height / 2, backgroundColor: color, minWidth: safe > 0 ? height : 0,
          width: width.interpolate({ inputRange: [0, 100], outputRange: ['0%', '100%'] }),
        }} />
    </View>
  );
}
