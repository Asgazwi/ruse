import { useEffect, useRef, useState } from 'react';
import { AccessibilityInfo, ActivityIndicator, Animated, Easing, Pressable, StyleSheet, View } from 'react-native';
import { AppText as Text } from './app_text';
import { useTheme } from '../lib/theme';
import { resolve_button, SIZE_HEIGHT, type button_size } from '../lib/button_look';

// The app's one button. Its look comes from the theme's optional "button" block (see lib/button_look.ts):
// a chunky raised edge that sinks when pressed, a squish-and-spring bounce, an optional shine that
// sweeps across, and a few other moods. Themes without a "button" block get the lively default.
// `outline` = quiet version, `soft` = tinted version, `size` = lg (default) | md | sm.
// `danger` keeps the colour you pass (e.g. red) even when the theme sets its own button colours.
// The file name stays GlowButton so every screen keeps working.
export function GlowButton({ label, on_press, color, text_color, outline, soft, disabled, busy, size = 'lg', danger, style }: {
  label: string; on_press?: () => void; color: string; text_color: string;
  outline?: boolean; soft?: boolean; disabled?: boolean; busy?: boolean; size?: button_size; danger?: boolean; style?: any;
}) {
  const { theme } = useTheme();
  const r = resolve_button(theme.button, color, text_color, theme.radius, { outline, soft, size, keep_color: danger });
  const h = SIZE_HEIGHT[size];

  const squish = useRef(new Animated.Value(1)).current;  // scale
  const sink = useRef(new Animated.Value(0)).current;    // 0 = resting, 1 = pushed into its edge
  const turn = useRef(new Animated.Value(0)).current;    // wiggle
  const sweep = useRef(new Animated.Value(0)).current;   // shine band, 0 to 1 across the button
  const breathe = useRef(new Animated.Value(0)).current; // idle pulse
  const [width, set_width] = useState(0);
  const [calm, set_calm] = useState(false);              // phone asks for less motion

  useEffect(() => { AccessibilityInfo.isReduceMotionEnabled().then(set_calm).catch(() => {}); }, []);

  const live = !disabled && !busy;
  const motion = r.press !== 'none' && !calm;

  // 'pulse' = a slow breathing glow while the button waits to be pressed.
  useEffect(() => {
    if (r.press !== 'pulse' || calm || !live) { breathe.setValue(0); return; }
    const loop = Animated.loop(Animated.sequence([
      Animated.timing(breathe, { toValue: 1, duration: 1100, easing: Easing.inOut(Easing.sin), useNativeDriver: true }),
      Animated.timing(breathe, { toValue: 0, duration: 1100, easing: Easing.inOut(Easing.sin), useNativeDriver: true }),
    ]));
    loop.start();
    return () => loop.stop();
  }, [r.press, calm, live, breathe]);

  const down = () => {
    if (r.depth > 0) Animated.timing(sink, { toValue: 1, duration: 70, useNativeDriver: true }).start();
    if (motion && r.press !== 'sink') Animated.spring(squish, { toValue: 0.94, speed: 50, bounciness: 0, useNativeDriver: true }).start();
  };
  const up = () => {
    if (r.depth > 0) Animated.spring(sink, { toValue: 0, speed: 18, bounciness: 12, useNativeDriver: true }).start();
    if (motion && r.press !== 'sink') Animated.spring(squish, { toValue: 1, speed: 14, bounciness: 20, useNativeDriver: true }).start();
  };
  const press = () => {
    if (motion && r.press === 'wiggle') {
      turn.setValue(0);
      Animated.sequence([-1, 1, -0.6, 0.6, 0].map((v) => Animated.timing(turn, { toValue: v, duration: 60, easing: Easing.inOut(Easing.quad), useNativeDriver: true }))).start();
    }
    if (r.shine && motion) {
      sweep.setValue(0);
      Animated.timing(sweep, { toValue: 1, duration: 520, easing: Easing.out(Easing.cubic), useNativeDriver: true }).start();
    }
    on_press?.();
  };

  const face_h = h - r.depth;
  const label_text = r.uppercase ? label.toUpperCase() : label;
  const scale = r.press === 'pulse' ? Animated.multiply(squish, breathe.interpolate({ inputRange: [0, 1], outputRange: [1, 1.035] })) : squish;

  return (
    <Pressable
      onPress={press}
      onPressIn={down}
      onPressOut={up}
      disabled={!live}
      accessibilityRole="button"
      accessibilityLabel={label}
      accessibilityState={{ disabled: !!disabled, busy: !!busy }}
      style={style}>
      <Animated.View
        style={[
          { height: h, borderRadius: r.radius, backgroundColor: r.edge ?? 'transparent' },
          disabled && { opacity: 0.45 },
          busy && { opacity: 0.8 },
          { transform: [{ scale }, { rotate: turn.interpolate({ inputRange: [-1, 1], outputRange: ['-3deg', '3deg'] }) }] },
        ]}>
        <Animated.View
          onLayout={(e) => set_width(e.nativeEvent.layout.width)}
          style={[
            s.face,
            {
              height: face_h, borderRadius: r.radius, backgroundColor: r.fill,
              borderWidth: r.border ? 1.5 : 0, borderColor: r.border ?? 'transparent',
              transform: [{ translateY: sink.interpolate({ inputRange: [0, 1], outputRange: [0, r.depth] }) }],
            },
          ]}>
          {r.shine ? (
            <>
              {/* a soft highlight along the top edge */}
              <View pointerEvents="none" style={[s.gloss, { borderRadius: r.radius }]} />
              {/* a bright band that sweeps across when pressed */}
              <Animated.View
                pointerEvents="none"
                style={[s.band, { transform: [{ translateX: sweep.interpolate({ inputRange: [0, 1], outputRange: [-60, width + 20] }) }, { rotate: '20deg' }] }]}
              />
            </>
          ) : null}
          {busy
            ? <ActivityIndicator size="small" color={r.fg} />
            : <Text numberOfLines={1} style={[s.label, size === 'sm' && s.label_sm, { color: r.fg }, r.uppercase && s.caps]}>{label_text}</Text>}
        </Animated.View>
      </Animated.View>
    </Pressable>
  );
}

const s = StyleSheet.create({
  face: { alignItems: 'center', justifyContent: 'center', paddingHorizontal: 22, overflow: 'hidden' },
  label: { fontFamily: 'Figtree_700Bold', fontSize: 15.5 },
  label_sm: { fontSize: 13.5 },
  caps: { letterSpacing: 0.8, fontSize: 13.5 },
  gloss: { position: 'absolute', top: 0, left: 0, right: 0, height: '48%', backgroundColor: 'rgba(255,255,255,0.14)' },
  band: { position: 'absolute', top: -20, bottom: -20, width: 26, backgroundColor: 'rgba(255,255,255,0.35)' },
});
