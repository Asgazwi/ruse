import { Modal, Pressable as RNPressable, StyleSheet, View } from 'react-native';
import { AppText as Text } from './app_text';
import { BouncyPressable as Pressable } from './bouncy_pressable';
import { GlowButton } from './glow_button';
import { useTheme } from '../lib/theme';
import { soft_shadow } from '../lib/soft_shadow';

// Small closing message when the reader presses Back inside a chapter (Phase C1).
// Not finished: Pin my place / Mark complete / Leave. Finished: Leave / Stay.
export function LeavePopup({ visible, done, pinned, on_pin, on_complete, on_leave, on_stay }: {
  visible: boolean; done: boolean; pinned: boolean;
  on_pin: () => void; on_complete: () => void; on_leave: () => void; on_stay: () => void;
}) {
  const { theme } = useTheme();
  const c = theme.colors;

  const btn = (label: string, on_press: () => void, filled: boolean) => (
    <GlowButton label={label} on_press={on_press} outline={!filled} color={filled ? c.accent : c.primary} text_color={c.accentFg} size="md" />
  );

  return (
    <Modal visible={visible} transparent animationType="fade" onRequestClose={on_stay}>
      <RNPressable style={s.backdrop} onPress={on_stay}>
        <RNPressable style={[s.card, soft_shadow(c.primary, 2), { backgroundColor: c.surface, borderColor: c.line }]} onPress={() => {}}>
          <Text style={{ fontSize: 34, textAlign: 'center' }}>{done ? '👋' : '📖'}</Text>
          <Text style={[s.title, { color: c.ink }]}>{done ? 'See you next time!' : 'Nice reading!'}</Text>
          <Text style={[s.body, { color: c.muted }]}>
            {done
              ? 'This chapter is complete. Leave now, or keep reading.'
              : 'Pin your place so you can continue from here, mark the chapter complete, or just leave.'}
          </Text>
          <View style={{ gap: 10, marginTop: 14 }}>
            {!done && btn(pinned ? '📌 Move my pin here' : '📌 Pin my place', on_pin, true)}
            {!done && btn('🎉 Mark complete', on_complete, false)}
            {btn('Leave', on_leave, done)}
            <Pressable onPress={on_stay} hitSlop={8} style={{ alignSelf: 'center', padding: 6 }}>
              <Text style={{ color: c.muted, fontFamily: 'Figtree_700Bold' }}>Stay and keep reading</Text>
            </Pressable>
          </View>
        </RNPressable>
      </RNPressable>
    </Modal>
  );
}

const s = StyleSheet.create({
  backdrop: { flex: 1, backgroundColor: 'rgba(0,0,0,0.4)', justifyContent: 'center', padding: 24 },
  card: { borderWidth: 1, borderRadius: 28, padding: 22 },
  title: { fontFamily: 'Figtree_700Bold', fontSize: 22, textAlign: 'center', marginTop: 6 },
  body: { fontFamily: 'Figtree_500Medium', fontSize: 15, lineHeight: 22, textAlign: 'center', marginTop: 6 },
  btn: { height: 48, borderRadius: 24, justifyContent: 'center', alignItems: 'center' },
});
