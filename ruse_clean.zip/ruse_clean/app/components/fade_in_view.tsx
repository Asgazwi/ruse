import { useEffect, useRef } from 'react';
import { Animated, Easing } from 'react-native';
import { useEffects } from '../lib/effects';

// Fades and floats its children up a little when they first appear.
// `index` staggers a list so cards arrive one after another (capped, so long lists do not drag).
// Stays still when "Sparkles when I tap" is off, because that switch doubles as the reduce-motion switch.
export function FadeInView({ index = 0, children, style }: { index?: number; children: React.ReactNode; style?: any }) {
  const { effects_on } = useEffects();
  const t = useRef(new Animated.Value(effects_on ? 0 : 1)).current;

  useEffect(() => {
    if (!effects_on) { t.setValue(1); return; }
    const run = Animated.timing(t, {
      toValue: 1, duration: 420, delay: Math.min(index, 8) * 70, easing: Easing.out(Easing.cubic), useNativeDriver: true,
    });
    run.start();
    return () => run.stop();
  }, [t, index, effects_on]);

  return (
    <Animated.View style={[style, { opacity: t, transform: [{ translateY: t.interpolate({ inputRange: [0, 1], outputRange: [14, 0] }) }] }]}>
      {children}
    </Animated.View>
  );
}
