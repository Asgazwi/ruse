import { Image, StyleSheet, View } from 'react-native';
import { AppText as Text } from './app_text';
import { avatar_color, avatar_initial } from '../lib/avatar_helpers';

// A round picture of a person: their photo, or a coloured circle with their first letter.
export function Avatar({ name, url, size = 40 }: { name?: string | null; url?: string | null; size?: number }) {
  const round = { width: size, height: size, borderRadius: size / 2 };
  if (url) {
    return <Image source={{ uri: url }} style={[round, { backgroundColor: avatar_color(name) }]} accessibilityLabel={name ? `${name}'s picture` : 'Picture'} />;
  }
  return (
    <View style={[s.fallback, round, { backgroundColor: avatar_color(name) }]} accessibilityLabel={name ? `${name}'s picture` : 'Picture'}>
      <Text style={{ color: '#ffffff', fontFamily: 'Figtree_700Bold', fontSize: Math.round(size * 0.44) }}>{avatar_initial(name)}</Text>
    </View>
  );
}

const s = StyleSheet.create({
  fallback: { alignItems: 'center', justifyContent: 'center' },
});
