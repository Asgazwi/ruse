import { StyleSheet, View } from 'react-native';
import { AppText as Text } from './app_text';
import { useTheme } from '../lib/theme';
import { alpha_hex } from '../lib/alpha_hex';
import { soft_shadow } from '../lib/soft_shadow';

// A friendly card for "nothing here yet" and "could not find that" moments.
// `children` is an optional slot under the text (for example a button).
export function EmptyState({ emoji, title, body, children }: { emoji: string; title: string; body?: string; children?: React.ReactNode }) {
  const { theme } = useTheme();
  const c = theme.colors;
  return (
    <View style={[s.card, soft_shadow(c.primary, 1), { backgroundColor: c.surface, borderColor: c.line }]}>
      <View style={[s.badge, { backgroundColor: alpha_hex(c.accent, 0.14), borderColor: alpha_hex(c.accent, 0.3) }]}>
        <Text style={s.emoji}>{emoji}</Text>
      </View>
      <Text style={[s.title, { color: c.ink }]}>{title}</Text>
      {!!body && <Text style={[s.body, { color: c.muted }]}>{body}</Text>}
      {children}
    </View>
  );
}

const s = StyleSheet.create({
  card: { borderWidth: 1, borderRadius: 26, padding: 24, alignItems: 'center', marginBottom: 14 },
  badge: { width: 72, height: 72, borderRadius: 36, borderWidth: 2, alignItems: 'center', justifyContent: 'center', marginBottom: 14 },
  emoji: { fontSize: 32 },
  title: { fontFamily: 'Figtree_700Bold', fontSize: 20, textAlign: 'center' },
  body: { fontFamily: 'Figtree_500Medium', fontSize: 15, lineHeight: 22, textAlign: 'center', marginTop: 6 },
});
