import { StyleSheet, View } from 'react-native';
import { AppText as Text } from './app_text';
import { BouncyPressable as Pressable } from './bouncy_pressable';
import { Cover } from './cover';
import { ProgressBar } from './progress_bar';
import { useTheme } from '../lib/theme';

// A horizontal card for one novel on Home: drawn cover on the left, words on the right.
// With `progress` (0 to 100) it shows a thin bar and a Resume button (the "carry on" card).
// `background` is accepted so old callers still compile; the reader uses it, Home does not.
export function NovelCard({ title, sub, badge, on_press, progress, action_label, meta }: {
  title: string; sub?: string; background?: string | null; badge?: string; on_press: () => void;
  progress?: number; action_label?: string; meta?: string; height?: number;
}) {
  const { theme } = useTheme();
  const c = theme.colors;
  return (
    <Pressable onPress={on_press} accessibilityRole="button" accessibilityLabel={title}
      style={[s.card, { backgroundColor: c.surface, borderColor: c.line, borderRadius: theme.radius ?? 16 }]}>
      <Cover title={title} width={68} height={98} font_size={12} />
      <View style={s.body}>
        {!!badge && <Text style={{ color: c.primary, fontFamily: 'Figtree_700Bold', fontSize: 11, letterSpacing: 0.8 }}>{badge.toUpperCase()}</Text>}
        <Text style={{ color: c.ink, fontFamily: 'Figtree_700Bold', fontSize: 18, lineHeight: 22, marginTop: 2 }} numberOfLines={2}>{title}</Text>
        {!!sub && <Text style={{ color: c.muted, fontFamily: 'Figtree_500Medium', fontSize: 13, marginTop: 2 }} numberOfLines={2}>{sub}</Text>}
        {typeof progress === 'number' && (
          <View style={{ marginTop: 'auto', paddingTop: 10 }}>
            <ProgressBar value={progress} color={c.primary} track={c.line} height={4} />
            <View style={s.foot}>
              <Text style={{ color: c.muted, fontFamily: 'Figtree_500Medium', fontSize: 12 }}>{meta ?? `${progress}%`}</Text>
              {!!action_label && (
                <View style={[s.action, { backgroundColor: c.primary }]}>
                  <Text style={{ color: c.primaryFg, fontFamily: 'Figtree_700Bold', fontSize: 13 }}>{action_label}</Text>
                </View>
              )}
            </View>
          </View>
        )}
      </View>
    </Pressable>
  );
}

const s = StyleSheet.create({
  card: { flexDirection: 'row', gap: 14, borderWidth: 1, padding: 12, marginBottom: 12 },
  body: { flex: 1, minWidth: 0 },
  foot: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginTop: 8 },
  action: { borderRadius: 14, paddingHorizontal: 14, paddingVertical: 6 },
});
