import { StyleSheet, View } from 'react-native';
import { router } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { AppText as Text } from './app_text';
import { BouncyPressable as Pressable } from './bouncy_pressable';
import { FadeInView } from './fade_in_view';
import { useTheme } from '../lib/theme';
import { mix_hex } from '../lib/look';
import { courses_label, encode_path, type CategoryNode } from '../lib/category_helpers';

// A folder row: tap to see what is inside the category. `color` is accepted so old callers still compile.
// `index` only staggers the entrance animation.
export function CategoryCard({ node, index = 0 }: { node: CategoryNode; color?: string; index?: number }) {
  const { theme } = useTheme();
  const c = theme.colors;
  return (
    <FadeInView index={index}>
      <Pressable
        onPress={() => router.push(`/category?path=${encode_path(node.path)}`)}
        accessibilityRole="button"
        accessibilityLabel={`${node.name}. ${courses_label(node.courses)}`}
        style={[s.card, { backgroundColor: c.surface, borderColor: c.line, borderRadius: theme.radius ?? 16 }]}>
        <View style={[s.icon, { backgroundColor: mix_hex(c.surface, c.primary, 0.12) }]}>
          <Ionicons name="folder-outline" size={22} color={c.primary} />
        </View>
        <View style={{ flex: 1 }}>
          <Text style={[s.title, { color: c.ink }]} numberOfLines={2}>{node.name}</Text>
          <Text style={[s.count, { color: c.muted }]}>{courses_label(node.courses)}</Text>
        </View>
        <Ionicons name="chevron-forward" size={20} color={c.muted} />
      </Pressable>
    </FadeInView>
  );
}

const s = StyleSheet.create({
  card: { flexDirection: 'row', alignItems: 'center', gap: 14, borderWidth: 1, padding: 14, marginBottom: 12 },
  icon: { width: 44, height: 44, borderRadius: 12, alignItems: 'center', justifyContent: 'center' },
  title: { fontFamily: 'Figtree_700Bold', fontSize: 17, lineHeight: 22 },
  count: { fontFamily: 'Figtree_500Medium', fontSize: 13.5, marginTop: 1 },
});
