import { useCallback, useEffect, useRef, useState } from 'react';
import { ActivityIndicator, Alert, AppState, KeyboardAvoidingView, Platform, Pressable as PressRN, ScrollView, StyleSheet, TextInput, View } from 'react-native';
import { useLocalSearchParams } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { AppText as Text } from '../../components/app_text';
import { BouncyPressable as Pressable } from '../../components/bouncy_pressable';
import { BackHeader } from '../../components/back_header';
import { useTheme } from '../../lib/theme';
import { useAuth } from '../../lib/auth';
import { is_network_error } from '../../lib/net_retry';
import { delete_message, fetch_conversation, mark_read, send_message } from '../../lib/messages_api';
import { block_user, fetch_blocked, unblock_user } from '../../lib/safety_api';
import { blocked_set, is_blocked } from '../../lib/safety';
import { ProfileCard } from '../../components/profile_card';
import { card_person, type CardPerson } from '../../lib/profile_card';
import { clean_message, day_label, MESSAGE_MAX_CHARS, same_user, starts_new_day, thread_with, message_time, type Message } from '../../lib/messages';
import { Avatar } from '../../components/avatar';

// One conversation (D3). Plain text, oldest at the top, the other person's picture beside their messages,
// a heading for each day. Hold one of YOUR messages to delete it. The chat refreshes itself every few seconds
// while it is open. Sending needs a connection: a message is never queued on the phone without anyone noticing.
const REFRESH_MS = 8000;

export default function Conversation() {
  const { name } = useLocalSearchParams<{ name: string }>();
  const other = decodeURIComponent(name ?? '');
  const { theme } = useTheme();
  const { me } = useAuth();
  const insets = useSafeAreaInsets();
  const c = theme.colors;
  const my_name = me?.username ?? null;

  const [all, setAll] = useState<Message[] | null>(null);
  const [text, setText] = useState('');
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);
  const [blocked, setBlocked] = useState(false);       // D4: I blocked this person
  const [who, setWho] = useState<CardPerson | null>(null); // tapping the name opens the profile card (block/report)
  const scroll_ref = useRef<ScrollView>(null);

  const load = useCallback(async () => {
    try {
      const [list, blocked_list] = await Promise.all([fetch_conversation(other), fetch_blocked().catch(() => [] as string[])]);
      setAll(list);
      setBlocked(is_blocked(blocked_set(blocked_list), other));
      setErr(null);
      if (list.some((m) => same_user(m.to, my_name) && !m.read)) mark_read(other).catch(() => {});
    } catch (e: any) {
      setErr(is_network_error(e) ? 'You need to be online to see this conversation.' : e?.message || 'Could not load messages.');
    }
  }, [other, my_name]);

  useEffect(() => { load(); }, [load]);

  // Quietly fetch new messages while this screen is open and the app is in front. Errors are ignored here:
  // the next tick simply tries again, and the screen never flashes a red message for a missed refresh.
  useEffect(() => {
    const tick = async () => {
      if (AppState.currentState !== 'active') return;
      try {
        const list = await fetch_conversation(other);
        setAll(list);
        if (list.some((m) => same_user(m.to, my_name) && !m.read)) mark_read(other).catch(() => {});
      } catch { /* try again next time */ }
    };
    const timer = setInterval(tick, REFRESH_MS);
    return () => clearInterval(timer);
  }, [other, my_name]);

  const ask_delete = (m: Message) => {
    Alert.alert('Delete this message?', 'It disappears for both of you.', [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Delete',
        style: 'destructive',
        onPress: async () => {
          setAll((prev) => (prev ?? []).filter((x) => x.id !== m.id)); // gone at once; put back if the server says no
          try { await delete_message(m.id); }
          catch (e: any) {
            setErr(is_network_error(e) ? 'Not deleted. You need to be online.' : e?.message || 'Could not delete that.');
            load();
          }
        },
      },
    ]);
  };

  const send = async () => {
    const checked = clean_message(text);
    if (!checked.ok) { setErr(checked.reason); return; }
    setBusy(true);
    setErr(null);
    try {
      const saved = await send_message(other, checked.text);
      setAll((prev) => [...(prev ?? []), saved]);
      setText('');
    } catch (e: any) {
      setErr(is_network_error(e) ? 'Not sent. You need to be online to send a message. Your text is still here.' : e?.message || 'Could not send that.');
    } finally {
      setBusy(false);
    }
  };

  const unblock = async () => {
    setBusy(true);
    try { await unblock_user(other); setBlocked(false); setErr(null); }
    catch (e: any) { setErr(is_network_error(e) ? 'You need to be online to unblock.' : e?.message || 'Could not unblock.'); }
    finally { setBusy(false); }
  };

  const shown = all ? thread_with(all, my_name, other) : [];
  const other_avatar = (all ?? []).map((m) => (same_user(m.from, other) ? m.fromAvatar : m.toAvatar)).find(Boolean) || '';
  const checked = clean_message(text);

  return (
    <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : undefined} style={{ flex: 1, backgroundColor: c.bg }}>
      <BackHeader top_padding={insets.top + 16} back_label="Messages" title={other || 'Message'} on_title={() => setWho(card_person(other))} />
      <ScrollView
        ref={scroll_ref}
        style={{ flex: 1 }}
        contentContainerStyle={{ padding: 16, paddingBottom: 8 }}
        keyboardShouldPersistTaps="handled"
        onContentSizeChange={() => scroll_ref.current?.scrollToEnd({ animated: false })}
      >
        {!!err && !busy && <Text style={{ color: '#b3261e', fontFamily: 'Figtree_500Medium', marginBottom: 8 }}>{err}</Text>}
        {all === null && !err && <ActivityIndicator color={c.primary} style={{ marginTop: 24 }} />}
        {all !== null && shown.length === 0 && (
          <View style={s.empty}>
            <Avatar name={other} url={other_avatar} size={72} />
            <Text style={{ color: c.ink, fontFamily: 'Figtree_700Bold', fontSize: 18, marginTop: 12 }}>{other}</Text>
            <Text style={{ color: c.muted, fontFamily: 'Figtree_500Medium', marginTop: 4 }}>No messages yet. Say hello.</Text>
          </View>
        )}
        {shown.map((m, i) => {
          const mine = same_user(m.from, my_name);
          const prev = shown[i - 1];
          const next = shown[i + 1];
          const new_day = starts_new_day(m.created, prev?.created);
          const last_in_group = !next || starts_new_day(next.created, m.created) || !same_user(next.from, m.from);
          const first_in_group = !prev || new_day || !same_user(prev.from, m.from);
          return (
            <View key={m.id}>
              {new_day ? (
                <View style={[s.day, { backgroundColor: c.surface, borderColor: c.line }]}>
                  <Text style={{ color: c.muted, fontFamily: 'Figtree_700Bold', fontSize: 12 }}>{day_label(m.created)}</Text>
                </View>
              ) : null}
              <View style={[s.bubble_row, { justifyContent: mine ? 'flex-end' : 'flex-start', marginTop: first_in_group ? 8 : 3 }]}>
                {!mine ? (
                  <View style={s.avatar_slot}>
                    {last_in_group ? <Avatar name={other} url={m.fromAvatar || other_avatar} size={30} /> : null}
                  </View>
                ) : null}
                <PressRN
                  onLongPress={mine ? () => ask_delete(m) : undefined}
                  delayLongPress={350}
                  accessibilityRole="text"
                  accessibilityHint={mine ? 'Press and hold to delete this message' : undefined}
                  style={[
                    s.bubble,
                    { backgroundColor: mine ? c.primary : c.surface, borderColor: mine ? c.primary : c.line },
                    mine ? { borderBottomRightRadius: last_in_group ? 4 : 18 } : { borderBottomLeftRadius: last_in_group ? 4 : 18 },
                  ]}
                >
                  <Text style={{ color: mine ? c.primaryFg : c.ink, fontFamily: 'Figtree_500Medium', fontSize: 15 }}>{m.text}</Text>
                  {last_in_group ? (
                    <Text style={{ color: mine ? c.primaryFg : c.muted, fontFamily: 'Figtree_500Medium', fontSize: 11, marginTop: 3, opacity: 0.75, alignSelf: 'flex-end' }}>{message_time(m.created)}</Text>
                  ) : null}
                </PressRN>
              </View>
            </View>
          );
        })}
        {shown.some((m) => same_user(m.from, my_name)) ? (
          <Text style={{ color: c.muted, fontFamily: 'Figtree_500Medium', fontSize: 12, textAlign: 'center', marginTop: 16 }}>
            Press and hold one of your messages to delete it.
          </Text>
        ) : null}
      </ScrollView>

      {blocked ? (
        <View style={[s.composer, { paddingBottom: insets.bottom + 12, borderColor: c.line, backgroundColor: c.surface }]}>
          <Text style={{ color: c.muted, fontFamily: 'Figtree_500Medium' }}>You blocked {other}. They cannot message you, and you will not see their messages.</Text>
          <Pressable onPress={unblock} disabled={busy} style={[s.send, { backgroundColor: c.primary, alignSelf: 'flex-start', paddingHorizontal: 22 }]}>
            <Text style={{ color: c.primaryFg, fontFamily: 'Figtree_700Bold' }}>Unblock</Text>
          </Pressable>
        </View>
      ) : (
      <View style={[s.composer, { paddingBottom: insets.bottom + 10, borderColor: c.line, backgroundColor: c.surface }]}>
        <TextInput
          value={text}
          onChangeText={setText}
          multiline
          maxLength={MESSAGE_MAX_CHARS}
          placeholder="Write a message…"
          placeholderTextColor={c.muted}
          style={[s.input, { color: c.ink, borderColor: c.line, backgroundColor: c.bg }]}
        />
        <Pressable
          onPress={send}
          disabled={!checked.ok || busy}
          accessibilityRole="button"
          accessibilityLabel="Send message"
          style={[s.send, { backgroundColor: checked.ok && !busy ? c.primary : c.line }]}
        >
          {busy
            ? <ActivityIndicator color={c.primaryFg} />
            : <Ionicons name="arrow-up" size={20} color={checked.ok ? c.primaryFg : c.muted} />}
        </Pressable>
        {text.length > MESSAGE_MAX_CHARS - 100 ? (
          <Text style={[s.counter, { color: c.muted }]}>{text.length}/{MESSAGE_MAX_CHARS}</Text>
        ) : null}
      </View>
      )}

      <ProfileCard
        person={who}
        on_close={() => setWho(null)}
        on_message={() => setWho(null)}
        on_blocked={() => { setBlocked(true); setWho(null); }}
      />
    </KeyboardAvoidingView>
  );
}

const s = StyleSheet.create({
  empty: { alignItems: 'center', paddingVertical: 48 },
  day: { alignSelf: 'center', borderWidth: 1, borderRadius: 12, paddingHorizontal: 12, paddingVertical: 4, marginTop: 14, marginBottom: 6 },
  bubble_row: { flexDirection: 'row', alignItems: 'flex-end' },
  avatar_slot: { width: 36, alignItems: 'flex-start' },
  bubble: { maxWidth: '78%', borderWidth: 1, borderRadius: 20, paddingHorizontal: 14, paddingVertical: 9 },
  composer: { flexDirection: 'row', alignItems: 'flex-end', flexWrap: 'wrap', gap: 10, borderTopWidth: 1, paddingHorizontal: 12, paddingTop: 10 },
  input: { flex: 1, borderWidth: 1, borderRadius: 18, paddingHorizontal: 16, paddingTop: 11, paddingBottom: 11, maxHeight: 120, fontFamily: 'Figtree_500Medium', fontSize: 15, textAlignVertical: 'top' },
  send: { width: 46, height: 46, borderRadius: 23, alignItems: 'center', justifyContent: 'center' },
  counter: { width: '100%', textAlign: 'right', fontFamily: 'Figtree_500Medium', fontSize: 12, paddingRight: 6 },
});
