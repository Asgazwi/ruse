import { useCallback, useState } from 'react';
import { ActivityIndicator, RefreshControl, ScrollView, StyleSheet, View } from 'react-native';
import { router, useFocusEffect } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { AppText as Text } from '../components/app_text';
import { BouncyPressable as Pressable } from '../components/bouncy_pressable';
import { BackHeader } from '../components/back_header';
import { CountDot } from '../components/count_dot';
import { Avatar } from '../components/avatar';
import { EmptyState } from '../components/empty_state';
import { useTheme } from '../lib/theme';
import { useAuth } from '../lib/auth';
import { is_network_error } from '../lib/net_retry';
import { fetch_all_messages } from '../lib/messages_api';
import { fetch_blocked } from '../lib/safety_api';
import { blocked_set, is_blocked } from '../lib/safety';
import { same_user, summarize_threads, message_time, type Thread } from '../lib/messages';
import { public_name } from '../lib/username';
import { NAV_CLEARANCE } from '../lib/nav_clearance';

// Direct messages (D3): one row per person, newest first. Tap a row to open the conversation.
export default function Messages() {
  const { theme } = useTheme();
  const { me } = useAuth();
  const insets = useSafeAreaInsets();
  const c = theme.colors;
  const [threads, setThreads] = useState<Thread[] | null>(null);
  const [err, setErr] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const my_name = me?.username ?? null;

  const load = useCallback(async () => {
    setBusy(true);
    try {
      const [all, blocked] = await Promise.all([fetch_all_messages(), fetch_blocked().catch(() => [] as string[])]);
      const hidden = blocked_set(blocked); // D4: people I blocked do not show in my inbox
      setThreads(summarize_threads(all, my_name).filter((t) => !is_blocked(hidden, t.with)));
      setErr(null);
    } catch (e: any) {
      setErr(is_network_error(e) ? 'You need to be online to see your messages.' : e?.message || 'Could not load messages.');
    } finally {
      setBusy(false);
    }
  }, [my_name]);

  useFocusEffect(useCallback(() => { load(); }, [load]));

  return (
    <View style={{ flex: 1, backgroundColor: c.bg }}>
      <ScrollView
        contentContainerStyle={{ paddingBottom: insets.bottom + NAV_CLEARANCE }}
        refreshControl={<RefreshControl refreshing={busy} onRefresh={load} tintColor={c.primary} />}
      >
        <BackHeader top_padding={insets.top + 16} back_label="Home" title="Messages" sub={my_name ? `You are ${public_name(me)}` : undefined} />
        <View style={{ padding: 20 }}>
          {!!err && <Text style={{ color: '#b3261e', fontFamily: 'Figtree_500Medium', marginBottom: 12 }}>{err}</Text>}
          {threads === null && !err && <ActivityIndicator color={c.primary} style={{ marginTop: 24 }} />}
          {threads !== null && threads.length === 0 && (
            <EmptyState emoji="✉️" title="No messages yet" body="Tap a username on a comment to send someone a message." />
          )}
          {(threads ?? []).map((t) => {
            const mine_last = same_user(t.last.from, my_name);
            return (
              <Pressable
                key={t.with}
                onPress={() => router.push(`/message/${encodeURIComponent(t.with)}`)}
                style={[s.row, { backgroundColor: c.surface, borderColor: t.unread ? c.primary : c.line, borderRadius: theme.radius ?? 16 }]}
                accessibilityRole="button"
                accessibilityLabel={`Conversation with ${t.with}${t.unread ? `, ${t.unread} unread` : ''}`}
              >
                <Avatar name={t.with} url={t.avatarUrl} size={50} />
                <View style={{ flex: 1, gap: 2 }}>
                  <View style={s.top_row}>
                    <Text style={[s.name, { color: c.ink }]} numberOfLines={1}>{t.with}</Text>
                    <Text style={{ color: c.muted, fontFamily: 'Figtree_500Medium', fontSize: 12 }}>{message_time(t.last.created)}</Text>
                  </View>
                  <Text style={{ color: t.unread ? c.ink : c.muted, fontFamily: t.unread ? 'Figtree_700Bold' : 'Figtree_500Medium', fontSize: 14 }} numberOfLines={1}>
                    {mine_last ? 'You: ' : ''}{t.last.text}
                  </Text>
                </View>
                <CountDot count={t.unread} />
              </Pressable>
            );
          })}
        </View>
      </ScrollView>
    </View>
  );
}

const s = StyleSheet.create({
  row: { flexDirection: 'row', alignItems: 'center', gap: 12, borderWidth: 1, borderRadius: 22, padding: 16, marginBottom: 12 },
  top_row: { flexDirection: 'row', justifyContent: 'space-between', gap: 8 },
  name: { fontFamily: 'Figtree_700Bold', fontSize: 16, flexShrink: 1 },
});
