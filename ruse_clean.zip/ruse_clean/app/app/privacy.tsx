// Privacy page (Phase H). DRAFT text: it describes what the app does today and must be checked
// (and the [in brackets] filled in) before the store listing or any public release.
import { ScrollView, StyleSheet, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { AppText as Text } from '../components/app_text';
import { BackHeader } from '../components/back_header';
import { useTheme } from '../lib/theme';
import { NAV_CLEARANCE } from '../lib/nav_clearance';

const SECTIONS: { title: string; lines: string[] }[] = [
  {
    title: 'What we keep on the server',
    lines: [
      'When you sign in with Google: your name and Gmail address, used to know who you are.',
      'The username you choose. Other readers see this, never your email.',
      'Optional: your gender (Boy, Girl, or skip) and an avatar photo you add.',
      'What you write: comments, replies, direct messages, and reports you send.',
      'Novels, chapters and themes you upload as an author.',
    ],
  },
  {
    title: 'What stays on your phone only',
    lines: [
      'Reading progress, pins, saved novels, your home background photo, and music and read-aloud settings.',
      'Comments you wrote while offline, until they are sent.',
      'Signing out removes these files from the phone.',
    ],
  },
  {
    title: 'Who can see what',
    lines: [
      'Other readers see your username, your avatar, your comments and replies, and messages sent to you.',
      'Authors see the comments on their own chapters.',
      'Admins can see email addresses on the Admin screen, and the reports readers send.',
      'Nobody else can see your email address through this app.',
    ],
  },
  {
    title: 'Blocking and reporting',
    lines: [
      'If you block someone, they cannot message you, and you will not see their messages.',
      'A report goes to the admins. Reports are read by people, not by a computer.',
    ],
  },
  {
    title: 'Your choices',
    lines: [
      'You can change your username once every 30 days.',
      'You can remove your avatar and your home background photo.',
      'Signing out clears the data kept on your phone.',
      '[To be decided: how to ask for your account and data to be deleted, and how fast.]',
    ],
  },
  {
    title: 'Children',
    lines: ['[To be decided: the age this app is for, and any extra rules for under-18s. Check the store age rating too.]'],
  },
  {
    title: 'Contact',
    lines: ['[Owner name and contact email for privacy questions.]'],
  },
];

export default function Privacy() {
  const { theme } = useTheme();
  const c = theme.colors;
  const insets = useSafeAreaInsets();
  return (
    <ScrollView style={{ flex: 1, backgroundColor: c.bg }} contentContainerStyle={{ paddingBottom: insets.bottom + NAV_CLEARANCE }}>
      <BackHeader top_padding={insets.top + 16} back_label="Settings" title="Privacy" />
      <View style={{ padding: 20, gap: 14 }}>
        <Text style={[s.draft, { color: '#b3261e', borderColor: '#b3261e' }]}>DRAFT. Not checked yet. Do not publish until it is reviewed.</Text>
        {SECTIONS.map((sec) => (
          <View key={sec.title} style={[s.card, { backgroundColor: c.surface, borderColor: c.line }]}>
            <Text style={[s.title, { color: c.ink }]}>{sec.title}</Text>
            {sec.lines.map((l, i) => (
              <Text key={i} style={{ color: c.ink, fontFamily: 'Figtree_500Medium', fontSize: 15, lineHeight: 22 }}>• {l}</Text>
            ))}
          </View>
        ))}
      </View>
    </ScrollView>
  );
}

const s = StyleSheet.create({
  draft: { fontFamily: 'Figtree_700Bold', fontSize: 13, borderWidth: 1, borderRadius: 12, padding: 10 },
  card: { borderWidth: 1, borderRadius: 22, padding: 16, gap: 8 },
  title: { fontFamily: 'Figtree_700Bold', fontSize: 17, marginBottom: 2 },
});
