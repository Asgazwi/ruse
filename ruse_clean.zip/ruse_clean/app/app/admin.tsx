import { useCallback, useState } from 'react';
import { ActivityIndicator, Alert, ScrollView, StyleSheet, TextInput, View } from 'react-native';
import { AppText as Text } from '../components/app_text';
import { BouncyPressable as Pressable } from '../components/bouncy_pressable';
import { GlowButton } from '../components/glow_button';
import { router, useFocusEffect } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useAuth } from '../lib/auth';
import { useData } from '../lib/data';
import { useTheme } from '../lib/theme';
import { api } from '../lib/backend';
import {
  ACTION_ADD_USER,
  ACTION_APPROVE_REQUEST,
  ACTION_REJECT_REQUEST,
  ACTION_REMOVE_USER,
  ACTION_SET_ROLE,
} from '../lib/actions';
import { is_admin, role_label, type role } from '../lib/roles';
import { fetch_reports, resolve_report, set_messaging } from '../lib/safety_api';
import { reason_label, MESSAGING_OFF_TEXT, type Report } from '../lib/safety';
import { is_network_error } from '../lib/net_retry';
import { NAV_CLEARANCE } from '../lib/nav_clearance';

// Admin screen (Phase R2). Admins accept or refuse requests (as Reader or Author),
// change a person's role, and remove people. Emails are shown only here.
export default function Admin() {
  const { me } = useAuth();
  const { admin, refresh_admin } = useData();
  const { theme } = useTheme();
  const insets = useSafeAreaInsets();
  const c = theme.colors;
  const [busy, setBusy] = useState<string | null>(null);
  const [message, setMessage] = useState<{ ok: boolean; text: string } | null>(null);
  const [new_email, setNewEmail] = useState('');
  const [new_name, setNewName] = useState('');
  const [new_role, setNewRole] = useState<role>('reader');
  const [reports, setReports] = useState<Report[] | null>(null); // D4: open reports from readers

  const load_reports = useCallback(async () => {
    try { setReports(await fetch_reports()); }
    catch (e: any) { setMessage({ ok: false, text: is_network_error(e) ? 'Reports need a connection.' : e?.message || 'Could not load reports.' }); }
  }, []);

  useFocusEffect(
    useCallback(() => {
      refresh_admin().then((err) => err && setMessage({ ok: false, text: err }));
      if (is_admin(me)) load_reports();
    }, [refresh_admin, load_reports, me]),
  );

  // D4: close a report, or turn messaging on/off for the reported person.
  const report_action = async (who: string, run: () => Promise<unknown>, done_text: string) => {
    setBusy(who);
    setMessage(null);
    try { await run(); setMessage({ ok: true, text: done_text }); await load_reports(); }
    catch (e: any) { setMessage({ ok: false, text: e?.message || 'That did not work.' }); }
    finally { setBusy(null); }
  };

  // Runs one backend change, then reloads the lists so the screen matches the server.
  const do_it = async (who: string, action: string, args: unknown[], done_text: string) => {
    setBusy(who);
    setMessage(null);
    try {
      await api(action, ...args);
      setMessage({ ok: true, text: done_text });
    } catch (e: any) {
      setMessage({ ok: false, text: e?.message || 'That did not work.' });
    }
    const err = await refresh_admin();
    if (err) setMessage({ ok: false, text: err });
    setBusy(null);
  };

  const confirm_remove = (email: string) =>
    Alert.alert('Remove this person?', `${email} will lose access.`, [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Remove',
        style: 'destructive',
        onPress: () => do_it(email, ACTION_REMOVE_USER, [email], `${email} removed.`),
      },
    ]);

  const set_person_role = (email: string, role: role) =>
    do_it(email, ACTION_SET_ROLE, [{ email, role }], `${email} is now ${role_label(role)}.`);

  const approve = (email: string, role: 'reader' | 'author') =>
    do_it(email, ACTION_APPROVE_REQUEST, [email, role], `${email} approved as ${role_label(role)}.`);

  const add_person = async () => {
    const email = new_email.trim().toLowerCase();
    if (!/^\S+@\S+\.\S+$/.test(email)) {
      setMessage({ ok: false, text: 'Type a full Gmail address, like name@gmail.com.' });
      return;
    }
    if (!new_name.trim()) {
      setMessage({ ok: false, text: 'Type their name too.' });
      return;
    }
    // Send both role (R2) and the old admin flag so older backends still work.
    await do_it(
      'add',
      ACTION_ADD_USER,
      [{ email, name: new_name.trim(), role: new_role, admin: new_role === 'admin' }],
      `${email} added as ${role_label(new_role)}.`,
    );
    setNewEmail('');
    setNewName('');
    setNewRole('reader');
  };

  if (!is_admin(me)) {
    return (
      <View style={[s.center, { backgroundColor: c.bg }]}>
        <Text style={[s.muted, { color: c.muted }]}>Only admins can manage people.</Text>
        <Pressable onPress={() => router.replace('/')} hitSlop={12}>
          <Text style={[s.link, { color: c.primary, marginTop: 16 }]}>Back</Text>
        </Pressable>
      </View>
    );
  }

  const btn = (label: string, on_press: () => void, who: string, filled = false, danger = false) => (
    <GlowButton
      key={label}
      label={label}
      on_press={on_press}
      disabled={busy !== null && busy !== who}
      busy={busy === who}
      outline={!filled}
      danger={danger}
      size="md"
      color={danger ? '#b3261e' : c.primary}
      text_color={c.primaryFg}
      style={{ minWidth: 88 }}
    />
  );

  const role_chip = (r: role, current: role, on_press: () => void, who: string) =>
    btn(role_label(r), on_press, who, current === r);

  return (
    <ScrollView
      style={{ backgroundColor: c.bg }}
      keyboardShouldPersistTaps="handled"
      contentContainerStyle={{ padding: 20, paddingTop: insets.top + 16, paddingBottom: insets.bottom + NAV_CLEARANCE }}>
      <Pressable onPress={() => (router.canGoBack() ? router.back() : router.replace('/'))} hitSlop={12}>
        <Text style={[s.link, { color: c.primary }]}>‹ Back</Text>
      </Pressable>
      <Text style={[s.title, { color: c.primary }]}>Admin</Text>
      <Text style={[s.muted, { color: c.muted, textAlign: 'left', marginTop: 4 }]}>
        Accept requests, set roles, remove people. Emails are only visible here.
      </Text>

      {message && (
        <Text style={{ marginTop: 10, color: message.ok ? c.primary : '#b3261e', fontFamily: 'Figtree_500Medium' }}>
          {message.text}
        </Text>
      )}
      {!admin && !message && <ActivityIndicator color={c.primary} style={{ marginTop: 24 }} />}

      <Text style={[s.section, { color: c.ink }]}>Reports</Text>
      {reports === null && <ActivityIndicator color={c.primary} style={{ marginTop: 8 }} />}
      {reports !== null && reports.length === 0 && (
        <Text style={[s.muted, { color: c.muted, textAlign: 'left' }]}>No open reports.</Text>
      )}
      {(reports ?? []).map((r) => (
        <View key={r.id} style={[s.row, { borderColor: c.line, backgroundColor: c.surface }]}>
          <View style={{ flex: 1 }}>
            <Text style={[s.name, { color: c.ink }]}>{r.reported}</Text>
            <Text style={[s.muted, { color: c.muted, textAlign: 'left' }]}>
              {reason_label(r.reason)} · {r.count} report{r.count === 1 ? '' : 's'}{r.messaging_off ? ' · messages off' : ''}
            </Text>
          </View>
          <View style={{ gap: 6, alignItems: 'flex-end' }}>
            {btn(
              r.messaging_off ? 'Messages on' : 'Messages off',
              () => report_action(r.reported, () => set_messaging(r.reported, r.messaging_off), r.messaging_off ? `${r.reported} can message again.` : `${r.reported}: ${MESSAGING_OFF_TEXT}`),
              r.reported,
              false,
              !r.messaging_off,
            )}
            {btn('Dismiss', () => report_action(r.id, () => resolve_report(r.id), 'Report closed.'), r.id)}
          </View>
        </View>
      ))}

      <Text style={[s.section, { color: c.ink }]}>Waiting for approval</Text>
      {admin && admin.requests.length === 0 && (
        <Text style={[s.muted, { color: c.muted, textAlign: 'left' }]}>No requests right now.</Text>
      )}
      {admin?.requests.map((p) => {
        const is_role_up = p.pendingRole === 'author';
        return (
          <View key={`${p.email}-${is_role_up ? 'role' : 'access'}`} style={[s.card, { backgroundColor: c.surface, borderColor: c.line }]}>
            <Text style={[s.name, { color: c.ink }]}>{p.name || p.email}</Text>
            {!!p.name && <Text style={[s.muted, { color: c.muted, textAlign: 'left' }]}>{p.email}</Text>}
            {is_role_up ? (
              <Text style={[s.muted, { color: c.muted, textAlign: 'left', marginTop: 4 }]}>Wants to become an Author</Text>
            ) : null}
            <View style={s.row}>
              {is_role_up ? (
                <>
                  {btn('Make Author', () => set_person_role(p.email, 'author'), p.email, true)}
                  {btn('Dismiss', () => do_it(p.email, ACTION_REJECT_REQUEST, [p.email], `${p.email} role request dismissed.`), p.email, false, true)}
                </>
              ) : (
                <>
                  {btn('As Reader', () => approve(p.email, 'reader'), p.email, true)}
                  {btn('As Author', () => approve(p.email, 'author'), p.email)}
                  {btn('Reject', () => do_it(p.email, ACTION_REJECT_REQUEST, [p.email], `${p.email} rejected.`), p.email, false, true)}
                </>
              )}
            </View>
          </View>
        );
      })}

      <Text style={[s.section, { color: c.ink }]}>People with access</Text>
      {admin?.users.map((p) => {
        const is_me = p.email === me.email?.toLowerCase();
        return (
          <View key={p.email} style={[s.card, { backgroundColor: c.surface, borderColor: c.line }]}>
            <Text style={[s.name, { color: c.ink }]}>
              {p.name || p.email}
              <Text style={{ color: c.muted, fontFamily: 'Figtree_500Medium' }}>  ·  {role_label(p.role)}</Text>
            </Text>
            {!!p.name && <Text style={[s.muted, { color: c.muted, textAlign: 'left' }]}>{p.email}</Text>}
            {is_me ? (
              <Text style={[s.muted, { color: c.muted, textAlign: 'left', marginTop: 8 }]}>This is you.</Text>
            ) : (
              <>
                <View style={s.row}>
                  {role_chip('reader', p.role, () => set_person_role(p.email, 'reader'), p.email)}
                  {role_chip('author', p.role, () => set_person_role(p.email, 'author'), p.email)}
                  {role_chip('admin', p.role, () => set_person_role(p.email, 'admin'), p.email)}
                </View>
                <View style={[s.row, { marginTop: 8 }]}>
                  {btn('Remove', () => confirm_remove(p.email), p.email, false, true)}
                </View>
              </>
            )}
          </View>
        );
      })}

      <Text style={[s.section, { color: c.ink }]}>Add someone directly</Text>
      <View style={[s.card, { backgroundColor: c.surface, borderColor: c.line }]}>
        <TextInput
          value={new_email}
          onChangeText={setNewEmail}
          placeholder="their Gmail address"
          placeholderTextColor={c.muted}
          autoCapitalize="none"
          autoCorrect={false}
          keyboardType="email-address"
          style={[s.input, { borderColor: c.line, color: c.ink }]}
        />
        <TextInput
          value={new_name}
          onChangeText={setNewName}
          placeholder="their name"
          placeholderTextColor={c.muted}
          autoCapitalize="words"
          style={[s.input, { borderColor: c.line, color: c.ink }]}
        />
        <Text style={{ color: c.ink, fontFamily: 'Figtree_500Medium', marginTop: 14, marginBottom: 6 }}>Role</Text>
        <View style={s.row}>
          {role_chip('reader', new_role, () => setNewRole('reader'), 'add-role')}
          {role_chip('author', new_role, () => setNewRole('author'), 'add-role')}
          {role_chip('admin', new_role, () => setNewRole('admin'), 'add-role')}
        </View>
        <GlowButton label="Add person" on_press={add_person} busy={busy === 'add'} disabled={busy !== null && busy !== 'add'} color={c.accent} text_color={c.accentFg} style={s.add_btn} />
      </View>
    </ScrollView>
  );
}

const s = StyleSheet.create({
  center: { flex: 1, alignItems: 'center', justifyContent: 'center', padding: 24 },
  title: { fontFamily: 'Figtree_700Bold', fontSize: 30, marginTop: 12 },
  section: { fontFamily: 'Figtree_700Bold', fontSize: 18, marginTop: 28, marginBottom: 10 },
  muted: { fontFamily: 'Figtree_500Medium', fontSize: 14, marginTop: 2, textAlign: 'center' },
  link: { fontFamily: 'Figtree_500Medium', fontSize: 17 },
  card: { borderWidth: 1, borderRadius: 22, padding: 16, marginBottom: 12 },
  name: { fontFamily: 'Figtree_700Bold', fontSize: 17 },
  row: { flexDirection: 'row', flexWrap: 'wrap', gap: 10, marginTop: 12 },
  small_btn: {
    height: 38,
    minWidth: 88,
    borderRadius: 19,
    borderWidth: 2,
    paddingHorizontal: 12,
    justifyContent: 'center',
    alignItems: 'center',
  },
  small_text: { fontFamily: 'Figtree_700Bold', fontSize: 14 },
  input: {
    height: 46,
    borderWidth: 1,
    borderRadius: 23,
    paddingHorizontal: 18,
    marginTop: 10,
    fontFamily: 'Figtree_500Medium',
    fontSize: 16,
  },
  add_btn: { marginTop: 16 },
});
