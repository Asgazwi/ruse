import { useCallback, useMemo, useState } from 'react';
import { ActivityIndicator, Image, ImageBackground, RefreshControl, ScrollView, StyleSheet, View } from 'react-native';
import { AppText as Text } from '../components/app_text';
import { BouncyPressable as Pressable } from '../components/bouncy_pressable';
import { router, useFocusEffect } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useAuth } from '../lib/auth';
import { useTheme } from '../lib/theme';
import { useData } from '../lib/data';
import { OfflineRibbon } from '../components/offline_ribbon';
import { SyncNotice } from '../components/sync_notice';
import { RequestAccess } from '../components/request_access';
import { APP_NAME } from '../lib/brand';
import { CoverTile } from '../components/cover_tile';
import { Floaters } from '../components/floaters';
import { Ionicons } from '@expo/vector-icons';
import { alpha_hex } from '../lib/alpha_hex';
import { Avatar } from '../components/avatar';
import { greeting_for_hour } from '../lib/greeting_for_hour';
import { chapters_for, done_count } from '../lib/reader';
import { usePins } from '../lib/pins';
import { unanswered_count } from '../lib/pin_helpers';
import { children_of } from '../lib/category_helpers';
import { CourseCard } from '../components/course_card';
import { CategoryCard } from '../components/category_card';
import { PushSetup } from '../components/push_setup';
import { CountDot } from '../components/count_dot';
import { NAV_CLEARANCE } from '../lib/nav_clearance';
import { GlowButton } from '../components/glow_button';
import { SectionLabel } from '../components/section_label';
import { EmptyState } from '../components/empty_state';
import { FadeInView } from '../components/fade_in_view';
import { W } from '../lib/words';
import { can_upload } from '../lib/roles';
import { kind_label, normalize_kind } from '../lib/novel_kind';
import { display_name } from '../lib/pin_helpers';
import { load_home_bg } from '../lib/home_bg';
import { UsernamePrompt } from '../components/username_prompt';
import { ProfileSetup } from '../components/profile_setup';
import { effective_gender } from '../lib/profile_local';
import { public_name } from '../lib/username';
import { fetch_all_messages } from '../lib/messages_api';
import { fetch_blocked } from '../lib/safety_api';
import { blocked_set, is_blocked } from '../lib/safety';
import { summarize_threads, unread_total, type Thread } from '../lib/messages';
import { continue_card, pick_random, percent, recommendable, waiting_threads } from '../lib/home_cards';
import { NovelCard } from '../components/novel_card';
import { is_novel_bg_off } from '../lib/novel_bg_pref';
import { resolve } from '../lib/downloads';

export default function Home() {
  const { status, me, error, signIn } = useAuth();
  const { theme } = useTheme();
  const { data, syncing, offline, error: load_error, refresh, admin } = useData();
  const { pins, comments, sync: sync_pins } = usePins();
  const insets = useSafeAreaInsets();
  const c = theme.colors;
  const [refreshing, setRefreshing] = useState(false);
  const [kind, setKind] = useState<'all' | 'novel' | 'manga' | 'webtoon'>('all');
  const [home_bg, setHomeBg] = useState<string | null>(() => load_home_bg());
  // Home cards (messages waiting, carry on, for you). Every hook is above the early returns below.
  const [msg_threads, setMsgThreads] = useState<Thread[]>([]);
  const unread_msgs = unread_total(msg_threads);
  useFocusEffect(useCallback(() => {
    if (status !== 'in' || !me?.allowed) return;
    Promise.all([fetch_all_messages(), fetch_blocked().catch(() => [] as string[])])
      .then(([all, blocked]) => {
        const hidden = blocked_set(blocked);
        setMsgThreads(summarize_threads(all, me?.username ?? null).filter((t) => !is_blocked(hidden, t.with)));
      })
      .catch(() => {});
  }, [status, me?.allowed, me?.username]));
  const resume = continue_card(data?.progress, data?.chapters ?? [], data?.subjects ?? []);
  // Re-picked only when the library changes, so the list does not jump on every render.
  const library_key = `${(data?.subjects ?? []).map((x) => x.id).join('|')}#${(data?.chapters ?? []).length}#${resume?.subject.id ?? ''}`;
  // The novel's own background photo (E5), unless this reader turned it off for that novel.
  const bg_of = (sub: any): string | null => (typeof sub?.backgroundUrl === 'string' && /^https:\/\/\S+$/.test(sub.backgroundUrl) && !is_novel_bg_off(sub.id) ? resolve(sub.backgroundUrl) : null);
  const recs = useMemo(
    () => pick_random(recommendable(data?.subjects ?? [], data?.chapters ?? [], resume?.subject.id ?? null), 4),
    [library_key], // eslint-disable-line react-hooks/exhaustive-deps
  );
  const subjects = data?.subjects ?? null;

  // Saved courses show instantly; this refreshes them quietly in the background.
  // Coming back from Settings only refreshes if the data is older than 15 seconds.
  useFocusEffect(
    useCallback(() => {
      setHomeBg(load_home_bg());
      if (status === 'in' && me?.allowed) { refresh({ max_age_ms: 15000 }); sync_pins({ max_age_ms: 15000 }); }
    }, [status, me?.allowed, refresh, sync_pins]),
  );

  const onRefresh = async () => {
    setRefreshing(true);
    await Promise.all([refresh(), sync_pins()]);
    setRefreshing(false);
  };

  // Only shown when there is nothing saved to fall back on.
  const empty_error = !data && (load_error || (offline ? `You are offline and no ${W.novels} are saved on this phone yet.` : null));

  if (status === 'loading') {
    return <View style={[s.center, { backgroundColor: c.bg }]}><ActivityIndicator color={c.primary} /></View>;
  }

  if (status === 'out') {
    return (
      <View style={[s.center, { backgroundColor: c.bg, paddingTop: insets.top, paddingBottom: insets.bottom }]}>
        <FadeInView style={s.sign_in}>
          <Image source={require('../assets/images/icon.png')} style={s.logo} />
          <Text style={[s.brand, { color: c.ink }]}>{APP_NAME}</Text>
          <Text style={[s.muted, { color: c.muted }]}>Read novels, webtoons and manga. Talk about every chapter.</Text>
          <GlowButton label="Continue with Google" on_press={signIn} color={c.primary} text_color={c.primaryFg} style={s.sign_in_btn} />
          {!!error && (
            <View style={[s.error_card, { backgroundColor: alpha_hex('#b3261e', 0.08), borderColor: alpha_hex('#b3261e', 0.3) }]}>
              <Text style={s.error_title}>Sign-in did not work</Text>
              <Text style={[s.error_text, { color: c.ink }]}>{String(error)}</Text>
              {String(error).includes('DEVELOPER_ERROR') && (
                <Text style={[s.error_hint, { color: c.muted }]}>Google does not recognise this build yet. In Google Cloud, add an Android OAuth client with this app's package name and the SHA-1 of the key that signed this build.</Text>
              )}
            </View>
          )}
        </FadeInView>
      </View>
    );
  }

  if (!me?.allowed) return <RequestAccess />;

  // One number for the whole phone: every chapter of every course, and how many are finished.
  const all_chapters = data?.chapters ?? [];
  const all_done = done_count(all_chapters, data?.progress?.completed);
  // Only people who uploaded chapters with comments see this row.
  const has_inbox = comments.some((cm) => cm.toMe && !cm.mine);
  const waiting_replies = unanswered_count(comments);
  // Top level: category folders first, then courses that are not in any category.
  const top = children_of(subjects ?? [], []);
  const kind_ok = (sub: any) => kind === 'all' || normalize_kind(sub?.kind) === kind;
  const shown_courses = top.courses.filter(kind_ok);
  const shown_recs = recs.filter(kind_ok);

  const need_username = !me.username || !String(me.username).trim();
  const need_profile = !need_username && !effective_gender(me);
  const KINDS: { key: typeof kind; label: string }[] = [{ key: 'all', label: 'All' }, { key: 'novel', label: 'Novels' }, { key: 'manga', label: 'Manga' }, { key: 'webtoon', label: 'Webtoons' }];

  const shell = (
    <>
      <Floaters />
      <PushSetup />
      <ScrollView
        contentContainerStyle={{ paddingBottom: insets.bottom + NAV_CLEARANCE }}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={c.primary} />}>
        <View style={{ paddingHorizontal: 20, paddingTop: insets.top + 14 }}>
          <View style={s.top_row}>
            <View style={s.brand_row}>
              <Text style={[s.wordmark, { color: c.ink }]}>{APP_NAME}</Text>
              {syncing && !!data && <ActivityIndicator size="small" color={c.muted} />}
            </View>
            <Pressable onPress={() => router.push('/settings')} hitSlop={12} accessibilityRole="button" accessibilityLabel="Your profile">
              <Avatar name={public_name(me)} url={me?.avatarUrl} size={36} />
            </Pressable>
          </View>
          <Text style={[s.greeting, { color: c.muted }]}>{greeting_for_hour(new Date().getHours())}</Text>
          <Text style={[s.title, { color: c.ink }]}>{resume ? `Pick up where you left off, ${public_name(me)}` : `Welcome, ${public_name(me)}`}</Text>
          {all_chapters.length > 0 && (
            <Text style={[s.stat, { color: c.muted }]}>{all_done} of {all_chapters.length} chapters read</Text>
          )}

          <OfflineRibbon />
          <SyncNotice />

          {(!!empty_error || (!!load_error && !!data)) && (
            <View style={[s.card, { backgroundColor: c.surface, borderColor: alpha_hex('#b3261e', 0.4) }]}>
              <Text style={{ color: '#b3261e', fontFamily: 'Figtree_500Medium' }}>{empty_error || load_error}</Text>
              <Pressable onPress={onRefresh} hitSlop={12}><Text style={[s.link, { color: c.primary, marginTop: 10 }]}>Try again</Text></Pressable>
            </View>
          )}

          {!data && !empty_error && <ActivityIndicator color={c.primary} style={{ marginTop: 24 }} />}

          {resume && (
            <View style={{ marginTop: 18 }}>
              <NovelCard
                title={resume.subject.title}
                sub={resume.chapter.title}
                badge={kind_label(resume.subject.kind)}
                progress={percent(resume.done, resume.total)}
                meta={`${resume.done} of ${resume.total} chapters`}
                action_label="Resume"
                on_press={() => router.push(`/chapter/${resume.chapter.id}`)}
              />
            </View>
          )}

          {has_inbox && (
            <Pressable onPress={() => router.push('/comments')} style={[s.row_card, { backgroundColor: c.surface, borderColor: waiting_replies ? c.primary : c.line, borderRadius: theme.radius ?? 16 }]}>
              <Ionicons name="chatbubbles-outline" size={22} color={c.primary} />
              <View style={{ flex: 1 }}>
                <Text style={[s.row_title, { color: c.ink }]}>Comments on my chapters</Text>
                <Text style={[s.row_sub, { color: c.muted }]}>{waiting_replies ? `${waiting_replies} waiting for a reply` : 'All answered'}</Text>
              </View>
              <Ionicons name="chevron-forward" size={20} color={c.muted} />
            </Pressable>
          )}

          {waiting_threads(msg_threads).length > 0 && (
            <>
              <SectionLabel text="Messages" right={`${unread_msgs} unread`} on_right={() => router.push('/messages')} />
              {waiting_threads(msg_threads).map((t) => (
                <Pressable key={t.with} onPress={() => router.push(`/message/${encodeURIComponent(t.with)}`)} style={[s.row_card, { backgroundColor: c.surface, borderColor: c.primary, borderRadius: theme.radius ?? 16 }]}>
                  <Avatar name={t.with} size={40} />
                  <View style={{ flex: 1 }}>
                    <Text style={[s.row_title, { color: c.ink }]} numberOfLines={1}>{t.with}</Text>
                    <Text style={[s.row_sub, { color: c.muted }]} numberOfLines={1}>{t.last.text}</Text>
                  </View>
                  <CountDot count={t.unread} />
                </Pressable>
              ))}
            </>
          )}

          <View style={s.chips}>
            {KINDS.map((k) => {
              const on = kind === k.key;
              return (
                <Pressable key={k.key} onPress={() => setKind(k.key)} accessibilityRole="button" accessibilityState={{ selected: on }}
                  style={[s.chip, { backgroundColor: on ? c.ink : 'transparent', borderColor: on ? c.ink : c.line }]}>
                  <Text style={{ color: on ? c.bg : c.muted, fontFamily: 'Figtree_700Bold', fontSize: 13 }}>{k.label}</Text>
                </Pressable>
              );
            })}
          </View>

          {shown_recs.length > 0 && (
            <>
              <SectionLabel text="Picked for you" />
              <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ marginHorizontal: -20 }} contentContainerStyle={{ paddingHorizontal: 20 }}>
                {shown_recs.map((sub) => (
                  <CoverTile key={sub.id} id={sub.id} title={sub.title} byline={sub.uploaderName ? display_name(sub.uploaderName, 'author') : undefined} />
                ))}
              </ScrollView>
            </>
          )}

          {subjects && subjects.length === 0 && (
            <EmptyState emoji="🌱" title={`No ${W.novels} yet`} body={can_upload(me) ? `Open the Author tab and upload a ${W.novel} to get started.` : `New ${W.novels} from authors will show up here.`} />
          )}

          {kind === 'all' && top.categories.length > 0 && <SectionLabel text="Categories" />}
          {kind === 'all' && top.categories.map((node, i) => <CategoryCard key={node.path.join('>')} node={node} index={i} />)}

          {shown_courses.length > 0 && <SectionLabel text={kind === 'all' && top.categories.length > 0 ? `Other ${W.novels}` : `Your library`} />}
          {shown_courses.map((sub, i) => {
            const chs = chapters_for(data?.chapters ?? [], sub.id);
            return (
              <CourseCard
                key={sub.id} id={sub.id} title={sub.title} summary={sub.summary}
                done={done_count(chs, data?.progress?.completed)} total={chs.length}
                pinned={pins.some((p) => p.subject === sub.id)}
                index={i + top.categories.length}
                kind_label={kind_label(sub.kind)}
                byline={sub.uploaderName || sub.createdBy ? display_name(sub.uploaderName || sub.createdBy, 'author') : undefined}
              />
            );
          })}
        </View>
      </ScrollView>
    </>
  );

  const body = home_bg ? (
    <ImageBackground source={{ uri: home_bg }} style={{ flex: 1 }} resizeMode="cover">
      <View style={[s.bg_scrim, { backgroundColor: c.bg }]} />
      {shell}
    </ImageBackground>
  ) : (
    <View style={{ flex: 1, backgroundColor: c.bg }}>{shell}</View>
  );

  return (
    <>
      {body}
      <UsernamePrompt visible={need_username} />
      <ProfileSetup visible={need_profile} />
    </>
  );
}

const s = StyleSheet.create({
  center: { flex: 1, alignItems: 'center', justifyContent: 'center', padding: 28 },
  sign_in: { width: '100%', maxWidth: 400, alignItems: 'center' },
  sign_in_btn: { width: '100%', marginTop: 32 },
  logo: { width: 84, height: 84, borderRadius: 22, marginBottom: 20 },
  error_card: { width: '100%', marginTop: 22, borderRadius: 14, borderWidth: 1, padding: 16 },
  error_title: { fontFamily: 'Figtree_700Bold', fontSize: 15, color: '#b3261e', marginBottom: 4 },
  error_text: { fontFamily: 'Figtree_500Medium', fontSize: 14, lineHeight: 20 },
  error_hint: { fontFamily: 'Figtree_500Medium', fontSize: 13, lineHeight: 19, marginTop: 8 },
  brand: { fontFamily: 'Figtree_700Bold', fontSize: 40, textAlign: 'center' },
  muted: { fontFamily: 'Figtree_500Medium', fontSize: 15, lineHeight: 22, textAlign: 'center', marginTop: 8, maxWidth: 280 },
  top_row: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  brand_row: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  wordmark: { fontFamily: 'Figtree_700Bold', fontSize: 24 },
  greeting: { fontFamily: 'Figtree_500Medium', fontSize: 14, marginTop: 22 },
  title: { fontFamily: 'Figtree_700Bold', fontSize: 30, lineHeight: 36, marginTop: 2 },
  stat: { fontFamily: 'Figtree_500Medium', fontSize: 14, marginTop: 6 },
  link: { fontFamily: 'Figtree_500Medium', fontSize: 16 },
  card: { borderWidth: 1, borderRadius: 16, padding: 16, marginTop: 14 },
  row_card: { flexDirection: 'row', alignItems: 'center', gap: 12, borderWidth: 1, padding: 14, marginBottom: 10 },
  row_title: { fontFamily: 'Figtree_700Bold', fontSize: 15.5 },
  row_sub: { fontFamily: 'Figtree_500Medium', fontSize: 13.5, marginTop: 1 },
  chips: { flexDirection: 'row', gap: 8, marginTop: 22 },
  chip: { borderWidth: 1, borderRadius: 18, paddingHorizontal: 14, paddingVertical: 7 },
  bg_scrim: { position: 'absolute', top: 0, right: 0, bottom: 0, left: 0, opacity: 0.9 },
});
