import { useCallback, useEffect, useRef, useState, type ComponentRef, type ReactNode } from 'react';
import { Alert, BackHandler, ImageBackground, Pressable as LongPress, ScrollView, StyleSheet, View } from 'react-native';
import { router, useFocusEffect, useLocalSearchParams } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { AppText as Text } from '../../components/app_text';
import { BouncyPressable as Pressable } from '../../components/bouncy_pressable';
import { BackHeader } from '../../components/back_header';
import { BlockView } from '../../components/block_view';
import { Celebrate } from '../../components/celebrate';
import { PinBar } from '../../components/pin_bar';
import { SyncNotice } from '../../components/sync_notice';
import { CommentSheet } from '../../components/comment_sheet';
import { LeavePopup } from '../../components/leave_popup';
import { FloatingTools } from '../../components/floating_tools';
import { ReaderEdge } from '../../components/reader_edge';
import { alpha_hex } from '../../lib/alpha_hex';
import { block_at } from '../../lib/drop_target';
import { GlowButton } from '../../components/glow_button';
import { EmptyState } from '../../components/empty_state';
import { useTheme } from '../../lib/theme';
import { useData } from '../../lib/data';
import { find_chapter, find_subject, neighbours, safe_color } from '../../lib/reader';
import { usePins } from '../../lib/pins';
import { block_counts, pin_for } from '../../lib/pin_helpers';
import { text_on } from '../../lib/contrast';
import { Breadcrumb } from '../../components/breadcrumb';
import { category_of, encode_path } from '../../lib/category_helpers';
import { RecommendThemeBanner } from '../../components/recommend_theme_banner';
import { useNovelTheme } from '../../lib/use_novel_theme';
import { is_novel_bg_off, set_novel_bg_off } from '../../lib/novel_bg_pref';
import { MangaReader } from '../../components/manga_reader';
import { manga_pages } from '../../lib/manga';
import { MusicBar } from '../../components/music_bar';
import { resolve } from '../../lib/downloads';
import { music_url } from '../../lib/music';
import { DOCK_CLEARANCE } from '../../lib/dock_layout';

// The chapter reader. Everything comes from the saved course data, so chapters
// you have loaded once open fine with no network.
export default function ChapterReader() {
  // ?block=3 opens the chapter at that spot; &sheet=1 also opens its comments.
  const { id, block, sheet } = useLocalSearchParams<{ id: string; block?: string; sheet?: string }>();
  const { theme } = useTheme();
  const { data, complete_chapter } = useData();
  const [celebrating, setCelebrating] = useState(0); // counts up each time, so the shower can replay
  const [note, setNote] = useState<string | null>(null);
  const { pins, comments, set_pin, remove_pin } = usePins();
  const scroll_ref = useRef<ComponentRef<typeof ScrollView>>(null);
  const body_y = useRef(0);
  const block_y = useRef<Record<number, number>>({});
  const block_h = useRef<Record<number, number>>({});
  const [hover, setHover] = useState<number | null>(null);   // the block under the dragged button
  const [hint, setHint] = useState(false);
  const target = block !== undefined && block !== '' && Number.isInteger(Number(block)) && Number(block) >= 0 ? Number(block) : null;
  // The comments sheet is for the whole chapter. `sheet_ref` is the part a new comment will refer to, if any.
  const [sheet_open, setSheetOpen] = useState(sheet === '1');
  const [sheet_ref, setSheetRef] = useState<number | null>(sheet === '1' ? target : null);
  const open_comments = (ref: number | null) => { setSheetRef(ref); setSheetOpen(true); };
  const [leaving, setLeaving] = useState(false);   // the closing message is showing
  const scroll_y = useRef(0);
  const insets = useSafeAreaInsets();
  const c = theme.colors;

  // Resolve chapter early so E4 can apply the novel theme (hook must run every render).
  const chapter_early = find_chapter(data?.chapters ?? [], id);
  const novelTheme = useNovelTheme(chapter_early?.subject);
  // E5: reader can hide the author background for this novel (phone-only).
  const [bg_off, setBgOff] = useState(() => is_novel_bg_off(chapter_early?.subject || ''));
  useEffect(() => {
    setBgOff(is_novel_bg_off(chapter_early?.subject || ''));
  }, [chapter_early?.subject]);

  // The phone's own Back button shows the closing message too (only while this screen is on top).
  useFocusEffect(useCallback(() => {
    const sub = BackHandler.addEventListener('hardwareBackPress', () => { setLeaving(true); return true; });
    return () => sub.remove();
  }, []));

  // Scroll to the pinned / requested spot once the blocks have been measured.
  useEffect(() => {
    if (target === null) return;
    const t = setTimeout(() => {
      const y = block_y.current[target];
      if (y !== undefined) scroll_ref.current?.scrollTo({ y: Math.max(0, body_y.current + y - 16), animated: false });
    }, 200);
    return () => clearTimeout(t);
  }, [target, id]);

  const chapter = find_chapter(data?.chapters ?? [], id);

  if (!chapter) {
    return (
      <View style={[s.center, { backgroundColor: c.bg }]}>
        <EmptyState emoji="📖" title="Chapter not found" body="It may have been removed. Go back and pull down to refresh.">
          <GlowButton label="Back to Home" on_press={() => router.replace('/')} color={c.primary} text_color={c.primaryFg} style={s.btn} />
        </EmptyState>
      </View>
    );
  }

  const subject = find_subject(data?.subjects ?? [], chapter.subject);
  const { prev, next } = neighbours(data?.chapters ?? [], chapter);
  const accent = safe_color(chapter.style?.accent, c.accent);
  const blocks = Array.isArray(chapter.blocks) ? chapter.blocks : [];
  // E2: a manga chapter shows its page images instead of text blocks.
  const pages = manga_pages(chapter);
  const is_manga = pages.length > 0;
  const is_done = (data?.progress?.completed ?? []).includes(chapter.id);
  const my_pin = pin_for(pins, chapter.id);
  const counts = block_counts(comments, chapter.id);
  const cat = category_of(subject);
  const crumbs = [
    ...cat.map((name, i) => ({ label: name, on_press: () => router.push(`/category?path=${encode_path(cat.slice(0, i + 1))}`) })),
    ...(subject ? [{ label: subject.title, on_press: () => router.push(`/course/${subject.id}`) }] : []),
    { label: chapter.title },
  ];
  // E5: author background behind the text (scrim keeps ink readable).
  const author_bg = typeof subject?.backgroundUrl === 'string' ? (resolve(subject.backgroundUrl) ?? '') : '';
  const show_author_bg = !!author_bg && !bg_off;
  const toggle_author_bg = () => {
    if (!subject?.id || !author_bg) return;
    const next = !bg_off;
    set_novel_bg_off(subject.id, next);
    setBgOff(next);
  };

  // Block under a screen height (the floating buttons report heights in screen space).
  const block_under = (root_y: number | null): number | null => {
    if (root_y === null) return null;
    const content_y = root_y + scroll_y.current - body_y.current;
    const boxes = blocks.map((_, i) => (block_y.current[i] === undefined ? undefined : { top: block_y.current[i], height: block_h.current[i] ?? 0 }));
    return block_at(content_y, boxes);
  };
  const on_hover = (root_y: number | null) => { const i = block_under(root_y); setHover((old) => (old === i ? old : i)); };
  const on_drop = (kind: 'pin' | 'comment', root_y: number) => {
    const i = block_under(root_y);
    if (i === null) return;
    if (kind === 'comment') open_comments(i);
    else if (my_pin?.block === i) remove_pin(chapter.id);
    else set_pin(chapter, i);
  };
  const on_tap = (kind: 'pin' | 'comment') => {
    if (kind === 'comment') { open_comments(null); return; }
    setHint(true); setTimeout(() => setHint(false), 2600);
  };
  // Jump to a part a comment refers to, and close the sheet.
  const jump_to = (b: number) => {
    setSheetOpen(false);
    setTimeout(() => {
      const y = block_y.current[b];
      if (y !== undefined) scroll_ref.current?.scrollTo({ y: Math.max(0, body_y.current + y - 16), animated: true });
    }, 250);
  };
  // Backup for people who do not like dragging: long press a block.
  const block_menu = (i: number) => Alert.alert('This spot', undefined, [
    { text: my_pin?.block === i ? 'Remove pin' : '📍 Pin here', onPress: () => (my_pin?.block === i ? remove_pin(chapter.id) : set_pin(chapter, i)) },
    { text: '💬 Comment on this part', onPress: () => open_comments(i) },
    { text: 'Cancel', style: 'cancel' },
  ]);

  const go_back = () => (router.canGoBack() ? router.back() : router.replace('/'));
  // The block nearest the top of the screen: where "Pin my place" pins.
  const current_block = () => {
    let at = 0;
    for (let i = 0; i < blocks.length; i++) {
      const y = block_y.current[i];
      if (y !== undefined && body_y.current + y <= scroll_y.current + 80) at = i;
    }
    return at;
  };

  const finish = async () => {
    setCelebrating((n) => n + 1);
    const r = await complete_chapter(chapter);
    setNote(r === 'queued' ? 'Saved on this phone. It will sync when you are back online.' : null);
  };

  const shell = (inner: ReactNode) =>
    show_author_bg ? (
      <ImageBackground source={{ uri: author_bg }} style={{ flex: 1 }} resizeMode="cover">
        {/* Theme-coloured scrim so body text stays readable on any photo. */}
        <View style={{ flex: 1, backgroundColor: alpha_hex(c.bg, 0.78) }}>{inner}</View>
      </ImageBackground>
    ) : (
      <View style={{ flex: 1, backgroundColor: c.bg }}>{inner}</View>
    );

  return shell(
    <>
      <ScrollView ref={scroll_ref} scrollEventThrottle={100} onScroll={(e) => { scroll_y.current = e.nativeEvent.contentOffset.y; }} contentContainerStyle={{ paddingBottom: insets.bottom + DOCK_CLEARANCE }}>
        <BackHeader
          top_padding={insets.top + 16}
          back_label={subject?.title || 'Back'}
          title={chapter.title}
          on_back={() => setLeaving(true)}
          sub={[chapter.summary, chapter.minutes ? `${chapter.minutes} min read` : ''].filter(Boolean).join(' · ') || undefined}
        />
        <View style={{ padding: 20, paddingTop: 24 }} onLayout={(e) => { body_y.current = e.nativeEvent.layout.y; }}>
          {cat.length > 0 && <Breadcrumb parts={crumbs} />}
          <SyncNotice />
          {novelTheme.show_banner && novelTheme.recommended ? (
            <View style={{ marginBottom: 12 }}>
              <RecommendThemeBanner
                recommended={novelTheme.recommended}
                on_yes={novelTheme.on_yes}
                on_always={novelTheme.on_always}
                on_no={novelTheme.on_no}
              />
            </View>
          ) : null}
          {music_url(subject) || author_bg ? (
            <View style={s.tools_row}>
              <View style={{ flex: 1 }}><MusicBar subject={subject} /></View>
              {author_bg ? (
                <Pressable
                  onPress={toggle_author_bg}
                  style={[s.bg_toggle, { borderColor: c.line, backgroundColor: c.surface, opacity: bg_off ? 0.55 : 1 }]}
                  accessibilityRole="button"
                  accessibilityLabel={bg_off ? 'Show author background' : 'Hide author background'}>
                  <Ionicons name="image-outline" size={20} color={c.primary} />
                </Pressable>
              ) : null}
            </View>
          ) : null}
          {is_manga ? <MangaReader pages={pages} /> : null}
          {!is_manga && blocks.map((b, i) => (
            <View key={i} onLayout={(e) => { block_y.current[i] = e.nativeEvent.layout.y; block_h.current[i] = e.nativeEvent.layout.height; }}>
              <LongPress onLongPress={() => block_menu(i)} delayLongPress={450} style={hover === i ? { backgroundColor: alpha_hex(accent, 0.14), borderRadius: 14, marginHorizontal: -6, paddingHorizontal: 6 } : undefined}>
                <BlockView block={b} chapter={chapter} />
              </LongPress>
              <PinBar
                pinned={my_pin?.block === i}
                count={counts[i] ?? 0}
                on_pin={() => (my_pin?.block === i ? remove_pin(chapter.id) : set_pin(chapter, i))}
                on_comments={() => open_comments(i)}
              />
            </View>
          ))}

          {!is_manga && blocks.length === 0 && <Text style={{ color: c.muted, fontFamily: 'Figtree_500Medium' }}>This chapter has no content yet.</Text>}


          <GlowButton
            label={is_done ? '✓ Chapter complete' : 'Mark chapter complete 🎉'}
            on_press={finish}
            disabled={is_done}
            color={is_done ? c.line : accent}
            text_color={is_done ? c.muted : text_on(accent)}
            style={s.finish}
          />
          {!!note && <Text style={{ color: c.muted, fontFamily: 'Figtree_500Medium', textAlign: 'center', marginTop: 10 }}>{note}</Text>}

          <View style={s.nav}>
            {prev ? (
              <Pressable onPress={() => router.replace(`/chapter/${prev.id}`)} style={[s.nav_btn, { backgroundColor: c.surface, borderColor: c.line, borderWidth: 1, borderRadius: theme.radius ?? 16 }]}>
                <Text style={{ color: c.muted, fontFamily: 'Figtree_500Medium', fontSize: 12 }}>Previous</Text>
                <Text style={{ color: c.ink, fontFamily: 'Figtree_700Bold', fontSize: 14 }} numberOfLines={1}>{prev.title}</Text>
              </Pressable>
            ) : <View style={{ flex: 1 }} />}
            {next ? (
              <Pressable onPress={() => router.replace(`/chapter/${next.id}`)} style={[s.nav_btn, { backgroundColor: c.primary, borderRadius: theme.radius ?? 16 }]}>
                <Text style={{ color: c.primaryFg, fontFamily: 'Figtree_500Medium', fontSize: 12, opacity: 0.8 }}>Next</Text>
                <Text style={{ color: c.primaryFg, fontFamily: 'Figtree_700Bold', fontSize: 14 }} numberOfLines={1}>{next.title}</Text>
              </Pressable>
            ) : <View style={{ flex: 1 }} />}
          </View>
        </View>
      </ScrollView>
      <FloatingTools on_hover={on_hover} on_drop={on_drop} on_tap={on_tap} />
      <ReaderEdge />
      {hint && (
        <View pointerEvents="none" style={[s.hint, { backgroundColor: c.ink }]}>
          <Text style={{ color: c.bg, fontFamily: 'Figtree_500Medium', textAlign: 'center' }}>Tap the comment button to comment on the chapter. Drag the pin or comment button onto a paragraph to pin it or refer to it.</Text>
        </View>
      )}
      <LeavePopup
        visible={leaving}
        done={is_done}
        pinned={!!my_pin}
        on_stay={() => setLeaving(false)}
        on_leave={() => { setLeaving(false); go_back(); }}
        on_pin={() => { set_pin(chapter, current_block()); setLeaving(false); go_back(); }}
        on_complete={async () => { setLeaving(false); await complete_chapter(chapter); go_back(); }}
      />
      <CommentSheet chapter={chapter} open={sheet_open} initial_ref={sheet_ref} on_close={() => setSheetOpen(false)} on_jump={jump_to} />
      {celebrating > 0 && <Celebrate key={celebrating} />}
    </>,
  );
}

const s = StyleSheet.create({
  center: { flex: 1, alignItems: 'center', justifyContent: 'center', padding: 24, gap: 8 },
  btn: { marginTop: 18, alignSelf: 'stretch' },
  finish: { marginTop: 8 },
  hint: { position: 'absolute', left: 72, right: 72, bottom: 28, borderRadius: 18, paddingVertical: 12, paddingHorizontal: 16 },
  nav: { flexDirection: 'row', gap: 12, marginTop: 16 },
  nav_btn: { flex: 1, minHeight: 64, paddingHorizontal: 14, paddingVertical: 10, justifyContent: 'center', gap: 2 },
  tools_row: { flexDirection: 'row', alignItems: 'center', justifyContent: 'flex-end', gap: 10, marginBottom: 14 },
  bg_toggle: { width: 56, height: 56, borderRadius: 22, borderWidth: 1, alignItems: 'center', justifyContent: 'center' },
});
