import { Stack } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { ActivityIndicator, View } from 'react-native';
import { useFonts, Figtree_500Medium, Figtree_700Bold } from '@expo-google-fonts/figtree';
import { Quicksand_500Medium, Quicksand_700Bold } from '@expo-google-fonts/quicksand';
import { Newsreader_500Medium, Newsreader_700Bold } from '@expo-google-fonts/newsreader';
import { Inter_500Medium, Inter_700Bold } from '@expo-google-fonts/inter';
import { Merriweather_500Medium, Merriweather_700Bold } from '@expo-google-fonts/merriweather';
import { Lora_500Medium, Lora_700Bold } from '@expo-google-fonts/lora';
import { RobotoMono_500Medium, RobotoMono_700Bold } from '@expo-google-fonts/roboto-mono';
import { AuthProvider } from '../lib/auth';
import { ThemeProvider, DEFAULT_THEME, useTheme } from '../lib/theme';
import { is_dark } from '../lib/contrast';
import { DataProvider } from '../lib/data';
import { EffectsProvider } from '../lib/effects';
import { EffectLayer } from '../components/effect_layer';
import { GlobalNav } from '../components/global_nav';

// Status bar icons follow the theme: light icons on dark themes, dark icons on light ones.
function ThemedStatusBar() {
  const { theme } = useTheme();
  return <StatusBar style={is_dark(theme.colors.bg) ? 'light' : 'dark'} />;
}

export default function Layout() {
  const [loaded] = useFonts({
    Figtree_500Medium, Figtree_700Bold, Quicksand_500Medium, Quicksand_700Bold,
    Newsreader_500Medium, Newsreader_700Bold, Inter_500Medium, Inter_700Bold,
    Merriweather_500Medium, Merriweather_700Bold, Lora_500Medium, Lora_700Bold,
    RobotoMono_500Medium, RobotoMono_700Bold,
  });
  if (!loaded) {
    return (
      <View style={{ flex: 1, justifyContent: 'center', backgroundColor: DEFAULT_THEME.colors.bg }}>
        <ActivityIndicator color={DEFAULT_THEME.colors.primary} />
      </View>
    );
  }
  return (
    <AuthProvider>
      <ThemeProvider>
        <EffectsProvider>
          <DataProvider>
            <ThemedStatusBar />
            <EffectLayer>
              <Stack screenOptions={{ headerShown: false }} />
            </EffectLayer>
            <GlobalNav />
          </DataProvider>
        </EffectsProvider>
      </ThemeProvider>
    </AuthProvider>
  );
}
