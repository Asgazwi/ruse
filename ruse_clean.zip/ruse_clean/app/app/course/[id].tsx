import { useState } from 'react';
import { ScrollView, StyleSheet, View } from 'react-native';
import { router, useLocalSearchParams } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { AppText as Text } from '../../components/app_text';
import { BouncyPressable as Pressable } from '../../components/bouncy_pressable';
import { BackHeader } from '../../components/back_header';
import { OfflineRibbon } from '../../components/offline_ribbon';
import { Floaters } from '../../components/floaters';
import { GlowButton } from '../../components/glow_button';
import { ProgressBar } from '../../components/progress_bar';
import { EmptyState } from '../../components/empty_state';
import { FadeInView } from '../../components/fade_in_view';
import { useTheme } from '../../lib/theme';
import { useData } from '../../lib/data';
import { card_palette } from '../../lib/look';
import { alpha_hex } from '../../lib/alpha_hex';
import { soft_shadow } from '../../lib/soft_shadow';
import { chapters_for, done_count, find_subject } from '../../lib/reader';
import { percent } from '../../lib/progress_helpers';
import { usePins } from '../../lib/pins';
import { latest_pin, pin_for } from '../../lib/pin_helpers';
import { Breadcrumb } from '../../components/breadcrumb';
import { category_of, encode_path } from '../../lib/category_helpers';
import { W } from '../../lib/words';
import { kind_label } from '../../lib/novel_kind';
import { display_name } from '../../lib/pin_helpers';
import { RecommendThemeBanner } from '../../components/recommend_theme_banner';
import { useNovelTheme } from '../../lib/use_novel_theme';
import { download_novel, novel_downloaded, remove_novel } from '../../lib/downloads';
import { NAV_CLEARANCE } from '../../lib/nav_clearance';

// A course: the list of its chapters. Tap one to read it.
export default function Course() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const { theme } = useTheme();
  const { data } = useData();
  const { pins } = usePins();
  const insets = useSafeAreaInsets();
  const c = theme.colors;

  const subject = find_subject(data?.subjects ?? [], id);
  // E4: recommend / apply exclusive theme for this novel while the screen is open.
  const novelTheme = useNovelTheme(subject?.id);
  const list = subject ? chapters_for(data?.chapters ?? [], subject.id) : [];
  const completed = data?.progress?.completed ?? [];
  const palette = card_palette(c);
  // "Continue where I stopped": the most recent pin in this course.
  const resume = latest_pin(pins, list.map((ch) => ch.id));
  const resume_chapter = resume ? list.find((ch) => ch.id === resume.chapter) : undefined;
  // Offline download (airplane mode). dl_busy shows progress; dl_tick re-reads the phone after a change.
  const [dl_busy, setDlBusy] = useState<string | null>(null);
  const [dl_note, setDlNote] = useState<string | null>(null);
  const [, setDlTick] = useState(0);

  if (!subject) {
    return (
      <View style={[s.center, { backgroundColor: c.bg }]}>
        <EmptyState emoji="🔎" title={`${W.Novel} not found`} body="It may have been removed. Go back and pull down to refresh.">
          <GlowButton label="Back to Home" on_press={() => router.replace('/')} color={c.primary} text_color={c.primaryFg} style={s.btn} />
        </EmptyState>
      </View>
    );
  }

  const done = done_count(list, completed);
  const cat = category_of(subject);
  const downloaded = novel_downloaded(subject, list);
  const toggle_download = async () => {
    if (dl_busy) return;
    setDlNote(null);
    if (downloaded) { remove_novel(subject, list); setDlTick((t) => t + 1); return; }
    setDlBusy('0');
    const r = await download_novel(subject, list, (d, t) => setDlBusy(`${d} of ${t}`));
    setDlBusy(null);
    setDlNote(r.failed > 0 ? `${r.failed} file(s) could not be saved. Check your connection and try again.` : 'Ready to read without internet.');
    setDlTick((t) => t + 1);
  };
  const crumbs = [
    { label: 'Home', on_press: () => router.replace('/') },
    ...cat.map((name, i) => ({ label: name, on_press: () => router.push(`/category?path=${encode_path(cat.slice(0, i + 1))}`) })),
    { label: subject.title },
  ];
  return (
    <View style={{ flex: 1, backgroundColor: c.bg }}>
      <Floaters />
      <ScrollView contentContainerStyle={{ paddingBottom: insets.bottom + NAV_CLEARANCE }}>
        <BackHeader
          top_padding={insets.top + 16}
          back_label="Home"
          title={subject.title}
          sub={[
            kind_label(subject.kind),
            subject.uploaderName || subject.createdBy ? `by ${display_name(subject.uploaderName || subject.createdBy, 'author')}` : '',
            subject.summary || (list.length ? `${done} of ${list.length} chapters done` : ''),
          ].filter(Boolean).join(' · ') || undefined}
        />
        <View style={{ padding: 20, gap: 12 }}>
          <OfflineRibbon />
          {novelTheme.show_banner && novelTheme.recommended ? (
            <RecommendThemeBanner
              recommended={novelTheme.recommended}
              on_yes={novelTheme.on_yes}
              on_always={novelTheme.on_always}
              on_no={novelTheme.on_no}
            />
          ) : null}
          {cat.length > 0 && <Breadcrumb parts={crumbs} />}
          {list.length > 0 && (
            <View style={[s.progress_card, soft_shadow(c.accent, 1), { backgroundColor: c.surface, borderColor: c.line }]}>
              <View style={s.progress_row}>
                <Text style={[s.progress_title, { color: c.ink }]}>Your progress</Text>
                <Text style={[s.progress_pct, { color: c.primary }]}>{percent(done, list.length)}%</Text>
              </View>
              <ProgressBar value={percent(done, list.length)} color={done >= list.length ? '#2e9e6b' : c.accent} track={c.line} height={12} />
              <Text style={{ color: c.muted, fontFamily: 'Figtree_500Medium', fontSize: 13, marginTop: 8 }}>
                {done} of {list.length} chapters done{done >= list.length ? ' 🎉' : ''}
              </Text>
            </View>
          )}
          {list.length > 0 && (
            <View style={[s.progress_card, { backgroundColor: c.surface, borderColor: c.line }]}>
              <Pressable onPress={toggle_download} disabled={!!dl_busy} accessibilityRole="button" style={s.progress_row}>
                <Text style={[s.progress_title, { color: c.ink }]}>{dl_busy ? `Downloading… ${dl_busy}` : downloaded ? 'Downloaded ✓' : 'Download for offline'}</Text>
                <Text style={[s.progress_pct, { color: c.primary }]}>{dl_busy ? '' : downloaded ? 'Remove' : 'Save'}</Text>
              </Pressable>
              <Text style={{ color: c.muted, fontFamily: 'Figtree_500Medium', fontSize: 13, marginTop: 6 }}>
                {dl_note ?? 'Pages, soundtrack and background are saved on this phone, so you can read in airplane mode. Signing out removes them.'}
              </Text>
            </View>
          )}
          {resume && resume_chapter && (
            <Pressable wiggle onPress={() => router.push(`/chapter/${resume.chapter}?block=${resume.block}`)} style={[s.card, s.row, soft_shadow(c.accent, 2), { backgroundColor: c.accent, borderColor: c.accent }]}>
              <View style={{ flex: 1 }}>
                <Text style={{ color: c.accentFg, fontFamily: 'Figtree_700Bold', fontSize: 16 }}>📌 Continue where you stopped</Text>
                <Text style={{ color: c.accentFg, fontFamily: 'Figtree_500Medium', opacity: 0.9, marginTop: 2 }} numberOfLines={1}>{resume_chapter.title}</Text>
              </View>
              <Text style={{ color: c.accentFg, fontSize: 28 }}>›</Text>
            </Pressable>
          )}
          {list.length === 0 && (
            <EmptyState emoji="📚" title="No chapters yet" body={`Upload a chapter for this ${W.novel} in Settings.`} />
          )}
          {list.map((ch, i) => {
            const is_done = completed.includes(ch.id);
            // Finished chapters turn green, so progress is visible at a glance.
            const color = is_done ? '#2e9e6b' : palette[i % palette.length];
            const pin = pin_for(pins, ch.id);
            return (
              <FadeInView key={ch.id} index={i}>
                <Pressable wiggle onPress={() => router.push(pin ? `/chapter/${ch.id}?block=${pin.block}` : `/chapter/${ch.id}`)} style={[s.card, s.row, soft_shadow(color, 1), { backgroundColor: c.surface, borderColor: is_done ? alpha_hex(color, 0.45) : c.line }]}>
                  <View style={[s.num_ring, { borderColor: alpha_hex(color, 0.28) }]}>
                    <View style={[s.num, { backgroundColor: color }]}>
                      <Text style={[s.num_text, { color: c.primaryFg }]}>{is_done ? '✓' : i + 1}</Text>
                    </View>
                  </View>
                  <View style={{ flex: 1 }}>
                    <Text style={[s.card_title, { color: c.ink }]}>{ch.title}</Text>
                    {!!ch.summary && <Text style={{ color: c.muted, fontFamily: 'Figtree_500Medium', lineHeight: 20 }}>{ch.summary}</Text>}
                    {!!ch.minutes && <Text style={[s.minutes, { color: c.muted }]}>⏱ {ch.minutes} min{is_done ? ' · done' : ''}{pin ? ' · 📌 pinned' : ''}</Text>}
                  </View>
                  <Text style={{ color: c.muted, fontSize: 26 }}>›</Text>
                </Pressable>
              </FadeInView>
            );
          })}
        </View>
      </ScrollView>
    </View>
  );
}

const s = StyleSheet.create({
  center: { flex: 1, alignItems: 'center', justifyContent: 'center', padding: 24, gap: 8 },
  btn: { marginTop: 18, alignSelf: 'stretch' },
  progress_card: { borderWidth: 1, borderRadius: 24, padding: 16, marginBottom: 18 },
  progress_row: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 10 },
  progress_title: { fontFamily: 'Figtree_700Bold', fontSize: 16 },
  progress_pct: { fontFamily: 'Figtree_700Bold', fontSize: 20 },
  card: { borderWidth: 1, borderRadius: 24, padding: 16, marginBottom: 14 },
  row: { flexDirection: 'row', alignItems: 'center', gap: 14 },
  card_title: { fontFamily: 'Figtree_700Bold', fontSize: 18, marginBottom: 2 },
  num_ring: { width: 54, height: 54, borderRadius: 27, borderWidth: 4, alignItems: 'center', justifyContent: 'center' },
  num: { width: 40, height: 40, borderRadius: 20, alignItems: 'center', justifyContent: 'center' },
  num_text: { fontFamily: 'Figtree_700Bold', fontSize: 18 },
  minutes: { fontFamily: 'Figtree_500Medium', fontSize: 13, marginTop: 4 },
});
