import { ScrollView, View } from 'react-native';
import { router } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useAuth } from '../lib/auth';
import { useTheme } from '../lib/theme';
import { useData } from '../lib/data';
import { OfflineRibbon } from '../components/offline_ribbon';
import { BackHeader } from '../components/back_header';
import { GlowButton } from '../components/glow_button';
import { ThemePicker } from '../components/theme_picker';
import { PushTestCard } from '../components/push_test_card';
import { SettingsRow, SettingsSection } from '../components/settings/settings_bits';
import { ProfileHeader } from '../components/settings/profile_header';
import { UsernameEditor } from '../components/settings/username_editor';
import { GenderChips } from '../components/settings/gender_chips';
import { HomeBackgroundCard } from '../components/settings/home_background_card';
import { TapEffectsCard } from '../components/settings/tap_effects_card';
import { AuthorTools } from '../components/settings/author_tools';
import { ReaderRoleCard } from '../components/settings/reader_role_card';
import { SavedFilesCard } from '../components/settings/saved_files_card';
import { is_admin, can_upload, role_label, role_of } from '../lib/roles';
import { NAV_CLEARANCE } from '../lib/nav_clearance';

// Settings = wiring only. Each group below is its own small component in components/settings/,
// and each one does its own saving and shows its own message right under its own buttons.
export default function Settings() {
  const { me, signOut, reload } = useAuth();
  const { theme } = useTheme();
  const { admin } = useData();
  const insets = useSafeAreaInsets();
  const c = theme.colors;

  return (
    <ScrollView style={{ backgroundColor: c.bg }} contentContainerStyle={{ paddingBottom: insets.bottom + NAV_CLEARANCE }}>
      <BackHeader
        top_padding={insets.top + 16}
        back_label="Home"
        title="Settings"
        sub={me?.email ? `${me.email} · ${role_label(role_of(me))}` : undefined}
      />
      <View style={{ padding: 20, paddingTop: 16 }}>
        <OfflineRibbon />

        <ProfileHeader me={me} reload={reload} />

        <SettingsSection title="About you">
          <UsernameEditor me={me} reload={reload} />
          <GenderChips me={me} reload={reload} />
        </SettingsSection>

        <SettingsSection title="Theme" plain>
          <ThemePicker />
        </SettingsSection>

        <SettingsSection title="Home screen">
          <HomeBackgroundCard />
        </SettingsSection>

        <SettingsSection title="Taps">
          <TapEffectsCard />
        </SettingsSection>

        {me?.allowed ? (
          <SettingsSection title="Notifications" plain>
            <PushTestCard />
          </SettingsSection>
        ) : null}

        {can_upload(me) ? <AuthorTools me={me} /> : <ReaderRoleCard me={me} reload={reload} />}

        {is_admin(me) ? (
          <SettingsSection title="People">
            <SettingsRow emoji="🛡️" label="Admin" hint="People and roles" count={admin?.requests.length ?? 0} on_press={() => router.push('/admin')} />
          </SettingsSection>
        ) : null}

        <SettingsSection title="Saved on this phone">
          <SavedFilesCard />
        </SettingsSection>

        <SettingsSection title="About">
          <SettingsRow emoji="🔒" label="Privacy" hint="What is kept, and who sees what" on_press={() => router.push('/privacy')} />
        </SettingsSection>

        <View style={{ marginTop: 28 }}>
          <GlowButton label="Sign out" outline danger color="#b3261e" text_color="#b3261e" on_press={async () => { await signOut(); router.replace('/'); }} />
        </View>
      </View>
    </ScrollView>
  );
}
