import { ScrollView, StyleSheet, View } from 'react-native';
import { router, useLocalSearchParams } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { BackHeader } from '../components/back_header';
import { OfflineRibbon } from '../components/offline_ribbon';
import { Floaters } from '../components/floaters';
import { CourseCard } from '../components/course_card';
import { kind_label } from '../lib/novel_kind';
import { display_name } from '../lib/pin_helpers';
import { CategoryCard } from '../components/category_card';
import { Breadcrumb } from '../components/breadcrumb';
import { GlowButton } from '../components/glow_button';
import { EmptyState } from '../components/empty_state';
import { useTheme } from '../lib/theme';
import { useData } from '../lib/data';
import { usePins } from '../lib/pins';
import { card_palette } from '../lib/look';
import { chapters_for, done_count } from '../lib/reader';
import { category_exists, children_of, decode_path, encode_path } from '../lib/category_helpers';
import { W } from '../lib/words';
import { NAV_CLEARANCE } from '../lib/nav_clearance';

// Inside one category: its sub-categories first, then the courses that live right here.
export default function Category() {
  const { path: path_param } = useLocalSearchParams<{ path?: string }>();
  const { theme } = useTheme();
  const { data } = useData();
  const { pins } = usePins();
  const insets = useSafeAreaInsets();
  const c = theme.colors;

  const path = decode_path(path_param);
  const subjects = data?.subjects ?? [];
  const palette = card_palette(c);

  if (path.length === 0 || !category_exists(subjects, path)) {
    return (
      <View style={[s.center, { backgroundColor: c.bg }]}>
        <EmptyState emoji="🗂️" title="Category not found" body="It may have been renamed. Go back and pull down to refresh.">
          <GlowButton label="Back to Home" on_press={() => router.replace('/')} color={c.primary} text_color={c.primaryFg} style={s.btn} />
        </EmptyState>
      </View>
    );
  }

  const { categories, courses } = children_of(subjects, path);
  const parent = path.slice(0, -1);
  const crumbs = [
    { label: 'Home', on_press: () => router.replace('/') },
    ...path.map((name, i) => ({
      label: name,
      on_press: i < path.length - 1 ? () => router.replace(`/category?path=${encode_path(path.slice(0, i + 1))}`) : undefined,
    })),
  ];

  return (
    <View style={{ flex: 1, backgroundColor: c.bg }}>
      <Floaters />
      <ScrollView contentContainerStyle={{ paddingBottom: insets.bottom + NAV_CLEARANCE }}>
        <BackHeader top_padding={insets.top + 16} back_label={parent.length ? parent[parent.length - 1] : 'Home'} title={path[path.length - 1]} />
        <View style={{ padding: 20 }}>
          <OfflineRibbon />
          <Breadcrumb parts={crumbs} />
          {categories.length === 0 && courses.length === 0 && <EmptyState emoji="🌸" title="Nothing in here yet" body={`${W.Novels} placed in this category will show up here.`} />}
          {categories.map((node, i) => <CategoryCard key={node.path.join('>')} node={node} color={palette[i % palette.length]} index={i} />)}
          {courses.map((sub, i) => {
            const chs = chapters_for(data?.chapters ?? [], sub.id);
            return (
              <CourseCard
                key={sub.id} id={sub.id} title={sub.title} summary={sub.summary}
                kind_label={kind_label(sub.kind)}
                byline={sub.uploaderName || sub.createdBy ? `by ${display_name(sub.uploaderName || sub.createdBy, 'author')}` : undefined}
                color={palette[(i + categories.length) % palette.length]}
                done={done_count(chs, data?.progress?.completed)} total={chs.length}
                pinned={pins.some((p) => p.subject === sub.id)}
                index={i + categories.length}
              />
            );
          })}
        </View>
      </ScrollView>
    </View>
  );
}

const s = StyleSheet.create({
  center: { flex: 1, alignItems: 'center', justifyContent: 'center', padding: 24, gap: 8 },
  btn: { marginTop: 18, alignSelf: 'stretch' },
});
