import { ScrollView, StyleSheet, View } from 'react-native';
import { router } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { AppText as Text } from '../components/app_text';
import { BouncyPressable as Pressable } from '../components/bouncy_pressable';
import { BackHeader } from '../components/back_header';
import { OfflineRibbon } from '../components/offline_ribbon';
import { useTheme } from '../lib/theme';
import { useData } from '../lib/data';
import { usePins } from '../lib/pins';
import { find_chapter } from '../lib/reader';
import { display_name, inbox_threads, is_unanswered, short_date, unanswered_count } from '../lib/pin_helpers';
import { NAV_CLEARANCE } from '../lib/nav_clearance';

// For the person who uploaded chapters: what readers wrote on them, newest first.
// "Open" goes to that spot in the reader, where you can reply or add to the chapter.
export default function Comments() {
  const { theme } = useTheme();
  const { data } = useData();
  const { comments } = usePins();
  const insets = useSafeAreaInsets();
  const c = theme.colors;

  const threads = inbox_threads(comments);
  const waiting = unanswered_count(comments);

  return (
    <View style={{ flex: 1, backgroundColor: c.bg }}>
      <ScrollView contentContainerStyle={{ paddingBottom: insets.bottom + NAV_CLEARANCE }}>
        <BackHeader
          top_padding={insets.top + 16}
          back_label="Home"
          title="Comments on my chapters"
          sub={threads.length ? `${waiting} waiting for a reply` : undefined}
        />
        <View style={{ padding: 20 }}>
          <OfflineRibbon />
          {threads.length === 0 && (
            <View style={[s.card, { backgroundColor: c.surface, borderColor: c.line }]}>
              <Text style={[s.card_title, { color: c.ink }]}>No comments yet</Text>
              <Text style={{ color: c.muted, fontFamily: 'Figtree_500Medium' }}>When someone comments on a chapter you uploaded, it shows up here.</Text>
            </View>
          )}
          {threads.map((t) => {
            const chapter = find_chapter(data?.chapters ?? [], t.root.chapter);
            const open_it = () => router.push(t.root.block >= 0 ? `/chapter/${t.root.chapter}?block=${t.root.block}&sheet=1` : `/chapter/${t.root.chapter}?sheet=1`);
            const last = t.replies.length ? t.replies[t.replies.length - 1] : null;
            return (
              <Pressable key={t.root.id} wiggle onPress={open_it} style={[s.card, { backgroundColor: c.surface, borderColor: is_unanswered(t) ? c.primary : c.line }]}>
                <Text style={{ color: c.muted, fontFamily: 'Figtree_500Medium', fontSize: 12 }}>
                  {chapter?.title || t.root.chapter}{t.root.block >= 0 ? ` · part ${t.root.block + 1}` : ''} · {short_date(t.root.created)}
                </Text>
                <Text style={[s.who, { color: c.ink }]}>{display_name(t.root.name, 'Someone')}</Text>
                <Text style={{ color: c.ink, fontFamily: 'Figtree_500Medium', fontSize: 15 }} numberOfLines={4}>{t.root.text}</Text>
                {last && (
                  <Text style={{ color: c.muted, fontFamily: 'Figtree_500Medium', fontSize: 13, marginTop: 8 }} numberOfLines={2}>
                    {last.mine ? 'You' : display_name(last.name, 'Someone')}: {last.text}
                  </Text>
                )}
                <Text style={{ color: is_unanswered(t) ? c.primary : c.muted, fontFamily: 'Figtree_700Bold', fontSize: 13, marginTop: 10 }}>
                  {is_unanswered(t) ? 'Needs a reply · Open ›' : 'Open ›'}
                </Text>
              </Pressable>
            );
          })}
        </View>
      </ScrollView>
    </View>
  );
}

const s = StyleSheet.create({
  card: { borderWidth: 1, borderRadius: 22, padding: 16, marginBottom: 12 },
  card_title: { fontFamily: 'Figtree_700Bold', fontSize: 18, marginBottom: 2 },
  who: { fontFamily: 'Figtree_700Bold', fontSize: 16, marginTop: 2, marginBottom: 2 },
});
