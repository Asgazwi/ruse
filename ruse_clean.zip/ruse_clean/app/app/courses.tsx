// Phase 7 · "Your courses" (Settings extras): see my courses, make a new one, download a
// chapter template filled in for a course, delete courses and chapters, reset my progress.
import { useState } from 'react';
import { Alert, Image, ScrollView, StyleSheet, TextInput, View } from 'react-native';
import { router } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { AppText as Text } from '../components/app_text';
import { BouncyPressable as Pressable } from '../components/bouncy_pressable';
import { Floaters } from '../components/floaters';
import { GlowButton } from '../components/glow_button';
import { OfflineRibbon } from '../components/offline_ribbon';
import { useTheme } from '../lib/theme';
import { useData } from '../lib/data';
import { useAuth } from '../lib/auth';
import { api } from '../lib/backend';
import { share_json_file } from '../lib/share_json';
import {
  ACTION_DELETE_CHAPTER, ACTION_DELETE_SUBJECT, ACTION_SAVE_SUBJECT,
} from '../lib/actions';
import { W } from '../lib/words';
import { is_admin, can_upload } from '../lib/roles';
import { display_name } from '../lib/pin_helpers';
import { kind_label, NOVEL_KINDS, normalize_kind } from '../lib/novel_kind';
import type { NovelKind, Subject } from '../lib/types';
import {
  can_manage, chapter_template_for, course_summary_error, course_title_error, delete_course_warning,
  my_courses, parse_category_text,
} from '../lib/course_admin_helpers';
import { comic_template, novel_template, theme_template_for_novel } from '../lib/templates';
import { clear_novel_background, upload_novel_background } from '../lib/novel_background';
import { upload_manga_chapter } from '../lib/manga_upload';
import { save_track_link } from '../lib/soundtrack';
import { NAV_CLEARANCE } from '../lib/nav_clearance';

export default function Courses() {
  const { theme } = useTheme();
  const { data, refresh, reset_progress } = useData();
  const { me } = useAuth();
  const insets = useSafeAreaInsets();
  const c = theme.colors;

  const email = me?.email ?? '';
  const isOwner = is_admin(me);  // admins manage every novel
  const author = can_upload(me); // readers only get "Reset my progress" on this screen
  const subjects = data?.subjects ?? [];
  const chapters = data?.chapters ?? [];
  const mine = my_courses(subjects, chapters, email, isOwner);

  const [title, setTitle] = useState('');
  const [summary, setSummary] = useState('');
  const [category, setCategory] = useState('');
  const [kind, setKind] = useState<NovelKind>('novel');
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState<string | null>(null);
  const [trackFor, setTrackFor] = useState<string | null>(null); // the novel whose soundtrack link field is open
  const [trackLink, setTrackLink] = useState('');

  // Runs one backend write, shows its error if any, then reloads the data.
  async function write(label: string, action: string, args: unknown[]): Promise<boolean> {
    setBusy(true);
    setMessage(null);
    try {
      await api(action, ...args);
      await refresh();
      return true;
    } catch (err) {
      setMessage(`${label} did not work: ${String((err as Error)?.message ?? err)}`);
      return false;
    } finally {
      setBusy(false);
    }
  }

  async function createCourse() {
    const cat = parse_category_text(category);
    const problem = course_title_error(title) ?? course_summary_error(summary) ?? cat.error;
    if (problem) { setMessage(problem); return; }
    const ok = await write(`Creating the ${W.novel}`, ACTION_SAVE_SUBJECT, [{ title: title.trim(), summary: summary.trim(), category: cat.parts, kind }]);
    if (ok) { setTitle(''); setSummary(''); setCategory(''); setKind('novel'); setMessage(`${W.Novel} created. Add chapters with a chapter template.`); }
  }

  function confirmDeleteCourse(course: { id: string; title: string }) {
    Alert.alert(`Delete ${W.novel}?`, delete_course_warning(course, chapters, email), [
      { text: 'Cancel', style: 'cancel' },
      { text: 'Delete', style: 'destructive', onPress: () => { void write(`Deleting the ${W.novel}`, ACTION_DELETE_SUBJECT, [course.id]); } },
    ]);
  }

  function confirmDeleteChapter(chapter: { id: string; title: string }) {
    Alert.alert('Delete chapter?', `Delete "${chapter.title}"? This cannot be undone.`, [
      { text: 'Cancel', style: 'cancel' },
      { text: 'Delete', style: 'destructive', onPress: () => { void write('Deleting the chapter', ACTION_DELETE_CHAPTER, [chapter.id]); } },
    ]);
  }

  function confirmReset() {
    Alert.alert('Reset my progress?', `Every chapter will show as not finished. Your ${W.novels} stay.`, [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Reset', style: 'destructive',
        onPress: async () => {
          setBusy(true);
          setMessage(null);
          const result = await reset_progress();
          setBusy(false);
          setMessage(result === 'saved' ? 'Your progress is reset.' : 'Could not reset progress. Check your connection and try again.');
        },
      },
    ]);
  }

  // B4 (new): the app makes the file itself. A comic gets a page list, a novel gets text blocks.
  async function downloadTemplate(courseId: string, count: number, course_kind?: string) {
    try {
      await share_json_file(`${courseId}-chapter-template.json`, chapter_template_for(courseId, count, chapters.map((ch) => ch.id), course_kind));
    } catch (err) {
      setMessage(`Could not share the template: ${String((err as Error)?.message ?? err)}`);
    }
  }

  // Whole-file templates: one new novel, or one new comic, with example chapters.
  async function downloadWhole(which: 'novel' | 'comic') {
    try {
      await share_json_file(which === 'novel' ? 'marginalia-novel-template.json' : 'marginalia-comic-template.json', which === 'novel' ? novel_template() : comic_template());
    } catch (err) {
      setMessage(`Could not share the template: ${String((err as Error)?.message ?? err)}`);
    }
  }

  // E4: theme template with forSubject already set to this novel.
  async function downloadNovelTheme(course: { id: string; title: string }) {
    try {
      await share_json_file(
        `${course.id}-theme-template.json`,
        theme_template_for_novel(course.id, course.title),
      );
    } catch (err) {
      setMessage(`Could not share the theme template: ${String((err as Error)?.message ?? err)}`);
    }
  }

  // E5: author reading background (needs folderId from backend).
  async function pickBackground(course: Subject) {
    const folderId = typeof course.folderId === 'string' ? course.folderId.trim() : '';
    if (!folderId) {
      setMessage(`This ${W.novel} has no Drive folder yet. The backend must create folderId on saveSubject (E1).`);
      return;
    }
    setBusy(true);
    setMessage(null);
    try {
      const r = await upload_novel_background({ subject_id: course.id, folder_id: folderId });
      if (r.ok === false) {
        if (r.error !== 'cancelled') setMessage(r.error);
        return;
      }
      await refresh();
      setMessage(`Reading background saved for “${course.title}”.`);
    } catch (err) {
      setMessage(`Background upload failed: ${String((err as Error)?.message ?? err)}`);
    } finally {
      setBusy(false);
    }
  }

  // Manga chapter from phone photos (E2): the author picks pages in order; they are uploaded and saved as one chapter.
  async function addMangaChapter(course: Subject, order: number) {
    const folderId = typeof course.folderId === 'string' ? course.folderId.trim() : '';
    setMessage(null);
    setBusy(true);
    try {
      const r = await upload_manga_chapter({
        subject_id: course.id,
        folder_id: folderId,
        title: `Chapter ${order + 1}`,
        order,
        on_progress: (done, total) => setMessage(`Uploading pages ${done} / ${total}…`),
      });
      if (r.ok === false) {
        if (r.error !== 'cancelled') setMessage(r.error);
        return;
      }
      await refresh();
      setMessage(`Saved ${r.count} pages as “Chapter ${order + 1}” in “${course.title}”. Pull down on Home to see it.`);
    } catch (err) {
      setMessage(`Chapter upload failed: ${String((err as Error)?.message ?? err)}`);
    } finally {
      setBusy(false);
    }
  }

  // Soundtrack (v63): the author pastes a direct link to the audio file on a file host. Readers get it through the music bar.
  async function saveSoundtrackLink(course: Subject) {
    setMessage(null);
    setBusy(true);
    try {
      const r = await save_track_link(course.id, trackLink);
      if (r.ok === false) { setMessage(r.error); return; }
      setTrackFor(null);
      setTrackLink('');
      await refresh();
      setMessage(`Soundtrack linked to “${course.title}”. Readers can save it and turn it on in the chapter.`);
    } catch (err) {
      setMessage(`Could not save the soundtrack link: ${String((err as Error)?.message ?? err)}`);
    } finally {
      setBusy(false);
    }
  }

  function openSoundtrackField(course: Subject) {
    setMessage(null);
    setTrackLink(typeof course.musicUrl === 'string' ? course.musicUrl : '');
    setTrackFor((open) => (open === course.id ? null : course.id));
  }

  function confirmClearBackground(course: Subject) {
    Alert.alert('Remove reading background?', `Readers will only see the theme colours for “${course.title}”.`, [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Remove',
        style: 'destructive',
        onPress: async () => {
          setBusy(true);
          setMessage(null);
          try {
            await clear_novel_background(course.id);
            await refresh();
            setMessage('Reading background removed.');
          } catch (err) {
            setMessage(`Could not remove background: ${String((err as Error)?.message ?? err)}`);
          } finally {
            setBusy(false);
          }
        },
      },
    ]);
  }

  const field = [s.input, { color: c.ink, borderColor: c.line, backgroundColor: c.surface }];

  return (
    <View style={{ flex: 1, backgroundColor: c.bg }}>
      <Floaters />
      <ScrollView contentContainerStyle={{ paddingBottom: insets.bottom + NAV_CLEARANCE }}>
        <View style={[s.header, { paddingTop: insets.top + 12 }]}>
          <Pressable onPress={() => (router.canGoBack() ? router.back() : router.replace('/settings'))} hitSlop={12}>
            <Text style={{ color: c.primary, fontFamily: 'Figtree_700Bold' }}>‹ Settings</Text>
          </Pressable>
          <Text style={[s.title, { color: c.ink }]}>{author ? `Your ${W.novels}` : 'My progress'}</Text>
        </View>

        <View style={s.body}>
          <OfflineRibbon />
          {message ? <Text style={[s.note, { color: c.ink, backgroundColor: c.surface, borderColor: c.line }]}>{message}</Text> : null}

          {author && (
          <View style={[s.card, { backgroundColor: c.surface, borderColor: c.line }]}>
            <Text style={[s.heading, { color: c.ink }]}>New {W.novel}</Text>
            <TextInput value={title} onChangeText={setTitle} placeholder={`${W.Novel} name`} placeholderTextColor={c.muted} maxLength={80} style={field} />
            <TextInput value={summary} onChangeText={setSummary} placeholder="Short summary (optional)" placeholderTextColor={c.muted} maxLength={300} multiline style={field} />
            <TextInput value={category} onChangeText={setCategory} placeholder="Category, e.g. DATA > DATA ANALYSIS (optional)" placeholderTextColor={c.muted} style={field} />
            <Text style={{ color: c.ink, fontFamily: 'Figtree_700Bold', marginTop: 4 }}>Kind</Text>
            <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>
              {NOVEL_KINDS.map((k) => {
                const on = kind === k;
                return (
                  <Pressable
                    key={k}
                    onPress={() => setKind(k)}
                    style={{
                      height: 36, paddingHorizontal: 14, borderRadius: 18, borderWidth: 2,
                      borderColor: on ? c.primary : c.line, backgroundColor: on ? c.primary : 'transparent',
                      justifyContent: 'center',
                    }}>
                    <Text style={{ color: on ? c.primaryFg : c.ink, fontFamily: 'Figtree_700Bold' }}>{kind_label(k)}</Text>
                  </Pressable>
                );
              })}
            </View>
            <GlowButton label={`Create ${W.novel}`} on_press={createCourse} disabled={busy} size="md" color={c.primary} text_color={c.primaryFg} />
            <Text style={{ color: c.muted, fontFamily: 'Figtree_500Medium', fontSize: 13, marginTop: 6 }}>
              Or fill in a whole file and upload it from Settings → Choose file:
            </Text>
            <View style={s.actions}>
              <GlowButton label={`Download ${W.novel} template`} on_press={() => downloadWhole('novel')} disabled={busy} size="md" outline color={c.primary} text_color={c.primaryFg} />
              <GlowButton label="Download comic template" on_press={() => downloadWhole('comic')} disabled={busy} size="md" outline color={c.primary} text_color={c.primaryFg} />
            </View>
          </View>
          )}

          {author && mine.length === 0 ? (
            <Text style={{ color: c.muted, fontFamily: 'Figtree_500Medium', marginTop: 8 }}>You have no {W.novels} or chapters yet.</Text>
          ) : null}

          {(author ? mine : []).map(({ course, chapters: inside }) => (
            <View key={course.id} style={[s.card, { backgroundColor: c.surface, borderColor: c.line }]}>
              <Text style={[s.heading, { color: c.ink }]}>{course.title}</Text>
              <Text style={[s.mono, { color: c.muted }]}>
                {kind_label((course as any).kind)} · id: {course.id} · {inside.length} chapter{inside.length === 1 ? '' : 's'}
                {(course as any).uploaderName || course.createdBy ? ` · by ${display_name((course as any).uploaderName || course.createdBy, 'author')}` : ''}
                {(course as any).folderId ? ' · folder ready' : ''}
              </Text>

              {can_manage(course.createdBy, email, isOwner) && typeof (course as Subject).backgroundUrl === 'string' && (course as Subject).backgroundUrl!.trim() ? (
                <Image
                  source={{ uri: (course as Subject).backgroundUrl!.trim() }}
                  style={{ width: '100%', height: 96, borderRadius: 14, marginTop: 4 }}
                  resizeMode="cover"
                />
              ) : null}

              {inside.map((ch) => (
                <View key={ch.id} style={[s.row, { borderColor: c.line }]}>
                  <View style={{ flex: 1 }}>
                    <Text style={{ color: c.ink, fontFamily: 'Figtree_700Bold' }}>{ch.title}</Text>
                    <Text style={[s.mono, { color: c.muted }]}>{ch.id}{ch.uploaderName || ch.uploadedBy ? ` · by ${display_name((ch as any).uploaderName || ch.uploadedBy, 'author')}` : ''}</Text>
                  </View>
                  {can_manage(ch.uploadedBy, email, isOwner) ? (
                    <GlowButton label="Delete" on_press={() => confirmDeleteChapter(ch)} disabled={busy} size="sm" outline color={c.ink} text_color={c.ink} />
                  ) : null}
                </View>
              ))}

              <View style={s.actions}>
                <GlowButton label="Chapter template" on_press={() => downloadTemplate(course.id, inside.length, normalize_kind((course as Subject).kind))} disabled={busy} size="md" color={c.accent} text_color={c.accentFg} />
                {can_manage(course.createdBy, email, isOwner) ? (
                  <GlowButton label={`Theme for this ${W.novel}`} on_press={() => downloadNovelTheme(course)} disabled={busy} size="md" outline color={c.primary} text_color={c.primaryFg} />
                ) : null}
                {can_manage(course.createdBy, email, isOwner) && ['manga', 'webtoon'].includes(normalize_kind((course as Subject).kind)) ? (
                  <GlowButton label="Add manga chapter from photos" on_press={() => addMangaChapter(course as Subject, inside.length)} disabled={busy} size="md" outline color={c.primary} text_color={c.primaryFg} />
                ) : null}
                {can_manage(course.createdBy, email, isOwner) ? (
                  <GlowButton label={(course as Subject).musicUrl ? 'Change soundtrack link' : 'Add soundtrack link'} on_press={() => openSoundtrackField(course as Subject)} disabled={busy} size="md" outline color={c.primary} text_color={c.primaryFg} />
                ) : null}
                {can_manage(course.createdBy, email, isOwner) && trackFor === course.id ? (
                  <View style={{ gap: 8 }}>
                    <TextInput
                      value={trackLink}
                      onChangeText={setTrackLink}
                      placeholder="Paste the direct link to the audio file"
                      placeholderTextColor={c.muted}
                      autoCapitalize="none"
                      autoCorrect={false}
                      keyboardType="url"
                      style={field}
                    />
                    <Text style={{ color: c.muted, fontFamily: 'Figtree_500Medium', fontSize: 12 }}>
                      A pasted link must open the audio file itself, not a web page. Dropbox links with dl=1 work best for big files.
                    </Text>
                    <GlowButton label={busy ? 'Checking the link…' : 'Save soundtrack link'} on_press={() => saveSoundtrackLink(course as Subject)} disabled={busy || !trackLink.trim()} size="md" color={c.primary} text_color={c.primaryFg} />
                  </View>
                ) : null}
                {can_manage(course.createdBy, email, isOwner) ? (
                  <GlowButton label={(course as Subject).backgroundUrl ? 'Change background' : 'Reading background'} on_press={() => pickBackground(course as Subject)} disabled={busy} size="md" outline color={c.primary} text_color={c.primaryFg} />
                ) : null}
                {can_manage(course.createdBy, email, isOwner) && (course as Subject).backgroundUrl ? (
                  <GlowButton label="Remove background" on_press={() => confirmClearBackground(course as Subject)} disabled={busy} size="md" outline color={c.ink} text_color={c.ink} />
                ) : null}
                {can_manage(course.createdBy, email, isOwner) ? (
                  <GlowButton label={`Delete ${W.novel}`} on_press={() => confirmDeleteCourse(course)} disabled={busy} size="md" outline color={c.ink} text_color={c.ink} />
                ) : null}
              </View>
            </View>
          ))}

          <GlowButton label="Reset my progress" on_press={confirmReset} disabled={busy} size="md" outline color={c.ink} text_color={c.ink} style={{ marginTop: 8 }} />
        </View>
      </ScrollView>
    </View>
  );
}

const s = StyleSheet.create({
  header: { paddingHorizontal: 20, paddingBottom: 12, gap: 6 },
  title: { fontFamily: 'Figtree_700Bold', fontSize: 26 },
  body: { padding: 20, gap: 14 },
  card: { borderRadius: 20, borderWidth: 1, padding: 16, gap: 10 },
  heading: { fontFamily: 'Figtree_700Bold', fontSize: 18 },
  mono: { fontSize: 12 },
  note: { padding: 12, borderRadius: 14, borderWidth: 1, fontFamily: 'Figtree_500Medium' },
  input: { borderWidth: 1, borderRadius: 14, paddingHorizontal: 12, paddingVertical: 10, fontFamily: 'Figtree_500Medium' },
  btn: { paddingHorizontal: 18, height: 44, borderRadius: 22, justifyContent: 'center', alignItems: 'center' },
  btnText: { fontFamily: 'Figtree_700Bold' },
  small: { paddingHorizontal: 12, height: 32, borderRadius: 16, borderWidth: 1, justifyContent: 'center', marginLeft: 8 },
  row: { flexDirection: 'row', alignItems: 'center', borderTopWidth: StyleSheet.hairlineWidth, paddingTop: 10 },
  actions: { flexDirection: 'row', flexWrap: 'wrap', gap: 10, marginTop: 4 },
});
