// "Read me first": the rules and exact steps for a successful upload. Static text only.
// Keep it in step with lib/upload_check.ts and Code.gs (the limits below come from them).
import { ScrollView, StyleSheet, View } from 'react-native';
import { router } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { AppText as Text } from '../components/app_text';
import { BouncyPressable as Pressable } from '../components/bouncy_pressable';
import { Floaters } from '../components/floaters';
import { useTheme } from '../lib/theme';
import { W } from '../lib/words';
import { NAV_CLEARANCE } from '../lib/nav_clearance';

const NOVEL_STEPS = [
  `Settings → ${W.Novel} template. Save the file and open it in a text editor.`,
  `The top block is called \"novel\". Give it a \"title\" with your ${W.novel} name (up to 80 characters). Its id is made from it automatically. Older files that say \"course\" still upload.`,
  'Write your chapters in "chapters" (1 to 100). Delete the sample chapters you do not need.',
  `Settings → Choose file → pick the file. The app checks it first. If it is fine: "${W.Novel} … saved with N chapters".`,
  'Go to Home and pull down to refresh.',
];

const CHAPTER_STEPS = [
  `Settings → Your ${W.novels} → Chapter template, next to your ${W.novel}. This file already has the ${W.novel} id filled in.`,
  'Change "title" and write the "blocks". The "id" is filled in for you; change it only if you want, and it must be unique (lowercase letters, digits and dashes).',
  `Set "order" to the chapter position in the ${W.novel}: 0 for the first, 1 for the second, and so on.`,
  'Settings → Choose file → pick the file. Result: "Saved 1 chapter".',
];

const RULES = [
  'Plain text only. No HTML, no pasted formatting.',
  'File type: .json. Commas, quotes and brackets must be right. Start from a template and only change the text.',
  `${W.Novel}: title 1 to 80 characters, summary up to 300. The whole ${W.novel} is saved only if every chapter is correct.`,
  'Chapter: title up to 120 characters, summary up to 400, "minutes" a whole number from 1 to 240, 1 to 100 blocks.',
  'Block types: p (text), h (heading, up to 200), code (text), list (items, 1 to 50), table (headers, 1 to 8; each row needs one cell per header), callout (kind tip, warn or ok, then text up to 1000).',
  'Paragraph and code text: up to 4000 characters. List items: up to 500 each. Table cells: up to 300 each.',
  'One saved chapter can be at most about 45,000 characters. Split longer chapters into two.',
  `Category (optional, in the ${W.novel}): "category": "DATA > DATA ANALYSIS". Up to 4 levels, names up to 40 characters.`,
  'Uploading a chapter with an id that already exists replaces it, but only if you uploaded it (or you are the owner).',
  `Themes can be uploaded only by the owner. Everyone else can upload ${W.novels} and chapters.`,
];

const THEME_RULES = [
  'Owner only. Settings → Theme template, then Choose file. Themes are checked before they are saved.',
  'Sound: "effects.sound" plays on each tap. Use a name (none, glass, harp, silk, water, piano, swell, or the older pop, bubble, chime, sparkle, tick, fanfare) or a sound code: {"wave": "sine" | "square" | "triangle" | "glass" | "harp" | "silk" | "water" | "piano" | "swell", "notes": [660, 990] (1 to 16 Hz values, 80 to 2000), "step_ms": 30 to 400, "volume": 0.05 to 0.6}.',
  'Fonts: "font" (body text) and "heading_font" (titles and buttons). Choose from Figtree, Newsreader, Inter, Merriweather, Lora, Roboto Mono or Quicksand.',
  `"radius": corner radius of ${W.novel} and folder cards, 4 to 32.`,
  '"colors": nine hex colours (bg, surface, ink, muted, line, primary, primaryFg, accent, accentFg).',
  '"effects" (optional, data only, never code):',
  '  • "tap": up to 6 recipes, up to 40 pieces per tap. Each: "shape" (glyph, dot, ring or rect), "glyph" (1 to 4 characters, for glyph), "colors" (1 to 6), "count" (1 to 24), "size": [min, max] 4 to 60, "spread" 0 to 300, "rise" -200 to 300, "spin" -720 to 720 degrees, "duration" 200 to 3000 ms, "grow" true or false.',
  '  • "background": up to 4 recipes, up to 30 floating pieces. Each: "shape", "glyph", "colors", "count" (1 to 20), "size", "duration" 8000 to 60000 ms, "opacity" 0.1 to 0.8.',
  '  • "haptic": true or false (a soft tick on each tap).',
  'Without "effects", the old named "effect" (hearts, petals, sparkle...) is used.',
];

const ERRORS = [
  ['"That file is not valid JSON"', 'A comma, quote or bracket is wrong. Start again from the template.'],
  ['"has type …"', 'Use only p, h, list, table, code or callout.'],
  [`"Unknown ${W.novel}"`, `Create the ${W.novel} first (Your ${W.novels} → New ${W.novel}), then use its id as "subject".`],
  ['"needs an "id"" or "needs an "order""', 'A single chapter needs a unique lowercase "id", a whole-number "order" and "schemaVersion": 1. The chapter template has them.'],
  ['"belongs to someone else"', 'Pick a different chapter id, or ask the owner.'],
  ['"Only the owner can do that"', 'Themes are owner-only. Send the file to the owner.'],
  ['"Saved 2 of 5 chapters, then …"', 'Chapter 3 failed. The first two are saved. Fix chapter 3 and upload only the rest.'],
  ['"Access denied"', 'Your account is not approved yet. Ask the owner to approve you.'],
];

export default function ReadMe() {
  const { theme } = useTheme();
  const insets = useSafeAreaInsets();
  const c = theme.colors;
  const card = [s.card, { backgroundColor: c.surface, borderColor: c.line }];
  const body = { color: c.ink, fontFamily: 'Figtree_500Medium' };

  return (
    <View style={{ flex: 1, backgroundColor: c.bg }}>
      <Floaters />
      <ScrollView contentContainerStyle={{ paddingBottom: insets.bottom + NAV_CLEARANCE }}>
        <View style={[s.header, { paddingTop: insets.top + 12 }]}>
          <Pressable onPress={() => (router.canGoBack() ? router.back() : router.replace('/settings'))} hitSlop={12}>
            <Text style={{ color: c.primary, fontFamily: 'Figtree_700Bold' }}>‹ Settings</Text>
          </Pressable>
          <Text style={[s.title, { color: c.ink }]}>Read me first</Text>
        </View>

        <View style={s.body}>
          <View style={card}>
            <Text style={[s.heading, { color: c.ink }]}>Upload a whole {W.novel}</Text>
            {NOVEL_STEPS.map((step, i) => <Text key={i} style={body}>{`${i + 1}. ${step}`}</Text>)}
          </View>

          <View style={card}>
            <Text style={[s.heading, { color: c.ink }]}>Add one chapter to a {W.novel}</Text>
            <Text style={body}>The {W.novel} must already exist.</Text>
            {CHAPTER_STEPS.map((step, i) => <Text key={i} style={body}>{`${i + 1}. ${step}`}</Text>)}
          </View>

          <View style={card}>
            <Text style={[s.heading, { color: c.ink }]}>Rules</Text>
            {RULES.map((rule, i) => <Text key={i} style={body}>{`• ${rule}`}</Text>)}
          </View>

          <View style={card}>
            <Text style={[s.heading, { color: c.ink }]}>Themes (owner)</Text>
            {THEME_RULES.map((rule, i) => <Text key={i} style={body}>{rule}</Text>)}
          </View>

          <View style={card}>
            <Text style={[s.heading, { color: c.ink }]}>If it fails</Text>
            {ERRORS.map(([msg, fix]) => (
              <View key={msg} style={{ gap: 2 }}>
                <Text style={{ color: c.primary, fontFamily: 'Figtree_700Bold' }}>{msg}</Text>
                <Text style={body}>{fix}</Text>
              </View>
            ))}
          </View>
        </View>
      </ScrollView>
    </View>
  );
}

const s = StyleSheet.create({
  header: { paddingHorizontal: 20, paddingBottom: 12, gap: 6 },
  title: { fontFamily: 'Figtree_700Bold', fontSize: 26 },
  body: { padding: 20, gap: 14 },
  card: { borderRadius: 20, borderWidth: 1, padding: 16, gap: 10 },
  heading: { fontFamily: 'Figtree_700Bold', fontSize: 18 },
});
