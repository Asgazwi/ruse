# RUSE (chat-only first)

Clean package: current frontend (v65) + fixed chat-only Supabase backend + active plan.

## Start here
1. Read **`RUSE_PLAN_v4_chat_only.md`** (the only active plan).
2. Backend is under `supabase/`. Frontend is under `app/`.

## Layout

```
RUSE_PLAN_v4_chat_only.md     ← active plan (read this)
README.md

app/                          ← Expo / React Native frontend (v65)
  app/                        ← screens (expo-router)
  components/
  lib/                        ← includes lib/sb/ (empty switch ready for Supabase handlers)
  assets/
  package.json
  ...

supabase/
  migrations/
    001_profiles_and_access.sql
    002_chat.sql
    003_guards_and_helpers.sql
  ruse_chat_all.sql           ← same three joined (use this OR the migrations, never both)
  tests/
    rls_chat.sql              ← run on a throwaway database after the migrations

file_service/                 ← Apps Script file service (avatars later)
  json_to_clasp.mjs
  ruse_file_service.json

archive/                      ← old plans & full SQL (parked, reference only)
  RUSE_PLAN_v2.md
  SUPABASE_PLAN_v2.md
  RUSE_PLAN_v3-1.md
  ruse_all.sql
```

## What is active vs parked

**Active (this package):**
- Sign-in, profiles, access control, plain-text chat (500 chars, 30-day retention)
- SQL migrations 001–003 + tests
- Frontend as it exists today (still talking to the old Apps Script backend)

**Parked (see archive/):**
- Catalog, comments/pins, themes, progress, friends/groups, end-to-end encrypted chat, full import scripts

## Immediate next steps (you)

1. Create a **throwaway** Supabase project (or local Postgres).
2. Run migrations `001` → `002` → `003` (or paste `ruse_chat_all.sql`).
3. Run `supabase/tests/rls_chat.sql`.
4. Fix any errors that appear, then create the real project.

Do **not** point the real app at Supabase until the throwaway tests pass.

## Notes
- Nothing in `supabase/` has been executed on a real Postgres yet.
- The old Apps Script backend continues to serve everything that is still parked.
- Old plan files that used to live inside `app/` were moved to `archive/` so there is only one active plan.
