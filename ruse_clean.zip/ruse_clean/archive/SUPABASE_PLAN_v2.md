# SUPABASE_PLAN.md: moving RUSE from Apps Script + Sheets to Supabase

Status: SQL for phases 0 to 4 is written in `supabase/migrations/` (001 to 005) with tests in `supabase/tests/`; the Supabase project is not created and the app is not connected. The 005 tests (G01 to G40) have **not been run**: no Postgres was available when they were written. Drive stays for photos and files.
Rule for this whole plan: **the app keeps working at every step.** Apps Script keeps running until the very last phase, and we move one group of actions at a time.

> Everything here is written for the Expo app in this project. All SQL below is **untested** (no database was available while writing it). It is meant to be run in order in a real Supabase project, and each phase has a test list to prove it works before moving on.

## Progress (frontend side)
- [x] `lib/backend.ts` switch with an empty `MOVED` set, and `lib/sb/` ready for handlers (section 13)
- [~] Phase 5 app work: track link field, content-type check, Save for offline, Clear saved downloads with size (waiting for your phone check)
- [x] Soundtrack upload code removed (`uploadPart`, chunked upload)
- [x] SQL written: 001 profiles, 002 chat, 003 catalog, 004 comments and pins, 005 guards and helpers (file names follow run order, see section 4)
- [~] Tests for 005 (`supabase/tests/rls_test.sql`, section 5, G01 to G40): written, **run them first**
- [x] Theme `button` block (v65) is allowed and validated by `theme_data_ok()` in 005
- [ ] Phase 0 **(you)**: create the project, turn on Google, put URL and anon key in `.env`, back up the Sheets, install the packages
- [ ] Phase 1 handlers in `lib/sb/` (sign-in, profiles, admin), then add their names to `MOVED`
- [ ] Phases 2, 3, 4, 6

---

## 1. Why move, and what we get

| Today (Apps Script + Sheets) | After (Supabase) |
|---|---|
| Chat refreshes every 8 seconds by asking the server | Messages arrive instantly (Realtime) |
| Every call waits 1 to 3 seconds (cold start, sheet reads) | Calls take tens of milliseconds |
| Rules are checked by code you must remember to call | Rules live in the database (Row Level Security), so a forgotten check cannot leak data |
| Push is sent from inside Apps Script; failures were invisible | A database trigger calls an Edge Function that logs every Expo answer |
| Rows are JSON text in cells, one lock for everything | Real tables, indexes, constraints, transactions |
| 6 minute and daily quota limits | Normal database limits |

What does **not** change: the app screens, the data shapes the screens use (we keep `jsonb` for novels and chapters so the app code barely changes), Google sign-in, Drive for photos and files.

---

## 2. Decisions to confirm before Phase 0

| # | Question | My recommendation | Why |
|---|---|---|---|
| D1 | Where do **soundtracks** live? | **An external file host** (MediaFire or similar). The author pastes a direct link, as today. The app saves each track only in its own app storage on the phone, never in Downloads (see 10.1). | No new server or storage needed. Only the link is stored in the novel. Photos and manga pages stay on Drive. |
| D2 | Catalog format (novels, chapters, themes) | **Keep as `jsonb`** in a `data` column | The app already reads these shapes. Normalising later is possible without touching screens. |
| D3 | Old **chat history** | **Do not migrate** | Messages need both people to exist in the new system. Start chat fresh; keep the sheet as an archive. |
| D4 | Old comments and pins | **Migrate** (comments claimed on first sign-in, see 6.4) | Readers expect their comments to survive. |
| D5 | Sheets after cutover | Keep as a read-only archive for 30 days, then stop using | Safety net. |
| D6 | Avatars | Stay on Drive for now, move to Storage later (optional) | One less thing to change in Phase 1. |

If you disagree with D1, everything else still works: only Phase 5 changes.

---

## 3. Target architecture

```
Phone (Expo app)
 |-- supabase-js ---------> Supabase
 |     auth (Google ID token), tables + RLS, Realtime
 |                              |
 |                              |-- Database Webhook --> Edge Function "push_notify" --> Expo push --> phone
 |
 |-- file requests --------> Apps Script "file service" (kept, much smaller)
       sends the Supabase token; the script asks Supabase "who is this?"
       then saves photos / pages into Drive and returns the link
```

### What stays in Apps Script (the "file service")

Only these actions remain: `uploadAsset` (pictures), `saveAvatar` (until D6), the Drive folder creation for new novels. If you keep soundtracks on Drive (D1 = no), `uploadPart` stays too.

How the file service knows who is calling, without any secret inside the script:

1. The app sends its **Supabase access token** with each file request.
2. The script calls `GET {SUPABASE_URL}/auth/v1/user` with that token and the public `apikey`. Supabase answers with the user id, or refuses.
3. The script calls `GET {SUPABASE_URL}/rest/v1/profiles?id=eq.<id>&select=role,allowed` **with the same user token**, so Row Level Security shows it only that person's own row. It then allows or refuses the upload.
4. For "is this my novel", it asks `rest/v1/subjects?id=eq.<id>&select=created_by` the same way.

Script Properties hold only `SUPABASE_URL` and the public anon key. **No service role key ever goes into Apps Script or the app.**

---

## 4. Project layout (in the Codespace)

```
supabase/
  config.toml
  migrations/
    001_profiles_and_access.sql
    002_chat.sql
    003_catalog.sql              (before comments: "who may delete" needs subjects)
    004_comments_and_pins.sql
    005_guards_and_helpers.sql   (username_available, JSON and theme guards, deleted_rows, progress_import, revokes)
  functions/
    push_notify/index.ts
  tests/
    00_helpers.sql
    rls_test.sql                 (all sections; run as superuser on a freshly migrated database)
scripts/
  export_sheets.gs          (runs in Apps Script, writes JSON into Drive "Backups")
  import_from_export.mjs    (Node, uses the service role key from an env var, never committed)
app/lib/
  supabase.ts               (the client, nothing else)
  backend.ts                (router: action name -> Supabase or Apps Script)
  sb/                       (one file per moved action, snake_case)
```

Naming rule: snake_case for every table, column, function, file.

Tools: `npx supabase init`, `npx supabase link --project-ref <ref>`, `npx supabase db push`. Versions to record when you start: Supabase CLI, `@supabase/supabase-js` 2.x, Node 20+.

---

## 5. Phase 0: prepare (no app changes)

1. Create the Supabase project. Pick the region closest to most of your readers. Save the database password somewhere safe.
2. Dashboard, **Authentication, Providers, Google**: enable it and add your **web client id** (and iOS client id if you use it) under *Authorized Client IDs*. The app already signs in with these.
3. Copy `Project URL` and the `anon` key into the app's `.env` as `EXPO_PUBLIC_SUPABASE_URL` and `EXPO_PUBLIC_SUPABASE_ANON_KEY`. The anon key is public by design; RLS protects the data. The **service role key** goes only into your Codespace secrets for the import script.
4. Run the old backup function so you have a full copy of the Sheets before anything moves.
5. Install in the app: `npx expo install @supabase/supabase-js @react-native-async-storage/async-storage react-native-url-polyfill`.

Done when: the project exists, Google provider is on, the Sheets backup is saved.

---

## 6. Phase 1: sign-in, profiles, roles, access requests

### 6.1 The idea

- A person signs in with Google exactly as today. The app takes the Google **ID token** and gives it to Supabase.
- On their first sign-in a trigger creates their `profiles` row.
- `allowed = false` means "waiting for an admin". The admin's pending list is simply `profiles where allowed = false`, so the old `Requests` sheet disappears.
- An admin can add someone **before** they sign in: that goes into `invited_users`, and the trigger picks it up on their first sign-in. The same table carries your old users across the move (see 6.4).

### 6.2 SQL: `001_profiles_and_access.sql`

```sql
create type public.user_role   as enum ('reader', 'author', 'admin');
create type public.gender_kind as enum ('boy', 'girl', 'skip');

-- People who may use the app but have not signed in yet (added by an admin, or carried over from the old sheet).
create table public.invited_users (
  email               text primary key,
  role                public.user_role not null default 'reader',
  username            text,
  username_changed_at timestamptz,
  gender              public.gender_kind,
  avatar_url          text,
  messaging_off       boolean not null default false
);

create table public.profiles (
  id                  uuid primary key references auth.users (id) on delete cascade,
  email               text not null unique,
  display_name        text not null default '',      -- the Google name: admins only, never shown to readers
  role                public.user_role not null default 'reader',
  allowed             boolean not null default false,
  request_status      text not null default 'pending' check (request_status in ('pending', 'rejected')),
  username            text,
  username_changed_at timestamptz,
  gender              public.gender_kind,
  avatar_url          text,
  messaging_off       boolean not null default false,
  role_request        text check (role_request is null or role_request = 'author'),
  added_at            timestamptz not null default now(),
  -- same rules as username_error() in the old backend
  constraint username_shape check (
    username is null or (
      username ~ '^[A-Za-z0-9_.]{3,20}$'
      and username !~ '^[._]' and username !~ '[._]$' and username !~ '[._]{2,}'
      and lower(username) <> all (array[
        'admin','administrator','owner','mod','moderator','support','help','ruse','system','null',
        'undefined','everyone','all','me','you','reader','author','official','staff','root','test','guest'])
    )
  )
);
create unique index profiles_username_unique on public.profiles (lower(username)) where username is not null;

-- ---- who is asking? (used by every policy) ----
create function public.is_member() returns boolean
language sql stable security definer set search_path = public as $$
  select coalesce((select allowed from public.profiles where id = auth.uid()), false)
$$;

create function public.is_admin() returns boolean
language sql stable security definer set search_path = public as $$
  select coalesce((select allowed and role = 'admin' from public.profiles where id = auth.uid()), false)
$$;

create function public.can_upload() returns boolean
language sql stable security definer set search_path = public as $$
  select coalesce((select allowed and role in ('author', 'admin') from public.profiles where id = auth.uid()), false)
$$;

-- ---- first sign-in: create the profile, using the invitation if there is one ----
create function public.handle_new_user() returns trigger
language plpgsql security definer set search_path = public as $$
declare invite public.invited_users%rowtype;
begin
  select * into invite from public.invited_users where lower(email) = lower(new.email);
  insert into public.profiles (id, email, display_name, role, allowed, username, username_changed_at, gender, avatar_url, messaging_off)
  values (
    new.id, lower(new.email), coalesce(new.raw_user_meta_data ->> 'full_name', ''),
    coalesce(invite.role, 'reader'), invite.email is not null,
    invite.username, invite.username_changed_at, invite.gender, invite.avatar_url, coalesce(invite.messaging_off, false)
  );
  return new;
end $$;

create trigger on_auth_user_created after insert on auth.users
for each row execute function public.handle_new_user();

-- ---- what a normal person may NOT change on their own profile ----
create function public.profiles_guard() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if auth.uid() is null then return new; end if;              -- SQL editor, import script, Edge Functions
  if not public.is_admin() then
    if new.role is distinct from old.role or new.allowed is distinct from old.allowed
       or new.email is distinct from old.email or new.added_at is distinct from old.added_at
       or new.request_status is distinct from old.request_status then
      raise exception 'You cannot change that.';
    end if;
  end if;
  if new.username is distinct from old.username then
    if old.username is not null and old.username_changed_at > now() - interval '30 days' then
      raise exception 'You can change your username once every 30 days.';
    end if;
    new.username_changed_at := now();
  end if;
  return new;
end $$;

create trigger profiles_guard_before_update before update on public.profiles
for each row execute function public.profiles_guard();

-- ---- Row Level Security ----
alter table public.profiles       enable row level security;
alter table public.invited_users  enable row level security;

create policy profiles_read_own    on public.profiles for select to authenticated using (id = auth.uid());
create policy profiles_read_admin  on public.profiles for select to authenticated using (public.is_admin());
create policy profiles_update_own  on public.profiles for update to authenticated using (id = auth.uid()) with check (id = auth.uid());
create policy profiles_update_admin on public.profiles for update to authenticated using (public.is_admin()) with check (public.is_admin());

create policy invited_admin_all on public.invited_users for all to authenticated
  using (public.is_admin()) with check (public.is_admin());

-- What other readers may see about a person: username and picture, never the email.
create view public.public_profiles as
  select id, username, avatar_url, role
  from public.profiles
  where allowed and username is not null and public.is_member();
grant select on public.public_profiles to authenticated;
```

Before the first sign-in, add yourself so you are not locked out:

```sql
insert into public.invited_users (email, role) values ('<your admin email>', 'admin');
```

### 6.3 App work

- `lib/supabase.ts`:

```ts
import 'react-native-url-polyfill/auto';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { createClient } from '@supabase/supabase-js';

export const supabase = createClient(process.env.EXPO_PUBLIC_SUPABASE_URL!, process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY!, {
  auth: { storage: AsyncStorage, autoRefreshToken: true, persistSession: true, detectSessionInUrl: false },
});
```

- In `lib/auth.tsx`, after `GoogleSignin.signIn()` succeeds:

```ts
const id_token = result.data?.idToken;
const { error } = await supabase.auth.signInWithIdToken({ provider: 'google', token: id_token! });
```

  The saved session means the app still opens offline, like today. (Check the current Supabase docs for the nonce note on iOS.)
- Keep the Google ID token for the file service only until Phase 5.
- Replace these actions (see section 13): `getMe`, `getProfile`, `saveProfile`, `saveUsername`, `checkUsername`, `requestAccess`, `requestRole`, `setMessaging`, and the admin group (`getAdminData`, `approveRequest`, `rejectRequest`, `addUser`, `setRole`, `setAdmin`, `removeUser`).
- `checkUsername` becomes a call to `username_available(name text)` (defined in `005_guards_and_helpers.sql`; same rules as the `username_shape` constraint; your own current name counts as available; returns `false` for anything invalid, so the app's `check_username_local` still gives the friendly reason).
- `removeUser` sets `allowed = false` (soft remove). Real deletion from `auth.users` is an Edge Function job and not needed.

### 6.4 Carrying the old users across

Export the `Users` sheet, then insert each row into `invited_users` (email, role, username, gender, avatar link, messaging off). When that person signs in for the first time, the trigger gives them their old role and username. Nobody has to be re-approved.

### 6.5 Test list

- You (admin) sign in: `allowed = true`, role admin.
- A new Google account signs in: profile exists, `allowed = false`, shows in your pending list.
- You approve it: they can read data.
- A normal user tries `update profiles set role = 'admin'` on themselves: refused.
- Two usernames differing only by capitals: second refused.
- Change username twice in a row: second refused.

Rollback: nothing else uses these tables yet; switch the action names back in `backend.ts`.

---

## 7. Phase 2: chat (the big win)

### 7.1 SQL: `002_chat.sql`

```sql
create table public.blocks (
  blocker_id uuid not null references public.profiles (id) on delete cascade,
  blocked_id uuid not null references public.profiles (id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (blocker_id, blocked_id)
);

create table public.reports (
  id          uuid primary key default gen_random_uuid(),
  reporter_id uuid not null references public.profiles (id) on delete cascade,
  reported_id uuid not null references public.profiles (id) on delete cascade,
  reason      text not null check (char_length(reason) between 1 and 500),
  status      text not null default 'open' check (status in ('open', 'resolved')),
  created_at  timestamptz not null default now()
);

create table public.messages (
  id           uuid primary key default gen_random_uuid(),
  sender_id    uuid not null references public.profiles (id) on delete cascade,
  recipient_id uuid not null references public.profiles (id) on delete cascade,
  body         text not null check (char_length(btrim(body)) between 1 and 500),
  created_at   timestamptz not null default now(),
  read_at      timestamptz,
  constraint messages_not_to_self check (sender_id <> recipient_id)
);
create index messages_pair_idx on public.messages (least(sender_id, recipient_id), greatest(sender_id, recipient_id), created_at desc);
create index messages_unread_idx on public.messages (recipient_id) where read_at is null;

create table public.push_tokens (
  token      text primary key,
  user_id    uuid not null references public.profiles (id) on delete cascade,
  updated_at timestamptz not null default now()
);

-- May this person message that person? (messages on, nobody blocked)
create function public.can_message(sender uuid, recipient uuid) returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.profiles r where r.id = recipient and r.allowed and not r.messaging_off)
     and not exists (select 1 from public.blocks b
                     where (b.blocker_id = recipient and b.blocked_id = sender)
                        or (b.blocker_id = sender    and b.blocked_id = recipient))
$$;

-- Same limits as the old backend: 5 per hour for accounts younger than 7 days, 40 per hour after that.
create function public.messages_rate_limit() returns trigger
language plpgsql security definer set search_path = public as $$
declare
  is_new boolean;
  sent   int;
begin
  select added_at > now() - interval '7 days' into is_new from public.profiles where id = new.sender_id;
  select count(*) into sent from public.messages where sender_id = new.sender_id and created_at > now() - interval '1 hour';
  if sent >= case when is_new then 5 else 40 end then
    raise exception 'You have sent too many messages. Try again later.';
  end if;
  return new;
end $$;

create trigger messages_rate_limit_before_insert before insert on public.messages
for each row execute function public.messages_rate_limit();

alter table public.messages    enable row level security;
alter table public.blocks      enable row level security;
alter table public.reports     enable row level security;
alter table public.push_tokens enable row level security;

create policy messages_read on public.messages for select to authenticated
  using (public.is_member() and auth.uid() in (sender_id, recipient_id)
    and not exists (select 1 from public.blocks b where b.blocker_id = auth.uid()
      and b.blocked_id = case when sender_id = auth.uid() then recipient_id else sender_id end));

create policy messages_send on public.messages for insert to authenticated
  with check (public.is_member() and sender_id = auth.uid() and public.can_message(sender_id, recipient_id));

create policy messages_delete_own on public.messages for delete to authenticated
  using (sender_id = auth.uid());
-- No update policy on purpose: marking read goes through mark_read() below, so nobody can edit a message.

create policy blocks_own on public.blocks for all to authenticated
  using (blocker_id = auth.uid()) with check (blocker_id = auth.uid() and public.is_member());

create policy reports_send  on public.reports for insert to authenticated with check (reporter_id = auth.uid() and public.is_member());
create policy reports_admin on public.reports for select to authenticated using (public.is_admin());
create policy reports_close on public.reports for update to authenticated using (public.is_admin()) with check (public.is_admin());

-- Mark everything from one person as read.
create function public.mark_read(other uuid) returns void
language sql security definer set search_path = public as $$
  update public.messages set read_at = now()
  where recipient_id = auth.uid() and sender_id = other and read_at is null
$$;

-- The inbox: one row per person, newest first, with the unread count and their picture.
create function public.inbox()
returns table (other_id uuid, username text, avatar_url text, last_body text, last_at timestamptz, last_from_me boolean, unread bigint)
language sql stable security definer set search_path = public as $$
  with mine as (
    select m.*, case when m.sender_id = auth.uid() then m.recipient_id else m.sender_id end as other_id
    from public.messages m
    where auth.uid() in (m.sender_id, m.recipient_id)
  ), last_one as (
    select distinct on (other_id) other_id, body, created_at, sender_id
    from mine order by other_id, created_at desc
  )
  select l.other_id, p.username, p.avatar_url, l.body, l.created_at, l.sender_id = auth.uid(),
         (select count(*) from mine x where x.other_id = l.other_id and x.recipient_id = auth.uid() and x.read_at is null)
  from last_one l
  join public.profiles p on p.id = l.other_id
  where public.is_member()
    and not exists (select 1 from public.blocks b where b.blocker_id = auth.uid() and b.blocked_id = l.other_id)
  order by l.created_at desc
$$;

-- A phone's notification address. A function, because a token may move between accounts on a shared phone.
create function public.register_push_token(t text) returns void
language sql security definer set search_path = public as $$
  insert into public.push_tokens (token, user_id) values (t, auth.uid())
  on conflict (token) do update set user_id = auth.uid(), updated_at = now()
$$;

create policy push_tokens_own on public.push_tokens for select to authenticated using (user_id = auth.uid());
create policy push_tokens_delete_own on public.push_tokens for delete to authenticated using (user_id = auth.uid());

-- Realtime: new and deleted messages reach the phone at once.
alter publication supabase_realtime add table public.messages;
```

The revokes for `inbox`, `mark_read`, `register_push_token` and `can_message` are in `005_guards_and_helpers.sql` (section 7 of that file), together with the `is_*` helpers and the trigger functions.

### 7.2 App work

- `fetch_conversation`: `supabase.from('messages').select('*').or(...)` for the pair, oldest first, limit 1000.
- `fetch_all_messages` becomes `supabase.rpc('inbox')`; the inbox screen reads the rows directly.
- `send_message`: `supabase.from('messages').insert({ sender_id, recipient_id, body })`. Database errors (rate limit, blocked) come back as readable text.
- `delete_message`: `supabase.from('messages').delete().eq('id', id)`.
- `mark_read`: `supabase.rpc('mark_read', { other })`.
- Blocks and reports map to plain inserts and deletes on `blocks` and `reports`.
- **Delete the 8 second polling** in the chat screen and subscribe instead:

```ts
const channel = supabase.channel(`chat:${my_id}`)
  .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'messages', filter: `recipient_id=eq.${my_id}` }, on_new)
  .on('postgres_changes', { event: 'DELETE', schema: 'public', table: 'messages' }, on_gone) // carries only the id: enough
  .subscribe();
// on leaving the screen: supabase.removeChannel(channel)
```

- Messages need the other person's picture and name: join `public_profiles` (the inbox already returns them).

### 7.3 Push: `supabase/functions/push_notify/index.ts`

A **Database Webhook** (dashboard, Database, Webhooks) on `INSERT` into `messages` calls this function, with a header `x-webhook-secret` you also store as a function secret.

```ts
import { createClient } from 'jsr:@supabase/supabase-js@2';

const db = createClient(Deno.env.get('SUPABASE_URL')!, Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!);

Deno.serve(async (req) => {
  if (req.headers.get('x-webhook-secret') !== Deno.env.get('PUSH_WEBHOOK_SECRET')) return new Response('no', { status: 401 });
  const { record } = await req.json();                       // the new message row
  const { data: sender } = await db.from('profiles').select('username').eq('id', record.sender_id).single();
  const { data: rows }   = await db.from('push_tokens').select('token').eq('user_id', record.recipient_id);
  const tokens = (rows ?? []).map((r) => r.token);
  if (!tokens.length) return new Response('no devices');

  const res = await fetch('https://exp.host/--/api/v2/push/send', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
    body: JSON.stringify(tokens.map((to) => ({
      to, title: `New message from ${sender?.username ?? 'someone'}`, body: String(record.body).slice(0, 120),
      data: { type: 'message', with: sender?.username }, sound: 'default', channelId: 'default', priority: 'high',
    }))),
  });
  const answer = await res.json();
  // Expo's answer is never ignored: log problems, and forget phones Expo says are gone.
  (answer.data ?? []).forEach(async (ticket: any, i: number) => {
    if (ticket.status === 'ok') return;
    console.error('push problem', ticket.details?.error, ticket.message);
    if (ticket.details?.error === 'DeviceNotRegistered') await db.from('push_tokens').delete().eq('token', tokens[i]);
  });
  return new Response('ok');
});
```

Notes: the **Google (FCM V1) key must be uploaded to Expo** (`eas credentials`, Android) or Android phones are never reached. The existing "Send me a test notification" button stays useful: make it call the same function through a small `test_push` Edge Function that also asks Expo for the receipts.

### 7.4 Test list (two accounts, two phones)

- A sends to B: B sees it within a second, the chat screen without refreshing.
- A deletes it: it disappears on B.
- B blocks A: A can no longer send; B's inbox hides A.
- B turns messages off: A's send is refused with a readable error.
- A new account sends 6 messages in an hour: the 6th is refused.
- Someone edits another person's message through the API: impossible (no update policy).
- B is offline: notification arrives on the phone.

Run `supabase/tests/rls_chat.sql` with two fake users:

```sql
begin;
select set_config('request.jwt.claims', '{"sub":"<uuid of A>","role":"authenticated"}', true);
set local role authenticated;
-- statements as A here, each should succeed or fail as listed above
rollback;
```

Rollback: put the chat actions back in `backend.ts` and restore the polling file from version control. The Sheets `Messages` tab was never touched.

---

## 8. Phase 3: comments and pins

### 8.1 SQL: `004_comments_and_pins.sql` (runs **after** `003_catalog.sql`: "who may delete" needs `subjects`. The plan used to number these the other way round; the files are the truth)

```sql
create table public.comments (
  id           uuid primary key default gen_random_uuid(),
  chapter_id   text not null,
  block        int  not null check (block >= 0),
  parent_id    uuid references public.comments (id) on delete cascade,
  author_id    uuid references public.profiles (id) on delete set null,
  author_email text,                                     -- only for comments carried over from the old sheet
  body         text not null check (char_length(btrim(body)) between 1 and 1000),
  created_at   timestamptz not null default now(),
  edited_at    timestamptz
);
create index comments_chapter_idx on public.comments (chapter_id, block, created_at);

-- One bookmark per person per chapter, like today.
create table public.pins (
  user_id    uuid not null references public.profiles (id) on delete cascade,
  chapter_id text not null,
  block      int  not null check (block >= 0),
  created_at timestamptz not null default now(),
  primary key (user_id, chapter_id)
);

-- Old comments belong to their writer as soon as that person signs in.
create function public.claim_old_comments() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  update public.comments set author_id = new.id where author_id is null and lower(author_email) = lower(new.email);
  return new;
end $$;
create trigger profiles_claim_comments after insert on public.profiles
for each row execute function public.claim_old_comments();

-- 30 comments per hour, and 100 per person per chapter (same as the old backend).
create function public.comments_limits() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if (select count(*) from public.comments where author_id = new.author_id and created_at > now() - interval '1 hour') >= 30 then
    raise exception 'You are commenting too fast. Try again later.';
  end if;
  if (select count(*) from public.comments where author_id = new.author_id and chapter_id = new.chapter_id) >= 100 then
    raise exception 'You have too many comments on this chapter.';
  end if;
  return new;
end $$;
create trigger comments_limits_before_insert before insert on public.comments
for each row execute function public.comments_limits();

alter table public.comments enable row level security;
alter table public.pins     enable row level security;

create policy comments_read   on public.comments for select to authenticated using (public.is_member());
create policy comments_insert on public.comments for insert to authenticated
  with check (public.is_member() and author_id = auth.uid());
create policy comments_edit_own on public.comments for update to authenticated
  using (author_id = auth.uid()) with check (author_id = auth.uid());
create policy comments_delete on public.comments for delete to authenticated using (
  author_id = auth.uid()
  or public.is_admin()
  or exists (select 1 from public.chapters c join public.subjects s on s.id = c.subject_id
             where c.id = comments.chapter_id and s.created_by = auth.uid())   -- the novel's uploader
);

create policy pins_own on public.pins for all to authenticated
  using (user_id = auth.uid()) with check (user_id = auth.uid() and public.is_member());
```

### 8.2 App work

Replace `getComments`, `saveComment`, `replyComment`, `deleteComment`, `getPins`, `savePin`, `deletePin`. `addBlockAfterComment` edits a chapter, so it moves with Phase 4. A new comment notifies the novel's uploader (and the parent's writer on a reply): add a second Database Webhook on `comments` that reuses the `push_notify` function (branch on `table`). **Put `block` in the notification data**, so a tap opens the right paragraph (the app already routes it).

### 8.3 Test list

Uploader deletes someone else's comment: works. A reader deletes someone else's: refused. 31st comment in an hour: refused. A pin replaces the old one in the same chapter.

---

## 9. Phase 4: catalog (novels, chapters, themes, progress)

### 9.1 SQL: `003_catalog.sql`

```sql
create table public.subjects (
  id               text primary key,
  position         int  not null default 0,
  data             jsonb not null,                 -- exactly what the app reads today
  created_by       uuid references public.profiles (id) on delete set null,
  created_by_email text,                           -- carried over; claimed on first sign-in
  updated_at       timestamptz not null default now()
);

create table public.chapters (
  id         text primary key,
  subject_id text not null references public.subjects (id) on delete cascade,
  position   int  not null default 0,
  data       jsonb not null,
  updated_at timestamptz not null default now()
);
create index chapters_subject_idx on public.chapters (subject_id, position);

create table public.themes (
  id         text primary key,
  data       jsonb not null,
  created_by uuid references public.profiles (id) on delete set null,
  updated_at timestamptz not null default now()
);

create table public.progress (
  user_id    uuid primary key references public.profiles (id) on delete cascade,
  data       jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now()
);

-- keep updated_at honest, so the app can ask only for what changed since its last visit
create function public.touch_updated_at() returns trigger language plpgsql as $$
begin new.updated_at := now(); return new; end $$;
create trigger subjects_touch before update on public.subjects for each row execute function public.touch_updated_at();
create trigger chapters_touch before update on public.chapters for each row execute function public.touch_updated_at();
create trigger themes_touch   before update on public.themes   for each row execute function public.touch_updated_at();
create trigger progress_touch before update on public.progress for each row execute function public.touch_updated_at();

create function public.claim_old_novels() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  update public.subjects set created_by = new.id where created_by is null and lower(created_by_email) = lower(new.email);
  return new;
end $$;
create trigger profiles_claim_novels after insert on public.profiles
for each row execute function public.claim_old_novels();

alter table public.subjects enable row level security;
alter table public.chapters enable row level security;
alter table public.themes   enable row level security;
alter table public.progress enable row level security;

create policy subjects_read  on public.subjects for select to authenticated using (public.is_member());
create policy subjects_write on public.subjects for all to authenticated
  using (public.is_admin() or (public.can_upload() and created_by = auth.uid()))
  with check (public.is_admin() or (public.can_upload() and created_by = auth.uid()));

create policy chapters_read  on public.chapters for select to authenticated using (public.is_member());
create policy chapters_write on public.chapters for all to authenticated
  using (public.is_admin() or exists (select 1 from public.subjects s where s.id = chapters.subject_id and s.created_by = auth.uid() and public.can_upload()))
  with check (public.is_admin() or exists (select 1 from public.subjects s where s.id = chapters.subject_id and s.created_by = auth.uid() and public.can_upload()));

create policy themes_read  on public.themes for select to authenticated using (public.is_member());
create policy themes_write on public.themes for all to authenticated
  using (public.is_admin() or (public.can_upload() and created_by = auth.uid()))
  with check (public.is_admin() or (public.can_upload() and created_by = auth.uid()));

create policy progress_own on public.progress for all to authenticated
  using (user_id = auth.uid()) with check (user_id = auth.uid());
```

### 9.1b SQL: `005_guards_and_helpers.sql`

The file is the source of truth (it is not pasted here so the two cannot drift). What it does:

| Part | What | Why |
|---|---|---|
| `username_available(name)` | boolean, signed-in only | `checkUsername` without a round trip through a table the person cannot read |
| `invited_users_username_unique` | unique index on `lower(username)` | an invitation can never make the first sign-in fail on the profiles unique index |
| JSON guards | `subjects_data_ok`, `chapters_data_ok`, `progress_data_ok` | data must be an object and not huge |
| `theme_data_ok(jsonb)` + `themes_data_ok` | mirrors `check_theme` in `lib/upload_check.ts`: name 1 to 40, fonts, `radius` 4 to 32, `effect` or `effects`, nine `#rrggbb` colours, `forSubject` up to 80, **`button`** (style, shape, press, `depth` 0 to 8, `shine`, `uppercase`, `colors.bg/fg/edge`; unknown keys refused, `_notes` allowed), effect list lengths and piece counts (6 tap recipes and 40 pieces, 4 background recipes and 30 pieces), total size 20 KB | an uploaded theme reaches every reader's phone; the detailed recipe fields stay checked in `lib/recipes.ts` |
| `themes_id_ok` | slug ids; `paper`, `obsidian_gold`, `sugar_bloom` refused | built-in names cannot be reused |
| `deleted_rows` + triggers, `updated_at` indexes | delta sync | see 9.2 |
| `progress_import` + `claim_old_progress` | old progress is staged by email and copied into `progress` at first sign-in, then removed | `progress.user_id` needs a profile, and old users have none yet |
| revokes | `is_member`, `is_admin`, `can_upload`, `can_message`, `mark_read`, `inbox`, `register_push_token` closed to `public` and `anon`, open to `authenticated`; trigger functions closed to everyone | signed-out visitors cannot call them over the API |

`themes_data_ok` is a CHECK on purpose (not a trigger): row-level security is tested first, so a reader who writes a theme still gets the clear row-level security refusal. **Importing old themes:** the import script goes through the same CHECK. Old themes with a bad shape will be refused; list them, fix them, and run again (do not drop the constraint).

Theme data shape the app reads (the `button` block is optional; see RUSE_PLAN B6):

```json
{ "name": "...", "font": "Inter", "heading_font": "Newsreader", "radius": 16, "effect": "none",
  "button": { "style": "raised", "shape": "pill", "press": "wiggle", "depth": 4, "shine": true, "uppercase": false,
              "colors": { "bg": "#ff6fa5", "fg": "#ffffff", "edge": "#c2457a" } },
  "colors": { "bg": "#...", "surface": "#...", "ink": "#...", "muted": "#...", "line": "#...",
              "primary": "#...", "primaryFg": "#...", "accent": "#...", "accentFg": "#..." } }
```

### 9.2 App work

- `getCourseData` becomes three selects (subjects, chapters, themes). Use **delta sync**: remember the newest `updated_at` seen and ask only for rows after it. Deleted rows: `public.deleted_rows(n, table_name, id, deleted_at)` exists (005) and is filled by a trigger on `subjects`, `chapters` and `themes` (cascades included); members may read it, nobody writes it directly. The app asks for `deleted_rows` after the last `n` it saw. Prune rows older than 60 days now and then; a phone that has been away longer does one full id check instead.
- `saveCourseBundle`, `saveChapter`, `saveSubject`, `deleteSubject`, `deleteChapter`, `saveTheme`, `deleteTheme`, `renameCategory`, `saveProgress`, `addBlockAfterComment`: plain upserts and deletes. **The checks the old backend ran inside `clean_chapter`, `validate_block`, `validate_style` and `validate_pages` must still run.** Keep them as pure TypeScript in the app (`lib/upload_check.ts` already does most). The database adds a last guard (005): novels, chapters and progress must be JSON objects under a size cap (100 KB, 1 MB, 100 KB), and themes pass `theme_data_ok()`. Treat anything an author uploads as untrusted: it is shown to every reader.
- Offline: your saved copies keep working because the data shape is unchanged.

### 9.3 Test list

An author edits their own novel: works. An author edits someone else's: refused. A reader inserts a novel: refused. Chapter order survives a round trip. Row counts match the old sheets (see section 11).

---

## 10. Phase 5: files

### 10.1 Soundtracks on an external file host, saved only in app storage (D1)

**Where it lives:** the author uploads the track to any free file host (Google Drive, Dropbox or similar) and pastes the **direct download link** into the novel as `musicUrl`. The app checks the link opens audio before saving it. Google Drive's warning page for big files fails that check, so a Drive link must be one that opens the file directly; a Dropbox link with `dl=1` at the end does. Nothing is stored on Supabase, and no bucket, signing or new server is needed. Only the link is saved in the novel.

**Direct link only:** the app downloads the link itself, so it must point at the audio file. A normal share page (an HTML page with a Download button) would download a web page instead of a track. Before choosing a host, check its current link rules and its terms for this use. I have not checked MediaFire's current rules. The app should also refuse a link whose content type is not audio, and show a readable message instead.

**Saved in app storage only:** the app saves the file with `expo-file-system` into its own document folder (`Paths.document`, already used in `lib/downloads.ts`). It never goes into Downloads, the gallery or shared storage. The phone's index (link to file) already records it, and playback uses the local copy when there is one.

**Save for offline:** each novel's music bar gets a "Save for offline" button that uses the existing `download_one`. It shows the size first and progress while it saves.

**Clear button:** Settings gets a "Clear saved downloads" button. It asks first, deletes every saved file and empties the index, and shows how much space the saved files use. Sign-out already calls `delete_all_downloads()`. After clearing, playback falls back to the link.

**Privacy of the app folder:** on a normal phone the app folder is private to the app. Turn off cloud backup of app data (`android.allowBackup` set to false in `app.json`) before launch, so saved tracks are not copied into a backup. Only publish tracks the author has the right to share.

**App work:** a "Track link" field on the author's novel screen (replacing the Drive upload for soundtracks), the Save for offline button, the Clear button, and the content-type check. No server work. The Drive `uploadPart` action is removed when Apps Script is retired.

**Migration `005_storage.sql`:** not needed. Remove it from the plan. Nothing new in SQL for soundtracks.

### 10.1-old Soundtracks on Supabase Storage (superseded, do not run)

```sql
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('soundtracks', 'soundtracks', true, 31457280, array['audio/mpeg', 'audio/mp4', 'audio/x-m4a', 'audio/wav', 'audio/ogg'])
on conflict (id) do nothing;

-- Path rule: <subject id>/<file name>. Only that novel's uploader (or an admin) may write there. Anyone may play.
create policy soundtracks_write on storage.objects for insert to authenticated with check (
  bucket_id = 'soundtracks' and (
    public.is_admin() or exists (select 1 from public.subjects s
      where s.id = (storage.foldername(name))[1] and s.created_by = auth.uid() and public.can_upload()))
);
create policy soundtracks_replace on storage.objects for update to authenticated using (
  bucket_id = 'soundtracks' and (
    public.is_admin() or exists (select 1 from public.subjects s
      where s.id = (storage.foldername(name))[1] and s.created_by = auth.uid()))
);
create policy soundtracks_remove on storage.objects for delete to authenticated using (
  bucket_id = 'soundtracks' and (
    public.is_admin() or exists (select 1 from public.subjects s
      where s.id = (storage.foldername(name))[1] and s.created_by = auth.uid()))
);
```

Make the bucket public for **reading** only if you accept that anyone with a link can play a track (the same as Drive "anyone with the link" today). Otherwise keep it private and use signed URLs.

App: replace `lib/soundtrack.ts` upload with a Storage upload, then save the public URL into the novel's `data.musicUrl` as today. For files above a few MB, use Supabase's **resumable (TUS) upload**, which fits the "small pieces, retry only the failed piece" behaviour already in `lib/upload_parts.ts`. (Check the current docs for the size at which they recommend TUS.)

### 10.2 Photos and manga pages stay on Drive

The app sends the **Supabase token** instead of the Google token. Change in Apps Script: `require_user` and `require_role` ask Supabase (section 3) instead of reading the `Users` sheet. `can_manage` asks Supabase for the novel's `created_by`. Drive folder creation for a new novel stays; the new novel's row in `subjects` stores the folder id inside `data`.

### 10.3 Test list

Author pastes a direct track link: it plays, and seeking works. A share-page link (not the file itself): refused with a readable message, not a silent failure. Save for offline: the file appears in the app's storage and does not appear in Downloads or the gallery. Airplane mode: the saved track plays. Clear saved downloads: files are gone, the index is empty, and playback uses the link again. Sign out: saved tracks are removed. A page upload to Drive works with the Supabase token and fails with an expired or fake token.

---

## 11. Importing the old data (Phase 4 and 6)

1. `scripts/export_sheets.gs` (in Apps Script): writes one JSON file per sheet into Drive `Backups`, with row counts in the file name.
2. `scripts/import_from_export.mjs` (Node, in the Codespace): reads those files and upserts in batches of 500 with the **service role key from an environment variable**. Never commit that key.
3. Import order: `invited_users`, `subjects`, `chapters`, `themes`, `comments` (with `author_email`), then `progress` for people who already have a profile; for everyone else write the old progress into `progress_import` (by email) and `claim_old_progress` (005) copies it in at their first sign-in, in its own trigger on `profiles`, not inside `handle_new_user`.
4. Checks after every import (stop and fix if any fails):

| Check | How |
|---|---|
| Row counts match | count in the sheet export = count in the table, per table |
| No duplicate keys | `select id, count(*) from <table> group by id having count(*) > 1` returns nothing |
| No missing owners | subjects with null `created_by_email` listed for you to decide |
| JSON is valid | the table checks in 005 refuse bad rows, so a failed import shows the id; also `select count(*) from chapters where jsonb_typeof(data) <> 'object'` is 0 |
| Themes pass | the import reports every theme refused by `themes_data_ok`; fix them, do not drop the check |
| Dates parse | no null `created_at` in comments |
| Spot check | open 3 novels, 3 chapters and 3 comment threads in the app and compare with the old version |

---

## 12. Phase 6: cutover and cleanup

1. Tell readers a short maintenance time. Freeze writes in the old backend (return "updating" for write actions).
2. Run the export and import one last time (it is safe to run again: it upserts).
3. Run the checks in section 11.
4. Flip every remaining action to Supabase in `backend.ts`, build the app, test on two phones.
5. Keep the Sheets read-only for 30 days, then archive them.
6. Remove the dead Apps Script files (everything except the file service), update `RUSE_PLAN_v2.md`, delete the old action constants.

Rollback until step 5 is finished: set the action list in `backend.ts` back to Apps Script.

---

## 13. Action by action: where each one goes

| Phase | Old Apps Script action | New home |
|---|---|---|
| 1 | getMe, getProfile | `profiles` select |
| 1 | saveProfile, saveUsername, setMessaging | `profiles` update (guarded by trigger) |
| 1 | checkUsername | `username_available()` function (005) |
| 1 | requestAccess | automatic on first sign-in |
| 1 | requestRole | `profiles.role_request = 'author'` |
| 1 | getAdminData, approveRequest, rejectRequest | `profiles` queries and updates (admin policy) |
| 1 | addUser, setRole, setAdmin, removeUser | `invited_users` insert, `profiles` update |
| 2 | getThreads | `inbox()` |
| 2 | getMessages, sendMessage, deleteMessage | `messages` select, insert, delete |
| 2 | markRead | `mark_read()` |
| 2 | blockUser, unblockUser, getBlocked | `blocks` |
| 2 | reportUser, getReports, resolveReport | `reports` |
| 2 | registerPushToken, unregisterPushToken, testPush | `register_push_token()`, `push_tokens`, Edge Function |
| 3 | getComments, saveComment, replyComment, deleteComment | `comments` |
| 3 | getPins, savePin, deletePin | `pins` |
| 4 | getCourseData | `subjects`, `chapters`, `themes` with delta sync |
| 4 | saveCourseBundle, saveSubject, saveChapter, deleteSubject, deleteChapter | upserts and deletes |
| 4 | addBlockAfterComment, renameCategory | chapter / subject updates |
| 4 | saveTheme, deleteTheme | `themes` (checked by `theme_data_ok`, includes `button`) |
| 4 | saveProgress | `progress` upsert |
| 5 | uploadPart (soundtracks) | file host link in `musicUrl`; app saves it to app storage |
| 5 | uploadAsset, saveAvatar | **stay** in the Apps Script file service |

### The "move one action at a time" switch

In `lib/backend.ts`:

```ts
import { gas_call } from './api';          // today's api(), renamed
import { sb_handlers } from './sb';        // one file per moved action

const MOVED = new Set<string>([/* add an action name here when its Supabase version passes its tests */]);

export async function api<T>(action: string, ...args: unknown[]): Promise<T> {
  return MOVED.has(action) ? sb_handlers[action](...args) as Promise<T> : gas_call<T>(action, ...args);
}
```

Nothing else in the app changes, and rolling back one action is deleting one word.

---

## 14. Security checklist (before real users move)

- Row Level Security is **on** for every table in `public`, and each table has the policies above. The dashboard's Security Advisor shows none missing.
- The service role key exists only in Codespace secrets and Edge Function secrets. Search the app and `.env` for it before every build.
- `public_profiles` is the only way readers see other people; it never contains emails.
- Uploaded novels and chapters are untrusted input (validated in the app and shown only through the existing safe renderer).
- Edge Function webhook secret is set and checked.
- Soundtrack links are only saved in the novel. The app saves files only in its own storage, and cloud backup of app data is off.
- Functions that only signed-in people may call have `revoke execute ... from public, anon` (done in 005; tests G37 to G40).
- A test with two ordinary accounts proves: no one reads another person's messages, no one edits another person's profile or comment, no reader writes a novel.

---

## 15. Costs, limits and things to check (numbers may have changed: verify on supabase.com/pricing)

Roughly, the free plan has: about 500 MB of database, about 1 GB of file storage, tens of thousands of monthly users, a couple of hundred simultaneous Realtime connections, and Edge Function calls in the hundreds of thousands per month. Things I believe are true but you must confirm:

- **Free projects can pause after about a week without activity.** A paused app looks broken. Either keep it used, or move to the paid plan before real readers arrive.
- Free projects may not include downloadable daily backups. Run `npx supabase db dump` monthly from the Codespace and keep the file in the Drive `Backups` folder.
- Check the maximum upload size on the free plan before promising 30 MB soundtracks.

---

## 16. Risks and what I would not do

| Risk | What to do |
|---|---|
| A mistake in a policy exposes data | Test with two accounts in every phase before moving on; never skip the Security Advisor |
| Old users must sign in again | They do not need approval (the invitation table carries their role), but they do need one sign-in after the update |
| Both backends disagree during the move | Each action lives in exactly one place at a time (the `MOVED` set); never write the same data to both |
| Big chapters make `getCourseData` slow | Delta sync, and fetch chapter `data` only when a chapter is opened (list with titles first) |
| Free tier pause | See section 15 |

Do **not**: put the service role key in the app; copy the whole sheet into Postgres in one blind import; turn off RLS "just to test"; move chat and catalog in the same release.

---

## 17. Suggested order and size

| Phase | Work | Rough size |
|---|---|---|
| 0 | Project, Google provider, backup | an evening |
| 1 | Sign-in, profiles, roles, admin screens | 2 to 3 days |
| 2 | Chat with Realtime, push | 2 to 3 days |
| 3 | Comments and pins | 1 to 2 days |
| 4 | Catalog, delta sync, import | 3 to 4 days |
| 5 | Soundtracks to Storage, file service token check | 1 to 2 days |
| 6 | Cutover and cleanup | 1 day |

I suggest starting with Phases 0 to 2: that already fixes the awkward chat, and everything after it can wait without hurting anything.
