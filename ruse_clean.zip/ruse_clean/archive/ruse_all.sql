-- ============================================================================
-- RUSE: whole Supabase schema in ONE file (phases 1 to 4 + guards)
-- Paste into Dashboard > SQL Editor > New query > Run, on a FRESH project.
--
-- This file is just 001 to 005 from supabase/migrations/ joined in run order:
--   001 profiles and access   002 chat   003 catalog   004 comments and pins
--   005 guards and helpers
-- The migration files stay the source of truth. If you change one, rebuild this
-- file (see build_one_file.sh) instead of editing it by hand.
--
-- UNTESTED: no Postgres was available when this was written. After running it:
--   1. Dashboard > Security Advisor: no table without RLS.
--   2. Run supabase/tests/00_helpers.sql, then rls_test.sql (G01 to G40) as superuser.
-- Do not run this twice on the same project (create type / create table will fail).
-- ============================================================================


-- ============================================================================
-- >>> 001_profiles_and_access.sql
-- ============================================================================

create type public.user_role   as enum ('reader', 'author', 'admin');
create type public.gender_kind as enum ('boy', 'girl', 'skip');

-- People who may use the app but have not signed in yet (added by an admin, or carried over from the old sheet).
create table public.invited_users (
  email               text primary key,
  role                public.user_role not null default 'reader',
  username            text,
  username_changed_at timestamptz,
  gender              public.gender_kind,
  avatar_url          text,
  messaging_off       boolean not null default false
);

create table public.profiles (
  id                  uuid primary key references auth.users (id) on delete cascade,
  email               text not null unique,
  display_name        text not null default '',      -- the Google name: admins only, never shown to readers
  role                public.user_role not null default 'reader',
  allowed             boolean not null default false,
  request_status      text not null default 'pending' check (request_status in ('pending', 'rejected')),
  username            text,
  username_changed_at timestamptz,
  gender              public.gender_kind,
  avatar_url          text,
  messaging_off       boolean not null default false,
  role_request        text check (role_request is null or role_request = 'author'),
  added_at            timestamptz not null default now(),
  -- same rules as username_error() in the old backend
  constraint username_shape check (
    username is null or (
      username ~ '^[A-Za-z0-9_.]{3,20}$'
      and username !~ '^[._]' and username !~ '[._]$' and username !~ '[._]{2,}'
      and lower(username) <> all (array[
        'admin','administrator','owner','mod','moderator','support','help','ruse','system','null',
        'undefined','everyone','all','me','you','reader','author','official','staff','root','test','guest'])
    )
  )
);
create unique index profiles_username_unique on public.profiles (lower(username)) where username is not null;

-- ---- who is asking? (used by every policy) ----
create function public.is_member() returns boolean
language sql stable security definer set search_path = public as $$
  select coalesce((select allowed from public.profiles where id = auth.uid()), false)
$$;

create function public.is_admin() returns boolean
language sql stable security definer set search_path = public as $$
  select coalesce((select allowed and role = 'admin' from public.profiles where id = auth.uid()), false)
$$;

create function public.can_upload() returns boolean
language sql stable security definer set search_path = public as $$
  select coalesce((select allowed and role in ('author', 'admin') from public.profiles where id = auth.uid()), false)
$$;

-- ---- first sign-in: create the profile, using the invitation if there is one ----
create function public.handle_new_user() returns trigger
language plpgsql security definer set search_path = public as $$
declare invite public.invited_users%rowtype;
begin
  select * into invite from public.invited_users where lower(email) = lower(new.email);
  insert into public.profiles (id, email, display_name, role, allowed, username, username_changed_at, gender, avatar_url, messaging_off)
  values (
    new.id, lower(new.email), coalesce(new.raw_user_meta_data ->> 'full_name', ''),
    coalesce(invite.role, 'reader'), invite.email is not null,
    invite.username, invite.username_changed_at, invite.gender, invite.avatar_url, coalesce(invite.messaging_off, false)
  );
  return new;
end $$;

create trigger on_auth_user_created after insert on auth.users
for each row execute function public.handle_new_user();

-- ---- what a normal person may NOT change on their own profile ----
create function public.profiles_guard() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if auth.uid() is null then return new; end if;              -- SQL editor, import script, Edge Functions
  if not public.is_admin() then
    if new.role is distinct from old.role or new.allowed is distinct from old.allowed
       or new.email is distinct from old.email or new.added_at is distinct from old.added_at
       or new.request_status is distinct from old.request_status then
      raise exception 'You cannot change that.';
    end if;
  end if;
  if new.username is distinct from old.username then
    if old.username is not null and old.username_changed_at > now() - interval '30 days' then
      raise exception 'You can change your username once every 30 days.';
    end if;
    new.username_changed_at := now();
  end if;
  return new;
end $$;

create trigger profiles_guard_before_update before update on public.profiles
for each row execute function public.profiles_guard();

-- ---- Row Level Security ----
alter table public.profiles       enable row level security;
alter table public.invited_users  enable row level security;

create policy profiles_read_own    on public.profiles for select to authenticated using (id = auth.uid());
create policy profiles_read_admin  on public.profiles for select to authenticated using (public.is_admin());
create policy profiles_update_own  on public.profiles for update to authenticated using (id = auth.uid()) with check (id = auth.uid());
create policy profiles_update_admin on public.profiles for update to authenticated using (public.is_admin()) with check (public.is_admin());

create policy invited_admin_all on public.invited_users for all to authenticated
  using (public.is_admin()) with check (public.is_admin());

-- What other readers may see about a person: username and picture, never the email.
create view public.public_profiles as
  select id, username, avatar_url, role
  from public.profiles
  where allowed and username is not null and public.is_member();
grant select on public.public_profiles to authenticated;


-- ============================================================================
-- >>> 002_chat.sql
-- ============================================================================

create table public.blocks (
  blocker_id uuid not null references public.profiles (id) on delete cascade,
  blocked_id uuid not null references public.profiles (id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (blocker_id, blocked_id)
);

create table public.reports (
  id          uuid primary key default gen_random_uuid(),
  reporter_id uuid not null references public.profiles (id) on delete cascade,
  reported_id uuid not null references public.profiles (id) on delete cascade,
  reason      text not null check (char_length(reason) between 1 and 500),
  status      text not null default 'open' check (status in ('open', 'resolved')),
  created_at  timestamptz not null default now()
);

create table public.messages (
  id           uuid primary key default gen_random_uuid(),
  sender_id    uuid not null references public.profiles (id) on delete cascade,
  recipient_id uuid not null references public.profiles (id) on delete cascade,
  body         text not null check (char_length(btrim(body)) between 1 and 500),
  created_at   timestamptz not null default now(),
  read_at      timestamptz,
  constraint messages_not_to_self check (sender_id <> recipient_id)
);
create index messages_pair_idx on public.messages (least(sender_id, recipient_id), greatest(sender_id, recipient_id), created_at desc);
create index messages_unread_idx on public.messages (recipient_id) where read_at is null;

create table public.push_tokens (
  token      text primary key,
  user_id    uuid not null references public.profiles (id) on delete cascade,
  updated_at timestamptz not null default now()
);

-- May this person message that person? (messages on, nobody blocked)
create function public.can_message(sender uuid, recipient uuid) returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.profiles r where r.id = recipient and r.allowed and not r.messaging_off)
     and not exists (select 1 from public.blocks b
                     where (b.blocker_id = recipient and b.blocked_id = sender)
                        or (b.blocker_id = sender    and b.blocked_id = recipient))
$$;

-- Same limits as the old backend: 5 per hour for accounts younger than 7 days, 40 per hour after that.
create function public.messages_rate_limit() returns trigger
language plpgsql security definer set search_path = public as $$
declare
  is_new boolean;
  sent   int;
begin
  select added_at > now() - interval '7 days' into is_new from public.profiles where id = new.sender_id;
  select count(*) into sent from public.messages where sender_id = new.sender_id and created_at > now() - interval '1 hour';
  if sent >= (case when is_new then 5 else 40 end) then
    raise exception 'You have sent too many messages. Try again later.';
  end if;
  return new;
end $$;

create trigger messages_rate_limit_before_insert before insert on public.messages
for each row execute function public.messages_rate_limit();

alter table public.messages    enable row level security;
alter table public.blocks      enable row level security;
alter table public.reports     enable row level security;
alter table public.push_tokens enable row level security;

create policy messages_read on public.messages for select to authenticated
  using (public.is_member() and auth.uid() in (sender_id, recipient_id)
    and not exists (select 1 from public.blocks b where b.blocker_id = auth.uid()
      and b.blocked_id = case when sender_id = auth.uid() then recipient_id else sender_id end));

create policy messages_send on public.messages for insert to authenticated
  with check (public.is_member() and sender_id = auth.uid() and public.can_message(sender_id, recipient_id));

create policy messages_delete_own on public.messages for delete to authenticated
  using (sender_id = auth.uid());
-- No update policy on purpose: marking read goes through mark_read() below, so nobody can edit a message.

create policy blocks_own on public.blocks for all to authenticated
  using (blocker_id = auth.uid()) with check (blocker_id = auth.uid() and public.is_member());

create policy reports_send  on public.reports for insert to authenticated with check (reporter_id = auth.uid() and public.is_member());
create policy reports_admin on public.reports for select to authenticated using (public.is_admin());
create policy reports_close on public.reports for update to authenticated using (public.is_admin()) with check (public.is_admin());

-- Mark everything from one person as read.
create function public.mark_read(other uuid) returns void
language sql security definer set search_path = public as $$
  update public.messages set read_at = now()
  where recipient_id = auth.uid() and sender_id = other and read_at is null
$$;

-- The inbox: one row per person, newest first, with the unread count and their picture.
create function public.inbox()
returns table (other_id uuid, username text, avatar_url text, last_body text, last_at timestamptz, last_from_me boolean, unread bigint)
language sql stable security definer set search_path = public as $$
  with mine as (
    select m.*, case when m.sender_id = auth.uid() then m.recipient_id else m.sender_id end as other_id
    from public.messages m
    where auth.uid() in (m.sender_id, m.recipient_id)
  ), last_one as (
    select distinct on (other_id) other_id, body, created_at, sender_id
    from mine order by other_id, created_at desc
  )
  select l.other_id, p.username, p.avatar_url, l.body, l.created_at, l.sender_id = auth.uid(),
         (select count(*) from mine x where x.other_id = l.other_id and x.recipient_id = auth.uid() and x.read_at is null)
  from last_one l
  join public.profiles p on p.id = l.other_id
  where public.is_member()
    and not exists (select 1 from public.blocks b where b.blocker_id = auth.uid() and b.blocked_id = l.other_id)
  order by l.created_at desc
$$;

-- A phone's notification address. A function, because a token may move between accounts on a shared phone.
create function public.register_push_token(t text) returns void
language sql security definer set search_path = public as $$
  insert into public.push_tokens (token, user_id) values (t, auth.uid())
  on conflict (token) do update set user_id = auth.uid(), updated_at = now()
$$;

create policy push_tokens_own on public.push_tokens for select to authenticated using (user_id = auth.uid());
create policy push_tokens_delete_own on public.push_tokens for delete to authenticated using (user_id = auth.uid());

-- Realtime: new and deleted messages reach the phone at once.
alter publication supabase_realtime add table public.messages;


-- ============================================================================
-- >>> 003_catalog.sql
-- ============================================================================

create table public.subjects (
  id               text primary key,
  position         int  not null default 0,
  data             jsonb not null,                 -- exactly what the app reads today
  created_by       uuid references public.profiles (id) on delete set null,
  created_by_email text,                           -- carried over; claimed on first sign-in
  updated_at       timestamptz not null default now()
);

create table public.chapters (
  id         text primary key,
  subject_id text not null references public.subjects (id) on delete cascade,
  position   int  not null default 0,
  data       jsonb not null,
  updated_at timestamptz not null default now()
);
create index chapters_subject_idx on public.chapters (subject_id, position);

create table public.themes (
  id         text primary key,
  data       jsonb not null,
  created_by uuid references public.profiles (id) on delete set null,
  updated_at timestamptz not null default now()
);

create table public.progress (
  user_id    uuid primary key references public.profiles (id) on delete cascade,
  data       jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now()
);

-- keep updated_at honest, so the app can ask only for what changed since its last visit
create function public.touch_updated_at() returns trigger language plpgsql as $$
begin new.updated_at := now(); return new; end $$;
create trigger subjects_touch before update on public.subjects for each row execute function public.touch_updated_at();
create trigger chapters_touch before update on public.chapters for each row execute function public.touch_updated_at();
create trigger themes_touch   before update on public.themes   for each row execute function public.touch_updated_at();
create trigger progress_touch before update on public.progress for each row execute function public.touch_updated_at();

create function public.claim_old_novels() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  update public.subjects set created_by = new.id where created_by is null and lower(created_by_email) = lower(new.email);
  return new;
end $$;
create trigger profiles_claim_novels after insert on public.profiles
for each row execute function public.claim_old_novels();

alter table public.subjects enable row level security;
alter table public.chapters enable row level security;
alter table public.themes   enable row level security;
alter table public.progress enable row level security;

create policy subjects_read  on public.subjects for select to authenticated using (public.is_member());
create policy subjects_write on public.subjects for all to authenticated
  using (public.is_admin() or (public.can_upload() and created_by = auth.uid()))
  with check (public.is_admin() or (public.can_upload() and created_by = auth.uid()));

create policy chapters_read  on public.chapters for select to authenticated using (public.is_member());
create policy chapters_write on public.chapters for all to authenticated
  using (public.is_admin() or exists (select 1 from public.subjects s where s.id = chapters.subject_id and s.created_by = auth.uid() and public.can_upload()))
  with check (public.is_admin() or exists (select 1 from public.subjects s where s.id = chapters.subject_id and s.created_by = auth.uid() and public.can_upload()));

create policy themes_read  on public.themes for select to authenticated using (public.is_member());
create policy themes_write on public.themes for all to authenticated
  using (public.is_admin() or (public.can_upload() and created_by = auth.uid()))
  with check (public.is_admin() or (public.can_upload() and created_by = auth.uid()));

create policy progress_own on public.progress for all to authenticated
  using (user_id = auth.uid()) with check (user_id = auth.uid());


-- ============================================================================
-- >>> 004_comments_and_pins.sql
-- ============================================================================

create table public.comments (
  id           uuid primary key default gen_random_uuid(),
  chapter_id   text not null,
  block        int  not null check (block >= -1),   -- -1 = the whole chapter (app: WHOLE_CHAPTER in lib/pin_helpers.ts)
  parent_id    uuid references public.comments (id) on delete cascade,
  author_id    uuid references public.profiles (id) on delete set null,
  author_email text,                                     -- only for comments carried over from the old sheet
  body         text not null check (char_length(btrim(body)) between 1 and 1000),
  created_at   timestamptz not null default now(),
  edited_at    timestamptz
);
create index comments_chapter_idx on public.comments (chapter_id, block, created_at);

-- One bookmark per person per chapter, like today.
create table public.pins (
  user_id    uuid not null references public.profiles (id) on delete cascade,
  chapter_id text not null,
  block      int  not null check (block >= 0),
  created_at timestamptz not null default now(),
  primary key (user_id, chapter_id)
);

-- Old comments belong to their writer as soon as that person signs in.
create function public.claim_old_comments() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  update public.comments set author_id = new.id where author_id is null and lower(author_email) = lower(new.email);
  return new;
end $$;
create trigger profiles_claim_comments after insert on public.profiles
for each row execute function public.claim_old_comments();

-- 30 comments per hour, and 100 per person per chapter (same as the old backend).
create function public.comments_limits() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if (select count(*) from public.comments where author_id = new.author_id and created_at > now() - interval '1 hour') >= 30 then
    raise exception 'You are commenting too fast. Try again later.';
  end if;
  if (select count(*) from public.comments where author_id = new.author_id and chapter_id = new.chapter_id) >= 100 then
    raise exception 'You have too many comments on this chapter.';
  end if;
  return new;
end $$;
create trigger comments_limits_before_insert before insert on public.comments
for each row execute function public.comments_limits();

alter table public.comments enable row level security;
alter table public.pins     enable row level security;

create policy comments_read   on public.comments for select to authenticated using (public.is_member());
create policy comments_insert on public.comments for insert to authenticated
  with check (public.is_member() and author_id = auth.uid());
create policy comments_edit_own on public.comments for update to authenticated
  using (author_id = auth.uid()) with check (author_id = auth.uid());
create policy comments_delete on public.comments for delete to authenticated using (
  author_id = auth.uid()
  or public.is_admin()
  or exists (select 1 from public.chapters c join public.subjects s on s.id = c.subject_id
             where c.id = comments.chapter_id and s.created_by = auth.uid())   -- the novel's uploader
);

create policy pins_own on public.pins for all to authenticated
  using (user_id = auth.uid()) with check (user_id = auth.uid() and public.is_member());


-- ============================================================================
-- >>> 005_guards_and_helpers.sql
-- ============================================================================

-- 005: guards and helpers the app needs on top of 001 to 004. Closes the "still open in the SQL" list from RUSE_PLAN v63.
--   1. username_available()        the plan promised it (checkUsername), 001 never defined it
--   2. invited_users username      one unique index, so an invitation can never break a first sign-in
--   3. jsonb guards                everything an author uploads is shown to every reader, so check it here too
--   4. theme_data_ok()             mirrors lib/upload_check.ts check_theme, including the new "button" block
--   5. deleted_rows + indexes      so the app can do delta sync (ask only for what changed since its last visit)
--   6. progress_import             old reading progress waits here and is copied in at the person's first sign-in
--   7. revoke execute              functions only signed-in people may call are closed to the signed-out role
-- The full tap/background recipe checks (lib/recipes.ts) stay in the app; the database enforces
-- shape, enums, ranges, piece counts and size, which is what protects other people's phones.

-- ---- 1. username_available -------------------------------------------------------------------
-- Same rules as the username_shape constraint in 001. Your own current name counts as available.
create function public.username_available(name text) returns boolean
language sql stable security definer set search_path = public as $$
  select coalesce(
        name ~ '^[A-Za-z0-9_.]{3,20}$' and name !~ '^[._]' and name !~ '[._]$' and name !~ '[._]{2,}'
    and lower(name) <> all (array[
        'admin','administrator','owner','mod','moderator','support','help','ruse','system','null',
        'undefined','everyone','all','me','you','reader','author','official','staff','root','test','guest'])
    and not exists (select 1 from public.profiles p
                    where lower(p.username) = lower(name) and p.id is distinct from auth.uid())
    and not exists (select 1 from public.invited_users i
                    where lower(i.username) = lower(name)
                      and lower(i.email) is distinct from (select lower(email) from public.profiles where id = auth.uid())),
    false)
$$;
revoke all on function public.username_available(text) from public, anon;
grant execute on function public.username_available(text) to authenticated;

-- ---- 2. invitations may not hand out a taken username ----------------------------------------
create unique index invited_users_username_unique on public.invited_users (lower(username)) where username is not null;

-- ---- 3. jsonb guards -------------------------------------------------------------------------
alter table public.subjects add constraint subjects_data_ok check (jsonb_typeof(data) = 'object' and octet_length(data::text) <= 100000);
alter table public.chapters add constraint chapters_data_ok check (jsonb_typeof(data) = 'object' and octet_length(data::text) <= 1000000);
alter table public.progress add constraint progress_data_ok check (jsonb_typeof(data) = 'object' and octet_length(data::text) <= 100000);

-- ---- 4. themes -------------------------------------------------------------------------------
create function public.theme_data_ok(d jsonb) returns boolean
language plpgsql immutable as $$
declare
  fonts   text[] := array['Figtree','Newsreader','Inter','Merriweather','Lora','Roboto Mono','Quicksand'];
  effs    text[] := array['none','ripple','confetti','sparkle','pop','hearts','petals','bubbles'];
  colkeys text[] := array['bg','surface','ink','muted','line','primary','primaryFg','accent','accentFg'];
  k text; b jsonb; e jsonb; el jsonb; pieces numeric;
begin
  if jsonb_typeof(d) is distinct from 'object' then return false; end if;
  if octet_length(d::text) > 20000 then return false; end if;

  if jsonb_typeof(d -> 'name') is distinct from 'string' or char_length(btrim(d ->> 'name')) not between 1 and 40 then return false; end if;
  if jsonb_typeof(d -> 'font') is distinct from 'string' or not ((d ->> 'font') = any (fonts)) then return false; end if;
  if d ? 'heading_font' and (jsonb_typeof(d -> 'heading_font') is distinct from 'string' or not ((d ->> 'heading_font') = any (fonts))) then return false; end if;
  if d ? 'effect' and (jsonb_typeof(d -> 'effect') is distinct from 'string' or not ((d ->> 'effect') = any (effs))) then return false; end if;
  if not (d ? 'effect') and not (d ? 'effects') then return false; end if;
  if d ? 'radius' then
    if jsonb_typeof(d -> 'radius') is distinct from 'number' then return false; end if;
    if (d ->> 'radius')::numeric <> trunc((d ->> 'radius')::numeric) or (d ->> 'radius')::numeric not between 4 and 32 then return false; end if;
  end if;
  if d ? 'forSubject' and jsonb_typeof(d -> 'forSubject') not in ('string', 'null') then return false; end if;
  if jsonb_typeof(d -> 'forSubject') = 'string' and char_length(d ->> 'forSubject') > 80 then return false; end if;

  -- colours: all nine, #rrggbb
  if jsonb_typeof(d -> 'colors') is distinct from 'object' then return false; end if;
  foreach k in array colkeys loop
    if jsonb_typeof(d -> 'colors' -> k) is distinct from 'string' or (d -> 'colors' ->> k) !~ '^#[0-9a-fA-F]{6}$' then return false; end if;
  end loop;

  -- button (optional): see lib/button_look.ts check_button. Keys starting with _ are notes.
  if d ? 'button' then
    b := d -> 'button';
    if jsonb_typeof(b) is distinct from 'object' then return false; end if;
    for k in select jsonb_object_keys(b) loop
      if k not like '\_%' and k not in ('style','shape','press','depth','shine','uppercase','colors') then return false; end if;
    end loop;
    if b ? 'style'  and (jsonb_typeof(b -> 'style')  is distinct from 'string' or not ((b ->> 'style')  = any (array['raised','flat','soft','outline']))) then return false; end if;
    if b ? 'shape'  and (jsonb_typeof(b -> 'shape')  is distinct from 'string' or not ((b ->> 'shape')  = any (array['round','pill','square']))) then return false; end if;
    if b ? 'press'  and (jsonb_typeof(b -> 'press')  is distinct from 'string' or not ((b ->> 'press')  = any (array['bounce','sink','wiggle','pulse','none']))) then return false; end if;
    if b ? 'depth' then
      if jsonb_typeof(b -> 'depth') is distinct from 'number' then return false; end if;
      if (b ->> 'depth')::numeric <> trunc((b ->> 'depth')::numeric) or (b ->> 'depth')::numeric not between 0 and 8 then return false; end if;
    end if;
    if b ? 'shine'     and jsonb_typeof(b -> 'shine')     is distinct from 'boolean' then return false; end if;
    if b ? 'uppercase' and jsonb_typeof(b -> 'uppercase') is distinct from 'boolean' then return false; end if;
    if b ? 'colors' then
      if jsonb_typeof(b -> 'colors') is distinct from 'object' then return false; end if;
      for k in select jsonb_object_keys(b -> 'colors') loop
        if k like '\_%' then continue; end if;
        if k not in ('bg','fg','edge') then return false; end if;
        if jsonb_typeof(b -> 'colors' -> k) is distinct from 'string' or (b -> 'colors' ->> k) !~ '^#[0-9a-fA-F]{6}$' then return false; end if;
      end loop;
    end if;
  end if;

  -- effects (optional): shape, list lengths and piece counts only
  if d ? 'effects' then
    e := d -> 'effects';
    if jsonb_typeof(e) is distinct from 'object' then return false; end if;
    if e ? 'haptic' and jsonb_typeof(e -> 'haptic') is distinct from 'boolean' then return false; end if;
    if e ? 'sound' and jsonb_typeof(e -> 'sound') not in ('string', 'object') then return false; end if;
    if e ? 'tap' then
      if jsonb_typeof(e -> 'tap') is distinct from 'array' or jsonb_array_length(e -> 'tap') > 6 then return false; end if;
      pieces := 0;
      for el in select * from jsonb_array_elements(e -> 'tap') loop
        if jsonb_typeof(el) is distinct from 'object' or jsonb_typeof(el -> 'count') is distinct from 'number' then return false; end if;
        if (el ->> 'count')::numeric not between 1 and 24 then return false; end if;
        pieces := pieces + (el ->> 'count')::numeric;
      end loop;
      if pieces > 40 then return false; end if;
    end if;
    if e ? 'background' then
      if jsonb_typeof(e -> 'background') is distinct from 'array' or jsonb_array_length(e -> 'background') > 4 then return false; end if;
      pieces := 0;
      for el in select * from jsonb_array_elements(e -> 'background') loop
        if jsonb_typeof(el) is distinct from 'object' or jsonb_typeof(el -> 'count') is distinct from 'number' then return false; end if;
        if (el ->> 'count')::numeric not between 1 and 20 then return false; end if;
        pieces := pieces + (el ->> 'count')::numeric;
      end loop;
      if pieces > 30 then return false; end if;
    end if;
  end if;

  return true;
end $$;

-- A CHECK (not a trigger) on purpose: row-level security is tested first, so a reader who tries to
-- write a theme still gets the clear "row-level security" refusal.
alter table public.themes add constraint themes_data_ok check (public.theme_data_ok(data));
-- Built-in looks live in the app; an uploaded theme may not take their ids. Ids are slugs.
alter table public.themes add constraint themes_id_ok check (
  id ~ '^[a-z0-9][a-z0-9_-]{0,59}$' and id <> all (array['paper','obsidian_gold','sugar_bloom']));

-- ---- 5. delta sync ---------------------------------------------------------------------------
create index subjects_updated_idx on public.subjects (updated_at);
create index chapters_updated_idx on public.chapters (updated_at);
create index themes_updated_idx   on public.themes   (updated_at);

-- Rows that were deleted, so a phone that was offline can remove them from its saved copy.
-- Delete cascades (a novel's chapters) fire the trigger too. Prune old rows now and then
-- (delete from public.deleted_rows where deleted_at < now() - interval '60 days'); a phone that has been
-- away longer than that does one full id check instead.
create table public.deleted_rows (
  n          bigserial primary key,
  table_name text not null check (table_name in ('subjects', 'chapters', 'themes')),
  id         text not null,
  deleted_at timestamptz not null default now()
);
create index deleted_rows_at_idx on public.deleted_rows (deleted_at);

create function public.log_deleted_row() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  insert into public.deleted_rows (table_name, id) values (tg_table_name, old.id);
  return old;
end $$;
create trigger subjects_log_delete after delete on public.subjects for each row execute function public.log_deleted_row();
create trigger chapters_log_delete after delete on public.chapters for each row execute function public.log_deleted_row();
create trigger themes_log_delete   after delete on public.themes   for each row execute function public.log_deleted_row();

alter table public.deleted_rows enable row level security;
create policy deleted_rows_read on public.deleted_rows for select to authenticated using (public.is_member());
-- no insert/update/delete policy: only the trigger above writes here

-- ---- 6. old reading progress, staged until the person first signs in ---------------------------
-- progress.user_id needs a profile, and an old user has none yet. The import script (service role) writes
-- here by email; the first sign-in moves the row into progress and removes the staged copy.
create table public.progress_import (
  email       text primary key,
  data        jsonb not null check (jsonb_typeof(data) = 'object' and octet_length(data::text) <= 100000),
  imported_at timestamptz not null default now()
);
alter table public.progress_import enable row level security;   -- no policies: only the service role and the trigger touch it

create function public.claim_old_progress() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  insert into public.progress (user_id, data)
    select new.id, s.data from public.progress_import s where lower(s.email) = lower(new.email)
    on conflict (user_id) do nothing;
  delete from public.progress_import where lower(email) = lower(new.email);
  return new;
end $$;
create trigger profiles_claim_progress after insert on public.profiles
for each row execute function public.claim_old_progress();

-- ---- 7. who may call what ----------------------------------------------------------------------
-- New functions are executable by everyone (public) and, on Supabase, by anon. Close them for the
-- signed-out role. Trigger functions never need EXECUTE to fire, so they are closed for everyone.
revoke execute on function public.is_member(), public.is_admin(), public.can_upload(),
  public.can_message(uuid, uuid), public.mark_read(uuid), public.inbox(), public.register_push_token(text)
  from public, anon;
grant execute on function public.is_member(), public.is_admin(), public.can_upload(),
  public.can_message(uuid, uuid), public.mark_read(uuid), public.inbox(), public.register_push_token(text)
  to authenticated;

revoke execute on function public.handle_new_user(), public.profiles_guard(), public.touch_updated_at(),
  public.claim_old_novels(), public.claim_old_comments(), public.comments_limits(), public.messages_rate_limit(),
  public.log_deleted_row(), public.claim_old_progress()
  from public, anon, authenticated;

