# RUSE · Plan v2 (Novels, Manga & Donghua)

Written from your notes after reading the v14 source. Nothing in this file is built yet, so every box is `[ ]`.
How to read it:
- `[ ]` not done · `[~]` code done and tested here, **waiting for your phone check** · `[x]` done and checked on your phone
- **Status (v65):** **Lively buttons.** One button for the whole app (`components/glow_button.tsx`): a raised edge that sinks when pressed, a squish-and-spring bounce, an optional shine sweep, and four more moods. Every ad hoc button (sign-in, popups, admin, Your novels, retry bars, username, profile setup) now uses it. **Buttons can be set from a theme file:** an optional `"button"` block (see **B6** below); the upload check validates it and the app falls back to the lively default for anything missing or wrong. Built-in themes got their own feel (Paper calm, Obsidian Gold square and firm, Sugar Bloom pill with a wiggle). **Backend:** Supabase migration `005_guards_and_helpers.sql` closes the SQL items left open in v63 (`username_available`, `deleted_rows`, the JSON guards, staged progress for old users, revoked execute rights) and adds a server-side theme check that includes `button`. Tests for it are written (G01 to G40) but **not run**: no Postgres was available here, run `supabase/tests/rls_test.sql` first. The Supabase project is still not created and nothing is connected. The separate `marginalia_templates` folder is only a fallback copy; the app builds the same files from `lib/templates.ts`. `tsc --noEmit` and the phone check are still open.
### v65 checklist
- [~] One lively `GlowButton`; ad hoc buttons replaced (B6)
- [~] Theme `button` block: type, upload check, templates (app + fallback folder), AI prompt, README
- [~] Built-in themes carry their own button look
- [~] SQL `005_guards_and_helpers.sql` + tests G01 to G40 (**run them: not run here**)
- [ ] `npx tsc --noEmit` on your machine **(you)**
- [ ] Phone check: Sign in, popups, Admin, Your novels, retry bars, in all three themes **(you)**
- [ ] Create the Supabase project, run migrations 001 to 005, then the tests **(you)**

- **Status (v64):** Upload files now start with `"novel"` instead of `"course"` (old files with `"course"` still upload; the old backend still gets a `"course"` copy until it moves). Frontend finished for the backend move. **B4 (templates made by the app)** is done: Settings → Author tools → Templates builds the novel, comic, theme (from the look you are using), blank theme and AI-prompt files from code (`lib/templates.ts`); Your novels has Novel / Comic template buttons and a chapter template that gives a page list for manga and webtoon novels and text blocks for novels. Every generated file was checked against the upload check (17 checks passed). "Add manga chapter from photos" now shows for webtoons too. Settings → Saved on this phone shows the space used. **Backend switch ready:** every screen now calls `api()` in `lib/backend.ts`, which sends an action to Apps Script until its name is added to `MOVED` (SUPABASE_PLAN section 13); `lib/sb/` is empty and waits for Phase 1. Dead code removed: `lib/upload_parts.ts`, `ACTION_UPLOAD_PART`, `api_part`, `lib/share_template.ts`. G3 stays dropped. All files parse and every import resolves, but the full `npx tsc --noEmit` was **not run** (no packages here): run it, then the phone check.
### v64 checklist (ticked as finished; `[~]` = code done, waiting for your phone check)
- [~] Templates made by the app: novel, comic, theme from current look, blank theme, AI prompt (Settings → Author tools → Templates)
- [~] Novel / Comic template buttons and kind-aware chapter template in Your novels
- [~] Upload files start with `novel` (old `course` files still upload)
- [~] "Add manga chapter from photos" shows for webtoons too
- [~] Saved on this phone shows the space used
- [~] Backend switch `lib/backend.ts` + empty `lib/sb/` (every screen calls `api()`)
- [x] Dead code removed (`upload_parts.ts`, `ACTION_UPLOAD_PART`, `api_part`, `share_template.ts`)
- [-] G3 dropped
- [ ] `npx tsc --noEmit` on your machine **(you)**
- [ ] Phone check of everything marked `[~]` **(you)**

- **Status (v63):** Reader and chat restyled in the v61 look: flat code blocks, serif headings with a short accent rule, flat previous / next chapter buttons, icon buttons for pin and comment (no emoji), flat pin markers, icon send button, inbox rows use the theme's radius. **Not built or typechecked yet: phone check needed.** Supabase Phase 0 prep: migrations 001–005 in `supabase/migrations/` (catalog runs before comments), tested on Postgres 16 with 125 checks passing. **Not connected to the app yet.** The SQL items that were still open then (`username_available`, `deleted_rows`, the JSON-object guard, staged progress for old users, revoked execute rights) are written in migration 005 as of v65. **(you)** Create the Supabase project and turn on the Google provider (plan Phase 0).
- **Status (v62):** App is now called **Marginalia** (display name only; package `com.ruse.academy`, slug and link scheme unchanged). Built-in themes are now **Paper** (default, gender neutral), **Obsidian Gold** (luxurious) and **Sugar Bloom** (super cute). Comments belong to the whole chapter; a writer can optionally refer to a part of it (backend: `block` -1 means whole chapter; `social_writes.gs` patched). Public / signed-in-only novels: dropped.
- **Status (v61: redesign step 1 — Paper, Ink and Blush themes, serif titles, flat header and cards, bottom tab bar, new Home; old pastel themes and effects removed from the built-ins). Status (v60):** Chat: other person's picture beside their messages, day headings, grouped bubbles, a pill composer with a round send button, **hold your own message to delete it** (backend `deleteMessage`), and the chat refreshes itself every 8 seconds while open. Pictures now show in the inbox, in chats and in comments (backend messages carry `fromAvatar` / `toAvatar`; a coloured letter shows when someone has no picture). Settings is rebuilt as small section components in `components/settings/` (profile header, username, look, theme, home photo, taps, notifications, author tools, role), each showing its own message under its own buttons. Idea being weighed: keep Drive for photos and files, move the rest of the backend to Supabase.
- **Status (v59):** Read aloud removed for good (G1). Soundtrack upload now sends the file in small pieces straight into Drive (new backend action `uploadPart`; `uploadAsset` still handles pictures). Notifications: the backend now reads and logs Expo's answers, Settings has a **Send me a test notification** button that shows which step fails, and tapping a message / comment / reply opens the right place. UI: reader buttons are one tidy dock (pin, comment, menu), one-row music bar, calmer Home photo with readable labels, and every screen keeps space under the last card for the round menu button.
- **Wrap-up (v55):** the app build is complete for this plan. Decisions taken: the Author tab opens Your novels; blocked people's comments are hidden; G3 is dropped (read-aloud is the only narration); manga pins/comments and pinch zoom are left for a later build. Still needed from you: the backend, phone checks, the new build (speech package), the privacy page brackets, and Phase H.
- **Status (latest zip v56):** O1 (offline downloads) added. Phase H trimmed: store listing and age rating dropped on your request.
- **Status before v56 (v55):** D2, D3, D4, E2 (pages and offline saving), F2 (author track), F3 (tap sounds), G1 are `[~]`. G2 dropped (no text-to-speech). Still open: G3 (confirm whether still wanted, now that G2 is dropped), Phase H. Backend list below is what unlocks the `[~]` items for phone checks.
- **(you)** = something only you can do (backend `Code.gs`, phone tests, decisions)
- *(my reading)* = I was not sure what you meant, so I picked one meaning. Tell me if it is wrong.
- Sizes: **S** small · **M** medium · **L** large. Every L is already split into smaller phases.
- After each phase I give you the whole app source as one zip.

---

## Decisions so far
- Offline login is **dropped** (A7). The phone's saved sign-in and saved novels are enough.
- **Everyone can see and reply** to comments (C3).
- Readers are shown by a **unique username**, never an email (D1a).
- **Three roles (new):** **Reader**, **Author**, **Admin**. Details in Phase R below.
- **Novel background photo (E):** the **author** can upload a background image for their novel (shown while reading that novel). Not forced; reader can still use their theme colors.
- **App / Home background (new):** each person can set a **custom background photo on the main (Home) screen**. Stored on the phone; optional; falls back to the theme background.
- **Music player (F2):** plays the **author-uploaded track for the novel**. *(Local music from the phone was dropped in v54.)*
- **Quiz is removed.** This is a novel reader, not a course. No end-of-chapter quiz.
- **Novel kinds (E1):** every work is tagged **Novel**, **Manga**, or **Donghua**.
- **Novel-exclusive themes:** a theme uploaded by an author **for a novel** (`forSubject`) stays on that novel only. It does **not** appear in the Settings theme picker.

---

## 0 · Where we are (v14, already built)
Sign in with Google · offline reading (the offline login is being removed, A7) · access requests and admin screen · Home / category / course / chapter reader · progress · pins and comments (synced, with push) · your courses (create, delete, chapter template) · themes with designed tap effects and sounds · tap effects, haptics, floating shapes.

---

## Phase A · Fix-ups from the v14 review (do these first)
**Part 1 delivered (v15). Part 2 delivered (v16): A3, A4, A6 and the status bar of A1. Waiting for your phone check and one `tsconfig` decision (see A6).**
Small, safe, and they stop bugs from spreading into the new work.
- [x] **A1 · Dark themes readable (S).** Quiz choices and tip callouts use fixed dark text, so they vanish on dark themes. Use theme colors. Status bar follows the theme (light icons on dark themes).
  - *Part 1 done:* quiz, callouts, table header, finish/next buttons. *Part 2 done:* status bar follows the theme (light icons when the theme background is dark). **(you)** phone check: switch themes, look at the clock/battery icons.
- [x] **A2 · No silent loss (S).** If the server refuses a queued pin or comment, show a small message and keep the text so it can be retried. Show "N changes waiting to send" somewhere visible.
  - *Done:* refused comments/pins are kept in a "not accepted" card (Retry / Throw away); "N changes waiting to send" card on Home, chapter and comment sheet. **(you)** phone check: turn on airplane mode, comment, then reconnect.
- [x] **A3 · Honest "Saved … ago" (S).** Finishing a chapter offline must not reset the saved time to "just now".
  - *Done:* the saved time only moves when the server really answered. **(you)** phone check: airplane mode, finish a chapter, the ribbon still says the old time.
- [x] **A4 · Remove dead code (S).** Delete `lib/notes.tsx`, `lib/notes_helpers.ts`, `NotesProvider`, `components/block_tools.tsx`, the unused `BlockView` props, and the duplicate animation loop in `DesignedFloater`.
  - *Done:* the three files and `NotesProvider` are gone; the unused `BlockView` props were already removed; glyph floaters now run one loop instead of two.
- [x] **A5 · Sign-out cleanup (S).** Also remove pins, queued progress and push-token files from the phone.
  - *Done:* Sign out now removes me, novels, queued progress, pins/queue, push token and old notes file (theme choice stays on purpose).
- [x] **A6 · Imports (S).** About 12 files import with `.ts` on the end. Add `allowImportingTsExtensions` to `tsconfig.json` (or drop the `.ts`) so `npx tsc --noEmit` passes.
  - *Done:* the `.ts` endings are removed from all imports, so no `tsconfig` change is needed. **(you)** run `npx tsc --noEmit` on your machine (the zip has no `package.json`/`tsconfig.json`, so I could only syntax-check here) and send me any errors.
- [x] **A7 · Drop the offline login (M), decided.** The phone already keeps you signed in and keeps your saved novels, so a second username and password adds nothing.
  - *Done in code:* screens/files removed, Home button and prompt removed, only Sign out wipes data, app opens saved profile after 6 s if Google is silent. **(you)** run `npm uninstall expo-secure-store expo-crypto`, remove `expo-secure-store` from `app.json` plugins if listed, new build, then test airplane-mode start.
  - Remove the "Log in offline" button, `app/offline_login.tsx`, `app/offline_setup.tsx`, `lib/offline_login.ts`, `lib/offline_store.ts`, `lib/sha256.ts`, and the "make your offline login" prompt on Home. Remove `expo-secure-store` and `expo-crypto` from `package.json` if nothing else uses them (new build).
  - Make offline start reliable: if the app opens with no network, it always opens the saved profile and saved novels. The only thing that wipes saved data is **Sign out**. (Today a "nobody is signed in" answer from Google, even while offline, wipes it.)
  - Honest note: anyone holding your unlocked phone can read the saved novels. That is the same as any reading app, so I treat it as fine.
- [x] **A9 · Never show an email to other readers (S).** Comments use `me.name || me.email` as the name, so a person without a name shows their email. Until usernames exist (D1a), fall back to "Reader" instead of an email.
  - *Done:* names fall back to "Reader"; an email-looking name from old comments is masked too.
- [x] **A8 · Chapter fonts (S).** `chapter_fonts()` honors every loaded font (Lora, Newsreader, …), not just Quicksand.
  - *Done:* any loaded font works, case-insensitive, kept exactly on every theme.

---

## Phase B · Words, templates and themes menu (quick wins)
**Doing it in parts. Part 1 = B1 (v17). Part 2 = B2 + B3 (v18). B4 waits until Phase R (roles) is in.**
- [x] **B1 · Course becomes Novel (M).** Every word the reader sees changes: "Your courses" → "Your novels", "Course template" → "Novel template", and so on. Ids and backend action names stay as they are, so nothing breaks. One word list in one file, so it can change again in minutes.
  - *Done (v17):* the list is `lib/words.ts` (`W.novel`, `W.novels`, …). Home, Settings, Your novels, category, novel screen, offline ribbon, upload messages, read-me and template hints all use it. Ids, file keys (`"course"`, `"subject"`) and backend action names are unchanged. The template file is now named `ruse-novel-template.json`. **(you)** phone check: look through Home, Settings, Your novels and Read me for any leftover "course". Note: the server's own error text "Unknown course" still says course until you change it in `Code.gs`.
- [x] **B2 · Templates (S), your note 7.**
  - Settings shows only **Novel template** and **Theme template**. Both are for **Authors and Admins** (Readers see neither, see Phase R).
  - **Chapter template is removed from Settings.** It stays inside **My novels**, per novel, already filled with that novel's id. That way a chapter can never be made without a novel.
  - *Done (v18):* Settings now has only Novel template (all) and Theme template (owner only). Chapter template lives in Your novels. Help texts point there. **(you)** phone check: Settings → Empty templates; Your novels → Chapter template still downloads.
- [~] **B4 · Templates generated in the app (M), your note: "why do you give me a template, the app should generate it".** The zip in `marginalia_templates/` becomes a fallback only. Each screen makes its own template file.
  - **Theme screen** → "Download theme template": a theme JSON prefilled with the current theme's colours, radius and effects. Blank option too. Lists only fonts the app has installed (see the font list in `fonts/built_in_fonts.json`).
  - **Authors screen** → "Download comic template" and "Download novel template": the whole-file shape with the `course` block and one example chapter.
  - **Inside a comic or novel (My novels)** → "Download chapter template": one chapter with a page list (comic) or text blocks (novel), already filled with that novel's id.
  - Each file carries short `_` notes with the rules (limits, https links, colours as #rrggbb), so it works without the prompt file.
  - Generated from code in `lib/templates.ts` (already holds the course template); saved with the share sheet or to app storage, not to a public folder.
  - The AI prompt (`PROMPT_for_AI.txt`) stays downloadable from Settings as a text file.
  - *Done in the app (v64):* builders in `lib/templates.ts`, buttons in Settings and Your novels, every file passes `lib/upload_check.ts`. Theme templates list only the 7 installed fonts. **(you)** phone check: download each file, open it, upload it back.
- [x] **B3 · Themes as a dropdown (S), your note 8.** One tidy picker instead of a wall of chips. Shows color dots and the name.
  - *Done (v18):* new `components/theme_picker.tsx`: a button with the current theme's dots and name, opens a list with a ✓ on the current one. **(you)** phone check: open it on a dark and a light theme, pick a theme, close by tapping outside.
- [x] **B4 · Remove themes (M), your note 8.** *(moved after Phase R)* A "Remove" in the dropdown for uploaded themes (built-in ones cannot be removed): **Admin any, Author only their own**. Asks "Are you sure?" first.
  - *Done in the app (v25):* Theme picker shows **Remove** on uploaded themes the role may delete (admin = any non-built-in; author = `mine` or `createdBy` matches email). Confirm dialog first. Calls `deleteTheme(id)`; if the current theme is removed, switches to the default built-in; then refreshes. Built-ins never show Remove. Theme type accepts `createdBy` / `mine` from the server. **(you)** phone check: as admin, remove an uploaded theme; confirm built-ins have no Remove; after remove the list updates.
  - Novel-exclusive themes (`forSubject`) are **hidden from the picker** (they stay on the novel); Remove in the picker only applies to global uploaded themes.
  - **(you)** Backend: `deleteTheme(id)`: admin any uploaded theme; author only a theme they uploaded; never a built-in one. Prefer returning `mine` / `createdBy` on each theme in `getCourseData`. Themes with `forSubject` are novel-only.
- [x] **B5 · Home / app background photo (S→M), your note.** Each person can pick a **custom photo as the Home (main) screen background**. Stored only on the phone. Optional; if none, the current theme background is used. A clear "Remove background" control. Uses `expo-image-picker` (same package as D1 avatar; new build when that lands).
  - *Done in the app (v27):* Settings → **Home background** (Choose / Change photo, preview, Remove). Image is copied into the app's private folder (`lib/home_bg.ts`) and remembered like the theme (stays after sign-out). Home screen shows it with a soft theme-coloured scrim so text stays readable. Reloads when you return from Settings. **(you)** phone check after a build that includes `expo-image-picker`: pick a photo, leave and reopen Home, remove it. If the picker module is missing, Settings shows a clear "needs a new build" message.

---

- [~] **B6 · Lively buttons, settable from a theme file (M), your note.**
  - **Look:** `GlowButton` is the one button. Default `raised`: a thick bottom edge that the face sinks into when pressed, plus a squish-and-spring bounce and a shine band that sweeps across. `size` is `lg` (default), `md` or `sm`; `outline` and `soft` are the quiet versions; `danger` keeps a red button red whatever the theme says. With the phone's "reduce motion" on, animations are skipped.
  - **Theme file:** optional `"button"` block. All keys optional; anything missing uses the default.
    - `style`: `raised` | `flat` | `soft` | `outline`
    - `shape`: `round` (follows the theme's radius, calmed down) | `pill` | `square`
    - `press`: `bounce` | `sink` | `wiggle` | `pulse` (gentle breathing while waiting) | `none`
    - `depth`: whole number 0 to 8 (raised edge thickness; small buttons stay flat)
    - `shine`: true | false · `uppercase`: true | false
    - `colors`: `{ "bg", "fg", "edge" }` as `#rrggbb`; leave out to use the theme's primary and accent
  - **Code:** `lib/button_look.ts` (types, `check_button`, `resolve_button`; pure, no React), `components/glow_button.tsx`, `Theme.button` in `lib/types.ts`, `check_theme` calls `check_button` in `lib/upload_check.ts`, built-in looks in `lib/theme.tsx`, theme templates and AI prompt in `lib/templates.ts`.
  - **Not covered on purpose:** selectable chips (kind and gender pickers), plain text links, and the card action label on novel cards are not buttons in this sense.
  - Checked here: the check and the resolver (all cases pass) and every template file against the upload check. **Not run:** typecheck and the phone. **(you)** phone check: all three themes; try a theme file with `"shape": "square"`, `"press": "pulse"` and custom `colors`; try a bad value (for example `"depth": 20`) and see the plain-words error.
  - **Backend:** whatever stores themes must keep the `button` key (Supabase: `themes.data` is jsonb and passes it; the check is in migration 005; the old Apps Script `saveTheme` would need to allow it).

---

## Backend at a glance (Supabase, planned; details in SUPABASE_PLAN_v2.md)
Nothing is connected yet. The app talks to the backend only through `api()` in `lib/backend.ts`; an action goes to Apps Script until its name is added to `MOVED`. All SQL lives in `supabase/migrations/` and runs in this order:

| File | What it holds |
|---|---|
| `001_profiles_and_access.sql` | `profiles`, `invited_users`, roles, first sign-in trigger, `is_member()` / `is_admin()` / `can_upload()`, guard against editing your own role, `public_profiles` view (no emails) |
| `002_chat.sql` | `messages`, `blocks`, `reports`, `push_tokens`, rate limits, `inbox()`, `mark_read()`, `register_push_token()` |
| `003_catalog.sql` | `subjects` (novels), `chapters`, `themes`, `progress`, `updated_at` triggers, old novels claimed at first sign-in |
| `004_comments_and_pins.sql` | `comments`, `pins`, limits, old comments claimed at first sign-in (needs 003 for "who may delete") |
| `005_guards_and_helpers.sql` | `username_available()`, JSON guards on novels, chapters and progress, `theme_data_ok()` (incl. `button`) and built-in id block, `deleted_rows` for delta sync, `progress_import` for old users, revoked execute rights |

Rules that hold everywhere: every table has Row Level Security; a reader never sees another person's email; the server checks who may do what and the app only hides buttons; uploads are untrusted and checked in the app **and** in the database. Files (pictures, manga pages) stay on Drive through the small Apps Script file service. Tests: `supabase/tests/rls_test.sql` (K = catalog, G = guards and helpers, and the earlier sections for profiles, chat, comments).

---

## Phase R · Three roles: Reader, Author, Admin (new, comes right after B3)
| | Reader | Author | Admin |
|---|---|---|---|
| Read novels, progress, pins | yes | yes | yes |
| Comment, reply, message others | yes | yes | yes |
| Upload novels and chapters, Your novels | no | yes (own) | yes (all) |
| Add themes | no | yes | yes |
| Recommend a theme for their novel (E4) | no | yes (own novels) | yes |
| Remove themes (B4) | no | own uploads | any uploaded theme |
| Delete comments | own only | own + on their novels | any |
| Accept / refuse new requests, set roles, see reports | no | no | yes |
- [x] **R1 · Roles in the app (M).** One small file (`lib/roles.ts`) answers "may this person do X?" from `me.role`, so every screen asks the same place. Settings shows only what the role allows: Readers see no Upload, no templates, no Your novels, no Theme template. *(The app only hides buttons; the server checks again.)* Old `isOwner` / `admin` flags keep working as Admin until the backend sends `role`.
  - *Done in the app (v21), backend left for later as you asked:* new `lib/roles.ts` (tested). While `me.role` is missing, owner/admin = Admin and everyone else stays Author, so nothing disappears today; a role the app does not know = Reader. Settings shows your role next to your email; Readers see no Upload, no templates, no Your novels, no Theme template, but get a "You are a Reader" card with **My progress** (reset progress). Admin screen and the people list open for any Admin. Home's empty text is reader-friendly. **(you)** phone check: you should still see everything as owner. *The role checks on the server are still to do (R1 backend line below).*
  - **(you)** Backend: `me` returns `role` (`reader` | `author` | `admin`). **Every** write action checks the role on the server (upload, saveTheme, deleteTheme, saveSubject, deleteSubject, deleteChapter…).
- [x] **R2 · Admin screen (M).** Today only the owner reaches People & access. It becomes the **Admin** screen: accept or refuse new requests (new people start as **Reader**; admin can accept as Reader or Author), change a person's role, remove a person. Shows emails to admins only (everyone else sees usernames, D1a).
  - *Done in the app (v22):* Admin screen uses roles end-to-end. Requests: **As Reader** / **As Author** / Reject. People list shows role and lets you set Reader / Author / Admin (current one filled) + Remove. Add-person picks a role. Types and normalizer accept `role` from the server (fallback: old `admin` flag → admin, else author so existing people keep upload rights). New actions: `approveRequest(email, role)`, `setRole({ email, role })`; `addUser` also sends `role` (+ `admin` for older backends). Settings button now says "Admin · people & roles". **(you)** phone check: open Admin as owner, confirm lists still load; try role chips (backend may still reject until Code.gs is updated).
  - **(you)** Backend: `approveRequest(email, role)`, `setRole(email, role)` (admin only); keeps `addUser` / `removeUser`. Prefer role over the old admin boolean. New people default to **reader**.
- [x] **R3 · "Become an author" request (S).** A Reader can tap "Ask to become an author"; admins see it in the same request list. *(my reading: authors are not self-service)*
  - *Done in the app (v23):* Settings → Reader card has **Ask to become an author** (calls `requestRole('author')`). While `me.roleRequestStatus === 'pending'`, shows a waiting line instead. Admin screen shows role-upgrade requests in the same Waiting list with **Make Author** / **Dismiss** (and a "Wants to become an Author" hint). Normalizer also merges a separate `roleRequests` list if the backend sends one, and accepts `pendingRole` / `requestedRole` / `kind: 'role'`. **(you)** phone check: as a Reader, send the request; as Admin, open Admin and approve/dismiss (needs backend).
  - **(you)** Backend: `requestRole('author')` (reader only; sets a pending role request). Include those in `getAdminData` requests (or `roleRequests`) with `pendingRole: 'author'`. `me.roleRequestStatus` = `'pending'` while waiting. Approve = `setRole(email, 'author')` (or approve path); dismiss clears the pending flag (e.g. via `rejectRequest`).

## Phase C · Reader upgrades
**Doing it in parts. Part 1 = C1 (v19). Part 2 = C2 (v20). Next: C3 (everyone sees comments; needs the backend and roles).**
- [x] **C1 · Back-button wrap-up popup (S), your note 1.** *(my reading)* When you press Back inside a chapter (header Back or the phone's back button), a small closing message appears instead of leaving right away. For example: "Nice reading! Pin your place, mark it complete, or leave." with three buttons. If the chapter is already complete, it just says goodbye with Leave / Stay.
  - *Done (v19):* new `components/leave_popup.tsx`. The header Back and the phone's back button (Android) both open it. "Pin my place" pins the block nearest the top of the screen, then leaves; "Mark complete" completes then leaves; tapping outside = Stay. **(you)** phone check: scroll halfway, press Back, Pin, reopen the chapter and see it jumps to the pin; also test on a completed chapter. *Not covered:* the iPhone swipe-back gesture still leaves directly.
- [x] **C2 · Floating pin and comment buttons (L→M), your note 2.**
  - Remove the Pin / 💬 row that sits under every block.
  - Two small round buttons float at the screen edge (📍 and 💬). You **drag one and drop it on a block**: the pin sticks there, or the comment box opens for that block.
  - They can be dragged to the other edge and remember where you left them. Blocks that already have comments show a small bubble count.
  - A long press on a block is the backup way, for people who do not like dragging.
  - *Done (v20), no new package and no new build:* I used React Native's built-in touch handling instead of a gesture library, so nothing needs installing. New: `components/floating_tools.tsx`, `lib/drop_target.ts` (tested), slimmer `components/pin_bar.tsx`.
  - How it works: drag 📍 or 💬 onto a paragraph (the paragraph lights up under your finger); drop near the opposite screen edge to move the buttons there (the side is remembered); a short touch shows a hint; long-press a paragraph for the backup menu (Pin / Comments). Blocks with a pin or comments still show a small "📌 Pinned" / "💬 N" tag under them; blocks with nothing show no row.
  - **(you)** phone check: drag each button onto a paragraph, drop it in empty space (it springs back), drag to the other edge, restart the app (side is remembered), long-press a paragraph. *Known limit:* the page does not auto-scroll while dragging, so drop on a paragraph that is on screen.
- [x] **C3 · Everyone can see and reply to comments (M), your notes 3 and update.**
  - Comments on a chapter are visible to every signed-in reader, shown with **username** and avatar (never an email).
  - **Anyone can reply to any comment.** Today only the comment's author and the uploader can. Replies stay one level deep (a reply to a reply goes into the same thread) so threads stay readable.
  - The uploader's replies keep an "author" tag.
  - Pins stay private (they are your place in the book).
  - **Admin** can delete any comment or reply; an **Author** can delete any comment on their own novels; everyone can edit or delete their own.
  - The "Comments on my chapters" inbox on Home still lists threads on your novels that need a reply.
  - *Done in the app (v29), backend left for you:* Reply is offered on every root comment for any signed-in reader (one level deep still). Delete: own, or uploader/`mine`/`can_manage` on the chapter, or admin. Tag shows **· author** for uploader replies. Visibility of *other people's* comments still depends on `getComments` returning them. **(you)** phone check once backend allows global reply + full `getComments`.
  - **(you)** Backend: `getComments` returns all comments of the chapters asked for; `replyComment` allowed for any signed-in user (not only author/uploader); comments return `username` and `avatarUrl`, never `email`.

---

## Phase D · People: profile, avatar, messages
Split into four, because messages need rules before they need screens.
- [x] **D1a · Unique usernames (M), your new note.** Do this early: public comments and the uploader name need it.
  - Everyone picks a **unique username** (3 to 20 letters, digits, `_` or `.`; not case sensitive; no spaces; blocked words list). It is checked on the server, so two people can never share one.
  - The username is what other readers see: on **comments and replies**, on **profile cards**, in **messages**, and as the **uploader name on every novel and chapter** ("by `username`"). **Email addresses are never shown to other readers.**
  - You can change it, but not more than once every 30 days, and old comments update to the new name.
  - Existing people get asked once on their next sign-in. Until they choose, they show as "Reader".
  - Where emails leak today and will be fixed: comment names (A9), "by email" in My novels, and `uploadedBy` in the data sent to every phone. The app should receive the uploader's **username** plus simple flags (`mine`, `can_manage`) instead of the uploader's email. The owner's People & access screen keeps showing emails, because the owner must know who is who.
  - *Done in the app (v28):* `lib/username.ts` (rules + blocked list + 30-day helper). `UsernamePrompt` on Home when `me.username` is missing. Settings → Username (save/update, client rate-limit hint). Comments post with `public_name(me)`. My novels masks email-like `uploadedBy` via `display_name` / `uploaderName`. Actions: `checkUsername`, `saveUsername`. Types: `Me.username`, `usernameChangedAt`; chapter/subject `uploaderName`, `mine`, `can_manage`. **(you)** phone check after backend: first login prompt; Settings change; comments show username.
  - **(you)** Backend: `checkUsername(name)`, `saveUsername(name)`; store per user; `me` returns `username` + `usernameChangedAt`; comments return username not email; chapters/novels return `uploaderName` + `mine`/`can_manage` (do not send uploader emails to non-admins). Enforce unique (case-insensitive) and 30-day change limit.
- [x] **D1 · Profile + two main themes (M).**
  - First sign-in asks: your **username** (D1a), **gender** (Boy / Girl; plus "Skip" which lets you pick a main theme yourself), and an **avatar** (optional).
  - Two **main default themes**: one for boys, one for girls. They are picked automatically from the gender answer. You can change theme any time; the other themes stay available.
  - *(my reading)* The five pastel themes stay as extra themes. I will design a boy main theme (cool and dark, with its own tap effect). **(you)** tell me if you want more boy themes later.
  - Avatars are shrunk to a small square on the phone before sending (new package `expo-image-picker`, plus `expo-image-manipulator`, so a new build is needed).
  - *Done in the app (v30), backend left for you:* After username, **ProfileSetup** asks Boy / Girl / Skip + optional avatar. Boy → **Midnight Tide** (new built-in, cool dark, ripple). Girl → **Cotton Candy**. Skip → no theme force. Settings → Profile can change gender (re-applies main theme) and avatar. Gender also saved locally so setup works before Code.gs is ready. **(you)** phone check after build with image picker/manipulator; confirm Midnight Tide appears in the theme list.
  - **(you)** Backend: `getProfile`, `saveProfile({ gender })`, `saveAvatar(base64)` (stored in a Drive folder; see Phase E1 for the folder idea), and `me` returns `gender` and `avatarUrl`.
- [~] **D2 · Profile cards (S).** Tap a username or avatar on a comment, reply or novel to see a small card: avatar, username, "Send message". No email, no real name.
  - *Done in the app (v35):* tapping a name on a comment or reply opens a card (`components/profile_card.tsx`, helper `lib/profile_card.ts`): avatar (or initial), username, and a "Send message" button that says "coming in a later update" until D3. Not tappable: your own name, "Reader", emails. Novel and inbox names are not wired yet. **(you)** phone check: tap a name on a comment. **(you)** Backend: comments should also return `avatarUrl` (optional; without it the card shows the initial).
- [~] **D3 · Direct messages, simple (M→L), your note 4.** Not a chat app: plain text, a list of conversations, a thread screen, push notification, "unread" dot. No typing indicators, no read receipts, no photos.
  - *Done in the app (v36):* Home card "✉️ Messages" with unread badge (`app/index.tsx`); inbox `app/messages.tsx`; conversation `app/message/[name].tsx` (plain text, max 500 characters, opening marks read); "Send message" on the profile card opens it. Logic in `lib/messages.ts` (tested here), server calls in `lib/messages_api.ts`, action names in `lib/actions.ts`. Sending needs a connection and is never queued. **Not done yet:** push notification for a new message (needs a new build and the backend). Until the backend exists the screens show "Could not load messages".
  - **(you)** phone check after the backend is in place.
  - Messages go to a **username**, never an email. **(you)** Backend: `sendMessage({ to_username, text })`, `getThreads`, `getMessages`, `markRead`.
- [~] **D4 · Safety (M).** Because everyone can comment and anyone can message: **Block**, **Report**, a limit on how many messages a new person can send per hour, and **Admins** can see reports and turn messaging off for a person. Without this I would not ship D3.
  - **(you)** Backend: `blockUser`, `reportUser`, rate limit, admin list of reports.
  - *Done in the app (v37):* Block and Report on the profile card (report asks for a reason from five choices; no free text). Block asks first. Blocked people are hidden from the inbox, and a conversation with one shows Unblock. Tapping the name in a conversation opens the card. Admin screen has a **Reports** list: Messages off/on per person, and Dismiss. Helpers in `lib/safety.ts` (tested here), calls in `lib/safety_api.ts`.
  - **Not done yet:** blocked people's comments are still shown (the plan does not say to hide them; say if you want that). The rate limit is the server's job: the app shows the server's message. Admin "messages off" is also enforced only by the server.
  - **(you)** Backend: `blockUser`, `unblockUser`, `getBlocked`, `reportUser` (with rate limit), `getReports`, `resolveReport`, `setMessaging`. Phone check after that.

---

## Phase E · Novels, Manga and Donghua
- [x] **E1 · Library model + Drive folder per novel (M).**
  - Every novel and chapter shows **"by username"** (the uploader's unique username, D1a), never an email.
  - Every novel gets a **kind**: Novel, Manga or Donghua *(my reading: Donghua = a novel or adaptation shown with its own look; Manga = picture pages)*.
  - Creating a novel makes a **Drive folder** and returns its id (**you**, backend, as you said). The folder holds: manga pages, music, narration audio, **novel background photo**, avatar-style files.
  - *Done in the app (v31), backend left for you:* `NovelKind` on Subject (`kind`, `folderId`, `uploaderName`). Create form has **Novel / Manga / Donghua** chips; `saveSubject` sends `kind`. Home + category cards show kind + `by username` (email masked). Course screen header shows kind · by · summary. Your novels list shows kind and "folder ready" when `folderId` is present. `uploadAsset` action ready. Template sample includes `course.kind`. **(you)** phone check after backend creates folders and returns kind/uploaderName/folderId.
  - **(you)** Backend: `saveSubject` accepts `kind` and creates `folderId`; `uploadAsset({ folderId, name, mime, base64 })`; reading assets back as links the app can open. Apps Script has size and daily limits, so I will check the exact numbers in Google's docs before we depend on them. For big files the fallback is to paste a Drive share link. Return `uploaderName` (not email) on subjects/chapters for non-admins.
- [~] **E2 · Manga reader (L→M).** A new chapter type made of images: a vertical strip you scroll, page-by-page mode, pinch to zoom, pre-load the next pages, save pages on the phone for offline reading. Upload as a folder of images or a list of image links.
  - *Done in the app (v38), first part:* a manga chapter is a list of https page links, `"pages": [...]` in the chapter JSON (up to 300). `components/manga_reader.tsx`: **Scroll** (pages stacked, scrolls with the chapter) and **Page by page** (swipe, or tap the left/right third), "3 / 24" counter, next 3 pages fetched early. Upload check accepts `pages` (`lib/manga.ts`, tested here).
  - *Done in the app (v44), offline pages:* **Save pages offline** downloads every page of a manga chapter to the phone, with progress; the reader then uses the phone's copies ("✓ Saved on this phone"). Uses `expo-file-system`, already in the app. Shows a rough size before saving.
  - *Done in the app (v47), uploads:* **PDF is dropped.** Opening a PDF inside the app needs a PDF rendering package and a new build, and it renders differently on each phone, so it is too much trouble. The fallback you chose: **Add manga chapter from photos** on a manga novel (pages in the order tapped, each shrunk on the phone and uploaded to the novel's folder, saved as one chapter). **JSON** chapters are unchanged (Settings → Choose file).
  - **Not done yet:** pinch to zoom (needs a gesture package: new build). Manga pages from photos: dropped (you asked for PDF and JSON only). (needs a picker and the backend's `uploadAsset`); pins and comments on manga pages (they attach to text paragraphs). Drive share links are not image links: use the direct link from `uploadAsset`.
  - **(you)** Backend: `uploadAsset` returns a direct image link for each page and audio link for the soundtrack, and `saveChapter` accepts `pages`.
- [x] **E3 · Quiz removed (S), your note.** This is a novel reader, not a course. The knowledge quiz is gone from the chapter reader, templates, read-me and upload checks. Old JSON may still carry a `quiz` field; the app ignores it. *(Earlier idea of reactions / polls / character vote is dropped unless you ask for it later.)*
  - *Done in the app (v24):* deleted `components/quiz.tsx`; chapter screen no longer renders quiz; templates and read-me no longer mention quiz; upload accepts (and ignores) a leftover `quiz` field so old files still load.
- [x] **E4 · Recommended / novel-exclusive theme (S→M), your note 5.** *(Authors and Admins only, for their own novels)*
  - The author uploads a theme **for that novel** (`forSubject` = novel id). It is **novel-exclusive**: stored with the novel and **not** listed in the global Settings theme picker (filter already in the app, v25).
  - When a reader opens the novel they see a banner: "The author recommends **Name**. Try it?" Yes / No / Always for this novel. Never forced.
  - *(Earlier idea: also list under "From authors" in the global picker — cancelled; exclusive means it stays on the novel only.)*
  - *Done in the app (v32), backend left for you:* `forSubject` accepted on theme upload; theme template + **Theme for this novel** download in Your novels (pre-fills `forSubject`); global picker still hides novel themes; recommend banner (Yes / No / Always) on novel + chapter screens; choice stored on the phone; theme override while on that novel only (`set_theme_override`). **(you)** phone check after backend returns novel themes with `forSubject`.
  - **(you)** Backend: `saveTheme` accepts `forSubject`; `getCourseData` returns novel themes with `forSubject` set (and/or `recommendedThemeId` on the subject). Author only for own novels; admin any.
- [x] **E5 · Novel background photo (S→M), your note.** *(Authors and Admins only, for their own novels)*
  - Author uploads one image as the novel's **reading background** (stored in the novel's Drive folder, E1).
  - When a reader opens the novel, the chapter reader can show that image behind the text (dimmed / with a scrim so text stays readable). Optional: reader can turn it off in the chapter menu and keep the theme only.
  - *Done in the app (v33), backend left for you:* Your novels → **Reading background** / Change / Remove (needs `folderId`); image resized on phone then `uploadAsset` + `saveSubject({ id, backgroundUrl })`; chapter reader shows photo with theme scrim; **Hide / Show author background** toggle (phone-only per novel). **(you)** phone check after backend returns `backgroundUrl` and `uploadAsset` returns `{ url }`.
  - **(you)** Backend: `uploadAsset` stores in novel folder and returns `{ url }`; `saveSubject` accepts `backgroundUrl` (set or clear with `""`); `getCourseData` returns `backgroundUrl` on the novel.

---

## Phase F · Sound and music
- [x] **F1 · Luxury sound set (M), your note 6.**
  - *Done in the app (v34), no new package:* six soft voices in `lib/sound_code.ts`: **glass, harp, silk, water, piano, swell** (layered harmonics, slow fade, small room echo, peak = the set volume). Old names (`pop`, `bubble`, `chime`, `sparkle`, `tick`, `fanfare`) now map to the soft set, so uploaded themes keep working; `sine/square/triangle` sound codes still work, and a sound code may use a voice name as its `wave`. Template and Read me text updated. **(you)** phone check: switch themes with different sounds and tell me which voices to change; I put 6 preview `.wav` files next to this zip so you can listen first. The current tap sounds are simple computer beeps (square and triangle waves). They get replaced by a soft set:
  - glass bell, harp pluck, silk shimmer, water drop, soft piano note, quiet "sparkle" swell,
  - gentle, short, reverb-like tails, low volume, never harsh.
  - I cannot download recorded sounds, so I will **synthesize** them (layered harmonics, slow decay, a little reverb), save them as audio files inside the app, and let you listen on the phone. **(you)** If you have recorded sounds you like and are allowed to use, send them and I use those instead; that is always better.
  - Theme files can still name a sound; old preset names (`pop`, `chime`, …) map to the new set so uploaded themes keep working.
- [~] **F2 · Background music player (L→M).** While reading, soft looping music.
  - *Done in the app (v39), author track part:* chapter reader shows a music bar when the novel has an author track (`musicUrl`, https): Turn on/off per novel, Mute, volume − / +. Keeps playing while you turn chapters of the same novel; stops when you leave the novel (after a short pause) or put the app away. Choices are kept on the phone. Uses `expo-audio`, already in the app.
  - *v54:* **local music from the phone is dropped** (you asked: keep only the author's tracks). The music bar offers **Author track** or **Off**, with volume and mute. The bar shows for every novel that has an author track.
  - *Done in the app (v46), author soundtrack:* Your novels → **Add soundtrack** / **Change soundtrack** picks an audio file (mp3, m4a, wav, ogg; up to 30 MB), uploads it to the novel's folder and links it as the novel's `musicUrl`.
  - **(you)** Backend: `getCourseData` returns `musicUrl` per novel (a direct https audio link from the novel folder). Phone check after that.
  - **Sources (either):**
    - **Author track** uploaded for that novel (Drive folder, E1), or
    - **Local music** the reader picks from their phone (stays on device; not uploaded).
  - Small player: play/pause, volume, mute, source switch (Author / Local / Off). Remembers choice per novel where possible.
  - Keeps playing as you turn chapters; stops when you leave the novel or put the app away.
  - Author track downloads once for offline.
  - **(you)** Backend: stores the author file in the novel's Drive folder (Phase E1); `getCourseData` returns its link. Local pick needs a media-library / document permission on the phone (new build).
- [~] **F3 · Mixing (S).** Tap sounds, music and narration share one volume plan: music lowers itself while narration speaks or a tap sound plays.
  - *Done in the app (v40), tap sounds part:* while a tap sound plays, the background music drops to about a third for 1.2 s, then comes back (`duck_music` in `lib/music_player.ts`, called by `lib/sound_play.ts`). The same hook is ready for narration (G1). **Not done yet:** narration ducking (G1 not built). **(you)** phone check: play a tap sound while music plays.

---

## Phase G · Narration (text to speech)
Honest note first: the voices built into a phone sound robotic. Very human voices come from **cloud neural voices** (for example Google Cloud, Microsoft Azure, OpenAI or ElevenLabs). These are already trained; we do not train anything ourselves. They cost money per character and need a secret key, which must stay **on the backend**, never in the app.
- [~] **G1 · Read aloud on the phone (M).** Quick first version using the phone's own voices: play / pause, speed, pick a male or female voice, highlights the paragraph being read. Free and works offline, but not "human". It is the base for G2.
  - *Done in the app (v41):* read-aloud bar in the chapter reader: Play / Pause, previous / next paragraph, speed (0.75× to 1.5×), female or male voice (best guess from the phone's voice names), and the paragraph being read is highlighted and kept on screen. Paragraphs, headings, callouts and list items are read; code and tables are skipped. Pause stops, and Play starts again from the same paragraph. Uses `expo-speech`.
  - **New package, so a new build:** `expo-speech`. **Not built yet:** the male/female choice depends on the phone's voice names, so on some phones it may not change. Pinch zoom and other items stay as in E2.
  - **(you)** phone check on a real phone after the new build.
- [-] **G2 · Human narration (L). DROPPED.** You said there is no need for text-to-speech (the Google Cloud voice choice and budget are not needed). G1 read-aloud on the phone is the narration.
  - The backend asks the TTS service for each chapter once, saves the result as an audio file in the novel's folder, and the app plays it (and can download it).
  - Male and female narrator per novel (the author picks the default; the reader can switch).
  - Text blocks are read; headings and code are handled sensibly; names can be given a spelling hint so Chinese names are pronounced well.
  - **(you)** choose the service and budget (see questions). Backend: `generateNarration(chapterId, voice)` that stores the audio and returns its link, with a daily limit to protect the bill.
- [-] **G3 · Player polish (S). DROPPED** (read-aloud is gone).  Progress bar, 15 s back / forward, sleep timer, continue from where you stopped, and works together with the music (F3).

## Offline downloads (O1)
- [~] **O1 · Download a novel for airplane mode (M).** On a novel's screen, **Download for offline** saves its manga pages, its author soundtrack and its background photo to the phone, with progress. Airplane mode then uses the phone's copies. Remove deletes them. **Sign out deletes every download from the phone**, as well as the saved data.
  - *Done in the app (v56):* `lib/downloads.ts` keeps one index on the phone (link → file). The manga reader, the music bar, the reader background and the Home cards all use the phone's copy when there is one. Sign-out calls `delete_all_downloads()` in `lib/auth.tsx`. Logic tested here with a mocked file system (11 checks passed).
  - **(you)** phone check: download a novel with Wi-Fi, turn on airplane mode, read it, play its track and see its pages. Then sign out and check the files are gone from the phone storage.

---

## Phase H · Ship it 🚀
- [ ] Release build and app icon / splash check (bundled sounds, images and fonts increase the size, so check it)
- [~] Privacy policy page (avatars, gender, messages, comments are personal data). *(v42)* In-app page `app/privacy.tsx` linked from Settings, **marked DRAFT**: the two open points and the owner contact are in [brackets]. Needs a review before any release. **(you)** fill in the brackets and check the wording.
- [-] Store listing, screenshots and age rating: dropped on your request ("ignore age rating and all that").
- [ ] Test on a low-end phone and with airplane mode
- [ ] Backup of the full source and the Apps Script

---

## Home screen cards (v51)
- *Done in the app:* the top of Home now shows three sections, each as cards:
  1. **Messages waiting:** up to three people with unread messages (tap to open the thread). Shows "No new messages" when there are none. Blocked people are left out.
  2. **Carry on:** the chapter you left off, with the novel's own background photo (E5) behind it, and "N% of M chapters done".
  3. **For you:** four novels picked at random from the ones that have chapters, each with its own background photo. Re-picked when the library changes, not on every visit.
- Background photos follow the reader's on/off choice for each novel (E5).
- *Fixed on the way:* the Home unread hook was placed after early returns, which breaks React's rules. All Home hooks now come before the early returns.
- **(you)** Phone check. Needs the backend to return `backgroundUrl` (E5) and `progress.active` (saved by the reader).

## Floating nav bar
- *v50:* one round ☰ button. Tap it and the tabs fan out in an arc, like the weapon wheel in GTA 5. Tap a tab to go, or tap outside to close. Items: Home, Messages (signed-in people), Author (authors and admins), Settings.
- **Where it shows:** on every screen for signed-in people, at the bottom centre (`components/global_nav.tsx`, mounted in `app/_layout.tsx`). It is **hidden** in the chapter reader and in a message thread.
- **In the reader:** a ☰ and a ‹ (back) button sit on the same edge as the pin and comment buttons, just below them (`components/reader_edge.tsx`). Back does the same as the header Back (asks before leaving).
- **Not done:** the Author tab has no destination yet (`route: null` in `lib/nav_items.ts`). The reader's edge side is read when the chapter opens; flipping the pin/comment side mid-chapter needs a reopen. *v52:* the wheel now opens with a small spring (the tabs grow out from the button and fade in) and closes with a quick fade back in.
- **(you)** Tell me where the author area lives, and whether the bar should also hide on other screens.

## Backend work for you (all in one place)
| Phase | Action | What it does |
|---|---|---|
| R1 | `me.role`; role checks on every write action | reader / author / admin, enforced on the server |
| R2 | `approveRequest(email, role)`, `setRole(email, role)` | admin accepts requests and sets roles |
| R3 | `requestRole` | a reader asks to become an author |
| B4 | `deleteTheme` | admin any, author own uploaded theme |
| C3 | `getComments`, `replyComment` | all comments visible; anyone can reply; usernames not emails |
| D1a | `checkUsername`, `saveUsername`; `mine` / `can_manage` flags | unique usernames; no emails sent to non-owners |
| D1 | `getProfile`, `saveProfile`, `saveAvatar` | name, gender, avatar; `me` returns them |
| D3 | `sendMessage`, `getThreads`, `getMessages`, `markRead` | simple direct messages |
| D4 | `blockUser`, `reportUser` (+ rate limit) | safety tools |
| D2 | `getComments` also returns `avatarUrl` per comment | avatar on the profile card (optional) |
| E1 | `saveSubject` with `kind`; folder creation; `uploadAsset` | Drive folder id per novel, upload files into it |
| E3 | — | quiz removed in app; no reactions/polls unless re-requested |
| E4 | `saveTheme` with `forSubject` | recommended theme linked to a novel |
| B6 | `saveTheme` keeps the `button` block | button look travels with the theme (Supabase: automatic, checked by `theme_data_ok`) |
| E5 | novel `backgroundUrl` via folder / `uploadAsset` | author reading background for a novel |
| F2 | music file in the folder, link in `getCourseData`; `saveSubject` accepts `musicUrl` | author soundtrack |
| G2 | `generateNarration` | TTS call, cache in Drive, daily limit |

Rule for every new action: **it checks on the server who is allowed**; the app only hides buttons.

## New packages (each needs a new build)
`expo-image-picker`, `expo-image-manipulator` (D1, also B5 Home background) · gesture handler + reanimated if missing (C2) · `expo-speech` (G1). `expo-audio` and `expo-notifications` are already in the app.

## Questions for you (my default in brackets, so you can answer with "ok")
1. **C1** Is the Back popup what you meant? [yes: Pin / Mark complete / Leave]
2. **D1** Gender choices: Boy, Girl, Skip? [yes]. Keep the five pastel themes as extras? [yes]
3. **D3** Who can message whom? [anyone signed in, but a new person can only send a few per hour; Block always works]
4. **E1** One word "Novel" with a tag Novel / Manga / Donghua? [yes]
5. **E3** Quiz removed (novel, not course). Reactions/polls only if you ask later. [removed]
6. **G2** Which voice service and monthly budget? [I suggest starting with one cloud service, narrate on demand and cache, small daily limit]
7. **F1** Will you send recorded sounds, or should I synthesize them? [synthesize, you judge them on the phone]
8. **D1a** Username rules OK? [3 to 20 letters, digits, `_` `.`; unique; changeable once every 30 days; only the username is shown, never the real name or email]

## Suggested order
A (fix-ups, including dropping offline login) → B1–B3 (words, templates, themes menu) → **R (roles)** → B4 → B5 (Home background photo) → D1a (usernames) → C1, C3, C2 → D1 → E1 → E4 → E5 (novel background photo) → F1 → D2, D3, D4 → E3 → E2 → F2 (author + local music), F3 → G1 → G2, G3 → H.
Reason: A and B are quick and safe; usernames (D1a) come before public comments so no email can ever show; the folder (E1) and profiles (D1) are needed by almost everything after them; narration (G2) is last because it costs money and needs the most backend work.
