# RUSE (Marginalia): one plan for the app and the backend

This file replaces `RUSE_PLAN_v2.md` (the app) and `Part 2` (the backend). **Part 1** is the app (frontend), **Part 2** is the backend (Supabase SQL, Google sign-in, the small Apps Script file service), **Appendix A** is the app-side file-service caller.

How to read it: `[ ]` not done · `[~]` code done, **waiting for your phone check** · `[x]` done and checked · **(you)** only you can do it.
Rule for the whole plan: **the app keeps working at every step.** The old Apps Script backend keeps running until the last step, and actions move to Supabase one at a time (`MOVED` in `lib/backend.ts`).

---

## Where we are

- **App:** v65 is built. Every screen already calls `api()` in `lib/backend.ts`, and `MOVED` is empty, so nothing uses Supabase yet. `lib/sb/` is empty, `lib/supabase.ts` does not exist, and the Supabase packages are not installed.
- **Second pass (7 Nov):** SQL, file service and plan text were read line by line. **Nothing was executed on Postgres** (none here). 6 high, 11 medium and several low findings are in the section "Second-pass review" below; proposed fixes are in Appendix B (untested).
- **Backend:** the SQL (migrations 001 to 005, also joined as `ruse_all.sql`) and its tests (G01 to G40) are written but have **never run on a real Postgres**. The Apps Script file service (`ruse_file_service.json`) passed 28 mock checks here but has never run on real Google or Supabase. The Supabase project is not created.

## What is left, in order

**A. You, now (no new code needed)**
1. [ ] `npx tsc --noEmit` in `app/`, then the phone check of everything marked `[~]` in Part 1 (buttons, templates, Phase 5 track link / Save for offline / Clear saved downloads, saved space)
2. [ ] Create the Supabase project, link it, push the SQL, set up Google sign-in, fill `app/.env`: **Part 2, section 5** (terminal steps)
3. [ ] Run the SQL tests on a throwaway local database: **section 5, step 8**. Fix every failure before going on
4. [ ] Deploy the file service with clasp: **section 5b**, and check the `ping` call
4b. [ ] Create the first admin with the one-line SQL in section 5, and decide on the last-admin guard (see the check below)
4c. [ ] **Second-pass review (7 Nov):** read the findings below, answer the 4 decisions, then run `Appendix B` (migration 006) after the tests pass and add tests G41 and up for it

**B. Code still to write (me, after A works)**
5. [ ] App foundation: install packages, `lib/supabase.ts`, sign-in hands the Google ID token to Supabase (section 6.3)
6. [ ] Phase 1 handlers in `lib/sb/` (getMe, profiles, usernames, admin); add each name to `MOVED` only after its phone test
7. [ ] Send `uploadAsset`, `saveAvatar`, `createNovelFolder` through the file-service caller (Appendix A); the app must save `folderId` into the novel right after `createNovelFolder`
8. [ ] Phase 2 chat with Realtime and push (Edge Function `push_notify` is not written yet)
8c. [ ] **End-to-end encrypted chat (decided 7 Nov):** design in section 7c, SQL in Appendix D (migration 008), app in Part 1 Phase J. **It replaces the plain-text chat of 002, 007 and the Phase I message screens before any of them is run on a real project.**
8b. [ ] **Phase 2b friends and group chat** (new): SQL in Appendix C (migration 007, needs 006 first), app in Part 1 Phase I, server notes in section 7b
9. [ ] Phase 3 comments and pins, Phase 4 catalog with delta sync
10. [ ] Import scripts for the old Sheets data (`scripts/export_sheets.gs`, `scripts/import_from_export.mjs`, not written yet)

**C. Ship (Part 1, Phase H, plus section 12)**
11. [ ] Fill the brackets in the privacy page and have it reviewed **(you)**
12. [ ] Cutover: new build tested on two phones, flip the rest of `MOVED`, keep the Sheets read-only for 30 days
13. [ ] Release build and icon / splash check, low-end phone and airplane-mode test, backup of the source and of both Apps Script projects

## Frontend vs backend check (7 Nov)

I compared the v65 app (`lib/`, `app/`, `components/`) with the SQL, the file service and the action map. Result:

**Matches (nothing to do)**
- All 49 app actions appear in Part 2, section 13 (the plan's old `uploadPart` is correctly retired).
- Limits: comment 1000 characters, message 500, username rules and reserved names, theme fonts, effects, `button` values and ranges, `radius` 4 to 32: same in the app and in the SQL.
- Sizes: subject data 100 KB, chapter 1 MB, theme 20 KB are above what the app's upload check allows.
- Ids: the app makes ids of lowercase letters, digits and dashes (up to 60); the SQL, the file service and the theme id rule all accept that.
- File service: `uploadAsset({folderId, name, mime, base64, kind})` returns `{url, id}`, `saveAvatar(base64)` returns `{avatarUrl}`, and the app only sends the kinds `background` and `manga-page`. Avatars are 256x256 JPEG, far below the limit.
- Chat Realtime: `messages` is added to the Realtime publication in 002.

**Fixed now**
1. **Whole-chapter comments would have failed.** The app uses block `-1` for a comment on the whole chapter (`WHOLE_CHAPTER`), but `comments.block` only allowed 0 or more. Now `>= -1` for comments (pins still need a real block). This is changed in `ruse_all.sql`; if you push the migration files instead, change the same line in `004_comments_and_pins.sql`.
2. **The file-service caller pointed at the old backend.** `file_service.ts` used `API_URL`, which is the old Apps Script address, so uploads would have gone to the wrong place. It now uses its own `FILE_API_URL` (Appendix A).
3. **No first admin.** Added the one-line SQL to create it (section 5).

**Still open (decide or build)**
- **No protection for the main admin.** The old backend never let `ADMIN_EMAIL` be removed or demoted. In the SQL any admin can demote or switch off any other admin, including themselves, and the last admin could lock everyone out. Needs a small trigger that refuses to remove the last allowed admin. Not written yet.
- **`removeUser` is soft** (`allowed = false`): the person can still sign in and see the waiting screen, and their old comments stay. That is what section 6.3 says; just be aware it is not a deletion.
- **`saveSubject` must create the Drive folder first.** The old backend made the folder inside `saveSubject` and returned `folderId`. In the new flow the Supabase handler has to call `createNovelFolder(id, title)` first and save the returned id in the novel's `data.folderId`, or later uploads for that novel are refused.
- **Kinds:** the app has Novel, Manga and **Webtoon** (old "donghua" values are read as webtoon). Part 1 still says Donghua in places; the app is right. The SQL accepts any kind, so old rows import fine.
- **Not checkable until the handlers exist:** the exact shapes that `getMe`, `getCourseData`, `getThreads`, `getComments` and the admin list return (fields like `mine`, `can_manage`, `uploaderName`, `fromAvatar`, `toAvatar`, `requestStatus`). Each handler must build the same object the screens read today; test it screen by screen before adding its name to `MOVED`.

---

## Second-pass review (7 Nov): SQL, file service, plan text

**What was and was not checked (read this first).**
- **Checked:** `ruse_all.sql` read line by line (no Postgres was available, so **nothing was executed**); all 31 files of the file service pass `node --check` and the manifest parses; `json_to_clasp.mjs` was run for real (it writes 31 files and fills in the Supabase values); every SQL block in this plan was diffed by script against `ruse_all.sql`; one Supabase claim was checked in the docs (Realtime DELETE, see M6).
- **Not checked:** the app itself (`lib/`, `app/`, `components/` were not in this upload, so the "Matches" list above was **not re-verified**); the tests G01 to G40 (`00_helpers.sql`, `rls_test.sql` not uploaded); the migration files 001 to 005 (only the joined file); `build_one_file.sh`; the 28 mock checks of the file service.

**Verified OK**
- RLS is switched on for all 14 tables. Every table has policies except `progress_import`, which is meant to be service-role only.
- Function grants are complete: the 7 callable helpers plus `username_available` are open only to signed-in people; the 9 trigger functions are closed to everyone. Only `theme_data_ok` stays executable by everyone (pure function, harmless).
- Table order works (003 before 004, because `comments_delete` reads `chapters` and `subjects`). `comments.block >= -1` is in `ruse_all.sql`.
- The username rules are identical in the `username_shape` constraint and in `username_available` (same reserved list, same regexes).
- `theme_data_ok` matches plan B6 and 9.1b: nine colours, the 7 fonts, `radius` 4 to 32, `depth` 0 to 8, the button keys, tap and background piece caps.
- File service: only the two public Supabase values are used, no service role key; tokens are cached only as a hash; the file type is judged by its bytes; the avatar's old files are trashed only after the profile update worked; folder creation is repeatable; the `can_manage_folder` URL filter is correctly encoded.
- `json_to_clasp.mjs` behaves as the plan says when run from the folder that holds both it and `ruse_file_service.json`.

### Decisions I need from you
1. **"Messages off": what does it mean?** In the SQL it only stops a person from *receiving* (finding H2). Do you want (a) the admin's switch to stop a person from *sending* too, as a separate flag so the person cannot undo it (my recommendation, in Appendix B), or (b) keep it as the person's own "do not disturb" only?
2. **Hide old emails with column permissions?** It means the app must list column names (never `select *`) on `comments` and `subjects` [recommended], or move the old emails to a staging table like `progress_import` (more work now, cleaner later).
3. **Avatar links:** allow only Google image/Drive hosts [recommended]. First check what link format the old backend stored; if it differs, the check in Appendix B must match it.
4. **Last admin:** refuse to remove, demote or switch off the last allowed admin [recommended, in Appendix B]. Do you also want a "main admin" who can never be demoted, like `ADMIN_EMAIL` before? (Not written; say yes and I add it.)

### High (fix before real users)
- **H1 · Old emails stay readable by every member.** `comments.author_email` and `subjects.created_by_email` are normal columns, the read policies return whole rows, and the claim triggers set `author_id` / `created_by` but **never clear the email**. Any approved member can read them over the API, which breaks D1a ("emails are never shown"). The import also copies the old data as-is, so `uploadedBy` emails would land inside `subjects.data` and `chapters.data`. *Fix:* Appendix B clears the email at claim time and hides both columns; the import script must strip `uploadedBy` and any email from `data`; new check row added to section 11.
- **H2 · Admin "messages off" does not do what D4 wants.** `can_message()` checks only the **recipient's** `messaging_off`. A person switched off by an admin can still send. And `profiles_guard` does not protect `messaging_off`, so anyone can turn their own flag back on. *Fix:* decision 1; Appendix B adds `messaging_banned` (admin only), checked on the sender.
- **H3 · Folder ownership can be faked.** The file service decides "is this my novel" from `subjects.data.folderId`, and an author can write **any** folder id into their own novel (the ids are in the catalog every reader downloads). They could then upload pictures into another author's folder. *Fix:* unique index on `data->>'folderId'` (Appendix B). With it, a folder id can belong to one novel only.
- **H4 · Waiting accounts can write `progress`.** `progress_own` has no `is_member()` check. Sign-up is open to any Google account, so anyone can create accounts and store 100 KB each. *Fix:* Appendix B adds `is_member()` to both sides of the policy.
- **H5 · Last admin (was already open).** Any admin can demote, switch off or delete the last admin, and with no admin nobody can get in. *Fix:* trigger in Appendix B (uses a lock so two admins cannot remove each other at the same moment). The SQL Editor and the service role stay free, so you can always repair it by hand.
- **H6 · A theme "for a novel" can target someone else's novel.** E4 says authors only for their own novels, but nothing in SQL checks `forSubject`. Author A could make every reader of author B's novel see a recommendation banner. *Fix:* trigger in Appendix B.

### Medium
- **M1 · Avatar link can point anywhere** (`avatar_url` has no check). Readers' phones would load any image URL, which allows tracking or unwanted pictures that the file service cannot remove. *Fix:* check constraint in Appendix B (decision 3).
- **M2 · Migrated users are treated as new for 7 days.** `invited_users` has no `added_at`, so every carried-over user gets `added_at = now()` at first sign-in and the 5-per-hour message limit. *Fix:* Appendix B adds `invited_users.added_at` and uses it.
- **M3 · `removeUser` and `rejectRequest` handlers need rules** (not SQL bugs):
  - a person who was only invited and never signed in must be **deleted from `invited_users`**, or they get in at first sign-in;
  - also delete the invitation of a signed-in person you remove, or a deleted Google account that signs in again is approved automatically;
  - a removed person is `allowed = false` with `request_status = 'pending'`, so they **reappear in the waiting list**; set `request_status = 'rejected'` on removal;
  - the admin people list must show `profiles` **and** `invited_users`, and `setRole` on an invited-only person must update `invited_users`;
  - approving a role request (`setRole(email,'author')`) must also clear `role_request`.
- **M4 · First-admin lockout** if you sign in before adding the invitation: recovery SQL added to section 5.
- **M5 · Drive space is not protected.** The file service runs as you, so every upload uses **your** Drive (15 GB on a free account), with no per-author cap. Trashed files still count until the trash is emptied, and changing or removing a reading background never deletes the old file (there is no delete action). *Fix:* decide a cap (for example a count per author per day in `CacheService`, and a pictures-per-novel limit), and add a small `deleteAsset` later. Keep an eye on the Drive size.
- **M6 · Realtime DELETE is not filtered** (confirmed in the Supabase docs: RLS is not applied to DELETE events; with the default setting only the primary key is sent). Every connected phone receives the id of every deleted message in the whole app. No content leaks (the id is a random uuid), but it costs traffic as users grow. Keep the filterless DELETE listener only while the app is small, or switch to soft delete.
- **M7 · Built-in theme ids may be incomplete.** `themes_id_ok` reserves 3 ids (`paper`, `obsidian_gold`, `sugar_bloom`), but this plan also names **Midnight Tide**, **Cotton Candy** and "five pastel themes", and B6 says "all three themes". Check `lib/theme.tsx` for the real built-in ids and update the constraint (a new migration, not an edit), or an uploaded theme can reuse a built-in's id.
- **M8 · `theme_data_ok` demands `count` on every tap and background recipe.** If `lib/recipes.ts` gives a default when `count` is missing, a theme the app accepts will be refused by the database. Test with each template file the app generates (B4).
- **M9 · RLS refusals are not readable.** A blocked or "off" send fails with "new row violates row-level security policy", not with text for the person. The handler must map error code `42501` to one friendly line, and the same line for blocked and for off, so a person cannot tell they were blocked.
- **M10 · Delta sync can miss a row.** `updated_at` is the time the transaction **started**. Ask for rows newer than the last `updated_at` seen **minus a few seconds** and merge by id.
- **M11 · Orphans.** `comments.chapter_id` and `pins.chapter_id` are plain text with no link to `chapters`, so deleting a chapter or novel leaves its comments and pins, and a chapter created again with the same id brings the old comments back. Either delete them in the same handler, or add the link after the import (`on delete cascade`).

### Low
- **L1 · Invitation vs existing username.** 005 stops two invitations from sharing a username, not an invitation colliding with a username a signed-in person already holds. That invitee's first sign-in would fail with "Database error saving new user". Check `username_available` before adding an invitation with a username (the old-sheet import is the only place this can happen).
- **L2 · Google config.** `skip_nonce_check = true` is a real trade-off: it lets Supabase accept a Google ID token without proving it was made for this sign-in. It is what the native button needs on some setups; know that you chose it. Also unverified: whether `config.toml` accepts two `env(...)` in one `client_id` string. If `config push` refuses it, use the Dashboard (the plan already says so).
- **L3 · `messages_pair_idx` will not be used** by the `.or(and(...),and(...))` query in 7.2. Fine for a small app; later add an `rpc` that filters on `least()` / `greatest()`.
- **L4 · A person can clear their own username** after 30 days (set it to null), which hides them from `public_profiles` and the inbox. Add `username_not_cleared` later if it matters.
- **L5 · `json_to_clasp.mjs` details.** It must sit **next to `ruse_file_service.json`** (the plan does not say where to put them; the repo root works with `node json_to_clasp.mjs app/.env`). The `.env` reader ignores `export KEY=` lines and inline `# comments`. The service-role check recognises the old JWT keys but may not recognise the newer `sb_secret_...` style keys, so look at the key you paste. If the text it replaces in `config` ever changes, the replace fails silently; check that `clasp_project/config.gs` shows your URL before pushing.
- **L6 · `clasp create` may rewrite `appsscript.json`** with a default one. Open `clasp_project/appsscript.json` after `clasp create` and check that the scopes and the `webapp` block are still there before `clasp push --force`.
- **L7 · Avatar before approval.** `saveAvatar` needs an approved account, but the first-sign-in profile screen comes before an admin approves. Show the avatar step after approval, or the person gets "waiting for approval".
- **L8 · Smaller RLS edges.** A removed person (`allowed = false`) can still edit their own old comments and delete them; a demoted author can still delete comments on their old novels. Both are harmless today; tighten if you prefer.

### Plan-text problems
**Fixed in this pass:** the rate-limit snippet in 7.1 was missing the brackets that the real SQL has (without them it very likely fails to run); the comments snippet in 8.1 still said `block >= 0`; 6.3 said to keep the Google token for the file service (the file service uses the Supabase token from the start); section 3 step 4 described the old novel-id lookup instead of the folder-id lookup the code uses; `createNovelFolder` was missing from the section 13 table; section 12 said to update `RUSE_PLAN_v2.md`; section 15 and the section 17 row still talked about soundtracks in Storage; the 005 table over-promised on usernames; the section 14 Security Advisor line now explains the one expected warning; recovery SQL for the first admin; the new "no emails in shared data" import check.

**Flagged, not changed (they depend on the app, which I cannot see):**
- Part 1 **F2** and **O1** still describe soundtracks as an upload of up to 30 MB to the novel folder, and the file service accepts only JPEG and PNG pictures. The A.1 list, section 10.1 and the file service all say "pasted track link, Save for offline, Clear saved downloads". Rewrite F2 and O1 to match.
- **E2** contradicts itself: "Manga pages from photos: dropped" and "PDF dropped" appear next to the v47 note that Add manga chapter from photos is done. F2 also still lists "Local music" as a source (dropped in v54).
- **G1 vs G3:** G1 says phone read-aloud is the narration; G3 says "read-aloud is gone".
- **B4** exists twice (templates generated in the app, and remove themes). Rename one.
- **Donghua vs Webtoon:** the app uses Webtoon; Part 1 still says Donghua in the decisions, E1 and the question list.
- **Numbering clash:** Part 1 uses D1 to D4 for phases and Part 2 section 2 uses D1 to D6 for decisions; Part 1 phases A to H and Part 2 phases 0 to 6 are both called "Phase". Rename one set (for example P0 to P6).
- 7.4 says to run `supabase/tests/rls_chat.sql`, but the layout in section 4 lists only `rls_test.sql`. Say which file really exists.
- Section 2 D1 still says "MediaFire or similar" while 10.1 says Drive or Dropbox and admits MediaFire was not checked. Pick one example host.
- Android: `android.allowBackup = false` (section 10.1) is not in the Phase H release list. Add it.
- The "Questions for you" list near the end of Part 1 is mostly answered; clear it.

---

# Part 1: the app (frontend)

## Decisions so far
- Offline login is **dropped** (A7). The phone's saved sign-in and saved novels are enough.
- **Everyone can see and reply** to comments (C3).
- Readers are shown by a **unique username**, never an email (D1a).
- **Three roles (new):** **Reader**, **Author**, **Admin**. Details in Phase R below.
- **Novel background photo (E):** the **author** can upload a background image for their novel (shown while reading that novel). Not forced; reader can still use their theme colors.
- **App / Home background (new):** each person can set a **custom background photo on the main (Home) screen**. Stored on the phone; optional; falls back to the theme background.
- **Music player (F2):** plays the **author-uploaded track for the novel**. *(Local music from the phone was dropped in v54.)*
- **Quiz is removed.** This is a novel reader, not a course. No end-of-chapter quiz.
- **Novel kinds (E1):** every work is tagged **Novel**, **Manga**, or **Donghua**.
- **Novel-exclusive themes:** a theme uploaded by an author **for a novel** (`forSubject`) stays on that novel only. It does **not** appear in the Settings theme picker.

---

## Phase A · Fix-ups from the v14 review (do these first)
**Part 1 delivered (v15). Part 2 delivered (v16): A3, A4, A6 and the status bar of A1. Waiting for your phone check and one `tsconfig` decision (see A6).**
Small, safe, and they stop bugs from spreading into the new work.
- [x] **A1 · Dark themes readable (S).** Quiz choices and tip callouts use fixed dark text, so they vanish on dark themes. Use theme colors. Status bar follows the theme (light icons on dark themes).
  - *Part 1 done:* quiz, callouts, table header, finish/next buttons. *Part 2 done:* status bar follows the theme (light icons when the theme background is dark). **(you)** phone check: switch themes, look at the clock/battery icons.
- [x] **A2 · No silent loss (S).** If the server refuses a queued pin or comment, show a small message and keep the text so it can be retried. Show "N changes waiting to send" somewhere visible.
  - *Done:* refused comments/pins are kept in a "not accepted" card (Retry / Throw away); "N changes waiting to send" card on Home, chapter and comment sheet. **(you)** phone check: turn on airplane mode, comment, then reconnect.
- [x] **A3 · Honest "Saved … ago" (S).** Finishing a chapter offline must not reset the saved time to "just now".
  - *Done:* the saved time only moves when the server really answered. **(you)** phone check: airplane mode, finish a chapter, the ribbon still says the old time.
- [x] **A4 · Remove dead code (S).** Delete `lib/notes.tsx`, `lib/notes_helpers.ts`, `NotesProvider`, `components/block_tools.tsx`, the unused `BlockView` props, and the duplicate animation loop in `DesignedFloater`.
  - *Done:* the three files and `NotesProvider` are gone; the unused `BlockView` props were already removed; glyph floaters now run one loop instead of two.
- [x] **A5 · Sign-out cleanup (S).** Also remove pins, queued progress and push-token files from the phone.
  - *Done:* Sign out now removes me, novels, queued progress, pins/queue, push token and old notes file (theme choice stays on purpose).
- [x] **A6 · Imports (S).** About 12 files import with `.ts` on the end. Add `allowImportingTsExtensions` to `tsconfig.json` (or drop the `.ts`) so `npx tsc --noEmit` passes.
  - *Done:* the `.ts` endings are removed from all imports, so no `tsconfig` change is needed. **(you)** run `npx tsc --noEmit` on your machine (the zip has no `package.json`/`tsconfig.json`, so I could only syntax-check here) and send me any errors.
- [x] **A7 · Drop the offline login (M), decided.** The phone already keeps you signed in and keeps your saved novels, so a second username and password adds nothing.
  - *Done in code:* screens/files removed, Home button and prompt removed, only Sign out wipes data, app opens saved profile after 6 s if Google is silent. **(you)** run `npm uninstall expo-secure-store expo-crypto`, remove `expo-secure-store` from `app.json` plugins if listed, new build, then test airplane-mode start.
  - Remove the "Log in offline" button, `app/offline_login.tsx`, `app/offline_setup.tsx`, `lib/offline_login.ts`, `lib/offline_store.ts`, `lib/sha256.ts`, and the "make your offline login" prompt on Home. Remove `expo-secure-store` and `expo-crypto` from `package.json` if nothing else uses them (new build).
  - Make offline start reliable: if the app opens with no network, it always opens the saved profile and saved novels. The only thing that wipes saved data is **Sign out**. (Today a "nobody is signed in" answer from Google, even while offline, wipes it.)
  - Honest note: anyone holding your unlocked phone can read the saved novels. That is the same as any reading app, so I treat it as fine.
- [x] **A9 · Never show an email to other readers (S).** Comments use `me.name || me.email` as the name, so a person without a name shows their email. Until usernames exist (D1a), fall back to "Reader" instead of an email.
  - *Done:* names fall back to "Reader"; an email-looking name from old comments is masked too.
- [x] **A8 · Chapter fonts (S).** `chapter_fonts()` honors every loaded font (Lora, Newsreader, …), not just Quicksand.
  - *Done:* any loaded font works, case-insensitive, kept exactly on every theme.

---

## Phase B · Words, templates and themes menu (quick wins)
**Doing it in parts. Part 1 = B1 (v17). Part 2 = B2 + B3 (v18). B4 waits until Phase R (roles) is in.**
- [x] **B1 · Course becomes Novel (M).** Every word the reader sees changes: "Your courses" → "Your novels", "Course template" → "Novel template", and so on. Ids and backend action names stay as they are, so nothing breaks. One word list in one file, so it can change again in minutes.
  - *Done (v17):* the list is `lib/words.ts` (`W.novel`, `W.novels`, …). Home, Settings, Your novels, category, novel screen, offline ribbon, upload messages, read-me and template hints all use it. Ids, file keys (`"course"`, `"subject"`) and backend action names are unchanged. The template file is now named `ruse-novel-template.json`. **(you)** phone check: look through Home, Settings, Your novels and Read me for any leftover "course". Note: the server's own error text "Unknown course" still says course until you change it in `Code.gs`.
- [x] **B2 · Templates (S), your note 7.**
  - Settings shows only **Novel template** and **Theme template**. Both are for **Authors and Admins** (Readers see neither, see Phase R).
  - **Chapter template is removed from Settings.** It stays inside **My novels**, per novel, already filled with that novel's id. That way a chapter can never be made without a novel.
  - *Done (v18):* Settings now has only Novel template (all) and Theme template (owner only). Chapter template lives in Your novels. Help texts point there. **(you)** phone check: Settings → Empty templates; Your novels → Chapter template still downloads.
- [~] **B4 · Templates generated in the app (M), your note: "why do you give me a template, the app should generate it".** The zip in `marginalia_templates/` becomes a fallback only. Each screen makes its own template file.
  - **Theme screen** → "Download theme template": a theme JSON prefilled with the current theme's colours, radius and effects. Blank option too. Lists only fonts the app has installed (see the font list in `fonts/built_in_fonts.json`).
  - **Authors screen** → "Download comic template" and "Download novel template": the whole-file shape with the `course` block and one example chapter.
  - **Inside a comic or novel (My novels)** → "Download chapter template": one chapter with a page list (comic) or text blocks (novel), already filled with that novel's id.
  - Each file carries short `_` notes with the rules (limits, https links, colours as #rrggbb), so it works without the prompt file.
  - Generated from code in `lib/templates.ts` (already holds the course template); saved with the share sheet or to app storage, not to a public folder.
  - The AI prompt (`PROMPT_for_AI.txt`) stays downloadable from Settings as a text file.
  - *Done in the app (v64):* builders in `lib/templates.ts`, buttons in Settings and Your novels, every file passes `lib/upload_check.ts`. Theme templates list only the 7 installed fonts. **(you)** phone check: download each file, open it, upload it back.
- [x] **B3 · Themes as a dropdown (S), your note 8.** One tidy picker instead of a wall of chips. Shows color dots and the name.
  - *Done (v18):* new `components/theme_picker.tsx`: a button with the current theme's dots and name, opens a list with a ✓ on the current one. **(you)** phone check: open it on a dark and a light theme, pick a theme, close by tapping outside.
- [x] **B4 · Remove themes (M), your note 8.** *(moved after Phase R)* A "Remove" in the dropdown for uploaded themes (built-in ones cannot be removed): **Admin any, Author only their own**. Asks "Are you sure?" first.
  - *Done in the app (v25):* Theme picker shows **Remove** on uploaded themes the role may delete (admin = any non-built-in; author = `mine` or `createdBy` matches email). Confirm dialog first. Calls `deleteTheme(id)`; if the current theme is removed, switches to the default built-in; then refreshes. Built-ins never show Remove. Theme type accepts `createdBy` / `mine` from the server. **(you)** phone check: as admin, remove an uploaded theme; confirm built-ins have no Remove; after remove the list updates.
  - Novel-exclusive themes (`forSubject`) are **hidden from the picker** (they stay on the novel); Remove in the picker only applies to global uploaded themes.
  - **(you)** Backend: `deleteTheme(id)`: admin any uploaded theme; author only a theme they uploaded; never a built-in one. Prefer returning `mine` / `createdBy` on each theme in `getCourseData`. Themes with `forSubject` are novel-only.
- [x] **B5 · Home / app background photo (S→M), your note.** Each person can pick a **custom photo as the Home (main) screen background**. Stored only on the phone. Optional; if none, the current theme background is used. A clear "Remove background" control. Uses `expo-image-picker` (same package as D1 avatar; new build when that lands).
  - *Done in the app (v27):* Settings → **Home background** (Choose / Change photo, preview, Remove). Image is copied into the app's private folder (`lib/home_bg.ts`) and remembered like the theme (stays after sign-out). Home screen shows it with a soft theme-coloured scrim so text stays readable. Reloads when you return from Settings. **(you)** phone check after a build that includes `expo-image-picker`: pick a photo, leave and reopen Home, remove it. If the picker module is missing, Settings shows a clear "needs a new build" message.

---

- [~] **B6 · Lively buttons, settable from a theme file (M), your note.**
  - **Look:** `GlowButton` is the one button. Default `raised`: a thick bottom edge that the face sinks into when pressed, plus a squish-and-spring bounce and a shine band that sweeps across. `size` is `lg` (default), `md` or `sm`; `outline` and `soft` are the quiet versions; `danger` keeps a red button red whatever the theme says. With the phone's "reduce motion" on, animations are skipped.
  - **Theme file:** optional `"button"` block. All keys optional; anything missing uses the default.
    - `style`: `raised` | `flat` | `soft` | `outline`
    - `shape`: `round` (follows the theme's radius, calmed down) | `pill` | `square`
    - `press`: `bounce` | `sink` | `wiggle` | `pulse` (gentle breathing while waiting) | `none`
    - `depth`: whole number 0 to 8 (raised edge thickness; small buttons stay flat)
    - `shine`: true | false · `uppercase`: true | false
    - `colors`: `{ "bg", "fg", "edge" }` as `#rrggbb`; leave out to use the theme's primary and accent
  - **Code:** `lib/button_look.ts` (types, `check_button`, `resolve_button`; pure, no React), `components/glow_button.tsx`, `Theme.button` in `lib/types.ts`, `check_theme` calls `check_button` in `lib/upload_check.ts`, built-in looks in `lib/theme.tsx`, theme templates and AI prompt in `lib/templates.ts`.
  - **Not covered on purpose:** selectable chips (kind and gender pickers), plain text links, and the card action label on novel cards are not buttons in this sense.
  - Checked here: the check and the resolver (all cases pass) and every template file against the upload check. **Not run:** typecheck and the phone. **(you)** phone check: all three themes; try a theme file with `"shape": "square"`, `"press": "pulse"` and custom `colors`; try a bad value (for example `"depth": 20`) and see the plain-words error.
  - **Backend:** whatever stores themes must keep the `button` key (Supabase: `themes.data` is jsonb and passes it; the check is in migration 005; the old Apps Script `saveTheme` would need to allow it).

---

## Phase R · Three roles: Reader, Author, Admin (new, comes right after B3)
| | Reader | Author | Admin |
|---|---|---|---|
| Read novels, progress, pins | yes | yes | yes |
| Comment, reply, message others | yes | yes | yes |
| Upload novels and chapters, Your novels | no | yes (own) | yes (all) |
| Add themes | no | yes | yes |
| Recommend a theme for their novel (E4) | no | yes (own novels) | yes |
| Remove themes (B4) | no | own uploads | any uploaded theme |
| Delete comments | own only | own + on their novels | any |
| Accept / refuse new requests, set roles, see reports | no | no | yes |
- [x] **R1 · Roles in the app (M).** One small file (`lib/roles.ts`) answers "may this person do X?" from `me.role`, so every screen asks the same place. Settings shows only what the role allows: Readers see no Upload, no templates, no Your novels, no Theme template. *(The app only hides buttons; the server checks again.)* Old `isOwner` / `admin` flags keep working as Admin until the backend sends `role`.
  - *Done in the app (v21), backend left for later as you asked:* new `lib/roles.ts` (tested). While `me.role` is missing, owner/admin = Admin and everyone else stays Author, so nothing disappears today; a role the app does not know = Reader. Settings shows your role next to your email; Readers see no Upload, no templates, no Your novels, no Theme template, but get a "You are a Reader" card with **My progress** (reset progress). Admin screen and the people list open for any Admin. Home's empty text is reader-friendly. **(you)** phone check: you should still see everything as owner. *The role checks on the server are still to do (R1 backend line below).*
  - **(you)** Backend: `me` returns `role` (`reader` | `author` | `admin`). **Every** write action checks the role on the server (upload, saveTheme, deleteTheme, saveSubject, deleteSubject, deleteChapter…).
- [x] **R2 · Admin screen (M).** Today only the owner reaches People & access. It becomes the **Admin** screen: accept or refuse new requests (new people start as **Reader**; admin can accept as Reader or Author), change a person's role, remove a person. Shows emails to admins only (everyone else sees usernames, D1a).
  - *Done in the app (v22):* Admin screen uses roles end-to-end. Requests: **As Reader** / **As Author** / Reject. People list shows role and lets you set Reader / Author / Admin (current one filled) + Remove. Add-person picks a role. Types and normalizer accept `role` from the server (fallback: old `admin` flag → admin, else author so existing people keep upload rights). New actions: `approveRequest(email, role)`, `setRole({ email, role })`; `addUser` also sends `role` (+ `admin` for older backends). Settings button now says "Admin · people & roles". **(you)** phone check: open Admin as owner, confirm lists still load; try role chips (backend may still reject until Code.gs is updated).
  - **(you)** Backend: `approveRequest(email, role)`, `setRole(email, role)` (admin only); keeps `addUser` / `removeUser`. Prefer role over the old admin boolean. New people default to **reader**.
- [x] **R3 · "Become an author" request (S).** A Reader can tap "Ask to become an author"; admins see it in the same request list. *(my reading: authors are not self-service)*
  - *Done in the app (v23):* Settings → Reader card has **Ask to become an author** (calls `requestRole('author')`). While `me.roleRequestStatus === 'pending'`, shows a waiting line instead. Admin screen shows role-upgrade requests in the same Waiting list with **Make Author** / **Dismiss** (and a "Wants to become an Author" hint). Normalizer also merges a separate `roleRequests` list if the backend sends one, and accepts `pendingRole` / `requestedRole` / `kind: 'role'`. **(you)** phone check: as a Reader, send the request; as Admin, open Admin and approve/dismiss (needs backend).
  - **(you)** Backend: `requestRole('author')` (reader only; sets a pending role request). Include those in `getAdminData` requests (or `roleRequests`) with `pendingRole: 'author'`. `me.roleRequestStatus` = `'pending'` while waiting. Approve = `setRole(email, 'author')` (or approve path); dismiss clears the pending flag (e.g. via `rejectRequest`).

## Phase C · Reader upgrades
**Doing it in parts. Part 1 = C1 (v19). Part 2 = C2 (v20). Next: C3 (everyone sees comments; needs the backend and roles).**
- [x] **C1 · Back-button wrap-up popup (S), your note 1.** *(my reading)* When you press Back inside a chapter (header Back or the phone's back button), a small closing message appears instead of leaving right away. For example: "Nice reading! Pin your place, mark it complete, or leave." with three buttons. If the chapter is already complete, it just says goodbye with Leave / Stay.
  - *Done (v19):* new `components/leave_popup.tsx`. The header Back and the phone's back button (Android) both open it. "Pin my place" pins the block nearest the top of the screen, then leaves; "Mark complete" completes then leaves; tapping outside = Stay. **(you)** phone check: scroll halfway, press Back, Pin, reopen the chapter and see it jumps to the pin; also test on a completed chapter. *Not covered:* the iPhone swipe-back gesture still leaves directly.
- [x] **C2 · Floating pin and comment buttons (L→M), your note 2.**
  - Remove the Pin / 💬 row that sits under every block.
  - Two small round buttons float at the screen edge (📍 and 💬). You **drag one and drop it on a block**: the pin sticks there, or the comment box opens for that block.
  - They can be dragged to the other edge and remember where you left them. Blocks that already have comments show a small bubble count.
  - A long press on a block is the backup way, for people who do not like dragging.
  - *Done (v20), no new package and no new build:* I used React Native's built-in touch handling instead of a gesture library, so nothing needs installing. New: `components/floating_tools.tsx`, `lib/drop_target.ts` (tested), slimmer `components/pin_bar.tsx`.
  - How it works: drag 📍 or 💬 onto a paragraph (the paragraph lights up under your finger); drop near the opposite screen edge to move the buttons there (the side is remembered); a short touch shows a hint; long-press a paragraph for the backup menu (Pin / Comments). Blocks with a pin or comments still show a small "📌 Pinned" / "💬 N" tag under them; blocks with nothing show no row.
  - **(you)** phone check: drag each button onto a paragraph, drop it in empty space (it springs back), drag to the other edge, restart the app (side is remembered), long-press a paragraph. *Known limit:* the page does not auto-scroll while dragging, so drop on a paragraph that is on screen.
- [x] **C3 · Everyone can see and reply to comments (M), your notes 3 and update.**
  - Comments on a chapter are visible to every signed-in reader, shown with **username** and avatar (never an email).
  - **Anyone can reply to any comment.** Today only the comment's author and the uploader can. Replies stay one level deep (a reply to a reply goes into the same thread) so threads stay readable.
  - The uploader's replies keep an "author" tag.
  - Pins stay private (they are your place in the book).
  - **Admin** can delete any comment or reply; an **Author** can delete any comment on their own novels; everyone can edit or delete their own.
  - The "Comments on my chapters" inbox on Home still lists threads on your novels that need a reply.
  - *Done in the app (v29), backend left for you:* Reply is offered on every root comment for any signed-in reader (one level deep still). Delete: own, or uploader/`mine`/`can_manage` on the chapter, or admin. Tag shows **· author** for uploader replies. Visibility of *other people's* comments still depends on `getComments` returning them. **(you)** phone check once backend allows global reply + full `getComments`.
  - **(you)** Backend: `getComments` returns all comments of the chapters asked for; `replyComment` allowed for any signed-in user (not only author/uploader); comments return `username` and `avatarUrl`, never `email`.

---

## Phase D · People: profile, avatar, messages
Split into four, because messages need rules before they need screens.
- [x] **D1a · Unique usernames (M), your new note.** Do this early: public comments and the uploader name need it.
  - Everyone picks a **unique username** (3 to 20 letters, digits, `_` or `.`; not case sensitive; no spaces; blocked words list). It is checked on the server, so two people can never share one.
  - The username is what other readers see: on **comments and replies**, on **profile cards**, in **messages**, and as the **uploader name on every novel and chapter** ("by `username`"). **Email addresses are never shown to other readers.**
  - You can change it, but not more than once every 30 days, and old comments update to the new name.
  - Existing people get asked once on their next sign-in. Until they choose, they show as "Reader".
  - Where emails leak today and will be fixed: comment names (A9), "by email" in My novels, and `uploadedBy` in the data sent to every phone. The app should receive the uploader's **username** plus simple flags (`mine`, `can_manage`) instead of the uploader's email. The owner's People & access screen keeps showing emails, because the owner must know who is who.
  - *Done in the app (v28):* `lib/username.ts` (rules + blocked list + 30-day helper). `UsernamePrompt` on Home when `me.username` is missing. Settings → Username (save/update, client rate-limit hint). Comments post with `public_name(me)`. My novels masks email-like `uploadedBy` via `display_name` / `uploaderName`. Actions: `checkUsername`, `saveUsername`. Types: `Me.username`, `usernameChangedAt`; chapter/subject `uploaderName`, `mine`, `can_manage`. **(you)** phone check after backend: first login prompt; Settings change; comments show username.
  - **(you)** Backend: `checkUsername(name)`, `saveUsername(name)`; store per user; `me` returns `username` + `usernameChangedAt`; comments return username not email; chapters/novels return `uploaderName` + `mine`/`can_manage` (do not send uploader emails to non-admins). Enforce unique (case-insensitive) and 30-day change limit.
- [x] **D1 · Profile + two main themes (M).**
  - First sign-in asks: your **username** (D1a), **gender** (Boy / Girl; plus "Skip" which lets you pick a main theme yourself), and an **avatar** (optional).
  - Two **main default themes**: one for boys, one for girls. They are picked automatically from the gender answer. You can change theme any time; the other themes stay available.
  - *(my reading)* The five pastel themes stay as extra themes. I will design a boy main theme (cool and dark, with its own tap effect). **(you)** tell me if you want more boy themes later.
  - Avatars are shrunk to a small square on the phone before sending (new package `expo-image-picker`, plus `expo-image-manipulator`, so a new build is needed).
  - *Done in the app (v30), backend left for you:* After username, **ProfileSetup** asks Boy / Girl / Skip + optional avatar. Boy → **Midnight Tide** (new built-in, cool dark, ripple). Girl → **Cotton Candy**. Skip → no theme force. Settings → Profile can change gender (re-applies main theme) and avatar. Gender also saved locally so setup works before Code.gs is ready. **(you)** phone check after build with image picker/manipulator; confirm Midnight Tide appears in the theme list.
  - **(you)** Backend: `getProfile`, `saveProfile({ gender })`, `saveAvatar(base64)` (stored in a Drive folder; see Phase E1 for the folder idea), and `me` returns `gender` and `avatarUrl`.
- [~] **D2 · Profile cards (S).** Tap a username or avatar on a comment, reply or novel to see a small card: avatar, username, "Send message". No email, no real name.
  - *Done in the app (v35):* tapping a name on a comment or reply opens a card (`components/profile_card.tsx`, helper `lib/profile_card.ts`): avatar (or initial), username, and a "Send message" button that says "coming in a later update" until D3. Not tappable: your own name, "Reader", emails. Novel and inbox names are not wired yet. **(you)** phone check: tap a name on a comment. **(you)** Backend: comments should also return `avatarUrl` (optional; without it the card shows the initial).
- [~] **D3 · Direct messages, simple (M→L), your note 4.** Not a chat app: plain text, a list of conversations, a thread screen, push notification, "unread" dot. No typing indicators, no read receipts, no photos.
  - *Done in the app (v36):* Home card "✉️ Messages" with unread badge (`app/index.tsx`); inbox `app/messages.tsx`; conversation `app/message/[name].tsx` (plain text, max 500 characters, opening marks read); "Send message" on the profile card opens it. Logic in `lib/messages.ts` (tested here), server calls in `lib/messages_api.ts`, action names in `lib/actions.ts`. Sending needs a connection and is never queued. **Not done yet:** push notification for a new message (needs a new build and the backend). Until the backend exists the screens show "Could not load messages".
  - **(you)** phone check after the backend is in place.
  - Messages go to a **username**, never an email. **(you)** Backend: `sendMessage({ to_username, text })`, `getThreads`, `getMessages`, `markRead`.
- [~] **D4 · Safety (M).** Because everyone can comment and anyone can message: **Block**, **Report**, a limit on how many messages a new person can send per hour, and **Admins** can see reports and turn messaging off for a person. Without this I would not ship D3.
  - **(you)** Backend: `blockUser`, `reportUser`, rate limit, admin list of reports.
  - *Done in the app (v37):* Block and Report on the profile card (report asks for a reason from five choices; no free text). Block asks first. Blocked people are hidden from the inbox, and a conversation with one shows Unblock. Tapping the name in a conversation opens the card. Admin screen has a **Reports** list: Messages off/on per person, and Dismiss. Helpers in `lib/safety.ts` (tested here), calls in `lib/safety_api.ts`.
  - **Not done yet:** blocked people's comments are still shown (the plan does not say to hide them; say if you want that). The rate limit is the server's job: the app shows the server's message. Admin "messages off" is also enforced only by the server.
  - **(you)** Backend: `blockUser`, `unblockUser`, `getBlocked`, `reportUser` (with rate limit), `getReports`, `resolveReport`, `setMessaging`. Phone check after that.

---

## Phase E · Novels, Manga and Donghua
- [x] **E1 · Library model + Drive folder per novel (M).**
  - Every novel and chapter shows **"by username"** (the uploader's unique username, D1a), never an email.
  - Every novel gets a **kind**: Novel, Manga or Donghua *(my reading: Donghua = a novel or adaptation shown with its own look; Manga = picture pages)*.
  - Creating a novel makes a **Drive folder** and returns its id (**you**, backend, as you said). The folder holds: manga pages, music, narration audio, **novel background photo**, avatar-style files.
  - *Done in the app (v31), backend left for you:* `NovelKind` on Subject (`kind`, `folderId`, `uploaderName`). Create form has **Novel / Manga / Donghua** chips; `saveSubject` sends `kind`. Home + category cards show kind + `by username` (email masked). Course screen header shows kind · by · summary. Your novels list shows kind and "folder ready" when `folderId` is present. `uploadAsset` action ready. Template sample includes `course.kind`. **(you)** phone check after backend creates folders and returns kind/uploaderName/folderId.
  - **(you)** Backend: `saveSubject` accepts `kind` and creates `folderId`; `uploadAsset({ folderId, name, mime, base64 })`; reading assets back as links the app can open. Apps Script has size and daily limits, so I will check the exact numbers in Google's docs before we depend on them. For big files the fallback is to paste a Drive share link. Return `uploaderName` (not email) on subjects/chapters for non-admins.
- [~] **E2 · Manga reader (L→M).** A new chapter type made of images: a vertical strip you scroll, page-by-page mode, pinch to zoom, pre-load the next pages, save pages on the phone for offline reading. Upload as a folder of images or a list of image links.
  - *Done in the app (v38), first part:* a manga chapter is a list of https page links, `"pages": [...]` in the chapter JSON (up to 300). `components/manga_reader.tsx`: **Scroll** (pages stacked, scrolls with the chapter) and **Page by page** (swipe, or tap the left/right third), "3 / 24" counter, next 3 pages fetched early. Upload check accepts `pages` (`lib/manga.ts`, tested here).
  - *Done in the app (v44), offline pages:* **Save pages offline** downloads every page of a manga chapter to the phone, with progress; the reader then uses the phone's copies ("✓ Saved on this phone"). Uses `expo-file-system`, already in the app. Shows a rough size before saving.
  - *Done in the app (v47), uploads:* **PDF is dropped.** Opening a PDF inside the app needs a PDF rendering package and a new build, and it renders differently on each phone, so it is too much trouble. The fallback you chose: **Add manga chapter from photos** on a manga novel (pages in the order tapped, each shrunk on the phone and uploaded to the novel's folder, saved as one chapter). **JSON** chapters are unchanged (Settings → Choose file).
  - **Not done yet:** pinch to zoom (needs a gesture package: new build). Manga pages from photos: dropped (you asked for PDF and JSON only). (needs a picker and the backend's `uploadAsset`); pins and comments on manga pages (they attach to text paragraphs). Drive share links are not image links: use the direct link from `uploadAsset`.
  - **(you)** Backend: `uploadAsset` returns a direct image link for each page and audio link for the soundtrack, and `saveChapter` accepts `pages`.
- [x] **E3 · Quiz removed (S), your note.** This is a novel reader, not a course. The knowledge quiz is gone from the chapter reader, templates, read-me and upload checks. Old JSON may still carry a `quiz` field; the app ignores it. *(Earlier idea of reactions / polls / character vote is dropped unless you ask for it later.)*
  - *Done in the app (v24):* deleted `components/quiz.tsx`; chapter screen no longer renders quiz; templates and read-me no longer mention quiz; upload accepts (and ignores) a leftover `quiz` field so old files still load.
- [x] **E4 · Recommended / novel-exclusive theme (S→M), your note 5.** *(Authors and Admins only, for their own novels)*
  - The author uploads a theme **for that novel** (`forSubject` = novel id). It is **novel-exclusive**: stored with the novel and **not** listed in the global Settings theme picker (filter already in the app, v25).
  - When a reader opens the novel they see a banner: "The author recommends **Name**. Try it?" Yes / No / Always for this novel. Never forced.
  - *(Earlier idea: also list under "From authors" in the global picker — cancelled; exclusive means it stays on the novel only.)*
  - *Done in the app (v32), backend left for you:* `forSubject` accepted on theme upload; theme template + **Theme for this novel** download in Your novels (pre-fills `forSubject`); global picker still hides novel themes; recommend banner (Yes / No / Always) on novel + chapter screens; choice stored on the phone; theme override while on that novel only (`set_theme_override`). **(you)** phone check after backend returns novel themes with `forSubject`.
  - **(you)** Backend: `saveTheme` accepts `forSubject`; `getCourseData` returns novel themes with `forSubject` set (and/or `recommendedThemeId` on the subject). Author only for own novels; admin any.
- [x] **E5 · Novel background photo (S→M), your note.** *(Authors and Admins only, for their own novels)*
  - Author uploads one image as the novel's **reading background** (stored in the novel's Drive folder, E1).
  - When a reader opens the novel, the chapter reader can show that image behind the text (dimmed / with a scrim so text stays readable). Optional: reader can turn it off in the chapter menu and keep the theme only.
  - *Done in the app (v33), backend left for you:* Your novels → **Reading background** / Change / Remove (needs `folderId`); image resized on phone then `uploadAsset` + `saveSubject({ id, backgroundUrl })`; chapter reader shows photo with theme scrim; **Hide / Show author background** toggle (phone-only per novel). **(you)** phone check after backend returns `backgroundUrl` and `uploadAsset` returns `{ url }`.
  - **(you)** Backend: `uploadAsset` stores in novel folder and returns `{ url }`; `saveSubject` accepts `backgroundUrl` (set or clear with `""`); `getCourseData` returns `backgroundUrl` on the novel.

---

## Phase F · Sound and music
- [x] **F1 · Luxury sound set (M), your note 6.**
  - *Done in the app (v34), no new package:* six soft voices in `lib/sound_code.ts`: **glass, harp, silk, water, piano, swell** (layered harmonics, slow fade, small room echo, peak = the set volume). Old names (`pop`, `bubble`, `chime`, `sparkle`, `tick`, `fanfare`) now map to the soft set, so uploaded themes keep working; `sine/square/triangle` sound codes still work, and a sound code may use a voice name as its `wave`. Template and Read me text updated. **(you)** phone check: switch themes with different sounds and tell me which voices to change; I put 6 preview `.wav` files next to this zip so you can listen first. The current tap sounds are simple computer beeps (square and triangle waves). They get replaced by a soft set:
  - glass bell, harp pluck, silk shimmer, water drop, soft piano note, quiet "sparkle" swell,
  - gentle, short, reverb-like tails, low volume, never harsh.
  - I cannot download recorded sounds, so I will **synthesize** them (layered harmonics, slow decay, a little reverb), save them as audio files inside the app, and let you listen on the phone. **(you)** If you have recorded sounds you like and are allowed to use, send them and I use those instead; that is always better.
  - Theme files can still name a sound; old preset names (`pop`, `chime`, …) map to the new set so uploaded themes keep working.
- [~] **F2 · Background music player (L→M).** While reading, soft looping music.
  - *Done in the app (v39), author track part:* chapter reader shows a music bar when the novel has an author track (`musicUrl`, https): Turn on/off per novel, Mute, volume − / +. Keeps playing while you turn chapters of the same novel; stops when you leave the novel (after a short pause) or put the app away. Choices are kept on the phone. Uses `expo-audio`, already in the app.
  - *v54:* **local music from the phone is dropped** (you asked: keep only the author's tracks). The music bar offers **Author track** or **Off**, with volume and mute. The bar shows for every novel that has an author track.
  - *Done in the app (v46), author soundtrack:* Your novels → **Add soundtrack** / **Change soundtrack** picks an audio file (mp3, m4a, wav, ogg; up to 30 MB), uploads it to the novel's folder and links it as the novel's `musicUrl`.
  - **(you)** Backend: `getCourseData` returns `musicUrl` per novel (a direct https audio link from the novel folder). Phone check after that.
  - **Sources (either):**
    - **Author track** uploaded for that novel (Drive folder, E1), or
    - **Local music** the reader picks from their phone (stays on device; not uploaded).
  - Small player: play/pause, volume, mute, source switch (Author / Local / Off). Remembers choice per novel where possible.
  - Keeps playing as you turn chapters; stops when you leave the novel or put the app away.
  - Author track downloads once for offline.
  - **(you)** Backend: stores the author file in the novel's Drive folder (Phase E1); `getCourseData` returns its link. Local pick needs a media-library / document permission on the phone (new build).
- [~] **F3 · Mixing (S).** Tap sounds, music and narration share one volume plan: music lowers itself while narration speaks or a tap sound plays.
  - *Done in the app (v40), tap sounds part:* while a tap sound plays, the background music drops to about a third for 1.2 s, then comes back (`duck_music` in `lib/music_player.ts`, called by `lib/sound_play.ts`). The same hook is ready for narration (G1). **Not done yet:** narration ducking (G1 not built). **(you)** phone check: play a tap sound while music plays.

---

## Phase G · Narration (text to speech)
Honest note first: the voices built into a phone sound robotic. Very human voices come from **cloud neural voices** (for example Google Cloud, Microsoft Azure, OpenAI or ElevenLabs). These are already trained; we do not train anything ourselves. They cost money per character and need a secret key, which must stay **on the backend**, never in the app.
- [~] **G1 · Read aloud on the phone (M).** Quick first version using the phone's own voices: play / pause, speed, pick a male or female voice, highlights the paragraph being read. Free and works offline, but not "human". It is the base for G2.
  - *Done in the app (v41):* read-aloud bar in the chapter reader: Play / Pause, previous / next paragraph, speed (0.75× to 1.5×), female or male voice (best guess from the phone's voice names), and the paragraph being read is highlighted and kept on screen. Paragraphs, headings, callouts and list items are read; code and tables are skipped. Pause stops, and Play starts again from the same paragraph. Uses `expo-speech`.
  - **New package, so a new build:** `expo-speech`. **Not built yet:** the male/female choice depends on the phone's voice names, so on some phones it may not change. Pinch zoom and other items stay as in E2.
  - **(you)** phone check on a real phone after the new build.
- [-] **G2 · Human narration (L). DROPPED.** You said there is no need for text-to-speech (the Google Cloud voice choice and budget are not needed). G1 read-aloud on the phone is the narration.
  - The backend asks the TTS service for each chapter once, saves the result as an audio file in the novel's folder, and the app plays it (and can download it).
  - Male and female narrator per novel (the author picks the default; the reader can switch).
  - Text blocks are read; headings and code are handled sensibly; names can be given a spelling hint so Chinese names are pronounced well.
  - **(you)** choose the service and budget (see questions). Backend: `generateNarration(chapterId, voice)` that stores the audio and returns its link, with a daily limit to protect the bill.
- [-] **G3 · Player polish (S). DROPPED** (read-aloud is gone).  Progress bar, 15 s back / forward, sleep timer, continue from where you stopped, and works together with the music (F3).

## Offline downloads (O1)
- [~] **O1 · Download a novel for airplane mode (M).** On a novel's screen, **Download for offline** saves its manga pages, its author soundtrack and its background photo to the phone, with progress. Airplane mode then uses the phone's copies. Remove deletes them. **Sign out deletes every download from the phone**, as well as the saved data.
  - *Done in the app (v56):* `lib/downloads.ts` keeps one index on the phone (link → file). The manga reader, the music bar, the reader background and the Home cards all use the phone's copy when there is one. Sign-out calls `delete_all_downloads()` in `lib/auth.tsx`. Logic tested here with a mocked file system (11 checks passed).
  - **(you)** phone check: download a novel with Wi-Fi, turn on airplane mode, read it, play its track and see its pages. Then sign out and check the files are gone from the phone storage.

---

## Phase H · Ship it 🚀
- [ ] Release build and app icon / splash check (bundled sounds, images and fonts increase the size, so check it)
- [~] Privacy policy page (avatars, gender, messages, comments are personal data). *(v42)* In-app page `app/privacy.tsx` linked from Settings, **marked DRAFT**: the two open points and the owner contact are in [brackets]. Needs a review before any release. **(you)** fill in the brackets and check the wording.
- [-] Store listing, screenshots and age rating: dropped on your request ("ignore age rating and all that").
- [ ] Test on a low-end phone and with airplane mode
- [ ] Privacy page: add friends lists and group membership once Phase I exists
- [ ] Backup of the full source and the Apps Script

---

## Phase I · Friends and group chat (new, needs the Supabase foundation)
**Not started.** Unlike every other phase, these have **no Apps Script version**: they exist only in Supabase (Part 2, section 7b, SQL in Appendix C). To keep "the app works at every step": the Friends card, the Groups tab and the "Add friend" button are **hidden until the person has a Supabase session** (a small `has_supabase_session()` check in `lib/supabase.ts`), and `lib/backend.ts` gets a second set, `SB_ONLY`, for these action names (they always go to `lib/sb/`, never to `gas_call`). Rules (limits, who can add whom) are in section 7b.
- [ ] **I1 · Friends (M).**
  - **Profile card (D2):** one more button that follows the state: **Add friend**, **Request sent** (tap to cancel), **Accept / Decline** (when they asked you), **Friends ✓** (tap for Unfriend, asks first). Next to the existing Send message, Block and Report.
  - **Friends screen** (`app/friends.tsx`), reached from the nav wheel and a Home card "Friends (N requests)": three tabs: **Friends** (tap = open the conversation, long press = Unfriend), **Requests** (incoming with Accept / Decline, outgoing with Cancel), **Find** (a search box; results after 3 letters show avatar, username and the right button).
  - Names are usernames only, never emails; a person without a username shows as "Reader" and cannot be searched.
  - Actions: `getFriends`, `findPeople`, `sendFriendRequest`, `respondFriendRequest`, `removeFriend`. Logic and the state-to-button helper in `lib/friends.ts` (pure, tested), server calls in `lib/sb/friends.ts`.
  - **(you)** phone check with two accounts, once the SQL is in: request, accept, unfriend, block (the friendship disappears), search by the first 3 letters.
- [ ] **I2 · Group chat (L).**
  - **Messages screen:** a switch at the top, **People | Groups**. Groups list = name, last line ("username: text"), time, unread badge; a **+ New group** button.
  - **New group** (`app/group_new.tsx`): name (1 to 40 characters) and a checklist of your **friends** (none = a group of one that you add to later).
  - **Group thread** (`app/group/[id].tsx`): same look as a direct thread (plain text, 500 characters), the sender's username and avatar above each bubble, your own messages on the right, Realtime for new messages, opening marks it read. Long press a message: **Delete** (yours; anyone's if you own the group).
  - **Group info** (`app/group_info.tsx`, tap the title): member list with the **owner** tagged; the owner sees **Add friend to group**, **Remove** on each member, **Rename** and **Delete group**; everyone sees **Leave group** (asks first). Tap a member for the profile card.
  - Names of senders are looked up in `public_profiles` for the ids in view; a sender who has left shows as "Former member".
  - Actions: `getGroups`, `getGroupMembers`, `createGroup`, `addGroupMember`, `removeGroupMember`, `leaveGroup`, `renameGroup`, `deleteGroup`, `getGroupMessages`, `sendGroupMessage`, `deleteGroupMessage`, `markGroupRead`. Logic in `lib/groups.ts` (pure, tested), server calls in `lib/sb/groups.ts`. Sending needs a connection and is never queued (same rule as D3).
  - **(you)** phone check with three accounts: create a group, add a friend, try to add a non-friend (refused), post from both phones and watch it arrive without refreshing, delete a message as owner, leave as owner.
- [ ] **I3 · Push and badges (S→M).** Two new webhook branches (section 7b); Home's "Messages waiting" card counts unread **group** threads too; a tap on a group notification opens the thread, a friend request notification opens Friends → Requests. Needs a new build only if `expo-notifications` routing changes.
- [ ] **I4 · Safety carry-over (S).** Blocking someone hides their group messages from you (done in SQL) and removes the friendship; the Admin **Reports** list gets an optional "in group" label later. The admin's "Messages off" button writes `messaging_banned` (review decision 1(a)); it stops group posting as well.

Handler sketch (the same style as Appendix A; `fail` turns database errors into plain words):

```ts
// lib/sb/friends.ts and lib/sb/groups.ts (shared helper at the top of each)
import { supabase } from '../supabase';
import { make_error } from '../net_retry';
const fail = (e: { message?: string; code?: string }) =>
  make_error(e.code === '42501' ? 'You cannot do that.' : e.message || 'Something went wrong.', 'backend');

export async function getFriends() {
  const { data, error } = await supabase.rpc('friends');
  if (error) throw fail(error);
  return data ?? [];                                   // [{ other_id, username, avatar_url, state, since }]
}
export async function findPeople(q: string) {
  const { data, error } = await supabase.rpc('find_people', { q });
  if (error) throw fail(error);
  return data ?? [];                                   // [{ id, username, avatar_url, relation }]
}
export async function sendFriendRequest(other: string) {
  const { data, error } = await supabase.rpc('send_friend_request', { other });
  if (error) throw fail(error);
  return data as 'sent' | 'accepted';
}
export async function respondFriendRequest(other: string, accept: boolean) {
  const { error } = await supabase.rpc('respond_friend_request', { other, accept });
  if (error) throw fail(error);
}
export async function removeFriend(other: string) {
  const { error } = await supabase.rpc('remove_friend', { other });
  if (error) throw fail(error);
}

export async function getGroups() {
  const { data, error } = await supabase.rpc('my_groups');
  if (error) throw fail(error);
  return data ?? [];
}
export async function createGroup(name: string, member_ids: string[]) {
  const { data, error } = await supabase.rpc('create_group', { group_name: name, member_ids });
  if (error) throw fail(error);
  return data as string;                               // the new group id
}
export async function getGroupMessages(group_id: string) {
  const { data, error } = await supabase.from('group_messages')
    .select('id, sender_id, body, created_at').eq('group_id', group_id)
    .order('created_at', { ascending: true }).limit(500);
  if (error) throw fail(error);
  return data ?? [];
}
export async function sendGroupMessage(group_id: string, sender_id: string, body: string) {
  const { error } = await supabase.from('group_messages').insert({ group_id, sender_id, body });
  if (error) throw fail(error);                        // rate limit and "banned" come back as readable text
}
// markGroupRead -> rpc('mark_group_read', { gid }); the other group calls are one rpc each
// (add_group_member{gid,other}, remove_group_member{gid,other}, leave_group{gid}, rename_group{gid,new_name}, delete_group{gid}).

// Realtime: row-level security already limits inserts to your own groups, so one listener is enough for the list,
// and a group_id filter for an open thread:
supabase.channel(`groups:${my_id}`)
  .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'group_messages', filter: `group_id=eq.${group_id}` }, on_new)
  .subscribe();
```

---

## Phase J · End-to-end encrypted chat and Google backup (new, replaces the plain-text chat screens)
**Not started.** Design and rules: Part 2, section 7c; SQL: Appendix D. This changes how the D3 messages and Phase I friends/groups screens store and show things; screens stay the same, the data underneath changes. It needs the Supabase foundation first, **a new custom build** (native crypto and secure storage), and sits behind `E2E_CHAT`.
- [ ] **J1 · Keys (M).** `lib/crypto.ts` wraps the chosen libsodium binding and nothing else (`make_key_pair`, `box_encrypt/decrypt`, `secretbox_encrypt/decrypt`, `seal`, `open_seal`, `fingerprint`). `lib/key_store.ts` keeps the private key in secure storage. First chat use: make the pair, `upsert` the public key into `device_keys`. Sign-out keeps the key (the person did not ask to lose chats); a new **"Delete my chat data from this phone"** button wipes keys and history after a warning.
- [ ] **J2 · Direct messages (L).** Send: encrypt locally, insert `{recipient_id, ciphertext, nonce}`. Receive: Realtime insert or "fetch pending" on open: decrypt, save to the local store, then **delete the server row** (the recipient policy allows it). Unread badge, Home "Messages waiting" and the inbox list all come from the local store. No server-side read receipts. Unsend works only while the row still exists.
- [ ] **J3 · Local store (M).** `lib/chat_store.ts`: app-private storage, rows encrypted with a key from secure storage; threads, messages, group keys by version, friends' key fingerprints. One writer, atomic saves. The store is what the backup reads.
- [ ] **J4 · Photos and videos (L).** Pick (photos shrunk first) → random file key → encrypt → upload to `chat_files/<my id>/<random>` → send the descriptor (path, file key, name, type, size) inside the encrypted message. Receiver downloads, decrypts, saves in app-private storage, shows a thumbnail. Friends only in direct chats (the server refuses otherwise, show its message). Size limit and a progress bar; videos are not re-encoded.
- [ ] **J5 · Groups (L).** Create: random group key, `seal` it for each member, call `publish_group_keys`. Add a member: the owner's phone locks the current key for the new person (same version). Remove or leave: the owner's phone sees `keys_stale`, makes version + 1 and locks it for those who remain (needs the owner online; until then members keep sending with the old version). Send with `key_version`; after storing locally call `ack_group_messages`. Sender names still come from `public_profiles`.
- [ ] **J6 · Google backup and restore (L).** Add the `drive.appdata` scope to the Google sign-in; request it only when the person turns backup on. `lib/chat_backup.ts`: build one JSON (private key, store export, optional media), upload to the app-data folder with the Drive REST API using the person's token; list and download for restore; "Back up now", daily automatic on Wi-Fi, "Last backup" time, **a plain warning before the first backup** (see the honest limits in 7c). Restore screen after sign-in on an empty phone.
- [ ] **J7 · Safety number and key-change notice (M).** Code from the two public keys on the profile card, QR scan to compare, "Security code changed" line in a thread when `device_keys.changed_at` is newer than the stored fingerprint.
- [ ] **J8 · Reports with evidence (S).** The report sheet gets an optional "Attach the last messages from this chat" tick (decrypted on the phone, up to 4000 characters, shown to the person before sending) → `reports.evidence`. Admin list shows it.
- [ ] **J9 · Push and wording (S).** `push_notify` sends "New message" / the group name, no text, and handles both new tables. Privacy page and Read me: what the server sees, the 30-day rule, the unencrypted Google backup, one phone per account, lost phone = lost history unless backed up.

Sketch of the core calls (not tested; only the library's own functions, never homemade crypto):

```ts
// lib/crypto.ts (names are the plan's; map them onto the chosen libsodium binding)
export type KeyPair = { publicKey: string; privateKey: string };        // base64
export function make_key_pair(): KeyPair;                                // crypto_box_keypair
export function box_encrypt(text: string, their_public: string, my_private: string): { ciphertext: string; nonce: string };
export function box_decrypt(ciphertext: string, nonce: string, their_public: string, my_private: string): string | null;
export function secretbox_encrypt(bytes: Uint8Array, key: string): { ciphertext: string; nonce: string };
export function seal(key: string, their_public: string): string;         // crypto_box_seal: wraps a group key for one member

// lib/sb/e2e_chat.ts
export async function send_direct(to_id: string, text: string) {
  const their = await get_public_key(to_id);                              // select from device_keys
  const { ciphertext, nonce } = box_encrypt(text, their, my_private_key());
  const { error } = await supabase.from('messages').insert({ sender_id: my_id, recipient_id: to_id, ciphertext, nonce });
  if (error) throw fail(error);
  await chat_store.add_sent(to_id, text);                                 // my copy lives only on this phone
}
export async function receive_pending() {
  const { data } = await supabase.from('messages').select('id, sender_id, ciphertext, nonce, attachment_path, created_at')
    .eq('recipient_id', my_id).order('created_at');
  for (const m of data ?? []) {
    const text = box_decrypt(m.ciphertext, m.nonce, await get_public_key(m.sender_id), my_private_key());
    await chat_store.add_received(m, text);                               // save first ...
    await supabase.from('messages').delete().eq('id', m.id);              // ... then remove it from the server
  }
}
```

---

## Home screen cards (v51)
- *Done in the app:* the top of Home now shows three sections, each as cards:
  1. **Messages waiting:** up to three people with unread messages (tap to open the thread). Shows "No new messages" when there are none. Blocked people are left out.
  2. **Carry on:** the chapter you left off, with the novel's own background photo (E5) behind it, and "N% of M chapters done".
  3. **For you:** four novels picked at random from the ones that have chapters, each with its own background photo. Re-picked when the library changes, not on every visit.
- Background photos follow the reader's on/off choice for each novel (E5).
- *Fixed on the way:* the Home unread hook was placed after early returns, which breaks React's rules. All Home hooks now come before the early returns.
- **(you)** Phone check. Needs the backend to return `backgroundUrl` (E5) and `progress.active` (saved by the reader).

## Floating nav bar
- *v50:* one round ☰ button. Tap it and the tabs fan out in an arc, like the weapon wheel in GTA 5. Tap a tab to go, or tap outside to close. Items: Home, Messages (signed-in people), Author (authors and admins), Settings.
- **Where it shows:** on every screen for signed-in people, at the bottom centre (`components/global_nav.tsx`, mounted in `app/_layout.tsx`). It is **hidden** in the chapter reader and in a message thread.
- **In the reader:** a ☰ and a ‹ (back) button sit on the same edge as the pin and comment buttons, just below them (`components/reader_edge.tsx`). Back does the same as the header Back (asks before leaving).
- **Not done:** the Author tab has no destination yet (`route: null` in `lib/nav_items.ts`). The reader's edge side is read when the chapter opens; flipping the pin/comment side mid-chapter needs a reopen. *v52:* the wheel now opens with a small spring (the tabs grow out from the button and fade in) and closes with a quick fade back in.
- **(you)** Tell me where the author area lives, and whether the bar should also hide on other screens.

## New packages (each needs a new build)
`expo-image-picker`, `expo-image-manipulator` (D1, also B5 Home background) · gesture handler + reanimated if missing (C2) · `expo-speech` (G1). `expo-audio` and `expo-notifications` are already in the app.

## Questions for you (my default in brackets, so you can answer with "ok")
1. **C1** Is the Back popup what you meant? [yes: Pin / Mark complete / Leave]
2. **D1** Gender choices: Boy, Girl, Skip? [yes]. Keep the five pastel themes as extras? [yes]
3. **D3** Who can message whom? [anyone signed in, but a new person can only send a few per hour; Block always works]
4. **E1** One word "Novel" with a tag Novel / Manga / Donghua? [yes]
5. **E3** Quiz removed (novel, not course). Reactions/polls only if you ask later. [removed]
6. **G2** Which voice service and monthly budget? [I suggest starting with one cloud service, narrate on demand and cache, small daily limit]
7. **F1** Will you send recorded sounds, or should I synthesize them? [synthesize, you judge them on the phone]
8. **D1a** Username rules OK? [3 to 20 letters, digits, `_` `.`; unique; changeable once every 30 days; only the username is shown, never the real name or email]

## Suggested order
A (fix-ups, including dropping offline login) → B1–B3 (words, templates, themes menu) → **R (roles)** → B4 → B5 (Home background photo) → D1a (usernames) → C1, C3, C2 → D1 → E1 → E4 → E5 (novel background photo) → F1 → D2, D3, D4 → E3 → E2 → F2 (author + local music), F3 → G1 → G2, G3 → H.
Reason: A and B are quick and safe; usernames (D1a) come before public comments so no email can ever show; the folder (E1) and profiles (D1) are needed by almost everything after them; narration (G2) is last because it costs money and needs the most backend work.


---

# Part 2: the backend (Supabase and the file service)

## 1. Why move, and what we get

| Today (Apps Script + Sheets) | After (Supabase) |
|---|---|
| Chat refreshes every 8 seconds by asking the server | Messages arrive instantly (Realtime) |
| Every call waits 1 to 3 seconds (cold start, sheet reads) | Calls take tens of milliseconds |
| Rules are checked by code you must remember to call | Rules live in the database (Row Level Security), so a forgotten check cannot leak data |
| Push is sent from inside Apps Script; failures were invisible | A database trigger calls an Edge Function that logs every Expo answer |
| Rows are JSON text in cells, one lock for everything | Real tables, indexes, constraints, transactions |
| 6 minute and daily quota limits | Normal database limits |

What does **not** change: the app screens, the data shapes the screens use (we keep `jsonb` for novels and chapters so the app code barely changes), Google sign-in, Drive for photos and files.

---

## 2. Decisions to confirm before Phase 0

| # | Question | My recommendation | Why |
|---|---|---|---|
| D1 | Where do **soundtracks** live? | **An external file host** (MediaFire or similar). The author pastes a direct link, as today. The app saves each track only in its own app storage on the phone, never in Downloads (see 10.1). | No new server or storage needed. Only the link is stored in the novel. Photos and manga pages stay on Drive. |
| D2 | Catalog format (novels, chapters, themes) | **Keep as `jsonb`** in a `data` column | The app already reads these shapes. Normalising later is possible without touching screens. |
| D3 | Old **chat history** | **Do not migrate** | Messages need both people to exist in the new system. Start chat fresh; keep the sheet as an archive. |
| D4 | Old comments and pins | **Migrate** (comments claimed on first sign-in, see 6.4) | Readers expect their comments to survive. |
| D5 | Sheets after cutover | Keep as a read-only archive for 30 days, then stop using | Safety net. |
| D6 | Avatars | Stay on Drive for now, move to Storage later (optional) | One less thing to change in Phase 1. |

If you disagree with D1, everything else still works: only Phase 5 changes.

---

## 3. Target architecture

```
Phone (Expo app)
 |-- supabase-js ---------> Supabase
 |     auth (Google ID token), tables + RLS, Realtime
 |                              |
 |                              |-- Database Webhook --> Edge Function "push_notify" --> Expo push --> phone
 |
 |-- file requests --------> Apps Script "file service" (kept, much smaller)
       sends the Supabase token; the script asks Supabase "who is this?"
       then saves photos / pages into Drive and returns the link
```

### What stays in Apps Script (the "file service")

Only these actions remain: `uploadAsset` (pictures), `saveAvatar` (until D6), the Drive folder creation for new novels. If you keep soundtracks on Drive (D1 = no), `uploadPart` stays too.

How the file service knows who is calling, without any secret inside the script:

1. The app sends its **Supabase access token** with each file request.
2. The script calls `GET {SUPABASE_URL}/auth/v1/user` with that token and the public `apikey`. Supabase answers with the user id, or refuses.
3. The script calls `GET {SUPABASE_URL}/rest/v1/profiles?id=eq.<id>&select=role,allowed` **with the same user token**, so Row Level Security shows it only that person's own row. It then allows or refuses the upload.
4. For "is this my novel", it asks `rest/v1/subjects?data->>folderId=eq.<drive folder id>&select=id,created_by&limit=1` the same way (it looks the novel up by the **folder id in the request**, as the code does). This is only safe with the unique index on `data->>'folderId'` in Appendix B (finding H3).

Script Properties hold only `SUPABASE_URL` and the public anon key. **No service role key ever goes into Apps Script or the app.**

---

## 4. Project layout (in the Codespace)

```
supabase/
  config.toml
  migrations/
    001_profiles_and_access.sql
    002_chat.sql
    003_catalog.sql              (before comments: "who may delete" needs subjects)
    004_comments_and_pins.sql
    005_guards_and_helpers.sql   (username_available, JSON and theme guards, deleted_rows, progress_import, revokes)
    006_review_fixes.sql         (proposed, Appendix B)
    007_friends_and_groups.sql   (proposed, Appendix C: friend requests, group chat)
  functions/
    push_notify/index.ts
  tests/
    00_helpers.sql
    rls_test.sql                 (all sections; run as superuser on a freshly migrated database)
scripts/
  export_sheets.gs          (runs in Apps Script, writes JSON into Drive "Backups")
  import_from_export.mjs    (Node, uses the service role key from an env var, never committed)
app/lib/
  supabase.ts               (the client, nothing else)
  backend.ts                (router: action name -> Supabase or Apps Script)
  sb/                       (one file per moved action, snake_case)
```

Naming rule: snake_case for every table, column, function, file.

Tools: `npx supabase init`, `npx supabase link --project-ref <ref>`, `npx supabase db push`. Versions to record when you start: Supabase CLI, `@supabase/supabase-js` 2.x, Node 20+.

---

## 5. Phase 0: create the project and push the SQL (terminal)

Run everything from the repo root (the folder that holds `supabase/` and `app/`). Needs Node 20+. Commands use `npx supabase`, so nothing is installed globally. CLI flags change between versions: if one is refused, run it with `--help`.

**Do these in the browser once** (no terminal for them):
- supabase.com, **New project**. Pick the region closest to your readers. Save the database password. Note the **project ref** (the `abcd1234` part of `https://abcd1234.supabase.co`).
- Google Cloud console: you already have a web and an iOS client id (they are in `app/.env`). You will also need the web client's **secret** from the same page, for step 6.

**Terminal steps**

```bash
# 1. log in (opens the browser once)
npx supabase login

# 2. start the local config. The migrations folder already exists; this only adds supabase/config.toml
npx supabase init

# 3. link this folder to your project (asks for the database password)
npx supabase link --project-ref <your-project-ref>

# 4. push the SQL: runs migrations 001 to 005 in order. Use this OR paste ruse_all.sql in the SQL Editor, never both.
npx supabase db push

# 5. check what the remote database now has
npx supabase migration list
```

**Google sign-in from the terminal (step 6).** Put the ids in a local, uncommitted file `supabase/.env` (add it to `.gitignore`):

```bash
GOOGLE_WEB_CLIENT_ID=...apps.googleusercontent.com
GOOGLE_IOS_CLIENT_ID=...apps.googleusercontent.com
GOOGLE_WEB_CLIENT_SECRET=...
```

then add this to `supabase/config.toml` and push it:

```toml
[auth.external.google]
enabled = true
client_id = "env(GOOGLE_WEB_CLIENT_ID),env(GOOGLE_IOS_CLIENT_ID)"
secret = "env(GOOGLE_WEB_CLIENT_SECRET)"
skip_nonce_check = true   # the native Google button does not hand Supabase a nonce; check current docs for the iOS note
```

```bash
# 6. send the auth settings to the linked project
npx supabase config push
```

If `config push` is not available in your CLI version, or refuses, do the same in the Dashboard: **Authentication, Providers, Google**, enable it, and put both client ids (comma separated) under *Authorized Client IDs*.

```bash
# 7. get the public values for the app. Write them into app/.env by hand:
#    EXPO_PUBLIC_SUPABASE_URL=https://<ref>.supabase.co
#    EXPO_PUBLIC_SUPABASE_ANON_KEY=<the anon key>
npx supabase projects api-keys --project-ref <your-project-ref>
```

Only the **anon** key goes in the app. The **service_role** key never goes in `app/.env`, in `config.toml`, in Apps Script, or in git. It lives only in your Codespace secrets, for the import script.

**First admin (do before you sign in for the first time).** The new database has no owner like the old `ADMIN_EMAIL`. Nobody is allowed in until an admin exists, and the first admin can only be created by you in the Dashboard, SQL Editor (use the same Google address you sign in with, in lowercase):

```sql
insert into public.invited_users (email, role) values ('<your admin email, lowercase>', 'admin');
```

Your first sign-in then creates your profile as an approved admin. Everyone else is approved from the Admin screen.

**If you already signed in once before adding yourself** (for example to test Google sign-in), the profile exists as `allowed = false` and the invitation is ignored, because the trigger only runs once. Fix it in the SQL Editor (it bypasses the guards):

```sql
update public.profiles set allowed = true, role = 'admin' where email = '<your admin email, lowercase>';
```

**Run the SQL tests (step 8): never on the real project.** The tests insert fake users, so use a throwaway local database (needs Docker):

```bash
npx supabase start                 # local Postgres + Auth, prints the DB url (usually postgresql://postgres:postgres@127.0.0.1:54322/postgres)
npx supabase db reset              # applies migrations 001 to 005 from scratch
psql "postgresql://postgres:postgres@127.0.0.1:54322/postgres" -v ON_ERROR_STOP=1 \
  -f supabase/tests/00_helpers.sql -f supabase/tests/rls_test.sql
npx supabase stop
```

No Docker? Create a second, empty Supabase project just for tests, link to it, `db push`, run the same `psql` line with its connection string (Dashboard, Connect), then delete it. Every G01 to G40 must pass before Phase 1 handlers are written.

**Back up and install (steps 9 and 10)**

```bash
# 9. a full copy of the old Sheets: run backup in the old Apps Script editor, check the files in Drive "Backups"

# 10. packages for the app
cd app && npx expo install @supabase/supabase-js @react-native-async-storage/async-storage react-native-url-polyfill
```

Later, monthly: `npx supabase db dump -f backup_$(date +%F).sql`, saved in the Drive `Backups` folder (free projects may not keep daily backups, see section 15).

Done when: `migration list` shows 001 to 005 on the remote, Google sign-in settings are pushed (or set in the Dashboard), `.env` has the URL and anon key, the tests pass locally, and the Sheets backup is saved.

---

## 5b. Deploy the file service (terminal)

Needs `app/.env` to hold the two Supabase values from step 7 first. Use a **new** Apps Script project; the old backend keeps running untouched.

```bash
npm install -g @google/clasp        # once
clasp login                         # once, opens the browser. Also turn on the Apps Script API: script.google.com/home/usersettings

node json_to_clasp.mjs app/.env     # writes clasp_project/ with the Supabase URL and anon key built into config.gs
cd clasp_project
clasp create --type standalone --title "RUSE file service" --rootDir .
clasp push --force                  # --force accepts the appsscript.json manifest without asking
clasp open                          # opens the editor
```

In the editor: choose `setup_everything` in the function list, **Run**, accept the permissions (it makes the Drive folders `RUSE Data`, `Novels`, `Avatars` and reports a missing Supabase setting). Then back in the terminal:

```bash
clasp deploy --description "file service v1"   # prints a deployment id; the web app URL is https://script.google.com/macros/s/<deployment id>/exec
curl -s -X POST "https://script.google.com/macros/s/<deployment id>/exec" \
  -H "Content-Type: text/plain" -d '{"action":"ping","args":[]}'    # expect {"ok":true,"data":{"ok":true}}
```

If the manifest's web app settings are not picked up, use Deploy, New deployment, Web app in the editor (Execute as: Me, Access: Anyone). To change code later: edit, `clasp push`, then `clasp deploy --deploymentId <id>` so the URL stays the same.

Done when: the `ping` call answers, and a real upload with a signed-in author's token lands in the novel's Drive folder (test list 10.3).

---

## 6. Phase 1: sign-in, profiles, roles, access requests

### 6.1 The idea

- A person signs in with Google exactly as today. The app takes the Google **ID token** and gives it to Supabase.
- On their first sign-in a trigger creates their `profiles` row.
- `allowed = false` means "waiting for an admin". The admin's pending list is simply `profiles where allowed = false`, so the old `Requests` sheet disappears.
- An admin can add someone **before** they sign in: that goes into `invited_users`, and the trigger picks it up on their first sign-in. The same table carries your old users across the move (see 6.4).

### 6.2 SQL: `001_profiles_and_access.sql`

```sql
create type public.user_role   as enum ('reader', 'author', 'admin');
create type public.gender_kind as enum ('boy', 'girl', 'skip');

-- People who may use the app but have not signed in yet (added by an admin, or carried over from the old sheet).
create table public.invited_users (
  email               text primary key,
  role                public.user_role not null default 'reader',
  username            text,
  username_changed_at timestamptz,
  gender              public.gender_kind,
  avatar_url          text,
  messaging_off       boolean not null default false
);

create table public.profiles (
  id                  uuid primary key references auth.users (id) on delete cascade,
  email               text not null unique,
  display_name        text not null default '',      -- the Google name: admins only, never shown to readers
  role                public.user_role not null default 'reader',
  allowed             boolean not null default false,
  request_status      text not null default 'pending' check (request_status in ('pending', 'rejected')),
  username            text,
  username_changed_at timestamptz,
  gender              public.gender_kind,
  avatar_url          text,
  messaging_off       boolean not null default false,
  role_request        text check (role_request is null or role_request = 'author'),
  added_at            timestamptz not null default now(),
  -- same rules as username_error() in the old backend
  constraint username_shape check (
    username is null or (
      username ~ '^[A-Za-z0-9_.]{3,20}$'
      and username !~ '^[._]' and username !~ '[._]$' and username !~ '[._]{2,}'
      and lower(username) <> all (array[
        'admin','administrator','owner','mod','moderator','support','help','ruse','system','null',
        'undefined','everyone','all','me','you','reader','author','official','staff','root','test','guest'])
    )
  )
);
create unique index profiles_username_unique on public.profiles (lower(username)) where username is not null;

-- ---- who is asking? (used by every policy) ----
create function public.is_member() returns boolean
language sql stable security definer set search_path = public as $$
  select coalesce((select allowed from public.profiles where id = auth.uid()), false)
$$;

create function public.is_admin() returns boolean
language sql stable security definer set search_path = public as $$
  select coalesce((select allowed and role = 'admin' from public.profiles where id = auth.uid()), false)
$$;

create function public.can_upload() returns boolean
language sql stable security definer set search_path = public as $$
  select coalesce((select allowed and role in ('author', 'admin') from public.profiles where id = auth.uid()), false)
$$;

-- ---- first sign-in: create the profile, using the invitation if there is one ----
create function public.handle_new_user() returns trigger
language plpgsql security definer set search_path = public as $$
declare invite public.invited_users%rowtype;
begin
  select * into invite from public.invited_users where lower(email) = lower(new.email);
  insert into public.profiles (id, email, display_name, role, allowed, username, username_changed_at, gender, avatar_url, messaging_off)
  values (
    new.id, lower(new.email), coalesce(new.raw_user_meta_data ->> 'full_name', ''),
    coalesce(invite.role, 'reader'), invite.email is not null,
    invite.username, invite.username_changed_at, invite.gender, invite.avatar_url, coalesce(invite.messaging_off, false)
  );
  return new;
end $$;

create trigger on_auth_user_created after insert on auth.users
for each row execute function public.handle_new_user();

-- ---- what a normal person may NOT change on their own profile ----
create function public.profiles_guard() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if auth.uid() is null then return new; end if;              -- SQL editor, import script, Edge Functions
  if not public.is_admin() then
    if new.role is distinct from old.role or new.allowed is distinct from old.allowed
       or new.email is distinct from old.email or new.added_at is distinct from old.added_at
       or new.request_status is distinct from old.request_status then
      raise exception 'You cannot change that.';
    end if;
  end if;
  if new.username is distinct from old.username then
    if old.username is not null and old.username_changed_at > now() - interval '30 days' then
      raise exception 'You can change your username once every 30 days.';
    end if;
    new.username_changed_at := now();
  end if;
  return new;
end $$;

create trigger profiles_guard_before_update before update on public.profiles
for each row execute function public.profiles_guard();

-- ---- Row Level Security ----
alter table public.profiles       enable row level security;
alter table public.invited_users  enable row level security;

create policy profiles_read_own    on public.profiles for select to authenticated using (id = auth.uid());
create policy profiles_read_admin  on public.profiles for select to authenticated using (public.is_admin());
create policy profiles_update_own  on public.profiles for update to authenticated using (id = auth.uid()) with check (id = auth.uid());
create policy profiles_update_admin on public.profiles for update to authenticated using (public.is_admin()) with check (public.is_admin());

create policy invited_admin_all on public.invited_users for all to authenticated
  using (public.is_admin()) with check (public.is_admin());

-- What other readers may see about a person: username and picture, never the email.
create view public.public_profiles as
  select id, username, avatar_url, role
  from public.profiles
  where allowed and username is not null and public.is_member();
grant select on public.public_profiles to authenticated;
```

Before the first sign-in, add yourself so you are not locked out:

```sql
insert into public.invited_users (email, role) values ('<your admin email>', 'admin');
```

### 6.3 App work

- `lib/supabase.ts`:

```ts
import 'react-native-url-polyfill/auto';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { createClient } from '@supabase/supabase-js';

export const supabase = createClient(process.env.EXPO_PUBLIC_SUPABASE_URL!, process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY!, {
  auth: { storage: AsyncStorage, autoRefreshToken: true, persistSession: true, detectSessionInUrl: false },
});
```

- In `lib/auth.tsx`, after `GoogleSignin.signIn()` succeeds:

```ts
const id_token = result.data?.idToken;
const { error } = await supabase.auth.signInWithIdToken({ provider: 'google', token: id_token! });
```

  The saved session means the app still opens offline, like today. (Check the current Supabase docs for the nonce note on iOS.)
- The file service takes the **Supabase** access token from day one (Appendix A), so the Google ID token is used only to sign in to Supabase and is not kept.
- Replace these actions (see section 13): `getMe`, `getProfile`, `saveProfile`, `saveUsername`, `checkUsername`, `requestAccess`, `requestRole`, `setMessaging`, and the admin group (`getAdminData`, `approveRequest`, `rejectRequest`, `addUser`, `setRole`, `setAdmin`, `removeUser`).
- `checkUsername` becomes a call to `username_available(name text)` (defined in `005_guards_and_helpers.sql`; same rules as the `username_shape` constraint; your own current name counts as available; returns `false` for anything invalid, so the app's `check_username_local` still gives the friendly reason).
- `removeUser` sets `allowed = false` (soft remove). Real deletion from `auth.users` is an Edge Function job and not needed.

### 6.4 Carrying the old users across

Export the `Users` sheet, then insert each row into `invited_users` (email, role, username, gender, avatar link, messaging off). When that person signs in for the first time, the trigger gives them their old role and username. Nobody has to be re-approved.

### 6.5 Test list

- You (admin) sign in: `allowed = true`, role admin.
- A new Google account signs in: profile exists, `allowed = false`, shows in your pending list.
- You approve it: they can read data.
- A normal user tries `update profiles set role = 'admin'` on themselves: refused.
- Two usernames differing only by capitals: second refused.
- Change username twice in a row: second refused.

Rollback: nothing else uses these tables yet; switch the action names back in `backend.ts`.

---

## 7. Phase 2: chat (the big win)

> **Superseded in part (7 Nov):** chat is now end-to-end encrypted (section 7c). Read the `body`, `inbox()`, `mark_read()` and the read/unread parts of this section as **replaced by Appendix D**. Everything else here (blocks, reports, rate limits, push tokens) stays.

### 7.1 SQL: `002_chat.sql`

```sql
create table public.blocks (
  blocker_id uuid not null references public.profiles (id) on delete cascade,
  blocked_id uuid not null references public.profiles (id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (blocker_id, blocked_id)
);

create table public.reports (
  id          uuid primary key default gen_random_uuid(),
  reporter_id uuid not null references public.profiles (id) on delete cascade,
  reported_id uuid not null references public.profiles (id) on delete cascade,
  reason      text not null check (char_length(reason) between 1 and 500),
  status      text not null default 'open' check (status in ('open', 'resolved')),
  created_at  timestamptz not null default now()
);

create table public.messages (
  id           uuid primary key default gen_random_uuid(),
  sender_id    uuid not null references public.profiles (id) on delete cascade,
  recipient_id uuid not null references public.profiles (id) on delete cascade,
  body         text not null check (char_length(btrim(body)) between 1 and 500),
  created_at   timestamptz not null default now(),
  read_at      timestamptz,
  constraint messages_not_to_self check (sender_id <> recipient_id)
);
create index messages_pair_idx on public.messages (least(sender_id, recipient_id), greatest(sender_id, recipient_id), created_at desc);
create index messages_unread_idx on public.messages (recipient_id) where read_at is null;

create table public.push_tokens (
  token      text primary key,
  user_id    uuid not null references public.profiles (id) on delete cascade,
  updated_at timestamptz not null default now()
);

-- May this person message that person? (messages on, nobody blocked)
create function public.can_message(sender uuid, recipient uuid) returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.profiles r where r.id = recipient and r.allowed and not r.messaging_off)
     and not exists (select 1 from public.blocks b
                     where (b.blocker_id = recipient and b.blocked_id = sender)
                        or (b.blocker_id = sender    and b.blocked_id = recipient))
$$;

-- Same limits as the old backend: 5 per hour for accounts younger than 7 days, 40 per hour after that.
create function public.messages_rate_limit() returns trigger
language plpgsql security definer set search_path = public as $$
declare
  is_new boolean;
  sent   int;
begin
  select added_at > now() - interval '7 days' into is_new from public.profiles where id = new.sender_id;
  select count(*) into sent from public.messages where sender_id = new.sender_id and created_at > now() - interval '1 hour';
  if sent >= (case when is_new then 5 else 40 end) then
    raise exception 'You have sent too many messages. Try again later.';
  end if;
  return new;
end $$;

create trigger messages_rate_limit_before_insert before insert on public.messages
for each row execute function public.messages_rate_limit();

alter table public.messages    enable row level security;
alter table public.blocks      enable row level security;
alter table public.reports     enable row level security;
alter table public.push_tokens enable row level security;

create policy messages_read on public.messages for select to authenticated
  using (public.is_member() and auth.uid() in (sender_id, recipient_id)
    and not exists (select 1 from public.blocks b where b.blocker_id = auth.uid()
      and b.blocked_id = case when sender_id = auth.uid() then recipient_id else sender_id end));

create policy messages_send on public.messages for insert to authenticated
  with check (public.is_member() and sender_id = auth.uid() and public.can_message(sender_id, recipient_id));

create policy messages_delete_own on public.messages for delete to authenticated
  using (sender_id = auth.uid());
-- No update policy on purpose: marking read goes through mark_read() below, so nobody can edit a message.

create policy blocks_own on public.blocks for all to authenticated
  using (blocker_id = auth.uid()) with check (blocker_id = auth.uid() and public.is_member());

create policy reports_send  on public.reports for insert to authenticated with check (reporter_id = auth.uid() and public.is_member());
create policy reports_admin on public.reports for select to authenticated using (public.is_admin());
create policy reports_close on public.reports for update to authenticated using (public.is_admin()) with check (public.is_admin());

-- Mark everything from one person as read.
create function public.mark_read(other uuid) returns void
language sql security definer set search_path = public as $$
  update public.messages set read_at = now()
  where recipient_id = auth.uid() and sender_id = other and read_at is null
$$;

-- The inbox: one row per person, newest first, with the unread count and their picture.
create function public.inbox()
returns table (other_id uuid, username text, avatar_url text, last_body text, last_at timestamptz, last_from_me boolean, unread bigint)
language sql stable security definer set search_path = public as $$
  with mine as (
    select m.*, case when m.sender_id = auth.uid() then m.recipient_id else m.sender_id end as other_id
    from public.messages m
    where auth.uid() in (m.sender_id, m.recipient_id)
  ), last_one as (
    select distinct on (other_id) other_id, body, created_at, sender_id
    from mine order by other_id, created_at desc
  )
  select l.other_id, p.username, p.avatar_url, l.body, l.created_at, l.sender_id = auth.uid(),
         (select count(*) from mine x where x.other_id = l.other_id and x.recipient_id = auth.uid() and x.read_at is null)
  from last_one l
  join public.profiles p on p.id = l.other_id
  where public.is_member()
    and not exists (select 1 from public.blocks b where b.blocker_id = auth.uid() and b.blocked_id = l.other_id)
  order by l.created_at desc
$$;

-- A phone's notification address. A function, because a token may move between accounts on a shared phone.
create function public.register_push_token(t text) returns void
language sql security definer set search_path = public as $$
  insert into public.push_tokens (token, user_id) values (t, auth.uid())
  on conflict (token) do update set user_id = auth.uid(), updated_at = now()
$$;

create policy push_tokens_own on public.push_tokens for select to authenticated using (user_id = auth.uid());
create policy push_tokens_delete_own on public.push_tokens for delete to authenticated using (user_id = auth.uid());

-- Realtime: new and deleted messages reach the phone at once.
alter publication supabase_realtime add table public.messages;
```

The revokes for `inbox`, `mark_read`, `register_push_token` and `can_message` are in `005_guards_and_helpers.sql` (section 7 of that file), together with the `is_*` helpers and the trigger functions.

### 7.2 App work

- `fetch_conversation`: `supabase.from('messages').select('*').or(...)` for the pair, oldest first, limit 1000.
- `fetch_all_messages` becomes `supabase.rpc('inbox')`; the inbox screen reads the rows directly.
- `send_message`: `supabase.from('messages').insert({ sender_id, recipient_id, body })`. Database errors (rate limit, blocked) come back as readable text.
- `delete_message`: `supabase.from('messages').delete().eq('id', id)`.
- `mark_read`: `supabase.rpc('mark_read', { other })`.
- Blocks and reports map to plain inserts and deletes on `blocks` and `reports`.
- **Delete the 8 second polling** in the chat screen and subscribe instead:

```ts
const channel = supabase.channel(`chat:${my_id}`)
  .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'messages', filter: `recipient_id=eq.${my_id}` }, on_new)
  .on('postgres_changes', { event: 'DELETE', schema: 'public', table: 'messages' }, on_gone) // carries only the id: enough
  .subscribe();
// on leaving the screen: supabase.removeChannel(channel)
```

- Messages need the other person's picture and name: join `public_profiles` (the inbox already returns them).

### 7.3 Push: `supabase/functions/push_notify/index.ts`

A **Database Webhook** (dashboard, Database, Webhooks) on `INSERT` into `messages` calls this function, with a header `x-webhook-secret` you also store as a function secret.

```ts
import { createClient } from 'jsr:@supabase/supabase-js@2';

const db = createClient(Deno.env.get('SUPABASE_URL')!, Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!);

Deno.serve(async (req) => {
  if (req.headers.get('x-webhook-secret') !== Deno.env.get('PUSH_WEBHOOK_SECRET')) return new Response('no', { status: 401 });
  const { record } = await req.json();                       // the new message row
  const { data: sender } = await db.from('profiles').select('username').eq('id', record.sender_id).single();
  const { data: rows }   = await db.from('push_tokens').select('token').eq('user_id', record.recipient_id);
  const tokens = (rows ?? []).map((r) => r.token);
  if (!tokens.length) return new Response('no devices');

  const res = await fetch('https://exp.host/--/api/v2/push/send', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
    body: JSON.stringify(tokens.map((to) => ({
      to, title: `New message from ${sender?.username ?? 'someone'}`, body: String(record.body).slice(0, 120),
      data: { type: 'message', with: sender?.username }, sound: 'default', channelId: 'default', priority: 'high',
    }))),
  });
  const answer = await res.json();
  // Expo's answer is never ignored: log problems, and forget phones Expo says are gone.
  (answer.data ?? []).forEach(async (ticket: any, i: number) => {
    if (ticket.status === 'ok') return;
    console.error('push problem', ticket.details?.error, ticket.message);
    if (ticket.details?.error === 'DeviceNotRegistered') await db.from('push_tokens').delete().eq('token', tokens[i]);
  });
  return new Response('ok');
});
```

Notes: the **Google (FCM V1) key must be uploaded to Expo** (`eas credentials`, Android) or Android phones are never reached. The existing "Send me a test notification" button stays useful: make it call the same function through a small `test_push` Edge Function that also asks Expo for the receipts.

### 7.4 Test list (two accounts, two phones)

- A sends to B: B sees it within a second, the chat screen without refreshing.
- A deletes it: it disappears on B.
- B blocks A: A can no longer send; B's inbox hides A.
- B turns messages off: A's send is refused with a readable error.
- A new account sends 6 messages in an hour: the 6th is refused.
- Someone edits another person's message through the API: impossible (no update policy).
- B is offline: notification arrives on the phone.

Run `supabase/tests/rls_chat.sql` with two fake users:

```sql
begin;
select set_config('request.jwt.claims', '{"sub":"<uuid of A>","role":"authenticated"}', true);
set local role authenticated;
-- statements as A here, each should succeed or fail as listed above
rollback;
```

Rollback: put the chat actions back in `backend.ts` and restore the polling file from version control. The Sheets `Messages` tab was never touched.

---

## 7b. Phase 2b: friends and group chat (new)

**Status: designed, SQL written, never run.** The message rules below (plain text, last-line previews, unread counts from the server) are **replaced by section 7c**; friends, group membership and the limits stay. The SQL is in **Appendix C** (`007_friends_and_groups.sql`). It needs migration 006 (`messaging_banned`). If you chose decision 1(b) in the review, replace `not s.messaging_banned` in `can_post_group` with `true` before running it.

**Rules chosen (change any of them before you build; each is one line of SQL or one handler):**
- **Friends:** a request must be **accepted**. If both people send a request to each other it becomes a friendship at once. Either person can cancel, decline or unfriend. Blocking someone removes the friendship. A person can send 20 requests per hour. Search is by **username prefix** (3 letters or more, 10 results); no emails anywhere.
- **Direct messages stay open to any signed-in person** (decision D3 is unchanged). Friends are for adding people to groups and for the friends list. *Option:* make DMs friends-only: add `and public.are_friends(sender, recipient)` to `can_message()`.
- **Groups:** any approved person can create one (up to **10 owned groups**, **30 people** each, name 1 to 40 characters). Only the **owner** adds people, and only **their friends**; nobody is added if there is a block between them and the owner. Anyone can leave. If the owner leaves, the longest-standing member becomes owner; the last person leaving deletes the group.
- **Messages:** plain text, 500 characters, same hourly limits as direct messages (5 for accounts younger than 7 days, 40 after; group and direct messages count together). A person may delete their own message; the **owner** and **admins** may delete any message in the group. Messages from someone **you blocked** are hidden from you. An admin's `messaging_banned` stops posting in groups too. A person's own "do not disturb" (`messaging_off`) affects direct messages only.
- **Realtime:** `group_messages` joins the Realtime publication; row-level security decides who receives an insert. The unfiltered DELETE event of finding M6 applies here too (message id only).
- **Push:** a second and third Database Webhook (`group_messages` insert, `friendships` insert) call `push_notify`, which branches on `payload.table`:
  - `group_messages`: send to every member except the sender and except people who blocked the sender; title is the group name, body is "username: first 100 characters", data `{ type: 'group', group_id }`.
  - `friendships`: send to the addressee, title "New friend request", body the requester's username, data `{ type: 'friend' }`. (Accepting does not notify, on purpose.)
  - Taps must route to the group thread or the Friends screen; the app already routes message taps, add these two cases.
- **Privacy page:** friends lists and group membership are personal data; add them to the privacy text (Part 1, Phase H) before release.

**Test list (two or three accounts; add as G50 and up in `rls_test.sql`):**
- A sends B a request: B sees it as incoming, A as outgoing. A sends it again: nothing changes. B sends A a request instead: both become friends.
- A person cannot send a request to themselves, to someone who blocked them, or to a waiting (not approved) account. The 21st request in an hour is refused.
- Blocking removes an existing friendship and a pending request.
- C (not a friend of A) cannot be added to A's group; a friend can; a member who is not the owner cannot add anyone; the 31st person is refused.
- A non-member cannot read the group, its members or its messages, and cannot post.
- A member reads and posts; a message from someone the reader blocked does not appear for the reader.
- A member deletes their own message; a plain member cannot delete another's; the owner can.
- The owner leaves: the next member becomes owner; the last member leaves: the group and its messages are gone.
- A person banned by an admin cannot post in a group.
- `select * from friendships` as a stranger returns nothing; `select are_friends(...)` and `select blocked_between(...)` are refused for every signed-in person (they are internal).

Rollback: nothing else uses these tables. Hide the Friends and Groups screens and drop the migration (`drop table` the five tables, then the functions); chat, comments and the catalog are untouched.

---

## 7c. End-to-end encrypted chat (decided 7 Nov)

**What you asked for:** messages, photos and videos exist only on the phones. Nothing readable stays in your Drive or database. A person who wants a copy that survives a lost phone backs it up to **their own Google Drive**, **not encrypted** (their own account, their choice).

**What the server holds, and for how long**
- A direct message: **ciphertext only** (scrambled text, a nonce, the sender, the recipient, a time) until the other phone has downloaded it. The receiving phone then deletes the row. A nightly job deletes anything undelivered after **30 days**. The sender may unsend a message until it is delivered.
- A group message: ciphertext until **every other member's phone** has confirmed it (or 30 days). Confirmations are kept in a small table and disappear with the message.
- A photo or video: encrypted **on the sender's phone**, uploaded to a private temporary bucket, and deleted by an hourly job as soon as no message points at it (or after one hour if it was never sent). The key to open it travels **inside** the encrypted message. Your Drive is not used for chat at all.
- Always visible to the server (cannot be hidden): who talks to whom, when, rough size, group names and members, friend lists. The privacy page must say so.

**How it works (plain words)**
- Each phone makes a **key pair** at first sign-in. The private half stays in the phone's secure storage; the public half goes into `device_keys`. Everyone can read public keys.
- **Direct message:** the sender locks the text with *their private key + the other person's public key* (libsodium `crypto_box`). Only the other phone can open it.
- **Group:** the owner makes one random **group key** and locks a copy for each member with that member's public key (`group_keys`). Messages and files are locked with the group key (`secretbox`). When someone is **removed or leaves**, the key is replaced (new `key_version`) and re-locked for the people who remain; a new member gets the current key and cannot read older messages.
- **Photos and videos:** a random key per file locks the file; that key and the file's name, type and size go inside the encrypted message. Photos are shrunk on the phone first; a video has a size limit (25 MB to start, see the open points). **Only friends can receive photos and videos in direct messages** (enforced in SQL); in groups, members can post them, and membership already needs friendship with the owner.
- **Safety number:** both phones show a short code made from the two public keys. If a friend's key **changes** (new phone), the app shows "Security code changed" in the thread, and the friendship card offers a check by comparing codes or scanning a QR.
- **Local history:** each phone keeps its own copy in app-private storage, encrypted with a key from secure storage. Unread counts, inbox lines and search come from this copy, not from the server.

**Backup to the person's own Google Drive (unencrypted, as decided)**
- A switch **Back up my chats to my Google Drive**, offered the first time someone chats (recommended, not forced). It uses the Google **`drive.appdata`** permission: a hidden folder only this app can see in that person's Drive. The phone talks to Google directly with the person's own sign-in; the file service and your Drive are not involved.
- The backup holds the **private key** and the chat history (photos and videos only if the person ticks it, because they use that person's 15 GB). It runs "Back up now" and, if switched on, once a day on Wi-Fi.
- **Restore:** sign in with Google on a new phone, tap Restore, and the key and history return. The same key means friends see no "code changed" warning. Restoring makes the new phone the active one.
- **Honest limits to show in the app and the privacy page:** because the backup is not encrypted, **anyone who can open that Google account can read the backup, and Google can technically read it too.** The end-to-end protection is against RUSE's servers, the network and your Drive, not against the person's own Google account. With backup off, a lost or reinstalled phone loses its history for good.
- Android: keep `allowBackup` off for the app so the phone's own cloud backup does not copy the keys elsewhere.

**Limits this design accepts**
- **One active phone per account** (one key). A second phone needs a restore, which replaces the first.
- **No forward secrecy** in version 1 (a stolen private key opens old messages that are still saved anywhere). The stronger Signal protocol is heavy in React Native; revisit later.
- **Push says only "New message"** (or the group name), never the text. The Edge Function cannot read anything.
- **Admins cannot read reported chats.** A report may carry the reporter's own decrypted excerpt (`reports.evidence`, optional, up to 4000 characters); the reporter chooses it.
- **Abuse control** rests on block, report, friends-only media, rate limits and the owner's right to delete in groups. The owner and admins can delete a group message only while it still sits on the server; local copies stay on phones.
- Realtime DELETE events stay unfiltered (finding M6), and now carry only a random id.

**Open points I could not verify (check before building)**
- Which libsodium binding for React Native is maintained today (needs a custom build, not Expo Go), and whether `expo-secure-store` (removed in A7) comes back for key storage.
- Whether `drive.appdata` needs Google's app verification on your OAuth consent screen, and the current Drive API upload rules.
- The Supabase plan's file size limit for a private bucket, and whether `pg_cron` can be enabled on your plan (the nightly delete needs it; otherwise run it from a scheduled Edge Function).
- The code samples in Part 1 Phase J are a sketch, not tested. **Do not write your own cryptography**: only call the library's `crypto_box`, `secretbox` and sealed-box functions.

**Test list (two phones, then three; add as G60 and up)**
- A sends B a message: B's phone shows it; `select ciphertext from messages` in the SQL Editor shows scrambled text; after B's phone confirms, the row is gone.
- B offline for a day: the row waits; B comes online and receives it, then it is gone. A row older than 30 days is removed by the job.
- A third account cannot read or delete A's or B's rows; a stranger cannot read a stored file or reference another person's file path.
- A photo to a non-friend is refused; to a friend works; the stored file is unreadable without the key; the file disappears within the hour after delivery.
- Group of three: all read each message; the owner removes C; C cannot read messages sent afterwards; the key version goes up; a new member D reads from the moment of joining only.
- B installs on a new phone without a backup: old history is gone, A sees "Security code changed". With a backup: history and key return, no warning.
- A report with an excerpt reaches the Admin list; without one it still does.
- Push text never contains message content.

Rollback: nothing else uses these tables. Phase J is behind a switch (`E2E_CHAT` in `lib/config.ts`); until it is on, the old screens stay hidden.

---

## 8. Phase 3: comments and pins

### 8.1 SQL: `004_comments_and_pins.sql` (runs **after** `003_catalog.sql`: "who may delete" needs `subjects`. The plan used to number these the other way round; the files are the truth)

```sql
create table public.comments (
  id           uuid primary key default gen_random_uuid(),
  chapter_id   text not null,
  block        int  not null check (block >= -1),   -- -1 = the whole chapter (app: WHOLE_CHAPTER in lib/pin_helpers.ts)
  parent_id    uuid references public.comments (id) on delete cascade,
  author_id    uuid references public.profiles (id) on delete set null,
  author_email text,                                     -- only for comments carried over from the old sheet
  body         text not null check (char_length(btrim(body)) between 1 and 1000),
  created_at   timestamptz not null default now(),
  edited_at    timestamptz
);
create index comments_chapter_idx on public.comments (chapter_id, block, created_at);

-- One bookmark per person per chapter, like today.
create table public.pins (
  user_id    uuid not null references public.profiles (id) on delete cascade,
  chapter_id text not null,
  block      int  not null check (block >= 0),
  created_at timestamptz not null default now(),
  primary key (user_id, chapter_id)
);

-- Old comments belong to their writer as soon as that person signs in.
create function public.claim_old_comments() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  update public.comments set author_id = new.id where author_id is null and lower(author_email) = lower(new.email);
  return new;
end $$;
create trigger profiles_claim_comments after insert on public.profiles
for each row execute function public.claim_old_comments();

-- 30 comments per hour, and 100 per person per chapter (same as the old backend).
create function public.comments_limits() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if (select count(*) from public.comments where author_id = new.author_id and created_at > now() - interval '1 hour') >= 30 then
    raise exception 'You are commenting too fast. Try again later.';
  end if;
  if (select count(*) from public.comments where author_id = new.author_id and chapter_id = new.chapter_id) >= 100 then
    raise exception 'You have too many comments on this chapter.';
  end if;
  return new;
end $$;
create trigger comments_limits_before_insert before insert on public.comments
for each row execute function public.comments_limits();

alter table public.comments enable row level security;
alter table public.pins     enable row level security;

create policy comments_read   on public.comments for select to authenticated using (public.is_member());
create policy comments_insert on public.comments for insert to authenticated
  with check (public.is_member() and author_id = auth.uid());
create policy comments_edit_own on public.comments for update to authenticated
  using (author_id = auth.uid()) with check (author_id = auth.uid());
create policy comments_delete on public.comments for delete to authenticated using (
  author_id = auth.uid()
  or public.is_admin()
  or exists (select 1 from public.chapters c join public.subjects s on s.id = c.subject_id
             where c.id = comments.chapter_id and s.created_by = auth.uid())   -- the novel's uploader
);

create policy pins_own on public.pins for all to authenticated
  using (user_id = auth.uid()) with check (user_id = auth.uid() and public.is_member());
```

### 8.2 App work

Replace `getComments`, `saveComment`, `replyComment`, `deleteComment`, `getPins`, `savePin`, `deletePin`. `addBlockAfterComment` edits a chapter, so it moves with Phase 4. A new comment notifies the novel's uploader (and the parent's writer on a reply): add a second Database Webhook on `comments` that reuses the `push_notify` function (branch on `table`). **Put `block` in the notification data**, so a tap opens the right paragraph (the app already routes it).

### 8.3 Test list

Uploader deletes someone else's comment: works. A reader deletes someone else's: refused. 31st comment in an hour: refused. A pin replaces the old one in the same chapter.

---

## 9. Phase 4: catalog (novels, chapters, themes, progress)

### 9.1 SQL: `003_catalog.sql`

```sql
create table public.subjects (
  id               text primary key,
  position         int  not null default 0,
  data             jsonb not null,                 -- exactly what the app reads today
  created_by       uuid references public.profiles (id) on delete set null,
  created_by_email text,                           -- carried over; claimed on first sign-in
  updated_at       timestamptz not null default now()
);

create table public.chapters (
  id         text primary key,
  subject_id text not null references public.subjects (id) on delete cascade,
  position   int  not null default 0,
  data       jsonb not null,
  updated_at timestamptz not null default now()
);
create index chapters_subject_idx on public.chapters (subject_id, position);

create table public.themes (
  id         text primary key,
  data       jsonb not null,
  created_by uuid references public.profiles (id) on delete set null,
  updated_at timestamptz not null default now()
);

create table public.progress (
  user_id    uuid primary key references public.profiles (id) on delete cascade,
  data       jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now()
);

-- keep updated_at honest, so the app can ask only for what changed since its last visit
create function public.touch_updated_at() returns trigger language plpgsql as $$
begin new.updated_at := now(); return new; end $$;
create trigger subjects_touch before update on public.subjects for each row execute function public.touch_updated_at();
create trigger chapters_touch before update on public.chapters for each row execute function public.touch_updated_at();
create trigger themes_touch   before update on public.themes   for each row execute function public.touch_updated_at();
create trigger progress_touch before update on public.progress for each row execute function public.touch_updated_at();

create function public.claim_old_novels() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  update public.subjects set created_by = new.id where created_by is null and lower(created_by_email) = lower(new.email);
  return new;
end $$;
create trigger profiles_claim_novels after insert on public.profiles
for each row execute function public.claim_old_novels();

alter table public.subjects enable row level security;
alter table public.chapters enable row level security;
alter table public.themes   enable row level security;
alter table public.progress enable row level security;

create policy subjects_read  on public.subjects for select to authenticated using (public.is_member());
create policy subjects_write on public.subjects for all to authenticated
  using (public.is_admin() or (public.can_upload() and created_by = auth.uid()))
  with check (public.is_admin() or (public.can_upload() and created_by = auth.uid()));

create policy chapters_read  on public.chapters for select to authenticated using (public.is_member());
create policy chapters_write on public.chapters for all to authenticated
  using (public.is_admin() or exists (select 1 from public.subjects s where s.id = chapters.subject_id and s.created_by = auth.uid() and public.can_upload()))
  with check (public.is_admin() or exists (select 1 from public.subjects s where s.id = chapters.subject_id and s.created_by = auth.uid() and public.can_upload()));

create policy themes_read  on public.themes for select to authenticated using (public.is_member());
create policy themes_write on public.themes for all to authenticated
  using (public.is_admin() or (public.can_upload() and created_by = auth.uid()))
  with check (public.is_admin() or (public.can_upload() and created_by = auth.uid()));

create policy progress_own on public.progress for all to authenticated
  using (user_id = auth.uid()) with check (user_id = auth.uid());
```

### 9.1b SQL: `005_guards_and_helpers.sql`

The file is the source of truth (it is not pasted here so the two cannot drift). What it does:

| Part | What | Why |
|---|---|---|
| `username_available(name)` | boolean, signed-in only | `checkUsername` without a round trip through a table the person cannot read |
| `invited_users_username_unique` | unique index on `lower(username)` | two invitations cannot share a username. **Not covered:** an invitation whose username a signed-in person already holds still makes that invitee's first sign-in fail; check `username_available` before inserting one (finding L1) |
| JSON guards | `subjects_data_ok`, `chapters_data_ok`, `progress_data_ok` | data must be an object and not huge |
| `theme_data_ok(jsonb)` + `themes_data_ok` | mirrors `check_theme` in `lib/upload_check.ts`: name 1 to 40, fonts, `radius` 4 to 32, `effect` or `effects`, nine `#rrggbb` colours, `forSubject` up to 80, **`button`** (style, shape, press, `depth` 0 to 8, `shine`, `uppercase`, `colors.bg/fg/edge`; unknown keys refused, `_notes` allowed), effect list lengths and piece counts (6 tap recipes and 40 pieces, 4 background recipes and 30 pieces), total size 20 KB | an uploaded theme reaches every reader's phone; the detailed recipe fields stay checked in `lib/recipes.ts` |
| `themes_id_ok` | slug ids; `paper`, `obsidian_gold`, `sugar_bloom` refused | built-in names cannot be reused |
| `deleted_rows` + triggers, `updated_at` indexes | delta sync | see 9.2 |
| `progress_import` + `claim_old_progress` | old progress is staged by email and copied into `progress` at first sign-in, then removed | `progress.user_id` needs a profile, and old users have none yet |
| revokes | `is_member`, `is_admin`, `can_upload`, `can_message`, `mark_read`, `inbox`, `register_push_token` closed to `public` and `anon`, open to `authenticated`; trigger functions closed to everyone | signed-out visitors cannot call them over the API |

`themes_data_ok` is a CHECK on purpose (not a trigger): row-level security is tested first, so a reader who writes a theme still gets the clear row-level security refusal. **Importing old themes:** the import script goes through the same CHECK. Old themes with a bad shape will be refused; list them, fix them, and run again (do not drop the constraint).

Theme data shape the app reads (the `button` block is optional; see RUSE_PLAN B6):

```json
{ "name": "...", "font": "Inter", "heading_font": "Newsreader", "radius": 16, "effect": "none",
  "button": { "style": "raised", "shape": "pill", "press": "wiggle", "depth": 4, "shine": true, "uppercase": false,
              "colors": { "bg": "#ff6fa5", "fg": "#ffffff", "edge": "#c2457a" } },
  "colors": { "bg": "#...", "surface": "#...", "ink": "#...", "muted": "#...", "line": "#...",
              "primary": "#...", "primaryFg": "#...", "accent": "#...", "accentFg": "#..." } }
```

### 9.2 App work

- `getCourseData` becomes three selects (subjects, chapters, themes). Use **delta sync**: remember the newest `updated_at` seen and ask only for rows after it. Deleted rows: `public.deleted_rows(n, table_name, id, deleted_at)` exists (005) and is filled by a trigger on `subjects`, `chapters` and `themes` (cascades included); members may read it, nobody writes it directly. The app asks for `deleted_rows` after the last `n` it saw. Prune rows older than 60 days now and then; a phone that has been away longer does one full id check instead.
- `saveCourseBundle`, `saveChapter`, `saveSubject`, `deleteSubject`, `deleteChapter`, `saveTheme`, `deleteTheme`, `renameCategory`, `saveProgress`, `addBlockAfterComment`: plain upserts and deletes. **The checks the old backend ran inside `clean_chapter`, `validate_block`, `validate_style` and `validate_pages` must still run.** Keep them as pure TypeScript in the app (`lib/upload_check.ts` already does most). The database adds a last guard (005): novels, chapters and progress must be JSON objects under a size cap (100 KB, 1 MB, 100 KB), and themes pass `theme_data_ok()`. Treat anything an author uploads as untrusted: it is shown to every reader.
- Offline: your saved copies keep working because the data shape is unchanged.

### 9.3 Test list

An author edits their own novel: works. An author edits someone else's: refused. A reader inserts a novel: refused. Chapter order survives a round trip. Row counts match the old sheets (see section 11).

---

## 10. Phase 5: files

### 10.1 Soundtracks on an external file host, saved only in app storage (D1)

**Where it lives:** the author uploads the track to any free file host (Google Drive, Dropbox or similar) and pastes the **direct download link** into the novel as `musicUrl`. The app checks the link opens audio before saving it. Google Drive's warning page for big files fails that check, so a Drive link must be one that opens the file directly; a Dropbox link with `dl=1` at the end does. Nothing is stored on Supabase, and no bucket, signing or new server is needed. Only the link is saved in the novel.

**Direct link only:** the app downloads the link itself, so it must point at the audio file. A normal share page (an HTML page with a Download button) would download a web page instead of a track. Before choosing a host, check its current link rules and its terms for this use. I have not checked MediaFire's current rules. The app should also refuse a link whose content type is not audio, and show a readable message instead.

**Saved in app storage only:** the app saves the file with `expo-file-system` into its own document folder (`Paths.document`, already used in `lib/downloads.ts`). It never goes into Downloads, the gallery or shared storage. The phone's index (link to file) already records it, and playback uses the local copy when there is one.

**Save for offline:** each novel's music bar gets a "Save for offline" button that uses the existing `download_one`. It shows the size first and progress while it saves.

**Clear button:** Settings gets a "Clear saved downloads" button. It asks first, deletes every saved file and empties the index, and shows how much space the saved files use. Sign-out already calls `delete_all_downloads()`. After clearing, playback falls back to the link.

**Privacy of the app folder:** on a normal phone the app folder is private to the app. Turn off cloud backup of app data (`android.allowBackup` set to false in `app.json`) before launch, so saved tracks are not copied into a backup. Only publish tracks the author has the right to share.

**App work:** a "Track link" field on the author's novel screen (replacing the Drive upload for soundtracks), the Save for offline button, the Clear button, and the content-type check. No server work. The Drive `uploadPart` action is removed when Apps Script is retired.

**Migration `005_storage.sql`:** not needed. Remove it from the plan. Nothing new in SQL for soundtracks.

### 10.1-old Soundtracks on Supabase Storage (superseded, do not run)

```sql
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('soundtracks', 'soundtracks', true, 31457280, array['audio/mpeg', 'audio/mp4', 'audio/x-m4a', 'audio/wav', 'audio/ogg'])
on conflict (id) do nothing;

-- Path rule: <subject id>/<file name>. Only that novel's uploader (or an admin) may write there. Anyone may play.
create policy soundtracks_write on storage.objects for insert to authenticated with check (
  bucket_id = 'soundtracks' and (
    public.is_admin() or exists (select 1 from public.subjects s
      where s.id = (storage.foldername(name))[1] and s.created_by = auth.uid() and public.can_upload()))
);
create policy soundtracks_replace on storage.objects for update to authenticated using (
  bucket_id = 'soundtracks' and (
    public.is_admin() or exists (select 1 from public.subjects s
      where s.id = (storage.foldername(name))[1] and s.created_by = auth.uid()))
);
create policy soundtracks_remove on storage.objects for delete to authenticated using (
  bucket_id = 'soundtracks' and (
    public.is_admin() or exists (select 1 from public.subjects s
      where s.id = (storage.foldername(name))[1] and s.created_by = auth.uid()))
);
```

Make the bucket public for **reading** only if you accept that anyone with a link can play a track (the same as Drive "anyone with the link" today). Otherwise keep it private and use signed URLs.

App: replace `lib/soundtrack.ts` upload with a Storage upload, then save the public URL into the novel's `data.musicUrl` as today. For files above a few MB, use Supabase's **resumable (TUS) upload**, which fits the "small pieces, retry only the failed piece" behaviour already in `lib/upload_parts.ts`. (Check the current docs for the size at which they recommend TUS.)

### 10.2 Photos and manga pages stay on Drive

The app sends the **Supabase token** instead of the Google token. Change in Apps Script: `require_user` and `require_role` ask Supabase (section 3) instead of reading the `Users` sheet. `can_manage` asks Supabase for the novel's `created_by`. Drive folder creation for a new novel stays; the new novel's row in `subjects` stores the folder id inside `data`.

### 10.3 Test list

Author pastes a direct track link: it plays, and seeking works. A share-page link (not the file itself): refused with a readable message, not a silent failure. Save for offline: the file appears in the app's storage and does not appear in Downloads or the gallery. Airplane mode: the saved track plays. Clear saved downloads: files are gone, the index is empty, and playback uses the link again. Sign out: saved tracks are removed. A page upload to Drive works with the Supabase token and fails with an expired or fake token.

---

## 11. Importing the old data (Phase 4 and 6)

1. `scripts/export_sheets.gs` (in Apps Script): writes one JSON file per sheet into Drive `Backups`, with row counts in the file name.
2. `scripts/import_from_export.mjs` (Node, in the Codespace): reads those files and upserts in batches of 500 with the **service role key from an environment variable**. Never commit that key.
3. Import order: `invited_users`, `subjects`, `chapters`, `themes`, `comments` (with `author_email`), then `progress` for people who already have a profile; for everyone else write the old progress into `progress_import` (by email) and `claim_old_progress` (005) copies it in at their first sign-in, in its own trigger on `profiles`, not inside `handle_new_user`.
4. Checks after every import (stop and fix if any fails):

| Check | How |
|---|---|
| Row counts match | count in the sheet export = count in the table, per table |
| No duplicate keys | `select id, count(*) from <table> group by id having count(*) > 1` returns nothing |
| No missing owners | subjects with null `created_by_email` listed for you to decide |
| JSON is valid | the table checks in 005 refuse bad rows, so a failed import shows the id; also `select count(*) from chapters where jsonb_typeof(data) <> 'object'` is 0 |
| Themes pass | the import reports every theme refused by `themes_data_ok`; fix them, do not drop the check |
| Dates parse | no null `created_at` in comments |
| No emails in shared data | `select id from subjects where data::text ~* '[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}'` must return nothing (strip `uploadedBy` and similar before import); for `chapters` look at each hit by hand, novel text may contain one on purpose (finding H1) |
| Spot check | open 3 novels, 3 chapters and 3 comment threads in the app and compare with the old version |

---

## 12. Phase 6: cutover and cleanup

1. Tell readers a short maintenance time. Freeze writes in the old backend (return "updating" for write actions).
2. Run the export and import one last time (it is safe to run again: it upserts).
3. Run the checks in section 11.
4. Flip every remaining action to Supabase in `backend.ts`, build the app, test on two phones.
5. Keep the Sheets read-only for 30 days, then archive them.
6. Remove the dead Apps Script files (everything except the file service), mark this plan done, delete the old action constants.

Rollback until step 5 is finished: set the action list in `backend.ts` back to Apps Script.

---

## 13. Action by action: where each one goes

| Phase | Old Apps Script action | New home |
|---|---|---|
| 1 | getMe, getProfile | `profiles` select |
| 1 | saveProfile, saveUsername, setMessaging | `profiles` update (guarded by trigger) |
| 1 | checkUsername | `username_available()` function (005) |
| 1 | requestAccess | automatic on first sign-in |
| 1 | requestRole | `profiles.role_request = 'author'` |
| 1 | getAdminData, approveRequest, rejectRequest | `profiles` queries and updates (admin policy) |
| 1 | addUser, setRole, setAdmin, removeUser | `invited_users` insert, `profiles` update |
| 2 | getThreads | `inbox()` |
| 2 | getMessages, sendMessage, deleteMessage | `messages` select, insert, delete |
| 2 | markRead | `mark_read()` |
| 2 | blockUser, unblockUser, getBlocked | `blocks` |
| 2 | reportUser, getReports, resolveReport | `reports` |
| 2 | registerPushToken, unregisterPushToken, testPush | `register_push_token()`, `push_tokens`, Edge Function |
| 2b | getFriends, findPeople | `friends()`, `find_people(q)` (new, Supabase only) |
| 2b | sendFriendRequest, respondFriendRequest, removeFriend | `send_friend_request()`, `respond_friend_request()`, `remove_friend()` (new) |
| 2b | getGroups, getGroupMembers | `my_groups()`, `group_members_list()` (new) |
| 2b | createGroup, addGroupMember, removeGroupMember, leaveGroup, renameGroup, deleteGroup, markGroupRead | the functions of the same name in 007 (new) |
| 2b | getGroupMessages, sendGroupMessage, deleteGroupMessage | `group_messages` select, insert, delete (new) |
| 3 | getComments, saveComment, replyComment, deleteComment | `comments` |
| 3 | getPins, savePin, deletePin | `pins` |
| 4 | getCourseData | `subjects`, `chapters`, `themes` with delta sync |
| 4 | saveCourseBundle, saveSubject, saveChapter, deleteSubject, deleteChapter | upserts and deletes |
| 4 | addBlockAfterComment, renameCategory | chapter / subject updates |
| 4 | saveTheme, deleteTheme | `themes` (checked by `theme_data_ok`, includes `button`) |
| 4 | saveProgress | `progress` upsert |
| 5 | uploadPart (soundtracks) | file host link in `musicUrl`; app saves it to app storage |
| 5 | uploadAsset, saveAvatar | **stay** in the Apps Script file service |
| 5 | createNovelFolder (new action) | **new**, also in the file service: makes the novel's Drive folder and returns `{folderId}`; the app saves it into `subjects.data.folderId` (needs the unique index in Appendix B) |

### The "move one action at a time" switch

In `lib/backend.ts`:

```ts
import { gas_call } from './api';          // today's api(), renamed
import { sb_handlers } from './sb';        // one file per moved action

const MOVED = new Set<string>([/* add an action name here when its Supabase version passes its tests */]);

export async function api<T>(action: string, ...args: unknown[]): Promise<T> {
  return MOVED.has(action) ? sb_handlers[action](...args) as Promise<T> : gas_call<T>(action, ...args);
}
```

Nothing else in the app changes, and rolling back one action is deleting one word.

---

## 14. Security checklist (before real users move)

- Row Level Security is **on** for every table in `public`, and each table has the policies above. The dashboard's Security Advisor shows none missing. Expect **one deliberate warning**: `public_profiles` is a view that runs with its owner's rights (that is how readers see usernames without seeing emails). Accept it knowingly; do not "fix" it by making the view run as the reader, or readers can no longer see anyone but themselves.
- The service role key exists only in Codespace secrets and Edge Function secrets. Search the app and `.env` for it before every build.
- `public_profiles` is the only way readers see other people; it never contains emails.
- Uploaded novels and chapters are untrusted input (validated in the app and shown only through the existing safe renderer).
- Edge Function webhook secret is set and checked.
- Chat tables hold **ciphertext only** and only until delivery (7c). Check once after Phase J: `select count(*) from messages` stays near zero when both phones are online, and no Drive or Storage file is older than a day.
- The chat private key is in the phone's secure storage and in the person's own Google Drive backup, never on your server.
- Soundtrack links are only saved in the novel. The app saves files only in its own storage, and cloud backup of app data is off.
- Functions that only signed-in people may call have `revoke execute ... from public, anon` (done in 005; tests G37 to G40).
- A test with two ordinary accounts proves: no one reads another person's messages, no one edits another person's profile or comment, no reader writes a novel.

---

## 15. Costs, limits and things to check (numbers may have changed: verify on supabase.com/pricing)

Roughly, the free plan has: about 500 MB of database, about 1 GB of file storage, tens of thousands of monthly users, a couple of hundred simultaneous Realtime connections, and Edge Function calls in the hundreds of thousands per month. Things I believe are true but you must confirm:

- **Free projects can pause after about a week without activity.** A paused app looks broken. Either keep it used, or move to the paid plan before real readers arrive.
- Free projects may not include downloadable daily backups. Run `npx supabase db dump` monthly from the Codespace and keep the file in the Drive `Backups` folder.
- Soundtracks are pasted links now (10.1), so the Storage upload size no longer matters. The file service's own limit is 5 MB per picture.

---

## 16. Risks and what I would not do

| Risk | What to do |
|---|---|
| A mistake in a policy exposes data | Test with two accounts in every phase before moving on; never skip the Security Advisor |
| Old users must sign in again | They do not need approval (the invitation table carries their role), but they do need one sign-in after the update |
| Both backends disagree during the move | Each action lives in exactly one place at a time (the `MOVED` set); never write the same data to both |
| Big chapters make `getCourseData` slow | Delta sync, and fetch chapter `data` only when a chapter is opened (list with titles first) |
| Free tier pause | See section 15 |

Do **not**: put the service role key in the app; copy the whole sheet into Postgres in one blind import; turn off RLS "just to test"; move chat and catalog in the same release.

---

## 17. Suggested order and size

| Phase | Work | Rough size |
|---|---|---|
| 0 | Project, Google provider, backup | an evening |
| 1 | Sign-in, profiles, roles, admin screens | 2 to 3 days |
| 2 | Chat with Realtime, push | 2 to 3 days |
| 3 | Comments and pins | 1 to 2 days |
| 4 | Catalog, delta sync, import | 3 to 4 days |
| 5 | Soundtrack link and saved downloads in the app (no Storage), file service token check | 1 to 2 days |
| 6 | Cutover and cleanup | 1 day |

I suggest starting with Phases 0 to 2: that already fixes the awkward chat, and everything after it can wait without hurting anything.


---

# Appendix A: `lib/file_service.ts` (not wired yet)

Needs `lib/supabase.ts` (Part 2, section 6.3) first. Then route the three file actions here from `lib/backend.ts`:
`const FILE_ACTIONS = new Set(['uploadAsset', 'saveAvatar', 'createNovelFolder']); if (FILE_ACTIONS.has(action)) return file_call<T>(action, ...args);`
The old backend and the file service are two different web apps, so the caller must use its own address. Add to `lib/config.ts`: `export const FILE_API_URL = process.env.EXPO_PUBLIC_FILE_URL as string;` and to `app/.env`: `EXPO_PUBLIC_FILE_URL=<the file service web app URL>`. `API_URL` stays on the old backend until cutover, then it can be removed.

```ts
// Calls the Apps Script FILE SERVICE with the Supabase access token (Part 2 section 3).
// NOT WIRED YET: needs lib/supabase.ts (Phase 0/1) to exist and export `supabase`.
// When it does, route the three file actions here from lib/backend.ts instead of gas_call:
//   const FILE_ACTIONS = new Set(['uploadAsset', 'saveAvatar', 'createNovelFolder']);
//   if (FILE_ACTIONS.has(action)) return file_call<T>(action, ...args);
import { FILE_API_URL } from './config';
import { supabase } from './supabase';
import { make_error } from './net_retry';

const TIMEOUT_MS = 45000; // uploads: one try, never retried (same rule as gas_call writes)

export async function file_call<T>(action: string, ...args: unknown[]): Promise<T> {
  const { data } = await supabase.auth.getSession(); // supabase-js refreshes an expired token itself
  const token = data.session?.access_token;
  if (!token) throw make_error('Please sign in again.', 'backend');

  const stop = new AbortController();
  const timer = setTimeout(() => stop.abort(), TIMEOUT_MS);
  let text = '';
  try {
    const res = await fetch(FILE_API_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'text/plain;charset=utf-8' }, // keeps Apps Script from needing a CORS preflight
      body: JSON.stringify({ action, args, token }),
      signal: stop.signal,
    });
    text = await res.text();
  } catch {
    throw make_error(
      (stop.signal.aborted ? 'The server took too long to answer.' : 'No connection to the server.') +
        ' It may or may not have saved, so check before trying again.',
      'network',
    );
  } finally {
    clearTimeout(timer);
  }

  let json: any;
  try { json = JSON.parse(text); } catch { throw make_error('The server sent something unexpected.', 'network'); }
  if (!json.ok) throw make_error(json.error || 'Something went wrong.', 'backend');
  return json.data as T;
}
```


---

# Appendix B: migration 006 (proposed, UNTESTED)

From the second-pass review. **No Postgres was available, so none of this has run.** Run it only on the throwaway database first, after G01 to G40 pass, then add one test per item (G41 and up). Items match the finding ids. Check the decision numbers before running: item 2 assumes decision 1(a), item 3 assumes decision 3, item 5 assumes decision 2. Save it as `supabase/migrations/006_review_fixes.sql`. Run it on a project that already has 005; every `create or replace` keeps the grants from 005.

```sql
-- 006: fixes from the 7 Nov review. UNTESTED.

-- H5 · never remove, demote or switch off the last active admin ---------------------------
create function public.keep_one_admin() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if auth.uid() is null then                              -- SQL Editor, import script: always free
    if tg_op = 'DELETE' then return old; end if;
    return new;
  end if;
  if old.role = 'admin' and old.allowed then
    if tg_op = 'UPDATE' and new.role = 'admin' and new.allowed then return new; end if;
    perform pg_advisory_xact_lock(7001);                  -- two admins cannot remove each other at the same moment
    if not exists (select 1 from public.profiles p where p.id <> old.id and p.role = 'admin' and p.allowed) then
      raise exception 'There must always be one active admin.';
    end if;
  end if;
  if tg_op = 'DELETE' then return old; end if;
  return new;
end $$;
create trigger keep_one_admin_update before update on public.profiles for each row execute function public.keep_one_admin();
create trigger keep_one_admin_delete before delete on public.profiles for each row execute function public.keep_one_admin();
revoke execute on function public.keep_one_admin() from public, anon, authenticated;

-- H2 · an admin-only "no messages" flag that also stops SENDING ------------------------------
alter table public.profiles add column messaging_banned boolean not null default false;

create or replace function public.profiles_guard() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if auth.uid() is null then return new; end if;          -- SQL editor, import script, Edge Functions
  if not public.is_admin() then
    if new.role is distinct from old.role or new.allowed is distinct from old.allowed
       or new.email is distinct from old.email or new.added_at is distinct from old.added_at
       or new.request_status is distinct from old.request_status
       or new.messaging_banned is distinct from old.messaging_banned then
      raise exception 'You cannot change that.';
    end if;
  end if;
  if new.username is distinct from old.username then
    if old.username is not null and old.username_changed_at > now() - interval '30 days' then
      raise exception 'You can change your username once every 30 days.';
    end if;
    new.username_changed_at := now();
  end if;
  return new;
end $$;

create or replace function public.can_message(sender uuid, recipient uuid) returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.profiles r where r.id = recipient and r.allowed and not r.messaging_off)
     and exists (select 1 from public.profiles s where s.id = sender and s.allowed and not s.messaging_banned)
     and not exists (select 1 from public.blocks b
                     where (b.blocker_id = recipient and b.blocked_id = sender)
                        or (b.blocker_id = sender    and b.blocked_id = recipient))
$$;
-- App: the admin "Messages off" button writes messaging_banned; a person's own "do not disturb" stays messaging_off.

-- H3 · one Drive folder id belongs to one novel only ---------------------------------------
create unique index subjects_folder_id_unique on public.subjects ((data ->> 'folderId'))
  where coalesce(data ->> 'folderId', '') <> '';

-- H4 · waiting accounts may not write progress ---------------------------------------------
drop policy progress_own on public.progress;
create policy progress_own on public.progress for all to authenticated
  using (user_id = auth.uid() and public.is_member())
  with check (user_id = auth.uid() and public.is_member());

-- H6 · a theme "for a novel" only for your own novel (admins: any) ---------------------------
create function public.themes_for_subject_guard() returns trigger
language plpgsql security definer set search_path = public as $$
declare
  fs    text := new.data ->> 'forSubject';
  owner uuid;
begin
  if auth.uid() is null or coalesce(fs, '') = '' or public.is_admin() then return new; end if;
  select created_by into owner from public.subjects where id = fs;
  if owner is distinct from auth.uid() then
    raise exception 'You can only add a theme for your own novel.';
  end if;
  return new;
end $$;
create trigger themes_for_subject_before_write before insert or update on public.themes
for each row execute function public.themes_for_subject_guard();
revoke execute on function public.themes_for_subject_guard() from public, anon, authenticated;

-- M1 · avatar links only from Google image / Drive hosts (decision 3: check the old link format first) ----
alter table public.profiles      add constraint profiles_avatar_url_ok
  check (avatar_url is null or avatar_url ~ '^https://(lh3\.googleusercontent\.com|drive\.google\.com)/');
alter table public.invited_users add constraint invited_avatar_url_ok
  check (avatar_url is null or avatar_url ~ '^https://(lh3\.googleusercontent\.com|drive\.google\.com)/');

-- M2 · carried-over users keep their real "joined" date --------------------------------------
alter table public.invited_users add column added_at timestamptz;

create or replace function public.handle_new_user() returns trigger
language plpgsql security definer set search_path = public as $$
declare invite public.invited_users%rowtype;
begin
  select * into invite from public.invited_users where lower(email) = lower(new.email);
  insert into public.profiles (id, email, display_name, role, allowed, username, username_changed_at, gender, avatar_url, messaging_off, added_at)
  values (
    new.id, lower(new.email), coalesce(new.raw_user_meta_data ->> 'full_name', ''),
    coalesce(invite.role, 'reader'), invite.email is not null,
    invite.username, invite.username_changed_at, invite.gender, invite.avatar_url, coalesce(invite.messaging_off, false),
    coalesce(invite.added_at, now())
  );
  return new;
end $$;

-- H1 · old emails: clear them once the person has claimed the row, and hide them from members ----------
create or replace function public.claim_old_comments() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  update public.comments set author_id = new.id, author_email = null
  where author_id is null and lower(author_email) = lower(new.email);
  return new;
end $$;

create or replace function public.claim_old_novels() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  update public.subjects set created_by = new.id, created_by_email = null
  where created_by is null and lower(created_by_email) = lower(new.email);
  return new;
end $$;

-- Column permissions (decision 2). After this the app must list column names, never select('*'), on these two tables.
revoke select on public.comments from authenticated, anon;
grant  select (id, chapter_id, block, parent_id, author_id, body, created_at, edited_at) on public.comments to authenticated;
revoke select on public.subjects from authenticated, anon;
grant  select (id, position, data, created_by, updated_at) on public.subjects to authenticated;
-- Any column added to these tables later needs its own grant select (...) in the same migration.
```

**Tests to add (G41 and up):**
- The only admin cannot demote, switch off or delete themselves (refused); with two admins, one can demote the other; the SQL Editor can still do any of it.
- Person A, banned by an admin, cannot send; a normal person cannot change `messaging_banned` on themselves; the admin can.
- Author A saves a novel with the folder id of author B's novel: refused by the unique index.
- A waiting account (`allowed = false`) inserting into `progress`: refused.
- Author A saves a theme with `forSubject` = a novel of B: refused; with their own novel: works; admin: works.
- `avatar_url` of `https://example.com/x.png`: refused; a `lh3.googleusercontent.com/d/...` link: accepted.
- A carried-over user's first sign-in: `added_at` equals the invitation's date; their old comments get `author_id` and `author_email` is null afterwards.
- A member running `select author_email from comments` and `select created_by_email from subjects`: permission denied.


---

# Appendix C: migration 007, friends and group chat (proposed, UNTESTED)

No Postgres was available, so none of this has run. Run it on the throwaway database after 001 to 006 and G01 to G40 pass, add the tests of section 7b, then on the real project. **Needs 006** (`profiles.messaging_banned`). Save as `supabase/migrations/007_friends_and_groups.sql`. All writes go through the functions (there are no insert, update or delete policies on friendships, group_members or chat_groups), so a rule cannot be skipped by calling the table directly.

```sql
-- 007: friends and group chat. UNTESTED. Needs 001 to 006.

-- ============================== friends ==============================
create table public.friendships (
  requester_id uuid not null references public.profiles (id) on delete cascade,
  addressee_id uuid not null references public.profiles (id) on delete cascade,
  status       text not null default 'pending' check (status in ('pending', 'accepted')),
  created_at   timestamptz not null default now(),
  responded_at timestamptz,
  primary key (requester_id, addressee_id),
  constraint friendships_not_self check (requester_id <> addressee_id)
);
-- one row per pair, whichever way round
create unique index friendships_pair_unique on public.friendships (least(requester_id, addressee_id), greatest(requester_id, addressee_id));
create index friendships_addressee_idx on public.friendships (addressee_id, status);
alter table public.friendships enable row level security;
create policy friendships_read on public.friendships for select to authenticated
  using (public.is_member() and auth.uid() in (requester_id, addressee_id));

-- internal helpers (not callable over the API: they would reveal other people's friends and blocks)
create function public.are_friends(a uuid, b uuid) returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.friendships f
                 where f.status = 'accepted'
                   and ((f.requester_id = a and f.addressee_id = b) or (f.requester_id = b and f.addressee_id = a)))
$$;

create function public.blocked_between(a uuid, b uuid) returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.blocks k
                 where (k.blocker_id = a and k.blocked_id = b) or (k.blocker_id = b and k.blocked_id = a))
$$;

create function public.send_friend_request(other uuid) returns text
language plpgsql security definer set search_path = public as $$
declare
  me       uuid := auth.uid();
  existing public.friendships%rowtype;
begin
  if not public.is_member() then raise exception 'Your account is not approved yet.'; end if;
  if other is null or other = me then raise exception 'Pick another person.'; end if;
  if not exists (select 1 from public.profiles p where p.id = other and p.allowed)
     or public.blocked_between(me, other) then
    raise exception 'You cannot send a friend request to this person.';
  end if;
  if (select count(*) from public.friendships where requester_id = me and created_at > now() - interval '1 hour') >= 20 then
    raise exception 'You sent too many friend requests. Try again later.';
  end if;

  select * into existing from public.friendships f
   where (f.requester_id = me and f.addressee_id = other) or (f.requester_id = other and f.addressee_id = me);
  if found then
    if existing.status = 'accepted' then return 'accepted'; end if;
    if existing.requester_id = me then return 'sent'; end if;          -- already waiting for them
    update public.friendships set status = 'accepted', responded_at = now()   -- they asked me first: it is mutual
     where requester_id = other and addressee_id = me;
    return 'accepted';
  end if;
  insert into public.friendships (requester_id, addressee_id) values (me, other);
  return 'sent';
end $$;

create function public.respond_friend_request(other uuid, accept boolean) returns void
language plpgsql security definer set search_path = public as $$
begin
  if not public.is_member() then raise exception 'Your account is not approved yet.'; end if;
  if accept then
    update public.friendships set status = 'accepted', responded_at = now()
     where requester_id = other and addressee_id = auth.uid() and status = 'pending';
  else
    delete from public.friendships
     where requester_id = other and addressee_id = auth.uid() and status = 'pending';
  end if;
end $$;

-- cancel a request I sent, or unfriend
create function public.remove_friend(other uuid) returns void
language sql security definer set search_path = public as $$
  delete from public.friendships f
   where (f.requester_id = auth.uid() and f.addressee_id = other)
      or (f.requester_id = other and f.addressee_id = auth.uid())
$$;

create function public.friends()
returns table (other_id uuid, username text, avatar_url text, state text, since timestamptz)
language sql stable security definer set search_path = public as $$
  with mine as (
    select case when f.requester_id = auth.uid() then f.addressee_id else f.requester_id end as other_id,
           case when f.status = 'accepted' then 'friend'
                when f.addressee_id = auth.uid() then 'incoming' else 'outgoing' end as state,
           coalesce(f.responded_at, f.created_at) as since
    from public.friendships f
    where auth.uid() in (f.requester_id, f.addressee_id)
  )
  select m.other_id, p.username, p.avatar_url, m.state, m.since
  from mine m
  join public.profiles p on p.id = m.other_id
  where public.is_member() and p.allowed
    and not exists (select 1 from public.blocks b where b.blocker_id = auth.uid() and b.blocked_id = m.other_id)
  order by (m.state = 'incoming') desc, lower(p.username), m.since desc
$$;

-- search by username PREFIX, 3 letters or more, 10 results, never yourself or anyone blocked either way
create function public.find_people(q text)
returns table (id uuid, username text, avatar_url text, relation text)
language sql stable security definer set search_path = public as $$
  select p.id, p.username, p.avatar_url,
         coalesce((select case when f.status = 'accepted' then 'friend'
                               when f.addressee_id = auth.uid() then 'incoming' else 'outgoing' end
                   from public.friendships f
                   where (f.requester_id = auth.uid() and f.addressee_id = p.id)
                      or (f.requester_id = p.id and f.addressee_id = auth.uid())), 'none')
  from public.profiles p
  where public.is_member()
    and char_length(btrim(coalesce(q, ''))) >= 3
    and p.allowed and p.username is not null and p.id <> auth.uid()
    and starts_with(lower(p.username), lower(btrim(q)))
    and not public.blocked_between(auth.uid(), p.id)
  order by lower(p.username)
  limit 10
$$;

-- blocking someone ends the friendship (and a pending request)
create function public.blocks_remove_friendship() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  delete from public.friendships f
   where (f.requester_id = new.blocker_id and f.addressee_id = new.blocked_id)
      or (f.requester_id = new.blocked_id and f.addressee_id = new.blocker_id);
  return new;
end $$;
create trigger blocks_remove_friendship_after_insert after insert on public.blocks
for each row execute function public.blocks_remove_friendship();

-- ============================== groups ==============================
create table public.chat_groups (
  id         uuid primary key default gen_random_uuid(),
  name       text not null check (char_length(btrim(name)) between 1 and 40),
  created_by uuid references public.profiles (id) on delete set null,
  created_at timestamptz not null default now()
);

create table public.group_members (
  group_id     uuid not null references public.chat_groups (id) on delete cascade,
  user_id      uuid not null references public.profiles (id) on delete cascade,
  role         text not null default 'member' check (role in ('owner', 'member')),
  joined_at    timestamptz not null default now(),
  last_read_at timestamptz not null default now(),
  primary key (group_id, user_id)
);
create index group_members_user_idx on public.group_members (user_id);
create unique index group_one_owner on public.group_members (group_id) where role = 'owner';

create table public.group_messages (
  id         uuid primary key default gen_random_uuid(),
  group_id   uuid not null references public.chat_groups (id) on delete cascade,
  sender_id  uuid references public.profiles (id) on delete set null,   -- kept (as "Former member") if the person is deleted
  body       text not null check (char_length(btrim(body)) between 1 and 500),
  created_at timestamptz not null default now()
);
create index group_messages_idx on public.group_messages (group_id, created_at desc);

-- who is asking? (used by the policies, so they are callable by signed-in people)
create function public.is_group_member(gid uuid) returns boolean
language sql stable security definer set search_path = public as $$
  select public.is_member()
     and exists (select 1 from public.group_members m where m.group_id = gid and m.user_id = auth.uid())
$$;

create function public.is_group_owner(gid uuid) returns boolean
language sql stable security definer set search_path = public as $$
  select public.is_member()
     and exists (select 1 from public.group_members m where m.group_id = gid and m.user_id = auth.uid() and m.role = 'owner')
$$;

-- may I post? member of the group, approved, and not switched off by an admin (needs 006)
create function public.can_post_group(gid uuid) returns boolean
language sql stable security definer set search_path = public as $$
  select public.is_group_member(gid)
     and exists (select 1 from public.profiles s where s.id = auth.uid() and s.allowed and not s.messaging_banned)
$$;

-- same hourly limits as direct messages; direct and group messages count together
create function public.group_messages_rate_limit() returns trigger
language plpgsql security definer set search_path = public as $$
declare
  is_new boolean;
  sent   int;
begin
  select added_at > now() - interval '7 days' into is_new from public.profiles where id = new.sender_id;
  select (select count(*) from public.messages       where sender_id = new.sender_id and created_at > now() - interval '1 hour')
       + (select count(*) from public.group_messages where sender_id = new.sender_id and created_at > now() - interval '1 hour')
    into sent;
  if sent >= (case when is_new then 5 else 40 end) then
    raise exception 'You have sent too many messages. Try again later.';
  end if;
  return new;
end $$;
create trigger group_messages_rate_limit_before_insert before insert on public.group_messages
for each row execute function public.group_messages_rate_limit();

alter table public.chat_groups    enable row level security;
alter table public.group_members  enable row level security;
alter table public.group_messages enable row level security;

create policy groups_read        on public.chat_groups   for select to authenticated using (public.is_group_member(id));
create policy group_members_read on public.group_members for select to authenticated using (public.is_group_member(group_id));
create policy group_messages_read on public.group_messages for select to authenticated using (
  public.is_group_member(group_id)
  and not exists (select 1 from public.blocks b where b.blocker_id = auth.uid() and b.blocked_id = group_messages.sender_id)
);
create policy group_messages_send on public.group_messages for insert to authenticated
  with check (sender_id = auth.uid() and public.can_post_group(group_id));
create policy group_messages_delete on public.group_messages for delete to authenticated
  using (sender_id = auth.uid() or public.is_group_owner(group_id) or public.is_admin());
-- No update policy: nobody edits a message. No policies at all for writing chat_groups / group_members: use the functions below.

create function public.create_group(group_name text, member_ids uuid[]) returns uuid
language plpgsql security definer set search_path = public as $$
declare
  me  uuid := auth.uid();
  gid uuid;
  m   uuid;
begin
  if not public.is_member() then raise exception 'Your account is not approved yet.'; end if;
  if char_length(btrim(coalesce(group_name, ''))) not between 1 and 40 then
    raise exception 'Give the group a name of 1 to 40 characters.';
  end if;
  if (select count(*) from public.group_members where user_id = me and role = 'owner') >= 10 then
    raise exception 'You already own 10 groups.';
  end if;
  if coalesce(array_length(member_ids, 1), 0) > 29 then raise exception 'A group can have 30 people at most.'; end if;

  insert into public.chat_groups (name, created_by) values (btrim(group_name), me) returning id into gid;
  insert into public.group_members (group_id, user_id, role) values (gid, me, 'owner');
  foreach m in array coalesce(member_ids, array[]::uuid[]) loop
    continue when m = me;
    if not public.are_friends(me, m) or public.blocked_between(me, m) then
      raise exception 'You can only add your friends.';
    end if;
    insert into public.group_members (group_id, user_id) values (gid, m) on conflict do nothing;
  end loop;
  return gid;
end $$;

create function public.add_group_member(gid uuid, other uuid) returns void
language plpgsql security definer set search_path = public as $$
begin
  if not public.is_group_owner(gid) then raise exception 'Only the group owner can add people.'; end if;
  if not public.are_friends(auth.uid(), other) or public.blocked_between(auth.uid(), other) then
    raise exception 'You can only add your friends.';
  end if;
  if (select count(*) from public.group_members where group_id = gid) >= 30 then
    raise exception 'This group is full (30 people).';
  end if;
  insert into public.group_members (group_id, user_id) values (gid, other) on conflict do nothing;
end $$;

create function public.remove_group_member(gid uuid, other uuid) returns void
language plpgsql security definer set search_path = public as $$
begin
  if other = auth.uid() then raise exception 'Use Leave group to leave.'; end if;
  if not public.is_group_owner(gid) then raise exception 'Only the group owner can remove people.'; end if;
  delete from public.group_members where group_id = gid and user_id = other and role <> 'owner';
end $$;

-- leave; if the owner leaves the longest-standing member takes over, and the last person out deletes the group
create function public.leave_group(gid uuid) returns void
language plpgsql security definer set search_path = public as $$
declare
  me         uuid := auth.uid();
  was_owner  boolean;
  next_owner uuid;
begin
  select (role = 'owner') into was_owner from public.group_members where group_id = gid and user_id = me;
  if was_owner is null then return; end if;
  delete from public.group_members where group_id = gid and user_id = me;
  if was_owner then
    select user_id into next_owner from public.group_members where group_id = gid order by joined_at, user_id limit 1;
    if next_owner is null then
      delete from public.chat_groups where id = gid;
    else
      update public.group_members set role = 'owner' where group_id = gid and user_id = next_owner;
    end if;
  end if;
end $$;

create function public.rename_group(gid uuid, new_name text) returns void
language plpgsql security definer set search_path = public as $$
begin
  if not public.is_group_owner(gid) then raise exception 'Only the group owner can rename it.'; end if;
  if char_length(btrim(coalesce(new_name, ''))) not between 1 and 40 then
    raise exception 'Give the group a name of 1 to 40 characters.';
  end if;
  update public.chat_groups set name = btrim(new_name) where id = gid;
end $$;

create function public.delete_group(gid uuid) returns void
language plpgsql security definer set search_path = public as $$
begin
  if not public.is_group_owner(gid) then raise exception 'Only the group owner can delete it.'; end if;
  delete from public.chat_groups where id = gid;
end $$;

create function public.mark_group_read(gid uuid) returns void
language sql security definer set search_path = public as $$
  update public.group_members set last_read_at = now() where group_id = gid and user_id = auth.uid()
$$;

create function public.group_members_list(gid uuid)
returns table (user_id uuid, username text, avatar_url text, role text, joined_at timestamptz)
language sql stable security definer set search_path = public as $$
  select m.user_id, p.username, p.avatar_url, m.role, m.joined_at
  from public.group_members m
  join public.profiles p on p.id = m.user_id
  where public.is_group_member(gid) and m.group_id = gid
  order by (m.role = 'owner') desc, m.joined_at
$$;

-- the Groups list: newest activity first, last line and unread count (messages from people I blocked are left out)
create function public.my_groups()
returns table (group_id uuid, name text, member_count bigint, my_role text,
               last_body text, last_sender text, last_at timestamptz, unread bigint)
language sql stable security definer set search_path = public as $$
  select g.id, g.name,
         (select count(*) from public.group_members x where x.group_id = g.id),
         m.role,
         lm.body,
         (select p.username from public.profiles p where p.id = lm.sender_id),
         coalesce(lm.created_at, g.created_at),
         (select count(*) from public.group_messages x
           where x.group_id = g.id and x.created_at > m.last_read_at and x.sender_id is distinct from auth.uid()
             and not exists (select 1 from public.blocks b where b.blocker_id = auth.uid() and b.blocked_id = x.sender_id))
  from public.group_members m
  join public.chat_groups g on g.id = m.group_id
  left join lateral (
    select y.body, y.created_at, y.sender_id from public.group_messages y
    where y.group_id = g.id
      and not exists (select 1 from public.blocks b where b.blocker_id = auth.uid() and b.blocked_id = y.sender_id)
    order by y.created_at desc limit 1
  ) lm on true
  where m.user_id = auth.uid() and public.is_member()
  order by coalesce(lm.created_at, g.created_at) desc
$$;

alter publication supabase_realtime add table public.group_messages;

-- ============================== who may call what ==============================
-- Same rule as 005: closed to the signed-out role. The two helpers are internal only (not even signed-in people).
revoke execute on function public.are_friends(uuid, uuid), public.blocked_between(uuid, uuid)
  from public, anon, authenticated;

revoke execute on function
  public.send_friend_request(uuid), public.respond_friend_request(uuid, boolean), public.remove_friend(uuid),
  public.friends(), public.find_people(text),
  public.is_group_member(uuid), public.is_group_owner(uuid), public.can_post_group(uuid),
  public.create_group(text, uuid[]), public.add_group_member(uuid, uuid), public.remove_group_member(uuid, uuid),
  public.leave_group(uuid), public.rename_group(uuid, text), public.delete_group(uuid), public.mark_group_read(uuid),
  public.group_members_list(uuid), public.my_groups()
  from public, anon;
grant execute on function
  public.send_friend_request(uuid), public.respond_friend_request(uuid, boolean), public.remove_friend(uuid),
  public.friends(), public.find_people(text),
  public.is_group_member(uuid), public.is_group_owner(uuid), public.can_post_group(uuid),
  public.create_group(text, uuid[]), public.add_group_member(uuid, uuid), public.remove_group_member(uuid, uuid),
  public.leave_group(uuid), public.rename_group(uuid, text), public.delete_group(uuid), public.mark_group_read(uuid),
  public.group_members_list(uuid), public.my_groups()
  to authenticated;

revoke execute on function public.group_messages_rate_limit(), public.blocks_remove_friendship()
  from public, anon, authenticated;
```

**Things to know before running it**
- `friendships.status` stays `pending` or `accepted`; a decline deletes the row, so the person can ask again (limit: 20 requests an hour). Persistent pests: Block, which also ends the friendship.
- The request limit counts rows that still exist, so send-cancel-send is not counted. If that becomes a problem, log requests in a small table like `deleted_rows`.
- Owner-only adding is a choice. To let any member add **their own** friends, change the first check in `add_group_member` to `public.is_group_member(gid)` (the friend check then uses the member, which it already does).
- Every function above is `security definer`; they all read `auth.uid()` and never trust an id passed in, except the other person's id, which is checked against friendships, blocks and group membership.
- Realtime DELETE events on `group_messages` are unfiltered (review finding M6): message ids only.


---

# Appendix D: migration 008, end-to-end encrypted chat (proposed, UNTESTED)

No Postgres was available, so none of this has run. **Merge-or-order rule:** run it **before** any real chat data exists (it drops the plain-text `body` columns and adds not-null ciphertext columns, which fail on filled tables). Order: 001 to 007, then this. It replaces `inbox()` and `mark_read()` from 002 and `my_groups()` from 007. Save as `supabase/migrations/008_e2e_chat.sql`. The server never sees a key or a message in clear: every function below handles ciphertext, ids and public keys only.

```sql
-- 008: end-to-end encrypted chat. UNTESTED. Needs 001 to 007.

-- ---------- public keys (one phone per account) ----------
create table public.device_keys (
  user_id    uuid primary key references public.profiles (id) on delete cascade,
  public_key text not null check (char_length(public_key) = 44),   -- base64 of a 32-byte key
  changed_at timestamptz not null default now()
);
alter table public.device_keys enable row level security;
create policy device_keys_read   on public.device_keys for select to authenticated using (public.is_member());
create policy device_keys_insert on public.device_keys for insert to authenticated
  with check (user_id = auth.uid() and public.is_member());
create policy device_keys_update on public.device_keys for update to authenticated
  using (user_id = auth.uid()) with check (user_id = auth.uid());

create function public.device_keys_touch() returns trigger language plpgsql as $$
begin
  if new.public_key is distinct from old.public_key then new.changed_at := now(); end if;
  return new;
end $$;
create trigger device_keys_touch_before_update before update on public.device_keys
for each row execute function public.device_keys_touch();

-- ---------- direct messages become ciphertext ----------
drop function public.inbox();
drop function public.mark_read(uuid);
alter table public.messages drop column body;
alter table public.messages drop column read_at;                    -- no server-side read receipts
alter table public.messages
  add column ciphertext      text not null check (char_length(ciphertext) between 1 and 6000),
  add column nonce           text not null check (char_length(nonce) = 32),
  add column attachment_path text check (attachment_path is null or char_length(attachment_path) <= 200);

-- the recipient removes a message once their phone has it (the sender can already unsend: messages_delete_own)
create policy messages_delete_recipient on public.messages for delete to authenticated
  using (recipient_id = auth.uid());

-- photos and videos in direct chats: friends only, and only from your own folder
create function public.messages_attachment_check() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if new.attachment_path is not null then
    if not public.are_friends(new.sender_id, new.recipient_id) then
      raise exception 'You can only send photos and videos to friends.';
    end if;
    if new.attachment_path not like new.sender_id::text || '/%' then
      raise exception 'That file is not yours.';
    end if;
  end if;
  return new;
end $$;
create trigger messages_attachment_check_before_insert before insert on public.messages
for each row execute function public.messages_attachment_check();

-- ---------- group messages become ciphertext ----------
alter table public.group_messages drop column body;
alter table public.group_messages
  add column ciphertext      text not null check (char_length(ciphertext) between 1 and 6000),
  add column nonce           text not null check (char_length(nonce) = 32),
  add column key_version     int  not null check (key_version >= 1),
  add column attachment_path text check (attachment_path is null or char_length(attachment_path) <= 200);

create function public.group_messages_attachment_check() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if new.attachment_path is not null and new.attachment_path not like new.sender_id::text || '/%' then
    raise exception 'That file is not yours.';
  end if;
  return new;
end $$;
create trigger group_messages_attachment_check_before_insert before insert on public.group_messages
for each row execute function public.group_messages_attachment_check();

-- who has confirmed which group message; the message is deleted when everyone else has
create table public.group_message_acks (
  message_id uuid not null references public.group_messages (id) on delete cascade,
  user_id    uuid not null references public.profiles (id) on delete cascade,
  primary key (message_id, user_id)
);
alter table public.group_message_acks enable row level security;     -- no policies: only the function below writes

create function public.ack_group_messages(gid uuid, ids uuid[]) returns void
language plpgsql security definer set search_path = public as $$
begin
  if not public.is_group_member(gid) then raise exception 'You are not in this group.'; end if;
  insert into public.group_message_acks (message_id, user_id)
    select gm.id, auth.uid() from public.group_messages gm where gm.group_id = gid and gm.id = any(ids)
  on conflict do nothing;
  delete from public.group_messages gm
   where gm.group_id = gid and gm.id = any(ids)
     and not exists (select 1 from public.group_members m
                      where m.group_id = gid and m.user_id is distinct from gm.sender_id
                        and not exists (select 1 from public.group_message_acks a
                                         where a.message_id = gm.id and a.user_id = m.user_id));
end $$;

-- ---------- group keys: each member only ever reads their own locked copy ----------
alter table public.chat_groups
  add column key_version int     not null default 0,
  add column keys_stale  boolean not null default true;

create table public.group_keys (
  group_id    uuid not null references public.chat_groups (id) on delete cascade,
  user_id     uuid not null references public.profiles (id) on delete cascade,
  key_version int  not null,
  wrapped_key text not null check (char_length(wrapped_key) between 40 and 400),
  wrapped_by  uuid references public.profiles (id) on delete set null,
  created_at  timestamptz not null default now(),
  primary key (group_id, user_id, key_version)
);
alter table public.group_keys enable row level security;
create policy group_keys_read_own on public.group_keys for select to authenticated using (user_id = auth.uid());

-- wrapped = { "<member uuid>": "<key locked for that member, base64>", ... }
create function public.publish_group_keys(gid uuid, version int, wrapped jsonb) returns void
language plpgsql security definer set search_path = public as $$
declare k record;
begin
  if not public.is_group_owner(gid) then raise exception 'Only the group owner can set the group key.'; end if;
  if version < 1 or version < (select key_version from public.chat_groups where id = gid) then
    raise exception 'That key version is old.';
  end if;
  for k in select j.key as uid, j.value as w from jsonb_each_text(wrapped) j loop
    if not exists (select 1 from public.group_members m where m.group_id = gid and m.user_id = k.uid::uuid) then
      raise exception 'That person is not in the group.';
    end if;
    insert into public.group_keys (group_id, user_id, key_version, wrapped_key, wrapped_by)
    values (gid, k.uid::uuid, version, k.w, auth.uid())
    on conflict (group_id, user_id, key_version) do update set wrapped_key = excluded.wrapped_key, wrapped_by = auth.uid();
  end loop;
  update public.chat_groups set key_version = version,
         keys_stale = exists (select 1 from public.group_members m
                              where m.group_id = gid
                                and not exists (select 1 from public.group_keys gk
                                                where gk.group_id = gid and gk.user_id = m.user_id and gk.key_version = version))
   where id = gid;
end $$;

-- someone left or was removed: their locked keys go, and the owner's phone must lock a new version for the rest
create function public.group_members_after_delete() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  delete from public.group_keys where group_id = old.group_id and user_id = old.user_id;
  update public.chat_groups set keys_stale = true where id = old.group_id;
  return old;
end $$;
create trigger group_members_after_delete_row after delete on public.group_members
for each row execute function public.group_members_after_delete();

-- the Groups list no longer shows a last line or unread count (the phone knows those)
drop function public.my_groups();
create function public.my_groups()
returns table (group_id uuid, name text, member_count bigint, my_role text, key_version int, keys_stale boolean)
language sql stable security definer set search_path = public as $$
  select g.id, g.name, (select count(*) from public.group_members x where x.group_id = g.id),
         m.role, g.key_version, g.keys_stale
  from public.group_members m
  join public.chat_groups g on g.id = m.group_id
  where m.user_id = auth.uid() and public.is_member()
  order by g.created_at desc
$$;

-- ---------- reports may carry the reporter's own excerpt ----------
alter table public.reports add column evidence text check (evidence is null or char_length(evidence) <= 4000);

-- ---------- temporary private bucket for encrypted files ----------
-- 25 MB to start; check your plan's limit. Files are ciphertext: the server cannot open them.
insert into storage.buckets (id, name, public, file_size_limit)
values ('chat_files', 'chat_files', false, 26214400)
on conflict (id) do nothing;

-- upload only into your own folder: <your user id>/<random name>
create policy chat_files_upload on storage.objects for insert to authenticated
  with check (bucket_id = 'chat_files' and public.is_member() and (storage.foldername(name))[1] = auth.uid()::text);

-- download: your own file, or a file that a message to you (or to a group you are in) points at
create policy chat_files_read on storage.objects for select to authenticated using (
  bucket_id = 'chat_files' and (
    (storage.foldername(name))[1] = auth.uid()::text
    or exists (select 1 from public.messages m where m.attachment_path = name and m.recipient_id = auth.uid())
    or exists (select 1 from public.group_messages g where g.attachment_path = name and public.is_group_member(g.group_id))
  )
);
-- No delete policy: the hourly Edge Function (service role) removes files that no message points at.
-- Deleting storage rows from SQL does not remove the file itself, so never rely on that.

-- ---------- who may call what ----------
revoke execute on function public.ack_group_messages(uuid, uuid[]), public.publish_group_keys(uuid, int, jsonb), public.my_groups()
  from public, anon;
grant  execute on function public.ack_group_messages(uuid, uuid[]), public.publish_group_keys(uuid, int, jsonb), public.my_groups()
  to authenticated;
revoke execute on function public.device_keys_touch(), public.messages_attachment_check(),
  public.group_messages_attachment_check(), public.group_members_after_delete()
  from public, anon, authenticated;
```

**Jobs to add (not SQL migrations)**
- **Nightly, 30 days:** `delete from public.messages where created_at < now() - interval '30 days'; delete from public.group_messages where created_at < now() - interval '30 days';` Use `pg_cron` if your plan lets you enable it (Dashboard, Integrations); otherwise a scheduled Edge Function with the service role.
- **Hourly, files:** Edge Function `purge_chat_files` (service role): list objects in `chat_files` older than **one hour**, delete every object whose name is not in `select attachment_path from messages union select attachment_path from group_messages`. The one-hour wait protects a file that is uploaded just before its message is sent.
- **`push_notify`:** drop `record.body`; send "New message" (direct) or the group name (group), `data` `{ type: 'message', with }` or `{ type: 'group', group_id }`; branch on `payload.table`, and for groups send to every member except the sender and anyone who blocked the sender.

**Tests (G60 and up)** are listed in section 7c. Also check: `select * from group_keys` as member A shows only A's own rows; a non-owner calling `publish_group_keys` is refused; `attachment_path` pointing into another person's folder is refused; a direct photo to a non-friend is refused.
