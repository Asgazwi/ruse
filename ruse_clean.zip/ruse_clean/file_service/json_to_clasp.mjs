// Turns ruse_file_service.json into a folder clasp can push. Nothing to edit by hand.
//   node json_to_clasp.mjs [scriptId] [path/to/app/.env]
// - Supabase URL and anon key are read from the .env (EXPO_PUBLIC_SUPABASE_URL / EXPO_PUBLIC_SUPABASE_ANON_KEY)
//   and written into config.gs. Both are public values. A service role key is refused.
// - Without a scriptId, run `clasp create --type standalone --title "RUSE file service" --rootDir .` in the folder first.
import fs from 'node:fs';
const script_id = process.argv[2] && !process.argv[2].includes('.env') ? process.argv[2] : '';
const env_path = process.argv.find(a => a.includes('.env')) || '.env';
let env = {};
if (fs.existsSync(env_path)) for (const line of fs.readFileSync(env_path, 'utf8').split(/\r?\n/)) { const m = line.match(/^\s*([A-Z0-9_]+)\s*=\s*(.*)\s*$/); if (m) env[m[1]] = m[2].replace(/^['"]|['"]$/g, ''); }
const url = env.EXPO_PUBLIC_SUPABASE_URL || '', key = env.EXPO_PUBLIC_SUPABASE_ANON_KEY || '';
if (/service_role/i.test(key) || (key.split('.')[1] && Buffer.from(key.split('.')[1], 'base64').toString().includes('service_role'))) { console.error('That key is a service role key. Use the anon key.'); process.exit(1); }
const proj = JSON.parse(fs.readFileSync(new URL('./ruse_file_service.json', import.meta.url), 'utf8'));
fs.mkdirSync('clasp_project', { recursive: true });
for (const f of proj.files) {
  let src = f.source;
  if (f.name === 'config') src = src.replace("{ SUPABASE_URL: '', SUPABASE_ANON_KEY: '' }", `{ SUPABASE_URL: ${JSON.stringify(url)}, SUPABASE_ANON_KEY: ${JSON.stringify(key)} }`);
  fs.writeFileSync(`clasp_project/${f.name}.${f.type === 'json' ? 'json' : 'gs'}`, src);
}
if (script_id) fs.writeFileSync('clasp_project/.clasp.json', JSON.stringify({ scriptId: script_id, rootDir: '.' }, null, 2));
console.log(`Wrote ${proj.files.length} files to clasp_project/` + (url && key ? ' (Supabase settings filled in)' : ' WARNING: no Supabase URL/key found in the .env yet'));
