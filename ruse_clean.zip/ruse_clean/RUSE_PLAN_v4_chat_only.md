# RUSE plan v4: chat-only first

Replaces the scope of `RUSE_PLAN_v3-1.md` (kept in `archive/`). Idea: ship **sign-in, profiles, access and plain-text chat** on Supabase. If it works, add the rest (and later your own VPS database).

**Status: nothing here has run on a real Postgres. The SQL was written by reading, not executing.**

## In scope
- Migrations `001` people and access, `002` chat, `003` guards and helpers (`supabase/migrations/`, also joined as `supabase/ruse_chat_all.sql`)
- File service (`file_service/`) only for `saveAvatar`; it can wait
- Plain-text chat, 500 characters, messages deleted after 30 days

## Parked (see archive/RUSE_PLAN_v3-1.md)
Catalog, comments and pins, themes, progress, import scripts, friends and groups (Appendix C), end-to-end encrypted chat (Appendix D), the second pass fixes for those tables.
The old Apps Script backend keeps serving everything that is parked.

## Fixes folded into the SQL (from the 7 Nov review)
| Finding | Fix |
|---|---|
| H2 admin "messages off" only stopped receiving | `profiles.messaging_banned` (admin only), checked on the **sender** in `can_message()` |
| H5 last admin | trigger `profiles_keep_one_admin`; SQL Editor / service role stay free |
| M1 avatar link can point anywhere | check constraint, Google image hosts only (**check the old stored format first**) |
| M2 migrated users treated as new | `invited_users.added_at`, copied into the profile |
| L1 invitation username collides | `handle_new_user` falls back to no username instead of blocking sign-in |
| New: 30-day username wait bypass | `profiles_guard` now forces `username_changed_at` back when the name did not change |
| New: waiting accounts | `mark_read` and `register_push_token` need an approved account |
| 30-day retention | `purge_old_messages()`; schedule nightly with pg_cron or an Edge Function |

## Decisions made
1. Messages off: separate admin flag (`messaging_banned`), person's own `messaging_off` stays.
2. Chat is plain text for now. Encryption is parked.
3. Last-admin guard yes; no separate "main admin".
4. Keep all database calls in `lib/sb/` (one function per file) so the backend can move to a VPS later.

## Order of work
1. [ ] Throwaway database: run `001`, `002`, `003` in order (Supabase local, or a second empty project). Fix every error before going on.
2. [ ] Run the tests: `supabase/tests/rls_chat.sql` (first admin, can_message / block / ban, rate limit, username rules, last-admin guard, avatar host, purge, inbox shape).
3. [ ] Look at what the old backend stored in `avatar_url`; adjust the host list in `003` if needed.
4. [ ] Create the real Supabase project, push the three migrations, set up Google sign-in, fill `app/.env` (steps in archive plan, section 5).
5. [ ] First admin: `insert into public.invited_users (email, role) values ('<your email, lowercase>', 'admin');` then sign in.
6. [ ] App: install packages, `lib/supabase.ts`, then handlers in `lib/sb/` for: getMe, getProfile, saveProfile, saveUsername, setMessaging, checkUsername, requestRole, admin actions, getThreads, getMessages, sendMessage, deleteMessage, markRead, block / unblock, reports, push token. Add each name to `MOVED` only after its phone test.
7. [ ] Map error code `42501` to one friendly line ("blocked" and "off" look the same to the sender).
8. [ ] Deploy the file service only when you want avatars (`node json_to_clasp.mjs app/.env`, then clasp, archive plan section 5b).
9. [ ] Nightly purge job for `purge_old_messages()`.

## Handler rules worth remembering (from the review)
- `removeUser`: delete the invitation too, set `request_status = 'rejected'`, and show invited-only people in the admin list.
- Approving a role request must clear `role_request`.
- Realtime DELETE events are not filtered by RLS: fine while the app is small.
- Never `select *` from `profiles` in the reader app; use `public_profiles` for other people.

## Not done in this zip
- App code / handlers in `lib/sb/`, Edge Function `push_notify`, import scripts.
- Real Postgres run of the migrations + tests (still untested).
